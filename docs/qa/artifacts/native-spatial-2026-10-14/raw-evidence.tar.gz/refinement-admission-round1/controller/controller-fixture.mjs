// fixture:native-spatial-layout
var nativeSpatialCountPairs = () => [{ holes: 2, solids: 1 }];
var createNativeSpatialLayout = (...args) => globalThis.__routeControllerFixture.plan(...args);

// fixture:native-spatial-geometry
var buildNativeSpatialGeometry = (definition) => globalThis.__routeControllerFixture.geometry(definition);
var createNativeSpatialActualVoidFeedback = () => ({ feedback: { holes: [] } });

// fixture:native-spatial-measure
var identifyNativeSpatialStructures = () => ({ structures: [] });
var evaluateNativeSpatialGeometry = () => globalThis.__routeControllerFixture.ground;

// fixture:native-spatial-visibility
var evaluateNativeSpatialVisibility = () => ({ accepted: true, reasons: [], metrics: {} });

// fixture:native-spatial-route-feedback
var evaluateNativeSpatialRouteProbe = (probe, geometry, ...rest) => globalThis.__routeControllerFixture.route(probe, geometry);

// src/generation/seed-fork.ts
function mix32(seed, label) {
  let h = seed >>> 0;
  for (let i = 0; i < label.length; i++) {
    h = Math.imul(h ^ label.charCodeAt(i), 2654435769);
  }
  h ^= h >>> 16;
  h = Math.imul(h, 2146121005);
  h ^= h >>> 15;
  return h >>> 0;
}

// src/generation/world-study/native-spatial-types.ts
var NativeSpatialGeometryWorkBudgetError = class extends Error {
  constructor() {
    super("Native geometry work budget exhausted before compilation");
    this.name = "NativeSpatialGeometryWorkBudgetError";
  }
};

// src/generation/world-study/native-spatial-generation.ts
function nativeSpatialLayoutFailureContext(error) {
  if (!(error instanceof Error)) return {};
  const context = error;
  return { ...context.initialPlacement ? { initialPlacement: structuredClone(context.initialPlacement) } : {}, ...context.qualification ? { qualification: structuredClone(context.qualification) } : {} };
}
function createNativeSpatialGeometryWorkBudget(attempt, limit, checkpoint) {
  if (!Number.isSafeInteger(limit) || limit < 1) throw new Error("Invalid native geometry work budget");
  attempt.geometryWorkBudget = limit;
  attempt.finalGeometryEvaluations ??= 0;
  attempt.geometryWork ??= [];
  return { checkpoint, run(request, work) {
    checkpoint();
    if (attempt.geometryEvaluations >= limit) {
      attempt.stopReason = "geometry-work-budget";
      throw new NativeSpatialGeometryWorkBudgetError();
    }
    const started = performance.now(), measurementCount = attempt.finalGeometryEvaluations;
    const trace = { ...request, ...request.site ? { site: { ...request.site } } : {}, ordinal: ++attempt.geometryEvaluations, outcome: "running", elapsedMs: 0, reasons: [] };
    attempt.geometryWork.push(trace);
    try {
      const result = work();
      trace.outcome = result.accepted ? "accepted" : "rejected";
      trace.reasons = [...result.reasons];
      if (result.invalidHoleIds) trace.invalidHoleIds = [...result.invalidHoleIds];
      return result;
    } catch (error) {
      trace.outcome = "exception";
      trace.error = error instanceof Error ? error.message : String(error);
      throw error;
    } finally {
      trace.elapsedMs = performance.now() - started;
      if (request.kind === "final-geometry") trace.finalMeasurementStarted = attempt.finalGeometryEvaluations > measurementCount;
      try {
        checkpoint();
      } catch (error) {
        trace.deadlineExceeded = true;
        throw error;
      }
    }
  } };
}
function nativeSpatialRefinementAdmission(gate, actualVoid) {
  const reasons = gate.reasons.filter((reason) => reason.startsWith("hole-profile-") || reason.startsWith("bay-") || reason === "ineffective-spatial-objects" || reason === "final-source-footprint-unsupported");
  const metrics = gate.metrics;
  if (!actualVoid.available) reasons.push(actualVoid.reason ?? "actual-void-feedback-unavailable");
  if (typeof metrics.holeProfileViolationCount === "number" && metrics.holeProfileViolationCount > 0) reasons.push("invalid-final-hole-profile");
  if (Array.isArray(metrics.rejectedObjects) && metrics.rejectedObjects.length) reasons.push("ineffective-spatial-objects");
  if (typeof metrics.finalSourceSupportViolationCount === "number" && metrics.finalSourceSupportViolationCount > 0) reasons.push("final-source-footprint-unsupported");
  if (typeof metrics.bayViolationCount === "number" && metrics.bayViolationCount > 0) reasons.push("invalid-fixed-bay");
  return { accepted: reasons.length === 0, reasons: [...new Set(reasons)] };
}
var MAX_STAGNANT_REFINEMENTS = 4;
var routeOrGeometryViolations = (feedback, policy) => feedback.routeFeedback?.violations ?? geometryViolationVector(feedback.gate, policy);
var exhausted = (state) => !!state.domainExhausted || (state.routeStage ? state.refinements >= 48 : state.stagnantRefinements >= MAX_STAGNANT_REFINEMENTS);
function nativeSpatialGeometryFingerprint(geometry, layout) {
  const { terrain } = geometry;
  const canonical = JSON.stringify({
    cols: terrain.cols,
    rows: terrain.rows,
    matter: Array.from(terrain.matter),
    reachable: Array.from(geometry.reachable),
    meshes: terrain.meshes.map((mesh) => ({ seed: mesh.spec.seed, role: terrain.roles.get(mesh.spec.id), positions: Array.from(mesh.positions), indices: Array.from(mesh.indices) })),
    outline: terrain.definition.terrainOutline,
    erosion: terrain.definition.erosion,
    assemblies: layout.assemblies,
    holes: layout.holes,
    bays: layout.bays,
    landJoins: layout.landJoins
  });
  let a = 2166136261, b = 2654435769;
  for (let i = 0; i < canonical.length; i++) {
    const code = canonical.charCodeAt(i);
    a = Math.imul(a ^ code, 16777619);
    b = Math.imul(b ^ code, 2246822519);
  }
  return { hash: (a >>> 0).toString(16).padStart(8, "0") + (b >>> 0).toString(16).padStart(8, "0"), canonical };
}
function geometryViolationVector(gate, policy) {
  const m = gate.metrics, number = (key) => typeof m[key] === "number" ? m[key] : Infinity;
  const excess = (value, limit) => Math.max(0, value - limit) / Math.max(1e-9, Math.abs(limit));
  const shortfall = (value, minimum) => Math.max(0, minimum - value) / Math.max(1e-9, Math.abs(minimum));
  const holes = number("holes"), solids = number("solids"), total = holes + solids;
  const ratioTolerance = Math.max(policy.holeCountAbsTolerance, policy.holeCountRelTolerance * solids);
  return [
    shortfall(total, number("minCount")),
    excess(total, number("maxCount")),
    Array.isArray(m.rejectedObjects) ? m.rejectedObjects.length / Math.max(1, number("targetCount")) : Infinity,
    shortfall(number("reachableBodySeats"), number("supportedBodySeats")),
    excess(Math.abs(number("walkAreaPx2") / number("targetWalkAreaPx2") - 1), policy.areaToleranceRatio),
    shortfall(solids, policy.minSolidCount),
    policy.requireMoreHoles && holes <= solids ? 1 : 0,
    excess(Math.abs(holes - policy.holeToSolidRatio * solids), ratioTolerance),
    typeof m.holeProfileViolationCount === "number" ? m.holeProfileViolationCount / Math.max(1, holes) : 0,
    typeof m.bayViolationCount === "number" ? m.bayViolationCount / Math.max(1, Number(m.bayCount) || 0) : 0,
    typeof m.finalSourceSupportViolationCount === "number" ? m.finalSourceSupportViolationCount / Math.max(1, solids) : 0,
    excess(number("maxEmptyUpperPx"), policy.maxEmptyRadiusPx),
    excess(number("maxDeepSpanPx"), policy.maxDeepEmptySpanPx),
    shortfall(number("wideRatio"), policy.minWideRatio),
    shortfall(number("largestWideRatio"), policy.minLargestWideRatio)
  ];
}
var compareFeedback = (a, b) => a.maximum - b.maximum || a.sum - b.sum || a.layout.candidate - b.layout.candidate;
var NativeSpatialGeometryArchive = class {
  constructor(policy) {
    this.policy = policy;
  }
  candidates = [];
  incumbent;
  states = /* @__PURE__ */ new Map();
  // Stage resets discard incomparable work fronts, not an already consumed
  // joint operation on exactly the same geometry in this generation attempt.
  jointClaims = /* @__PURE__ */ new Set();
  retired = [];
  clear() {
    this.retired.push(...this.currentHistory());
    this.candidates = [];
    this.incumbent = void 0;
    this.states.clear();
  }
  offer(layout, gate, fingerprint, actualVoid, routeFeedback, admission) {
    if (routeFeedback && !routeFeedback.comparable) throw new Error("Incomparable route probe cannot enter native feedback archive");
    if (this.states.has(fingerprint.canonical)) return this.incumbent;
    this.states.set(fingerprint.canonical, { firstCandidate: layout.candidate, geometryHash: fingerprint.hash, refinements: 0, stagnantRefinements: 0, singleScanStagnant: false, jointAttempted: this.jointClaims.has(fingerprint.canonical), refinable: admission?.accepted ?? true, refinementRejectionReasons: admission ? [...admission.reasons] : [], ...routeFeedback ? { routeStage: true } : {} });
    const feedback = { layout, gate, fingerprint, actualVoid, routeFeedback }, violations = routeOrGeometryViolations(feedback, this.policy), entry = { ...feedback, violations, maximum: Math.max(...violations), sum: violations.reduce((a, b) => a + b, 0) };
    if (!this.incumbent || compareFeedback(entry, this.incumbent) < 0) this.incumbent = entry;
    if (admission && !admission.accepted) return this.incumbent;
    const dominates = (a, b) => a.violations.every((v, i) => v <= b.violations[i]) && a.violations.some((v, i) => v < b.violations[i]);
    if (!this.candidates.some((existing) => dominates(existing, entry))) {
      this.candidates = this.candidates.filter((existing) => !dominates(entry, existing));
      this.candidates.push(entry);
    }
    const compare = compareFeedback;
    this.candidates.sort(compare);
    if (this.candidates.length > 4) {
      const best = this.candidates[0], kept = /* @__PURE__ */ new Set([best]);
      const extremes = best.violations.map((value, axis) => {
        const extreme = [...this.candidates].sort((a, b) => a.violations[axis] - b.violations[axis] || compare(a, b))[0];
        return { extreme, gain: value - extreme.violations[axis], axis };
      }).filter((row) => row.gain > 0).sort((a, b) => b.gain - a.gain || compare(a.extreme, b.extreme) || a.axis - b.axis);
      for (const row of extremes) {
        if (kept.size === 4) break;
        kept.add(row.extreme);
      }
      for (const entry2 of this.candidates) {
        if (kept.size === 4) break;
        kept.add(entry2);
      }
      this.candidates = [...kept].sort(compare);
    }
    return this.incumbent;
  }
  recordRefinement(base, result) {
    const state = this.states.get(base.fingerprint.canonical);
    if (!state) throw new Error("Native refinement has no measured base history");
    const refinement = result?.layout.plan?.refinement;
    if (refinement?.kind === "single") state.singleScanStagnant = !refinement.constraintsImproved;
    const next = result ? this.candidates.find((entry) => entry.layout.candidate === result.layout.candidate) : void 0;
    const old = routeOrGeometryViolations(base, this.policy), maximum = Math.max(...old), sum = old.reduce((a, b) => a + b, 0);
    const improved = !!next && next.fingerprint.canonical !== base.fingerprint.canonical && (next.maximum < maximum || next.maximum === maximum && next.sum < sum);
    state.refinements++;
    state.stagnantRefinements = improved ? 0 : state.stagnantRefinements + 1;
    if (result) {
      state.lastResultCandidate = result.layout.candidate;
      state.lastResultGeometryHash = result.fingerprint.hash;
    }
    this.candidates = this.candidates.filter((entry) => !exhausted(this.states.get(entry.fingerprint.canonical)));
  }
  retire(base) {
    const state = this.states.get(base.fingerprint.canonical);
    if (!state) throw new Error("Native retirement has no measured base");
    state.domainExhausted = true;
    this.candidates = this.candidates.filter((entry) => entry.fingerprint.canonical !== base.fingerprint.canonical);
  }
  advanceRouteDomain(base, nextOrdinal, seenTupleKeys) {
    const state = this.states.get(base.fingerprint.canonical);
    if (!state || !state.routeStage || !Number.isSafeInteger(nextOrdinal) || nextOrdinal < (state.routeTupleCursor ?? 0) || nextOrdinal > 48) throw new Error("Invalid native route tuple cursor");
    state.routeTupleCursor = nextOrdinal;
    state.routeSeenTupleKeys = [...seenTupleKeys];
  }
  /** Claim before entering the sampler: failure or an exception still consumes
   * this immutable geometry's one joint candidate set. This does not alter the
   * existing refinement/progress budget or grant an exhausted base more work. */
  claimJoint(base) {
    const state = this.states.get(base.fingerprint.canonical);
    if (!state) throw new Error("Native joint refinement has no measured base history");
    if (base.routeFeedback || !state.singleScanStagnant || state.jointAttempted || state.stagnantRefinements >= MAX_STAGNANT_REFINEMENTS || !base.actualVoid || !base.gate.reasons.some((reason) => reason.startsWith("G1-") || reason.startsWith("G3-"))) return false;
    state.jointAttempted = true;
    this.jointClaims.add(base.fingerprint.canonical);
    return true;
  }
  firstCandidate(fingerprint) {
    return this.states.get(fingerprint.canonical)?.firstCandidate;
  }
  currentHistory() {
    return [...this.states.values()].map((state) => ({ ...state, exhausted: exhausted(state) }));
  }
  get baseHistory() {
    return [...this.retired, ...this.currentHistory()];
  }
  get candidateIds() {
    return this.candidates.map((entry) => entry.layout.candidate);
  }
  get best() {
    return this.incumbent;
  }
  get nextBase() {
    const entry = this.candidates.find((value) => !exhausted(this.states.get(value.fingerprint.canonical)));
    if (!entry) return void 0;
    return entry.routeFeedback ? { ...entry, routeFeedback: { ...entry.routeFeedback, refinementOrdinal: this.states.get(entry.fingerprint.canonical).routeTupleCursor ?? 0, seenTupleKeys: this.states.get(entry.fingerprint.canonical).routeSeenTupleKeys ?? [] } } : entry;
  }
};
function* createNativeSpatialGeometryCandidates(native, input, requestedSeed, geometrySeed, attempt, checkpoint, onMeasured) {
  const archive = new NativeSpatialGeometryArchive(input.policy);
  const geometryWork = createNativeSpatialGeometryWorkBudget(attempt, input.policy.maxGeometryEvaluations, checkpoint);
  const pairs = nativeSpatialCountPairs(input);
  if (!pairs.length) throw new Error("Native spatial intent has no legal whole-layout count pair");
  const domains = pairs.flatMap((_, countPairIndex) => input.world.bayCountOptions.map((_2, bayCountIndex) => ({ countPairIndex, bayCountIndex })));
  if (domains.length > input.policy.maxGeometryEvaluations) throw new Error("Count-pair / bay probe domain exceeds the bounded proposal budget");
  let initialDomain = 0, explorationDomain = 0;
  let routeEpoch;
  for (let candidate = 0; candidate < input.policy.maxGeometryEvaluations; candidate++) {
    checkpoint();
    if (attempt.geometryEvaluations >= input.policy.maxGeometryEvaluations) {
      attempt.stopReason = "geometry-work-budget";
      return;
    }
    if (routeEpoch && routeEpoch.consumedTuples >= routeEpoch.tupleLimit) {
      routeEpoch.ended = "tuple-budget";
      archive.clear();
      routeEpoch = void 0;
    }
    const nextBase = archive.nextBase;
    if (!nextBase && archive.best?.routeFeedback) {
      if (routeEpoch) routeEpoch.ended = "domain-exhausted";
      routeEpoch = void 0;
      archive.clear();
    }
    const fresh = !nextBase || !nextBase.routeFeedback && initialDomain < domains.length;
    const previous = fresh ? void 0 : nextBase?.routeFeedback ? { ...nextBase, routeFeedback: { ...nextBase.routeFeedback, remainingTupleBudget: routeEpoch.tupleLimit - routeEpoch.consumedTuples } } : nextBase;
    const { countPairIndex, bayCountIndex } = fresh ? domains[initialDomain < domains.length ? initialDomain++ : explorationDomain++ % domains.length] : { countPairIndex: previous.layout.countPairIndex, bayCountIndex: previous.layout.bayCountIndex };
    if (!pairs[countPairIndex] || input.world.bayCountOptions[bayCountIndex] === void 0) throw new Error("Archived native plan no longer belongs to its frozen count / bay domain");
    const requestedBayCount = input.world.bayCountOptions[bayCountIndex];
    const proposalKind = fresh ? "fresh" : "refinement";
    const feedbackBaseCandidate = previous?.layout.candidate;
    const feedbackBaseHash = previous?.fingerprint.hash;
    checkpoint();
    let layout;
    attempt.layoutProposals++;
    const jointAllowed = previous ? archive.claimJoint(previous) : false;
    attempt.feedbackBases = archive.baseHistory;
    let routeTrialsCharged = false;
    const chargeRouteTrials = (value) => {
      if (!previous?.routeFeedback || routeTrialsCharged) return;
      if (!value || typeof value !== "object" || !("consumedTuples" in value) || !("nextOrdinal" in value) || !("seenTupleKeys" in value)) throw new Error("Native route placement omitted its tuple ledger");
      const consumed = value.consumedTuples, next = value.nextOrdinal, seen = value.seenTupleKeys, old = previous.routeFeedback.seenTupleKeys;
      if (!routeEpoch || typeof consumed !== "number" || !Number.isSafeInteger(consumed) || consumed < 0 || consumed > routeEpoch.tupleLimit - routeEpoch.consumedTuples || typeof next !== "number" || !Array.isArray(seen) || seen.some((key) => typeof key !== "string") || new Set(seen).size !== seen.length || consumed !== seen.length - old.length || old.some((key, i) => key !== seen[i]))
        throw new Error("Native route placement exceeded its shared tuple budget");
      routeEpoch.consumedTuples += consumed;
      archive.advanceRouteDomain(previous, next, seen);
      routeTrialsCharged = true;
    };
    try {
      const measured = geometryWork.run({ kind: "final-geometry", candidate }, () => {
        let proposal;
        try {
          proposal = createNativeSpatialLayout(native, input, requestedSeed, geometrySeed, candidate, previous ? { ...previous, allowJoint: jointAllowed } : void 0, countPairIndex, bayCountIndex, geometryWork);
        } catch (error) {
          if (error && typeof error === "object" && "routeRefinement" in error) chargeRouteTrials(error.routeRefinement);
          throw error;
        }
        if (previous?.routeFeedback) chargeRouteTrials(proposal.plan.refinement?.route);
        layout = proposal;
        checkpoint();
        attempt.finalGeometryEvaluations++;
        const geometry2 = buildNativeSpatialGeometry(proposal.definition, geometrySeed), groups2 = identifyNativeSpatialStructures(geometry2, proposal.assemblies, input.policy);
        const fingerprint2 = nativeSpatialGeometryFingerprint(geometry2, proposal);
        const ground2 = evaluateNativeSpatialGeometry(
          geometry2,
          groups2,
          input.policy,
          input.world,
          { placements: proposal.holes, profiles: input.holeProfiles },
          { landRects: proposal.plan.land, placements: proposal.bays, landJoins: proposal.landJoins, profiles: input.bayProfiles, allowedCounts: input.world.bayCountOptions, minWideJoinPx: input.world.landRectMinOverlapPx }
        );
        if (onMeasured) onMeasured(structuredClone({ layout: proposal, gate: ground2, geometryHash: fingerprint2.hash }));
        const actualVoid2 = createNativeSpatialActualVoidFeedback(geometry2, groups2, proposal.holes);
        return { accepted: ground2.accepted, reasons: ground2.reasons, layout: proposal, geometry: geometry2, groups: groups2, fingerprint: fingerprint2, ground: ground2, actualVoid: actualVoid2 };
      });
      layout = measured.layout;
      const { geometry, groups, fingerprint, ground, actualVoid } = measured, duplicateOfCandidate = archive.firstCandidate(fingerprint);
      const actualVoidFeedback = { available: !!actualVoid.feedback, ...actualVoid.reason ? { reason: actualVoid.reason } : {}, holeCount: actualVoid.feedback?.holes.length ?? 0 };
      const refinementAdmission = nativeSpatialRefinementAdmission(ground, actualVoidFeedback);
      const gates = { geometry: ground };
      if (ground.accepted) {
        checkpoint();
        gates.visibility = evaluateNativeSpatialVisibility(geometry, groups.structures, input.policy);
      }
      let routeFeedback;
      if (previous?.routeFeedback && ground.accepted && gates.visibility?.accepted) {
        routeEpoch.probeEvaluations++;
        routeFeedback = evaluateNativeSpatialRouteProbe(previous.routeFeedback.probe, geometry, groups, ground, input.policy, checkpoint);
        gates.routeProbe = routeFeedback.gate;
      }
      const reasons = [...Object.values(gates).flatMap((gate) => gate.reasons), ...routeFeedback?.comparabilityReasons.map((reason) => `route-probe:${reason}`) ?? []], accepted = !reasons.length;
      if (previous?.routeFeedback) {
        if (routeFeedback?.comparable) archive.offer(layout, ground, fingerprint, actualVoid.feedback, routeFeedback, refinementAdmission);
        archive.recordRefinement(previous, routeFeedback?.comparable ? { layout, gate: ground, fingerprint, actualVoid: actualVoid.feedback, routeFeedback } : void 0);
      } else if (ground.accepted) {
        archive.clear();
      } else {
        archive.offer(layout, ground, fingerprint, actualVoid.feedback, void 0, refinementAdmission);
        if (previous) archive.recordRefinement(previous, { layout, gate: ground, fingerprint, actualVoid: actualVoid.feedback });
      }
      attempt.feedbackBases = archive.baseHistory;
      const trace = {
        candidate,
        geometrySeed,
        layoutSeed: layout.layoutSeed,
        geometryHash: fingerprint.hash,
        actualVoidFeedback,
        jointAllowed,
        ...routeFeedback ? { routeProbe: {
          sourceCandidate: routeFeedback.probe.sourceCandidate,
          sourceGeometryHash: routeFeedback.probe.sourceGeometryHash,
          refinementOrdinal: previous.routeFeedback.refinementOrdinal,
          comparable: routeFeedback.comparable,
          comparabilityReasons: routeFeedback.comparabilityReasons,
          violations: routeFeedback.violations,
          maximum: Number.isFinite(routeFeedback.maximum) ? routeFeedback.maximum : null,
          sum: Number.isFinite(routeFeedback.sum) ? routeFeedback.sum : null,
          witnessCount: routeFeedback.witnesses.length
        } } : {},
        ...duplicateOfCandidate === void 0 ? {} : { duplicateOfCandidate },
        proposalKind,
        countPairIndex,
        bayCountIndex,
        requestedBayCount,
        ...feedbackBaseCandidate === void 0 ? {} : { feedbackBaseCandidate, feedbackBaseHash },
        feedbackArchiveCandidates: archive.candidateIds,
        feedbackBestCandidate: archive.best?.layout.candidate,
        requestedCounts: layout.requestedCounts,
        accepted,
        reasons,
        gates
      };
      attempt.candidates.push(trace);
      checkpoint();
      if (accepted) {
        const feedback = yield { layout, geometry, groups, trace };
        if (feedback) {
          const probe = feedback.probe;
          if (probe.geometrySeed !== geometrySeed || probe.sourceCandidate !== candidate || probe.sourceGeometryHash !== fingerprint.hash)
            throw new Error("Native full route feedback does not belong to the yielded candidate");
          if (feedback.gate.accepted || !feedback.comparable) throw new Error("Native full route feedback requires a comparable failed family");
          if (routeEpoch) routeEpoch.ended = "new-full-feedback";
          routeEpoch = { sourceCandidate: probe.sourceCandidate, sourceGeometryHash: probe.sourceGeometryHash, tupleLimit: 48, consumedTuples: 0, probeEvaluations: 0 };
          (attempt.routeEpochs ??= []).push(routeEpoch);
          archive.clear();
          archive.offer(layout, ground, fingerprint, actualVoid.feedback, feedback, refinementAdmission);
          attempt.feedbackBases = archive.baseHistory;
        }
      }
    } catch (error) {
      const reason = error instanceof Error ? error.message : String(error);
      const routeRefinement = error && typeof error === "object" && "routeRefinement" in error ? error.routeRefinement : void 0;
      if (routeRefinement) chargeRouteTrials(routeRefinement);
      if (attempt.stopReason === "deadline") throw error;
      if (previous) {
        archive.recordRefinement(previous);
        if (previous.routeFeedback && error && typeof error === "object" && "routeRefinement" in error && error.routeRefinement && typeof error.routeRefinement === "object" && "exhausted" in error.routeRefinement && error.routeRefinement.exhausted === true) archive.retire(previous);
      }
      attempt.feedbackBases = archive.baseHistory;
      const layoutSeed = layout?.layoutSeed ?? mix32(requestedSeed, `${input.policy.algorithm}:${input.policy.version}:${input.policy.sourceHash}:${input.world.worldId}:${geometrySeed}:${candidate}`);
      attempt.candidates.push({ candidate, geometrySeed, layoutSeed, jointAllowed, proposalKind, countPairIndex, bayCountIndex, requestedBayCount, ...nativeSpatialLayoutFailureContext(error), ...feedbackBaseCandidate === void 0 ? {} : { feedbackBaseCandidate, feedbackBaseHash }, feedbackArchiveCandidates: archive.candidateIds, feedbackBestCandidate: archive.best?.layout.candidate, requestedCounts: layout?.requestedCounts ?? pairs[countPairIndex], accepted: false, reasons: [reason], gates: routeRefinement ? { routePlanning: { accepted: false, reasons: [reason], metrics: { refinement: routeRefinement } } } : {} });
      if (attempt.stopReason === "geometry-work-budget") return;
    }
  }
  attempt.stopReason = attempt.geometryEvaluations >= input.policy.maxGeometryEvaluations ? "geometry-work-budget" : "proposal-budget";
}
export {
  NativeSpatialGeometryArchive,
  createNativeSpatialGeometryCandidates,
  createNativeSpatialGeometryWorkBudget,
  nativeSpatialGeometryFingerprint,
  nativeSpatialLayoutFailureContext,
  nativeSpatialRefinementAdmission
};
