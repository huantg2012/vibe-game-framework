// src/generation/seed-fork.ts
function mix32(seed2, label) {
  let h = seed2 >>> 0;
  for (let i = 0; i < label.length; i++) {
    h = Math.imul(h ^ label.charCodeAt(i), 2654435769);
  }
  h ^= h >>> 16;
  h = Math.imul(h, 2146121005);
  h ^= h >>> 15;
  return h >>> 0;
}

// src/generation/world-study/native-volume-cellular.ts
var TAU = Math.PI * 2;
var uv = (point) => [point[0], point[1]];
var lerp = (a, b, t) => a + (b - a) * t;
function variation(seed2, salt) {
  let value = Math.imul(seed2 ^ salt, 73244475);
  value = Math.imul(value ^ value >>> 16, 73244475);
  return ((value ^ value >>> 16) >>> 0) / 4294967296;
}
function buildCellularShell(builder) {
  const spec = builder.spec, count = Math.min(4, Math.max(2, spec.branches));
  for (let cell = 0; cell < count; cell++) {
    const scale = cell % 3 === 0 ? 1.25 : cell % 3 === 1 ? 0.91 : 0.9;
    const rx = spec.length / count * 0.45 * scale;
    const ry = spec.width * (cell % 3 === 0 ? 0.38 : cell % 3 === 1 ? 0.23 : 0.29);
    const ox = ((cell + 0.5) / count - 0.5) * spec.length;
    const oy = (cell % 2 ? -0.15 : 0.1) * spec.width;
    const opening = (cell % 2 ? -0.5 : 0.5) * Math.PI + (variation(spec.seed, 2700 + cell) - 0.5) * 0.27;
    const gap = 1.2 + spec.opening * 1.38 + (cell % 3 === 1 ? 0.9 : cell % 3 === 0 ? -0.26 : -0.43);
    const mouthBias = cell % 3 === 0 ? 0.32 : cell % 3 === 1 ? 0.62 : 0.38;
    const start = opening + gap * mouthBias, end = opening + TAU - gap * (1 - mouthBias);
    const steps = 48, rows = [];
    const phase2 = variation(spec.seed, 2730 + cell) * 0.6 + cell * 1.9;
    for (let index = 0; index <= steps; index++) {
      const t = index / steps, angle = lerp(start, end, t);
      const ca = Math.cos(angle), sa = Math.sin(angle);
      const shoulder = Math.pow(0.5 + 0.5 * Math.cos(angle - phase2), 3);
      const outerRadius = 0.94 + shoulder * (0.31 + spec.distortion * 0.13) + Math.sin(angle * 2 + phase2) * 0.085 + Math.sin(angle * 3 - phase2) * 0.045;
      const outerX = ox + rx * ca * outerRadius;
      const outerY = oy + ry * sa * outerRadius;
      const hollowRadius = 0.62 + 0.08 * Math.sin(angle + phase2 + 0.65) + 0.06 * Math.sin(angle * 2 - phase2) + 0.025 * Math.sin(angle * 3 - phase2);
      const innerX = ox + rx * 0.045 * Math.cos(phase2) + rx * ca * hollowRadius;
      const innerY = oy - ry * 0.055 * Math.sin(phase2) + ry * sa * (hollowRadius + 0.08);
      const seam = Math.pow(Math.abs(Math.sin(t * Math.PI)), 0.48);
      const tornLip = 0.29 + 0.71 * Math.min(1, t / (cell % 3 === 1 ? 0.43 : 0.29));
      const height = spec.height * (cell % 3 === 1 ? 0.48 : cell % 3 === 2 ? 0.79 : 1) * (0.39 + shoulder * 0.36 + seam * 0.22 + 0.1 * Math.sin(angle + phase2)) * tornLip;
      const foot = spec.blocking === 1 ? Math.min(8, height * 0.35) : 0;
      const point = (across, z) => [lerp(outerX, innerX, across), lerp(outerY, innerY, across), z];
      rows.push([
        point(0, 0),
        point(0.035, foot),
        point(0.16, height * 0.63),
        point(0.42 + shoulder * 0.08, height),
        point(0.79, height * (0.81 + shoulder * 0.08)),
        point(0.96, Math.max(foot, height * 0.22)),
        point(1, 0)
      ]);
    }
    for (let index = 0; index < steps; index++) {
      for (let across = 0; across < rows[index].length - 1; across++) {
        const a = rows[index][across], b = rows[index + 1][across];
        const c = rows[index + 1][across + 1], d = rows[index][across + 1];
        builder.quad(a, b, c, d, across < 4 ? 0 : 2, [uv(a), uv(b), uv(c), uv(d)], [0, 0, 1], across < 2 ? 1 : across < 4 ? 0 : 5);
        if (cell === 0 && index === Math.floor(steps * 0.47) && across === 3) {
          const onFace = (u, v) => [
            a[0] + (b[0] - a[0]) * u + (c[0] - a[0]) * v,
            a[1] + (b[1] - a[1]) * u + (c[1] - a[1]) * v,
            a[2] + (b[2] - a[2]) * u + (c[2] - a[2]) * v + 0.08
          ];
          const p = onFace(0.08, 0.12), q = onFace(0.57, 0.12), r = onFace(0.4, 0.4), s = onFace(0.08, 0.4);
          builder.quad(p, q, r, s, 3, [uv(p), uv(q), uv(r), uv(s)], [0, 0, 1], 3);
          builder.joint(onFace(0.28, 0.27));
        }
      }
    }
    for (const at of [0, steps]) {
      const row = rows[at], angle = at === 0 ? start : end, sign = at === 0 ? -1 : 1;
      for (let across = 0; across < row.length - 1; across++) {
        const a = row[across], b = row[across + 1];
        const run = Math.min(6, spec.thickness * 0.42) * (at === 0 ? 0.72 : 1.12);
        const dx = -Math.sin(angle) * run * sign, dy = Math.cos(angle) * run * sign;
        const c = [b[0] + dx, b[1] + dy, 0], d = [a[0] + dx, a[1] + dy, 0];
        builder.quad(a, b, c, d, 1, [uv(a), uv(b), uv(c), uv(d)], [0, 0, 1], 3);
      }
    }
  }
}

// src/generation/world-study/native-volume-pleated-tear.ts
var uv2 = (p) => [p[0], p[1]];
var EPSILON = 1e-7;
function createPleatedTear(builder, centre, tangent) {
  const magnitude = Math.hypot(...tangent);
  if (magnitude < EPSILON) throw new Error("Pleated tear needs a real surface direction");
  const direction = [tangent[0] / magnitude, tangent[1] / magnitude];
  const normal = [-direction[1], direction[0]];
  const length2 = Math.min(12, builder.spec.length * 0.15, builder.spec.width * 0.15);
  const halfWidth = Math.min(1.3, length2 * 0.11), depth = Math.min(1.4, builder.spec.height * 0.06);
  const local = (p, axis) => {
    const basis = axis === 0 ? direction : normal;
    return (p[0] - centre[0]) * basis[0] + (p[1] - centre[1]) * basis[1];
  };
  const planes = [
    { axis: 0, limit: -length2 / 2, greater: true },
    { axis: 0, limit: length2 / 2, greater: false },
    { axis: 1, limit: -halfWidth, greater: true },
    { axis: 1, limit: halfWidth, greater: false }
  ];
  const clip2 = (polygon2, plane) => {
    const output = [];
    for (let i = 0; i < polygon2.length; i++) {
      const a = polygon2[i], b = polygon2[(i + 1) % polygon2.length];
      const av = local(a, plane.axis), bv = local(b, plane.axis);
      const ai = plane.greater ? av >= plane.limit : av <= plane.limit;
      const bi = plane.greater ? bv >= plane.limit : bv <= plane.limit;
      if (ai) output.push(a);
      if (ai !== bi) {
        const t = (plane.limit - av) / (bv - av);
        output.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]);
      }
    }
    return output;
  };
  const draw = (polygon2, material, region) => {
    for (let i = 1; i + 1 < polygon2.length; i++) {
      const a = polygon2[0], b = polygon2[i], c = polygon2[i + 1];
      builder.quad(a, b, c, c, material, [uv2(a), uv2(b), uv2(c), uv2(c)], [0, 0, 1], region);
    }
  };
  const bottom = (p, lift = 0) => {
    const along = local(p, 0) * 0.94, across = local(p, 1) * 0.72;
    return [
      centre[0] + direction[0] * along + normal[0] * across,
      centre[1] + direction[1] * along + normal[1] * across,
      p[2] - depth + lift
    ];
  };
  const glowPlanes = [
    { axis: 0, limit: -length2 * 0.35, greater: true },
    { axis: 0, limit: length2 * 0.35, greater: false },
    { axis: 1, limit: -halfWidth * 0.55, greater: true },
    { axis: 1, limit: halfWidth * 0.75, greater: false }
  ];
  let jointWritten = false;
  return {
    triangle(a, b, c) {
      let inside3 = [a, b, c];
      for (const plane of planes) {
        draw(clip2(inside3, { ...plane, greater: !plane.greater }), 0, 4);
        inside3 = clip2(inside3, plane);
        if (inside3.length < 3) return;
      }
      const floor = inside3.map((p) => bottom(p));
      draw(floor, 2, 3);
      for (let i = 0; i < inside3.length; i++) {
        const next = (i + 1) % inside3.length, p = inside3[i], q = inside3[next];
        if (!planes.some((plane) => Math.abs(local(p, plane.axis) - plane.limit) < EPSILON && Math.abs(local(q, plane.axis) - plane.limit) < EPSILON)) continue;
        builder.quad(p, q, floor[next], floor[i], 2, [uv2(p), uv2(q), uv2(floor[next]), uv2(floor[i])], [0, 0, 1], 3);
      }
      if (builder.spec.blocking !== 1) return;
      let glow = inside3;
      for (const plane of glowPlanes) glow = clip2(glow, plane);
      if (glow.length < 3) return;
      const lit = glow.map((p) => bottom(p, 0.04));
      draw(lit, 3, 3);
      if (!jointWritten) {
        builder.joint([
          lit.reduce((sum, p) => sum + p[0], 0) / lit.length,
          lit.reduce((sum, p) => sum + p[1], 0) / lit.length,
          lit.reduce((sum, p) => sum + p[2], 0) / lit.length
        ]);
        jointWritten = true;
      }
    }
  };
}

// src/generation/world-study/native-volume-expansion.ts
var NATIVE_VOLUME_SHAPE_PROFILES = ["rib-vault", "pleated-sheet", "cellular-shell", "lobed-cushion", "monolith-buttress", "terrace-shelf", "pleated-tear"];
var uv3 = (p) => [p[0], p[1]];
var clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
function noise(seed2, salt) {
  let value = Math.imul(seed2 ^ salt, 73244475);
  value = Math.imul(value ^ value >>> 16, 73244475);
  return ((value ^ value >>> 16) >>> 0) / 4294967296;
}
function fracture(b, a, c, d, size) {
  const sample = (u, v) => [
    a[0] + (c[0] - a[0]) * u + (d[0] - a[0]) * v,
    a[1] + (c[1] - a[1]) * u + (d[1] - a[1]) * v,
    a[2] + (c[2] - a[2]) * u + (d[2] - a[2]) * v + 0.08
  ];
  const length2 = Math.hypot(c[0] - a[0], c[1] - a[1]);
  const perpendicular = Math.abs((c[0] - a[0]) * (d[1] - a[1]) - (c[1] - a[1]) * (d[0] - a[0])) / Math.max(1e-3, length2);
  const du = size ? Math.min(0.44, size[0] / Math.max(1e-3, length2)) : 0.44;
  const dv = size ? Math.min(0.22, size[1] / Math.max(1e-3, perpendicular)) : 0.22;
  const p = sample(0.16, 0.12), q = sample(size ? 0.16 + du : 0.6, 0.12), r = sample(size ? 0.16 + du * 0.82 : 0.52, size ? 0.12 + dv : 0.34), s = sample(0.16, size ? 0.12 + dv : 0.34);
  b.quad(p, q, r, s, 3, [uv3(p), uv3(q), uv3(r), uv3(s)], [0, 0, 1], 3);
  b.joint(sample(size ? 0.16 + du * 0.43 : 0.35, size ? 0.12 + dv * 0.5 : 0.23));
}
function ribbon(b, centres, radii, form, marked = false, sideScales) {
  const rows = [];
  const section2 = form === "ridge" ? [[-1, 0], [-0.91, 0.14], [-0.63, 0.62], [-0.12, 1], [0.28, 0.9], [0.75, 0.41], [0.94, 0.14], [1, 0]] : [[-1, 0], [-0.95, 0.2], [-0.76, 0.77], [-0.37, 0.98], [0.29, 1], [0.74, 0.84], [0.94, 0.2], [1, 0]];
  for (let i = 0; i < centres.length; i++) {
    const p = centres[i], before = centres[Math.max(0, i - 1)], after = centres[Math.min(centres.length - 1, i + 1)];
    const dx = after[0] - before[0], dy = after[1] - before[1], length2 = Math.hypot(dx, dy) || 1;
    const radius = radii[i], foot = b.spec.blocking === 1 ? Math.min(8, p[2] * 0.32) : 0;
    rows.push(section2.map(([across, rise], at) => {
      const breadth = radius * across * (sideScales?.[i]?.[across < 0 ? 0 : 1] ?? 1);
      return [
        p[0] - dy / length2 * breadth,
        p[1] + dx / length2 * breadth,
        at === 0 || at === section2.length - 1 ? 0 : Math.max(foot, p[2] * rise)
      ];
    }));
  }
  let distance3 = 0;
  for (let i = 0; i < rows.length - 1; i++) {
    const a = rows[i], c = rows[i + 1], nextDistance = distance3 + Math.hypot(centres[i + 1][0] - centres[i][0], centres[i + 1][1] - centres[i][1]);
    for (let j = 0; j < a.length - 1; j++) {
      const cut = j === 0 || j === a.length - 2, slot = cut ? 1 : j >= 4 ? 2 : 0;
      b.quad(
        a[j],
        c[j],
        c[j + 1],
        a[j + 1],
        slot,
        [[distance3, j * radii[i] / 3], [nextDistance, j * radii[i + 1] / 3], [nextDistance, (j + 1) * radii[i + 1] / 3], [distance3, (j + 1) * radii[i] / 3]],
        [0, 0, 1],
        cut ? 3 : form === "pad" ? 5 : 4
      );
      if (marked && i === Math.floor((rows.length - 1) * 0.53) && j === 3) fracture(b, a[j], c[j], c[j + 1]);
    }
    distance3 = nextDistance;
  }
  for (const index of [0, rows.length - 1]) {
    const row = rows[index], centre = centres[index], neighbour = centres[index === 0 ? 1 : index - 1];
    const dx = centre[0] - neighbour[0], dy = centre[1] - neighbour[1], length2 = Math.hypot(dx, dy) || 1;
    const run = Math.min(7, b.spec.thickness * 0.6);
    for (let j = 0; j < row.length - 1; j++) {
      const a = row[j], c = row[j + 1], af = [a[0] + dx / length2 * run, a[1] + dy / length2 * run, 0], cf = [c[0] + dx / length2 * run, c[1] + dy / length2 * run, 0];
      b.quad(a, af, cf, c, 1, [uv3(a), uv3(af), uv3(cf), uv3(c)], [0, 0, 1], 3);
    }
  }
}
function ribVault(b) {
  const s = b.spec, count = s.branches, spine = [], radii = [];
  for (let i = 0; i <= 28; i++) {
    const t = i / 28, arch = Math.sin(Math.PI * t);
    spine.push([(t - 0.5) * s.length, -s.width * (0.33 + 0.035 * Math.sin(t * 5)), s.height * (0.53 + arch * 0.47)]);
    radii.push(s.width * (0.058 + 0.018 * arch));
  }
  ribbon(b, spine, radii, "ridge", true);
  for (let rib = 0; rib < count; rib++) {
    const at = (rib + 0.52) / count, length2 = s.width * (0.46 + noise(s.seed, 1900 + rib) * 0.28), centres = [], widths = [];
    for (let i = 0; i <= 20; i++) {
      const t = i / 20, bend = Math.sin(t * Math.PI * 0.86);
      centres.push([
        (at - 0.5) * s.length + bend * s.length * (0.036 + s.fold * 0.035),
        -s.width * 0.33 + t * length2,
        s.height * (0.6 - t * 0.36 + bend * 0.12) * (1 - rib % 3 * 0.055)
      ]);
      widths.push(Math.min(s.length / count * 0.18, s.width * 0.057) * (1 - t * 0.38));
    }
    ribbon(b, centres, widths, "ridge");
  }
}
function pleatedSheet(b, openedTear = false) {
  const s = b.spec, gap = Math.min(s.length * 0.38, Math.max(48, s.width * (0.28 + s.opening * 0.14) + 20));
  const centreGap = (0.04 + (noise(s.seed, 1981) - 0.5) * 0.1) * s.length;
  const folds = [
    [-0.35, 0.08],
    [0, 0.68],
    [0.16, 0.13],
    [0.43, 0.94],
    [0.56, 0.17],
    [0.9, 0.58],
    [1.14, 0.06],
    [1.31, 0.85],
    [1.6, 0.14],
    [1.87, 0.7],
    [2.2, 0.12]
  ];
  const creaseAt = (at) => {
    for (let i = 1; i < folds.length; i++) if (at <= folds[i][0]) {
      const a = folds[i - 1], c = folds[i], t = clamp((at - a[0]) / (c[0] - a[0]), 0, 1);
      return a[1] + (c[1] - a[1]) * t;
    }
    return folds[folds.length - 1][1];
  };
  const tear = (at, centre, radius) => Math.max(0, 1 - Math.abs(at - centre) / radius);
  const pieces = [[-s.length * 0.5, centreGap - gap * 0.5], [centreGap + gap * 0.5, s.length * 0.5]];
  for (const [piece, [start, end]] of pieces.entries()) {
    const along = 36, across = 16, rows = [];
    for (let i = 0; i <= along; i++) {
      const t = i / along, baseX = start + (end - start) * t, u = baseX / s.length + 0.5, row = [];
      const north = s.width * (-0.43 + 0.045 * Math.sin(u * 5.1) + 0.13 * tear(t, piece ? 0.28 : 0.7, 0.16));
      const south = s.width * (0.38 + 0.065 * Math.sin(u * 4.6 + 0.8) - 0.17 * tear(t, piece ? 0.78 : 0.23, 0.13));
      for (let j = 0; j <= across; j++) {
        const v = j / across;
        const x = baseX + s.length * (0.012 + 0.06 * tear(v, piece ? 0.7 : 0.24, 0.2)) * (1 - t) ** 5 - s.length * (0.018 + 0.075 * tear(v, piece ? 0.34 : 0.76, 0.18)) * t ** 5;
        const phase2 = u * (0.6 + s.branches * 0.16) + (v - 0.5) * (0.2 + s.fold * 0.1);
        const crease = creaseAt(phase2), amplitude = 0.79 + 0.12 * Math.sin(u * 4.7 + 0.9) + v * 0.09;
        const foot = s.blocking === 1 ? Math.min(8, s.height * 0.22) : 0;
        row.push([
          x,
          north + (south - north) * v,
          foot + s.height * (0.065 + crease * amplitude) * (0.79 + 0.21 * Math.sin(Math.PI * v))
        ]);
      }
      rows.push(row);
    }
    let ridge = 4;
    if (openedTear && piece === 1) {
      for (let i = 5; i < along - 4; i++)
        if (rows[i][6][2] > rows[ridge][6][2]) ridge = i;
    }
    const openedSurface = openedTear && piece === 1 ? createPleatedTear(
      b,
      rows[ridge][6],
      [rows[ridge][7][0] - rows[ridge][5][0], rows[ridge][7][1] - rows[ridge][5][1]]
    ) : void 0;
    for (let i = 0; i < along; i++) for (let j = 0; j < across; j++) {
      const a = rows[i][j], c = rows[i + 1][j], d = rows[i + 1][j + 1], e = rows[i][j + 1];
      if (openedSurface) {
        openedSurface.triangle(a, c, d);
        openedSurface.triangle(a, d, e);
      } else b.quad(a, c, d, e, 0, [uv3(a), uv3(c), uv3(d), uv3(e)], [0, 0, 1], 4);
      if (!openedTear && start < 0 && i === 15 && j === 7) fracture(b, a, c, d);
    }
    const outline = [
      ...rows.map((row) => row[0]),
      ...rows[along].slice(1),
      ...rows.slice(0, along).reverse().map((row) => row[across]),
      ...rows[0].slice(1, across).reverse()
    ];
    const feet = outline.map((p, i) => {
      const prev = outline[(i + outline.length - 1) % outline.length], next = outline[(i + 1) % outline.length];
      const dx = next[0] - prev[0], dy = next[1] - prev[1], length2 = Math.hypot(dx, dy) || 1, width = s.blocking === 1 ? Math.min(6, s.thickness * 0.55) : 1.5;
      return [p[0] + dy / length2 * width, p[1] - dx / length2 * width, 0];
    });
    for (let i = 0; i < outline.length; i++) {
      const next = (i + 1) % outline.length, a = outline[i], c = outline[next];
      const exposedInnerTear = piece === 0 && i > along + 3 && i < along + across - 3;
      b.quad(a, feet[i], feet[next], c, exposedInnerTear ? 2 : 1, [uv3(a), uv3(feet[i]), uv3(feet[next]), uv3(c)], [0, 0, 1], 3);
    }
  }
}
function lobedCushion(b) {
  const s = b.spec, count = clamp(s.branches - 1, 2, 3);
  for (let lobe = 0; lobe < count; lobe++) {
    const side = (lobe + 0.5) / count - 0.5, extent = (lobe === 0 ? 0.94 : 0.7) + noise(s.seed, 2100 + lobe) * 0.05;
    const points = [], radii = [], sideScales = [];
    for (let i = 0; i <= 36; i++) {
      const t = i / 36, shoulder = Math.pow(Math.sin(Math.PI * t), 0.5), taper = 0.04 + 0.96 * shoulder;
      const widthPeak = Math.exp(-Math.pow((t - (0.32 + lobe * 0.18)) / 0.22, 2));
      const curl = Math.exp(-Math.pow((t - (lobe === 0 ? 0.81 : 0.67)) / (0.1 + s.fold * 0.04), 2));
      points.push([
        (t - 0.5) * s.length * extent + lobe * s.length * 0.105,
        side * s.width + (t - 0.5) * s.width * (0.12 + s.distortion * 0.14),
        s.height * (0.1 + shoulder * 0.15 + curl * (lobe === 0 ? 0.5 + s.fold * 0.25 : 0.19))
      ]);
      radii.push(s.width / count * 0.33 * taper * (1 - s.opening * 0.14));
      const outer = 1.15 + widthPeak * (lobe === 0 ? 0.8 : 0.4);
      const notch = 1 - 0.17 * Math.exp(-Math.pow((t - 0.61) / 0.095, 2));
      sideScales.push(lobe === 0 ? [outer * notch, 0.9] : lobe === count - 1 ? [0.9, outer] : [0.86, 0.88]);
    }
    ribbon(b, points, radii, "pad", lobe === 0, sideScales);
  }
}
function planarMass(b, outline, topHeight, baseZ = 0, marked = false) {
  const cx = outline.reduce((sum, p) => sum + p[0], 0) / outline.length, cy = outline.reduce((sum, p) => sum + p[1], 0) / outline.length;
  const foot = outline.map(([x, y]) => [x, y, baseZ]);
  const low = outline.map(([x, y]) => [
    cx + (x - cx) * 0.965,
    cy + (y - cy) * 0.965,
    baseZ + Math.min(b.spec.blocking === 1 ? 9 : 1, (topHeight(x, y) - baseZ) * 0.32)
  ]);
  const crown = outline.map(([x, y]) => {
    const px = cx + (x - cx) * 0.85, py = cy + (y - cy) * 0.85;
    return [px, py, topHeight(px, py)];
  });
  const centre = [cx, cy, topHeight(cx, cy)];
  let distance3 = 0;
  for (let i = 0; i < outline.length; i++) {
    const next = (i + 1) % outline.length, a = foot[i], c = foot[next], edge = Math.hypot(c[0] - a[0], c[1] - a[1]);
    b.quad(a, c, low[next], low[i], 1, [[distance3, baseZ], [distance3 + edge, baseZ], [distance3 + edge, low[next][2]], [distance3, low[i][2]]], [0, 0, 1], 3);
    b.quad(
      low[i],
      low[next],
      crown[next],
      crown[i],
      i % 3 === 0 ? 2 : 1,
      [[distance3, low[i][2]], [distance3 + edge, low[next][2]], [distance3 + edge, crown[next][2]], [distance3, crown[i][2]]],
      [0, 0, 1],
      1
    );
    b.quad(centre, crown[i], crown[next], centre, 0, [uv3(centre), uv3(crown[i]), uv3(crown[next]), uv3(centre)], [0, 0, 1], 0);
    if (marked && i === 1) fracture(b, centre, crown[i], crown[next], [18, 1.4]);
    distance3 += edge;
  }
}
function monolithButtress(b) {
  const s = b.spec, l = s.length, w = s.width, gap = Math.max(30, l * (0.12 + s.opening * 0.14));
  const offset = (noise(s.seed, 2201) - 0.5) * l * 0.08;
  const sideMouth = Math.min(w * 0.2, Math.max(32, w * (0.08 + s.opening * 0.08)) - w * 0.025);
  planarMass(
    b,
    [[-l * 0.46, -w * 0.42], [l * 0.34, -w * 0.49], [l * 0.46, -w * 0.27], [l * 0.38, -w * 0.025], [-l * 0.4, -w * 0.025]],
    (x, y) => s.height * (0.8 + x / l * s.fold * 0.2 - y / w * 0.24),
    0,
    true
  );
  planarMass(b, [
    [-l * 0.4, -w * 0.12],
    [-gap * 0.5 + offset, -w * 0.12],
    [-gap * 0.5 + offset, w * 0.31],
    [-l * 0.25, w * 0.48],
    [-l * 0.46, w * 0.34]
  ], (x, y) => s.height * (0.65 - y / w * 0.4 - x / l * 0.14));
  planarMass(b, [
    [gap * 0.5 + offset, sideMouth],
    [l * 0.39, sideMouth],
    [l * 0.46, w * 0.26],
    [l * 0.31, w * 0.43],
    [gap * 0.5 + offset, w * 0.29]
  ], (_x, y) => s.height * (0.67 - y / w * (0.2 + s.fold * 0.22)));
}
function terraceShelf(b) {
  const s = b.spec, tiers = clamp(s.branches, 2, 4), l = s.length, w = s.width;
  const scaled = (outline) => outline.map(([x, y]) => [x * l, y * w]);
  const lowerHeight = (x, y) => s.height * (0.4 + x / l * 0.17 + y / w * (0.06 + s.fold * 0.04));
  planarMass(b, scaled([[-0.49, -0.32], [-0.34, -0.5], [0.41, -0.43], [0.49, -0.18], [0.39, 0.035], [-0.38, 0.035]]), lowerHeight);
  planarMass(b, scaled([[-0.43, -0.09], [0.085, -0.09], [0.045, 0.22], [-0.1, 0.44], [-0.48, 0.32]]), lowerHeight);
  planarMass(b, scaled([[0.245, -0.09], [0.41, -0.1], [0.5, 0.13], [0.35, 0.39], [0.285, 0.25]]), lowerHeight);
  const upper = [[-0.37, -0.26], [-0.27, -0.43], [-0.02, -0.39], [0.18, -0.17], [0.04, -0.055], [-0.28, -0.09]];
  for (let tier = 1; tier < tiers; tier++) {
    const along = 0.56 ** (tier - 1), across = 0.68 ** (tier - 1);
    const outline = scaled(upper.map(([x, y]) => [-0.12 + (x + 0.12) * along, -0.23 + (y + 0.23) * across]));
    const height = (x, y) => s.height * (0.42 + 0.53 * tier / (tiers - 1) + (x / l + 0.15) * 0.1 - (y / w + 0.25) * (0.08 + s.fold * 0.05));
    planarMass(b, outline, height, 0, tier === tiers - 1);
  }
}
function buildExpandedNativeVolume(builder) {
  switch (builder.spec.shapeProfile) {
    case "rib-vault":
      ribVault(builder);
      return;
    case "pleated-sheet":
      pleatedSheet(builder);
      return;
    case "pleated-tear":
      pleatedSheet(builder, true);
      return;
    case "cellular-shell":
      buildCellularShell(builder);
      return;
    case "lobed-cushion":
      lobedCushion(builder);
      return;
    case "monolith-buttress":
      monolithButtress(builder);
      return;
    case "terrace-shelf":
      terraceShelf(builder);
      return;
    default:
      throw new Error("Unknown expanded native shape profile");
  }
}

// src/generation/world-study/native-volume-organization.ts
var uv4 = (p) => [p[0], p[1]];
var mix = (a, c, t) => [a[0] + (c[0] - a[0]) * t, a[1] + (c[1] - a[1]) * t, a[2] + (c[2] - a[2]) * t];
function curved(points, at) {
  const i = Math.min(points.length - 2, Math.floor(at)), t = at - i;
  const a = points[i], c = points[i + 1], before = points[Math.max(0, i - 1)], after = points[Math.min(points.length - 1, i + 2)];
  const tangent = (u, v) => u * v <= 0 ? 0 : 2 / (1 / u + 1 / v);
  return [0, 1, 2].map((axis) => {
    const d = c[axis] - a[axis], start = i === 0 ? d : tangent(a[axis] - before[axis], d);
    const end = i === points.length - 2 ? d : tangent(d, after[axis] - c[axis]);
    return (2 * t ** 3 - 3 * t * t + 1) * a[axis] + (t ** 3 - 2 * t * t + t) * start + (-2 * t ** 3 + 3 * t * t) * c[axis] + (t ** 3 - t * t) * end;
  });
}
function pressureFracture(b, a, c, d) {
  if (b.spec.blocking !== 1) return;
  const sample = (u, v) => [
    a[0] + (c[0] - a[0]) * u + (d[0] - a[0]) * v,
    a[1] + (c[1] - a[1]) * u + (d[1] - a[1]) * v,
    a[2] + (c[2] - a[2]) * u + (d[2] - a[2]) * v + 0.04
  ];
  const p = sample(0.16, 0.16), q = sample(0.45, 0.16), r = sample(0.39, 0.28), t = sample(0.16, 0.28);
  b.quad(p, q, r, t, 3, [uv4(p), uv4(q), uv4(r), uv4(t)], [0, 0, 1], 3);
  b.joint(sample(0.28, 0.21));
}
function buildCompressedWedge(b) {
  const s = b.spec;
  const along = [-0.5, -0.34, -0.03, 0.19, 0.32, 0.43];
  const breadth = [0.57, 0.94, 1, 0.89, 0.75, 0.63];
  const rise = [0.51, 0.9, 1, 0.77, 0.52, 0.3];
  const across = [-1, -0.73, -0.36, 0.02, 0.41, 0.76, 1];
  const crown = [0.23, 0.68, 0.94, 1, 0.88, 0.62, 0.19];
  const tear = [-0.04, 0.01, -0.045, 0.075, -5e-3, -0.075, -0.11];
  const rows = [], feet = [];
  for (let i = 0; i < along.length; i++) {
    const u = i / (along.length - 1), centre = s.width * (-0.06 + 0.08 * u + 0.025 * Math.sin(u * Math.PI));
    const radius = s.width * 0.48 * breadth[i];
    const top = s.height * rise[i], foot = s.blocking === 1 ? Math.min(4, s.height * 0.12) : 0;
    const row = across.map((v, j) => {
      const shift = s.length * (tear[j] * u ** 5 + v * (0.025 - u * 0.04));
      const z = foot + (top - foot) * crown[j];
      return [s.length * along[i] + shift, centre + radius * v, z];
    });
    rows.push(row);
    const spread = Math.min(6, s.width * 0.04);
    feet.push(row.map((p, j) => [
      p[0] + (i === 0 ? -spread : i === along.length - 1 ? spread : 0),
      p[1] + (j === 0 ? -spread : j === across.length - 1 ? spread : 0),
      0
    ]));
  }
  const sample = (u, v) => curved(rows.map((row) => curved(row, v)), u);
  for (let i = 0; i < (rows.length - 1) * 2; i++) for (let j = 0; j < (across.length - 1) * 2; j++) {
    const a = sample(i / 2, j / 2), c = sample((i + 1) / 2, j / 2), d = sample((i + 1) / 2, (j + 1) / 2), e = sample(i / 2, (j + 1) / 2);
    const cut = i >= (rows.length - 2) * 2 && (j === 2 || j === 3 || j === 8 || j === 9);
    b.quad(a, c, d, e, cut ? 1 : 0, [uv4(a), uv4(c), uv4(d), uv4(e)], [0, 0, 1], cut ? 3 : 1);
    if (i === 3 && j === 4) pressureFracture(b, a, c, d);
  }
  for (const side of [0, across.length - 1]) for (let i = 0; i < (rows.length - 1) * 2; i++) {
    const a = sample(i / 2, side), c = sample((i + 1) / 2, side), af = curved(feet.map((row) => row[side]), i / 2), cf = curved(feet.map((row) => row[side]), (i + 1) / 2);
    b.quad(af, cf, c, a, 0, [uv4(af), uv4(cf), uv4(c), uv4(a)], [0, side ? 1 : -1, 0], 1);
  }
  for (const i of [0, rows.length - 1]) for (let j = 0; j < (across.length - 1) * 2; j++) {
    const a = sample(i, j / 2), c = sample(i, (j + 1) / 2), af = curved(feet[i], j / 2), cf = curved(feet[i], (j + 1) / 2);
    const cut = i !== 0, sectionUV = (p) => [p[1], p[2]];
    b.quad(
      af,
      cf,
      c,
      a,
      cut ? 1 : 0,
      [sectionUV(af), sectionUV(cf), sectionUV(c), sectionUV(a)],
      [cut ? 1 : -1, 0, 0],
      cut ? 3 : 1
    );
  }
}
function buildPorousBreak(b) {
  const s = b.spec;
  const along = [-0.49, -0.34, -0.19, -0.025, 0.19, 0.35, 0.48];
  const widths = [0.43, 0.82, 1, 0.91, 0.94, 0.66, 0.29];
  const heights = [0.43, 0.76, 1, 0.93, 0.74, 0.62, 0.27];
  const split = [0.77, 0.55, 0.19, 0.13, 0.28, 0.52, 0.81];
  const rows = along.map((x, i) => {
    const radius = s.width * 0.48 * widths[i], centre = s.width * (0.045 * Math.sin(i * 0.7) - 0.035);
    const z = s.height * heights[i], t = split[i];
    const foot = [x * s.length, centre - radius, 0];
    const shoulder = [x * s.length + s.length * 0.012, centre - radius * 0.77, z * 0.59];
    const crown = [x * s.length, centre - radius * 0.17, z];
    const lip = [x * s.length + s.length * 0.022 * Math.sin(i * 1.3), centre + radius * t, z * (1 - 0.25 * t - 0.65 * t * t)];
    const toe = [x * s.length + Math.min(5, s.length * 0.02), centre + radius, 0];
    return { foot, shoulder, crown, lip, toe };
  });
  const sizes = [5, 12, 7, 14, 6, 4], offsets = [0.56, 0.35, 0.65, 0.47, 0.37, 0.48], depths = [0.44, 0.61, 0.38, 0.5, 0.63, 0.43];
  const rowAt = (u) => ["foot", "shoulder", "crown", "lip", "toe"].map((key) => curved(rows.map((row) => row[key]), u));
  for (let i = 0; i < rows.length - 1; i++) {
    const a = rows[i], c = rows[i + 1];
    for (let along2 = 0; along2 < 2; along2++) for (let across = 0; across < 6; across++) {
      const start = rowAt(i + along2 / 2), end = rowAt(i + (along2 + 1) / 2);
      const p = curved(start, across / 2), q = curved(end, across / 2), r = curved(end, (across + 1) / 2), t = curved(start, (across + 1) / 2);
      b.quad(p, q, r, t, 0, [uv4(p), uv4(q), uv4(r), uv4(t)], [0, 0, 1], 0);
      if (i === 2 && along2 === 1 && across === 4) pressureFracture(b, p, q, r);
    }
    const sample = (u, v) => {
      const row = rowAt(i + u);
      return mix(row[3], row[4], v);
    };
    const centreU = offsets[i], centreV = depths[i], centre = sample(centreU, centreV);
    const width = c.lip[0] - a.lip[0], depth = (a.toe[1] - a.lip[1] + (c.toe[1] - c.lip[1])) / 2;
    const radius = Math.min(sizes[i] / 2, width * 0.23, depth * 0.23);
    const outer = [[0, 0], [0.5, 0], [1, 0], [1, 0.5], [1, 1], [0.5, 1], [0, 1], [0, 0.5]];
    const ring = outer.map(([u, v]) => sample(u, v)), mouth = [], bottom = [];
    const recess = Math.min(5, centre[2] * 0.32, radius * 0.74);
    for (let j = 0; j < 8; j++) {
      const angle = -Math.PI * 0.75 + j * Math.PI / 4;
      const dx = Math.cos(angle) * radius, dy = Math.sin(angle) * radius * (0.68 + i % 2 * 0.12);
      mouth.push(sample(centreU + dx / width, centreV + dy / depth));
      const p = sample(centreU + dx * 0.63 / width, centreV + dy * 0.63 / depth);
      bottom.push([p[0], p[1], p[2] - recess]);
    }
    const centreBottom = [centre[0], centre[1], centre[2] - recess];
    for (let j = 0; j < 8; j++) {
      const k = (j + 1) % 8, p = mouth[j], q = mouth[k], af = bottom[j], cf = bottom[k];
      b.quad(ring[j], ring[k], q, p, 1, [uv4(ring[j]), uv4(ring[k]), uv4(q), uv4(p)], [0, 0, 1], 3);
      b.quad(p, q, cf, af, 2, [uv4(p), uv4(q), uv4(cf), uv4(af)], [0, 0, 1], 2);
      b.quad(
        af,
        cf,
        centreBottom,
        centreBottom,
        2,
        [uv4(af), uv4(cf), uv4(centreBottom), uv4(centreBottom)],
        [0, 0, 1],
        0
      );
    }
  }
  for (const i of [0, rows.length - 1]) {
    const row = rowAt(i), face = [0, 0.5, 1, 1.5, 2, 2.5, 3, 4].map((at) => curved(row, at));
    for (let j = 1; j < face.length - 1; j++) {
      const a = face[0], c = face[j], d = face[j + 1];
      b.quad(a, c, d, d, 0, [uv4(a), uv4(c), uv4(d), uv4(d)], [i ? 1 : -1, 0, 0], 0);
    }
  }
}
function smoothOrganizedSurface(mesh) {
  const groups = /* @__PURE__ */ new Map();
  for (let face = 0; face < mesh.triangleCount; face++) {
    if (mesh.materials[face] !== 0) continue;
    for (let corner = 0; corner < 3; corner++) {
      const vertex = mesh.indices[face * 3 + corner], at = vertex * 3;
      const previous = mesh.indices[face * 3 + (corner + 1) % 3] * 3;
      const next = mesh.indices[face * 3 + (corner + 2) % 3] * 3;
      const ax = mesh.positions[previous] - mesh.positions[at], ay = mesh.positions[previous + 1] - mesh.positions[at + 1], az = mesh.positions[previous + 2] - mesh.positions[at + 2];
      const bx = mesh.positions[next] - mesh.positions[at], by = mesh.positions[next + 1] - mesh.positions[at + 1], bz = mesh.positions[next + 2] - mesh.positions[at + 2];
      const dot = (ax * bx + ay * by + az * bz) / (Math.hypot(ax, ay, az) * Math.hypot(bx, by, bz));
      const weight = Math.acos(Math.max(-1, Math.min(1, dot)));
      const key = `${mesh.positions[at]},${mesh.positions[at + 1]},${mesh.positions[at + 2]}:${mesh.regions[face]}`;
      const entries = groups.get(key) ?? [];
      entries.push({ vertex, weight });
      groups.set(key, entries);
    }
  }
  const normals = new Float32Array(mesh.normals), creaseCosine = Math.cos(55 * Math.PI / 180);
  for (const entries of groups.values()) for (const { vertex } of entries) {
    const at = vertex * 3, nx = mesh.normals[at], ny = mesh.normals[at + 1], nz = mesh.normals[at + 2];
    let x = 0, y = 0, z = 0;
    for (const { vertex: other, weight } of entries) {
      const q = other * 3, ox = mesh.normals[q], oy = mesh.normals[q + 1], oz = mesh.normals[q + 2];
      if (nx * ox + ny * oy + nz * oz < creaseCosine) continue;
      x += ox * weight;
      y += oy * weight;
      z += oz * weight;
    }
    const length2 = Math.hypot(x, y, z);
    if (length2 > 0) {
      normals[at] = x / length2;
      normals[at + 1] = y / length2;
      normals[at + 2] = z / length2;
    }
  }
  return { ...mesh, normals };
}

// src/generation/world-study/native-volume-settled-sheet.ts
function buildSettledSheet(b) {
  const outline = [
    [-0.5, -0.23],
    [-0.29, -0.48],
    [0.13, -0.37],
    [0.4, -0.26],
    [0.51, -0.03],
    [0.34, 0.29],
    [0.23, 0.13],
    [0.04, -0.02],
    [0.13, 0.23],
    [-0.1, 0.49],
    [-0.37, 0.34],
    [-0.28, 0.13],
    [-0.46, 0.02]
  ];
  const parts = [[0, 1, 2, 7, 11, 12], [11, 7, 8, 9, 10], [2, 3, 4, 5, 6, 7]];
  buildSettledMaterial(b, outline, parts, "sheet");
}
function buildSettledFan(b) {
  const outline = [
    [-0.5, -0.3],
    [-0.32, -0.49],
    [0.24, -0.4],
    [0.43, -0.18],
    [0.51, 0.17],
    [0.29, 0.39],
    [0.16, 0.21],
    [0.09, -0.04],
    [-0.02, 0.36],
    [-0.3, 0.5],
    [-0.46, 0.17],
    [-0.3, -0.1]
  ];
  const parts = [[0, 1, 2, 3, 7, 11], [11, 7, 8, 9, 10], [7, 3, 4, 5, 6]];
  buildSettledMaterial(b, outline, parts, "fan");
}
function buildSettledMaterial(b, outline, parts, profile) {
  const s = b.spec;
  if (s.blocking !== 0 || s.height > 6) throw new Error("Settled material requires shallow, nonblocking material");
  const boundary = outline.map(([x, y]) => [x * s.length, y * s.width]);
  const smooth2 = (n) => {
    const t = Math.max(0, Math.min(1, n));
    return t * t * (3 - 2 * t);
  };
  const height = ([x, y]) => {
    let distance3 = Infinity;
    for (let i = 0; i < boundary.length; i++) {
      const a = boundary[i], c = boundary[(i + 1) % boundary.length];
      const dx = c[0] - a[0], dy = c[1] - a[1];
      const t = Math.max(0, Math.min(1, ((x - a[0]) * dx + (y - a[1]) * dy) / (dx * dx + dy * dy)));
      distance3 = Math.min(distance3, Math.hypot(x - a[0] - dx * t, y - a[1] - dy * t));
    }
    const retreat = 5 + 3 * Math.sin(x * 0.043 + y * 0.025) + 2 * Math.sin(y * 0.071 - x * 0.019);
    const buried = smooth2((distance3 - retreat) / 24);
    const fold = profile === "sheet" ? 0.45 + 0.55 * smooth2((y / s.width + 0.34 + 0.14 * x / s.length) / 0.7) : 0.78 + x / s.length * (0.08 + s.fold * 0.08) - y / s.width * 0.13 - 0.27 * smooth2((x / s.length - 0.09) / 0.25) * smooth2((y / s.width + 0.04) / 0.3);
    return s.height * buried * fold;
  };
  const clip2 = (polygon2, axis, at, greater) => {
    const result = [];
    for (let i = 0; i < polygon2.length; i++) {
      const a = polygon2[i], c = polygon2[(i + 1) % polygon2.length];
      const ai = greater ? a[axis] >= at : a[axis] <= at;
      const ci = greater ? c[axis] >= at : c[axis] <= at;
      if (ai) result.push(a);
      if (ai !== ci) {
        const t = (at - a[axis]) / (c[axis] - a[axis]);
        result.push([a[0] + (c[0] - a[0]) * t, a[1] + (c[1] - a[1]) * t]);
      }
    }
    return result;
  };
  const minX = Math.min(...boundary.map((p) => p[0])), maxX = Math.max(...boundary.map((p) => p[0]));
  const minY = Math.min(...boundary.map((p) => p[1])), maxY = Math.max(...boundary.map((p) => p[1]));
  const xs = Array.from({ length: 13 }, (_, i) => minX + (maxX - minX) * i / 12);
  const ys = Array.from({ length: 11 }, (_, i) => minY + (maxY - minY) * i / 10);
  for (const part of parts) for (let x = 0; x < 12; x++) for (let y = 0; y < 10; y++) {
    const polygon2 = clip2(clip2(clip2(
      clip2(part.map((i) => boundary[i]), 0, xs[x], true),
      0,
      xs[x + 1],
      false
    ), 1, ys[y], true), 1, ys[y + 1], false);
    if (polygon2.length < 3) continue;
    const points = polygon2.map((p) => [p[0], p[1], height(p)]);
    for (let i = 1; i < points.length - 1; i++) {
      b.quad(
        points[0],
        points[i],
        points[i + 1],
        points[i + 1],
        0,
        [polygon2[0], polygon2[i], polygon2[i + 1], polygon2[i + 1]],
        [0, 0, 1],
        4
      );
    }
  }
}

// src/generation/world-study/native-volume-settled-projection.ts
var cross = (a, b) => a[0] * b[1] - a[1] * b[0];
var subtract = (a, b) => [a[0] - b[0], a[1] - b[1]];
var xy = (p) => [p[0], p[1]];
function buildSettledProjection(b, construct, refine) {
  if (b.spec.blocking !== 0 || b.spec.height > 6) throw new Error("Settled projection requires shallow nonblocking material");
  const source = [];
  const add = (a, c, d) => {
    if (Math.abs(cross(subtract(xy(c), xy(a)), subtract(xy(d), xy(a)))) > 1e-8) source.push([a, c, d]);
  };
  construct({
    spec: b.spec,
    quad(a, c, d, e) {
      add(a, c, d);
      add(a, d, e);
    },
    joint() {
      throw new Error("Shallow source must not emit a pollution joint");
    }
  });
  const weights = (p, t) => {
    const a = xy(t[0]), ab = subtract(xy(t[1]), a), ac = subtract(xy(t[2]), a), ap = subtract(p, a);
    const area3 = cross(ab, ac), v = cross(ap, ac) / area3, w = cross(ab, ap) / area3, u = 1 - v - w;
    return u >= -1e-8 && v >= -1e-8 && w >= -1e-8 ? [u, v, w] : null;
  };
  const contains3 = (p) => source.some((t) => weights(p, t) !== null);
  const key = (p) => `${p[0].toFixed(7)},${p[1].toFixed(7)}`;
  const edges2 = /* @__PURE__ */ new Map();
  for (const t of source) for (let i = 0; i < 3; i++) {
    const a = xy(t[i]), c = xy(t[(i + 1) % 3]), ak = key(a), ck = key(c), id = ak < ck ? `${ak}/${ck}` : `${ck}/${ak}`;
    const edge = edges2.get(id);
    if (edge) edge.uses++;
    else edges2.set(id, { a, b: c, uses: 1 });
  }
  const candidates = [...edges2.values()].filter((e) => e.uses === 1), boundary = [];
  const epsilon = Math.max(b.spec.length, b.spec.width) * 1e-6;
  for (const edge of candidates) {
    const ab = subtract(edge.b, edge.a), length2 = Math.hypot(...ab), cuts = [0, 1];
    for (const other of candidates) {
      if (other === edge) continue;
      const cd = subtract(other.b, other.a), ac = subtract(other.a, edge.a), denominator = cross(ab, cd);
      if (Math.abs(denominator) > 1e-9) {
        const t = cross(ac, cd) / denominator, u = cross(ac, ab) / denominator;
        if (t > 0 && t < 1 && u >= 0 && u <= 1) cuts.push(t);
      } else if (Math.abs(cross(ac, ab)) < 1e-7) {
        for (const p of [other.a, other.b]) {
          const ap = subtract(p, edge.a), t = (ap[0] * ab[0] + ap[1] * ab[1]) / (length2 * length2);
          if (t > 0 && t < 1) cuts.push(t);
        }
      }
    }
    cuts.sort((a, c) => a - c);
    const at = (t) => [edge.a[0] + ab[0] * t, edge.a[1] + ab[1] * t];
    for (let i = 0; i < cuts.length - 1; i++) {
      if (cuts[i + 1] - cuts[i] < 1e-8) continue;
      const p = at((cuts[i] + cuts[i + 1]) / 2), nx = -ab[1] / length2 * epsilon, ny = ab[0] / length2 * epsilon;
      if (contains3([p[0] + nx, p[1] + ny]) !== contains3([p[0] - nx, p[1] - ny]))
        boundary.push({ a: at(cuts[i]), b: at(cuts[i + 1]), uses: 1 });
    }
  }
  if (!boundary.length) throw new Error("Settled material has no exterior boundary");
  const cache = /* @__PURE__ */ new Map();
  const surface = (p) => {
    const id = key(p), known = cache.get(id);
    if (known) return known;
    let distance3 = Infinity, height = 0;
    for (const edge of boundary) {
      const ab = subtract(edge.b, edge.a), ap = subtract(p, edge.a);
      const t2 = Math.max(0, Math.min(1, (ap[0] * ab[0] + ap[1] * ab[1]) / (ab[0] * ab[0] + ab[1] * ab[1])));
      distance3 = Math.min(distance3, Math.hypot(ap[0] - ab[0] * t2, ap[1] - ab[1] * t2));
    }
    for (const triangle of source) {
      const w = weights(p, triangle);
      if (w) height = Math.max(height, w[0] * triangle[0][2] + w[1] * triangle[1][2] + w[2] * triangle[2][2]);
    }
    const span = Math.min(34, Math.max(16, b.spec.width * 0.18)) * (1 + 0.22 * p[0] / b.spec.length - 0.12 * p[1] / b.spec.width);
    const t = Math.max(0, Math.min(1, distance3 / span)), settled = t * t * (3 - 2 * t);
    const point = [p[0], p[1], height * settled];
    cache.set(id, point);
    return point;
  };
  const emit = (a, c, d) => {
    b.quad(surface(a), surface(c), surface(d), surface(d), 0, [a, c, d, d], [0, 0, 1], 0);
  };
  const midpoint = (a, c) => [(a[0] + c[0]) / 2, (a[1] + c[1]) / 2];
  for (const triangle of source) {
    const [a, c, d] = triangle.map(xy);
    if (refine) {
      const ac = midpoint(a, c), cd = midpoint(c, d), da = midpoint(d, a);
      emit(a, ac, da);
      emit(ac, c, cd);
      emit(da, cd, d);
      emit(ac, cd, da);
    } else emit(a, c, d);
  }
}

// src/generation/world-study/native-volume-ground.ts
var NATIVE_VOLUME_V4_PROFILES = ["fracture-fan", "fallen-bundle", "clamp-bank", "torn-sheet", "compressed-wedge", "porous-break", "settled-sheet", "settled-fan", "settled-bundle", "settled-clamp"];
var uv5 = (p) => [p[0], p[1]];
function fracturedFace(b, a, c, d) {
  if (b.spec.blocking !== 1) return;
  const length2 = Math.hypot(c[0] - a[0], c[1] - a[1]);
  const perpendicular = Math.abs((c[0] - a[0]) * (d[1] - a[1]) - (c[1] - a[1]) * (d[0] - a[0])) / Math.max(1e-3, length2);
  const du = Math.min(0.34, 24 / Math.max(1, length2)), dv = Math.min(0.23, 6 / Math.max(1, perpendicular));
  const sample = (u, v) => [
    a[0] + (c[0] - a[0]) * u + (d[0] - a[0]) * v,
    a[1] + (c[1] - a[1]) * u + (d[1] - a[1]) * v,
    a[2] + (c[2] - a[2]) * u + (d[2] - a[2]) * v + 0.06
  ];
  const p = sample(0.17, 0.14), q = sample(0.17 + du, 0.14), r = sample(0.17 + du * 0.78, 0.14 + dv), t = sample(0.17, 0.14 + dv);
  b.quad(p, q, r, t, 3, [uv5(p), uv5(q), uv5(r), uv5(t)], [0, 0, 1], 3);
  b.joint(sample(0.17 + du * 0.43, 0.14 + dv * 0.43));
}
function insetOutline(b, outline) {
  const cx = outline.reduce((sum, p) => sum + p[0], 0) / outline.length, cy = outline.reduce((sum, p) => sum + p[1], 0) / outline.length;
  return outline.map(([x, y]) => {
    const factor = b.spec.blocking === 1 ? Math.min(0.25, 6.5 / Math.max(1, Math.hypot(x - cx, y - cy))) : 0;
    return [x + (cx - x) * factor, y + (cy - y) * factor];
  });
}
function surfaceHeight(b, height) {
  const foot = b.spec.blocking === 1 ? Math.min(6, b.spec.height * 0.3) : 0;
  return foot + height * (1 - foot / b.spec.height);
}
function section(b, outline, height, scar = false, closed = true) {
  const crown = closed ? insetOutline(b, outline) : outline;
  const top = crown.map(([x, y]) => [x, y, surfaceHeight(b, height(x, y))]);
  const cx = crown.reduce((sum, p) => sum + p[0], 0) / crown.length;
  const cy = crown.reduce((sum, p) => sum + p[1], 0) / crown.length;
  const centre = [cx, cy, surfaceHeight(b, height(cx, cy))];
  for (let i = 0; i < top.length; i++) {
    const a = top[i], c = top[(i + 1) % top.length];
    b.quad(a, c, centre, centre, 0, [uv5(a), uv5(c), uv5(centre), uv5(centre)], [0, 0, 1]);
    if (closed) {
      const footA = outline[i], footC = outline[(i + 1) % outline.length], af = [...footA, 0], cf = [...footC, 0];
      b.quad(
        af,
        cf,
        c,
        a,
        1,
        [[a[0], 0], [c[0], 0], [c[0], c[2]], [a[0], a[2]]],
        [a[0] + c[0] - 2 * cx, a[1] + c[1] - 2 * cy, 0],
        3
      );
    }
    if (scar && i === 1) fracturedFace(b, a, c, centre);
  }
}
function strip(b, rows, innerFrom = Infinity) {
  for (let i = 0; i < rows.length - 1; i++) {
    const a = rows[i], c = rows[i + 1];
    for (let j = 0; j < a.length - 1; j++) {
      const edge = j === 0 || j === a.length - 2;
      b.quad(
        a[j],
        c[j],
        c[j + 1],
        a[j + 1],
        edge ? 1 : j >= innerFrom ? 2 : 0,
        [uv5(a[j]), uv5(c[j]), uv5(c[j + 1]), uv5(a[j + 1])],
        [0, 0, 1],
        edge ? 3 : 0
      );
      if (i === 1 && j === 3) fracturedFace(b, a[j], c[j], c[j + 1]);
    }
  }
  for (const index of [0, rows.length - 1]) {
    const row = rows[index], direction = index === 0 ? -1 : 1;
    for (let j = 0; j < row.length - 1; j++) {
      const a = row[j], c = row[j + 1], af = [a[0], a[1], 0], cf = [c[0], c[1], 0];
      b.quad(af, a, c, cf, 1, [uv5(af), uv5(a), uv5(c), uv5(cf)], [direction, 0, 0], 3);
    }
  }
}
function fractureFan(b) {
  const s = b.spec, l = s.length, w = s.width;
  const outline = [
    [-0.5, -0.3],
    [-0.32, -0.49],
    [0.24, -0.4],
    [0.43, -0.18],
    [0.51, 0.17],
    [0.29, 0.39],
    [0.16, 0.21],
    [0.09, -0.04],
    [-0.02, 0.36],
    [-0.3, 0.5],
    [-0.46, 0.17],
    [-0.3, -0.1]
  ];
  const feet = outline.map(([x, y]) => [x * l, y * w]);
  const depths = [0.16, 0.1, 0.18, 0.48, 0.94, 0.3, 0.78, 0.42, 0.7, 1, 0.26, 0.12];
  const breadth = Math.min(s.blocking === 1 ? 11 : 6, Math.min(l, w) * 0.065);
  const inward = (a, c) => {
    const dx = c[0] - a[0], dy = c[1] - a[1], size = Math.hypot(dx, dy);
    return [-dy / size, dx / size];
  };
  const crown = feet.map((p, i) => {
    const before = inward(feet[(i + feet.length - 1) % feet.length], p), after = inward(p, feet[(i + 1) % feet.length]);
    const dx = before[0] + after[0], dy = before[1] + after[1], size = Math.hypot(dx, dy);
    return [p[0] + dx / size * breadth * depths[i], p[1] + dy / size * breadth * depths[i]];
  });
  const rims = feet.map((a, i) => {
    const next = (i + 1) % feet.length, c = feet[next], p = crown[i], q = crown[next], normal = inward(a, c);
    const samples = i === 4 ? [0, 0.24, 0.61, 0.76, 1] : i === 8 ? [0, 0.32, 0.79, 1] : [0, 1];
    return samples.map((t) => {
      const chip = i === 4 ? t === 0.61 ? 0.83 : t === 0.76 ? 0.12 : 0 : i === 8 && t === 0.32 ? 0.38 : 0;
      return {
        foot: [a[0] + (c[0] - a[0]) * t, a[1] + (c[1] - a[1]) * t],
        top: [
          p[0] + (q[0] - p[0]) * t + normal[0] * breadth * chip,
          p[1] + (q[1] - p[1]) * t + normal[1] * breadth * chip
        ]
      };
    });
  });
  const parts = [[0, 1, 2, 3, 7, 11], [11, 7, 8, 9, 10], [7, 3, 4, 5, 6]];
  const alongShoulder = ([x, y]) => ((y / w + 0.04) * 0.34 + (x / l - 0.09) * 0.14) / Math.hypot(0.34, 0.14);
  const bands = [-1, 0.055, 0.14, 1], drops = [0, 0, 0.27, 0.45];
  const height = (p, part) => {
    let drop = 0;
    if (part === 2) {
      const v = alongShoulder(p), band = Math.max(0, Math.min(2, bands.findIndex((at) => at > v) - 1));
      const t = (v - bands[band]) / (bands[band + 1] - bands[band]);
      drop = drops[band] + (drops[band + 1] - drops[band]) * t;
    }
    return surfaceHeight(b, s.height * (0.78 + p[0] / l * (0.08 + s.fold * 0.08) - p[1] / w * 0.13 - drop));
  };
  const clip2 = (polygon2, boundary, greater) => {
    const result = [];
    for (let j = 0; j < polygon2.length; j++) {
      const a = polygon2[j], c = polygon2[(j + 1) % polygon2.length], av = alongShoulder(a), cv = alongShoulder(c);
      const ai = greater ? av >= boundary : av <= boundary, ci = greater ? cv >= boundary : cv <= boundary;
      if (ai) result.push(a);
      if (ai !== ci) {
        const t = (boundary - av) / (cv - av);
        result.push([a[0] + (c[0] - a[0]) * t, a[1] + (c[1] - a[1]) * t]);
      }
    }
    return result;
  };
  for (const [part, indices] of parts.entries()) {
    const polygon2 = [];
    for (let i = 0; i < indices.length; i++) {
      const at = indices[i], next = indices[(i + 1) % indices.length];
      if ((at + 1) % feet.length === next) polygon2.push(...rims[at].slice(0, -1).map((p) => p.top));
      else polygon2.push(crown[at]);
    }
    for (let band = 0; band < (part === 2 ? 3 : 1); band++) {
      const face = part === 2 ? clip2(clip2(polygon2, bands[band], true), bands[band + 1], false) : polygon2;
      if (face.length < 3) continue;
      const centre = [face.reduce((sum, p) => sum + p[0], 0) / face.length, face.reduce((sum, p) => sum + p[1], 0) / face.length];
      const mid = [...centre, height(centre, part)];
      for (let i = 0; i < face.length; i++) {
        const p = face[i], q = face[(i + 1) % face.length], a = [...p, height(p, part)], c = [...q, height(q, part)];
        b.quad(a, c, mid, mid, 0, [uv5(a), uv5(c), uv5(mid), uv5(mid)], [0, 0, 1]);
        if (part === 0 && i === 1) fracturedFace(b, a, c, mid);
      }
    }
  }
  for (let edge = 0; edge < feet.length; edge++) {
    const row = rims[edge], part = edge >= 3 && edge <= 6 ? 2 : 0;
    for (let j = 0; j < row.length - 1; j++) {
      const p = row[j], q = row[j + 1], av = alongShoulder(p.top), cv = alongShoulder(q.top);
      const cuts = part === 2 ? [0, ...bands.map((v) => (v - av) / (cv - av)).filter((t) => t > 0 && t < 1), 1].sort((a, c) => a - c) : [0, 1];
      for (let k = 0; k < cuts.length - 1; k++) {
        const lerp2 = (a2, c2, t) => [a2[0] + (c2[0] - a2[0]) * t, a2[1] + (c2[1] - a2[1]) * t];
        const a = lerp2(p.top, q.top, cuts[k]), c = lerp2(p.top, q.top, cuts[k + 1]);
        const af = [...lerp2(p.foot, q.foot, cuts[k]), 0], cf = [...lerp2(p.foot, q.foot, cuts[k + 1]), 0];
        const at = [...a, height(a, part)], ct = [...c, height(c, part)];
        const material = edge === 4 || edge === 5 || edge === 8 || edge === 7 && j === 0 ? 1 : 0;
        b.quad(af, cf, ct, at, material, [uv5(af), uv5(cf), uv5(ct), uv5(at)], [0, 0, 1], material === 1 ? 3 : 0);
      }
    }
  }
}
function fallenBundle(b) {
  const s = b.spec, rows = [];
  const bend = ((Math.imul(s.seed, 1103515245) >>> 0) / 4294967296 - 0.5) * s.distortion * 0.06;
  const widths = [1, 1.16, 1.02, 0.77, 0.64, 0.38];
  const xs = [-0.5, -0.34, -0.1, 0.15, 0.34, 0.5];
  for (let i = 0; i < xs.length; i++) {
    const t = i / (xs.length - 1), x = xs[i] * s.length;
    const centre = s.width * (Math.sin(t * 2.2) * (0.12 + s.fold * 0.06 + bend) - 0.06);
    const radius = s.width * 0.4 * widths[i];
    const peak = s.height * (0.93 - t * 0.48 + Math.sin(t * Math.PI) * 0.1);
    const foot = s.blocking === 1 ? Math.min(7, peak * 0.3) : 0;
    const profile = [[-1, 0], [-0.93, foot / peak], [-0.63, 0.69], [-0.16, 1], [0.32, 0.85], [0.77, 0.41], [0.96, foot / peak], [1, 0]];
    rows.push(profile.map(([across, rise], at) => [
      x + s.length * 0.022 * across * (i === 0 ? 1 : i === xs.length - 1 ? -1 : 0),
      centre + radius * across * (across > 0 ? 0.84 + 0.1 * t : 1),
      at === 0 || at === profile.length - 1 ? 0 : Math.max(foot, peak * rise)
    ]));
  }
  strip(b, rows);
  const count = Math.min(4, s.branches);
  for (let i = 0; i < count; i++) {
    const y = s.width * (0.02 + (i / (count - 1) - 0.5) * 0.22), x = s.length * (0.38 + i % 2 * 0.022);
    section(
      b,
      [
        [x, y - s.width * 0.065],
        [s.length * (0.56 + 0.035 * i), y - s.width * 0.026],
        [s.length * (0.53 + 0.032 * i), y + s.width * 0.019],
        [x, y + s.width * 0.039]
      ],
      (px) => s.height * (0.26 - (px / s.length - 0.38) * 0.63)
    );
  }
}
function clampBank(b) {
  const s = b.spec, rows = [], textureRows = [];
  const along = [-0.5, -0.36, -0.13, 0.12, 0.34, 0.49];
  const breadths = [0.62, 1, 1.14, 0.91, 0.72, 0.35];
  const stations = along.map((t, i) => ({
    x: t * s.length,
    bend: s.width * (0.1 * Math.sin(i * 0.65) - 0.03),
    width: s.width * breadths[i],
    peak: s.height * (0.7 + 0.3 * Math.sin((i + 0.6) / (along.length + 0.2) * Math.PI))
  }));
  const across = [-0.5, -0.46, -0.34, -0.13 - s.fold * 0.045, 0.05, 0.2 + s.opening * 0.035, 0.4, 0.47, 0.5];
  const samples = across.flatMap((a, i) => i === across.length - 1 ? [a] : [a, a + (across[i + 1] - a) / 3, a + (across[i + 1] - a) * 2 / 3]);
  const smoothHeight = (v, values) => {
    const slopes = across.slice(0, -1).map((a, i) => (values[i + 1] - values[i]) / (across[i + 1] - a));
    const tangents = values.map((_value, i) => i === 0 ? slopes[0] : i === values.length - 1 ? slopes[i - 1] : slopes[i - 1] * slopes[i] <= 0 ? 0 : 2 / (1 / slopes[i - 1] + 1 / slopes[i]));
    const index = Math.min(across.length - 2, Math.max(0, across.findIndex((a) => a > v) - 1));
    const span = across[index + 1] - across[index], t = (v - across[index]) / span;
    return (2 * t ** 3 - 3 * t * t + 1) * values[index] + (t ** 3 - 2 * t * t + t) * span * tangents[index] + (-2 * t ** 3 + 3 * t * t) * values[index + 1] + (t ** 3 - t * t) * span * tangents[index + 1];
  };
  const subdivisions = 2;
  for (let at = 0; at <= (stations.length - 1) * subdivisions; at++) {
    const segment = Math.min(stations.length - 2, Math.floor(at / subdivisions)), t = at / subdivisions - segment;
    const a = stations[segment], c = stations[segment + 1], u = at / ((stations.length - 1) * subdivisions);
    const lerp2 = (p, q) => p + (q - p) * t;
    const x = lerp2(a.x, c.x), width = lerp2(a.width, c.width), bend = lerp2(a.bend, c.bend);
    const peak = lerp2(a.peak, c.peak), foot = s.blocking === 1 ? Math.min(8, peak * 0.32) : 0;
    const pressure = Math.sin(Math.PI * u) ** 2, shoulder = 0.5 + 0.5 * Math.cos(u * Math.PI * 1.7 + 0.4);
    const profile = [
      0,
      foot / peak,
      0.54 + shoulder * 0.08,
      1,
      0.84 + pressure * 0.09,
      0.31 + shoulder * 0.16,
      0.13 + pressure * 0.09,
      foot / peak,
      0
    ];
    const row = samples.map((v, j) => {
      const isFoot = j === 0 || j === samples.length - 1;
      const end = Math.min(9, s.length * 0.038) * ((1 - u) ** 12 - u ** 12);
      const tear = 0.42 + 0.58 * Math.max(0, 1 - Math.abs((v - 0.1) / 0.35));
      return [
        x + s.length * 0.028 * v + (isFoot ? 0 : end * tear),
        bend + width * v,
        isFoot ? 0 : Math.max(foot * 0.6, peak * smoothHeight(v, profile))
      ];
    });
    let arc = 0;
    const texels = row.map((point, j) => {
      if (j) {
        const previous = row[j - 1];
        arc += Math.hypot(point[1] - previous[1], point[2] - previous[2]);
      }
      return [x, arc];
    });
    rows.push(row);
    textureRows.push(texels);
  }
  for (let i = 0; i < rows.length - 1; i++) for (let j = 0; j < samples.length - 1; j++) {
    const a = rows[i][j], c = rows[i + 1][j], d = rows[i + 1][j + 1], e = rows[i][j + 1];
    const edge = j === 0 || j === samples.length - 2, inner = samples[j] >= 0.05;
    const slot = edge ? 1 : inner ? 2 : 0;
    b.quad(a, c, d, e, slot, [
      textureRows[i][j],
      textureRows[i + 1][j],
      textureRows[i + 1][j + 1],
      textureRows[i][j + 1]
    ], [0, 0, 1], edge ? 3 : inner ? 1 : 0);
    if (i === Math.floor((rows.length - 1) * 0.34) && j === 10) fracturedFace(b, a, c, d);
  }
  for (const index of [0, rows.length - 1]) {
    const row = rows[index], station = stations[index === 0 ? 0 : stations.length - 1];
    for (let j = 0; j < row.length - 1; j++) {
      const a = row[j], c = row[j + 1], af = [station.x + s.length * 0.028 * samples[j], a[1], 0], cf = [station.x + s.length * 0.028 * samples[j + 1], c[1], 0];
      b.quad(af, cf, c, a, 1, [[0, a[1]], [0, c[1]], [c[2], c[1]], [a[2], a[1]]], [0, 0, 1], 3);
    }
  }
}
function tornSheet(b) {
  const s = b.spec;
  const outline = [
    [-0.5, -0.23],
    [-0.29, -0.48],
    [0.13, -0.37],
    [0.4, -0.26],
    [0.51, -0.03],
    [0.34, 0.29],
    [0.23, 0.13],
    [0.04, -0.02],
    [0.13, 0.23],
    [-0.1, 0.49],
    [-0.37, 0.34],
    [-0.28, 0.13],
    [-0.46, 0.02]
  ];
  const feet = outline.map(([x, y]) => [x * s.length, y * s.width]);
  const depths = [0.18, 0.1, 0.16, 0.3, 0.52, 0.94, 0.62, 0.28, 0.72, 1, 0.47, 0.23, 0.14];
  const breadth = Math.min(s.blocking === 1 ? 4 : 1.2, Math.min(s.length, s.width) * 0.035);
  const inward = (a, c) => {
    const dx = c[0] - a[0], dy = c[1] - a[1], size = Math.hypot(dx, dy);
    return [-dy / size, dx / size];
  };
  const crown = feet.map((p, i) => {
    const a = inward(feet[(i + feet.length - 1) % feet.length], p), c = inward(p, feet[(i + 1) % feet.length]);
    const dx = a[0] + c[0], dy = a[1] + c[1], size = Math.hypot(dx, dy);
    return [p[0] + dx / size * breadth * depths[i], p[1] + dy / size * breadth * depths[i]];
  });
  const parts = [[0, 1, 2, 7, 11, 12], [11, 7, 8, 9, 10], [2, 3, 4, 5, 6, 7]];
  const clamp3 = (value) => Math.max(0, Math.min(1, value));
  const smooth2 = (value) => {
    const t = clamp3(value);
    return t * t * (3 - 2 * t);
  };
  const phase2 = ([x, y]) => y / s.width + (0.18 + s.fold * 0.1) * x / s.length;
  const height = (point) => {
    const v = phase2(point), x = point[0] / s.length;
    const lift = v < -0.25 ? 0.035 : v < 0.17 ? 0.035 + 0.965 * smooth2((v + 0.25) / 0.42) : 1 - 0.71 * smooth2((v - 0.17) / 0.25);
    const amplitude = 0.56 + 0.44 * smooth2((0.38 - x) / 0.86);
    const foot = s.blocking === 1 ? Math.min(3.5, s.height * 0.16) : 0;
    return foot + (s.height - foot) * (0.025 + amplitude * lift);
  };
  const clip2 = (polygon2, axis, boundary, greater) => {
    const result = [];
    for (let j = 0; j < polygon2.length; j++) {
      const a = polygon2[j], c = polygon2[(j + 1) % polygon2.length], av = a[axis], cv = c[axis];
      const ai = greater ? av >= boundary : av <= boundary, ci = greater ? cv >= boundary : cv <= boundary;
      if (ai) result.push(a);
      if (ai !== ci) {
        const t = (boundary - av) / (cv - av);
        result.push([a[0] + (c[0] - a[0]) * t, a[1] + (c[1] - a[1]) * t]);
      }
    }
    return result;
  };
  const xs = [-0.52, -0.36, -0.18, 0.1, 0.27, 0.4, 0.53].map((x) => x * s.length);
  const ys = [-0.52, -0.35, -0.25, -0.16, -0.05, 0.035, 0.1, 0.16, 0.22, 0.28, 0.35, 0.43, 0.55].map((y) => y * s.width);
  for (const [part, indices] of parts.entries()) for (let x = 0; x < xs.length - 1; x++) for (let y = 0; y < ys.length - 1; y++) {
    const polygon2 = clip2(clip2(clip2(clip2(indices.map((i) => crown[i]), 0, xs[x], true), 0, xs[x + 1], false), 1, ys[y], true), 1, ys[y + 1], false);
    if (polygon2.length < 3) continue;
    const points = polygon2.map((p) => [...p, height(p)]);
    const centre = [polygon2.reduce((sum, p) => sum + p[0], 0) / polygon2.length, polygon2.reduce((sum, p) => sum + p[1], 0) / polygon2.length];
    const material = phase2(centre) > 0.17 ? 2 : 0;
    for (let i = 1; i < points.length - 1; i++) {
      const a = points[0], c = points[i], d = points[i + 1];
      b.quad(a, c, d, d, material, [uv5(a), uv5(c), uv5(d), uv5(d)], [0, 0, 1], 4);
      if (part === 0 && x === 2 && y === 3 && i === 1) fracturedFace(b, a, c, d);
    }
  }
  for (let edge = 0; edge < feet.length; edge++) {
    const next = (edge + 1) % feet.length, a = crown[edge], c = crown[next], af = feet[edge], cf = feet[next];
    const cuts = [0, ...xs.map((v) => (v - a[0]) / (c[0] - a[0])), ...ys.map((v) => (v - a[1]) / (c[1] - a[1])), 1].filter((t) => t >= 0 && t <= 1).sort((x, y) => x - y);
    const at = (u, v, t) => [u[0] + (v[0] - u[0]) * t, u[1] + (v[1] - u[1]) * t];
    for (let i = 0; i < cuts.length - 1; i++) {
      if (cuts[i + 1] - cuts[i] < 1e-9) continue;
      const p = at(a, c, cuts[i]), q = at(a, c, cuts[i + 1]);
      const pFoot = [...at(af, cf, cuts[i]), 0], qFoot = [...at(af, cf, cuts[i + 1]), 0];
      const pTop = [...p, height(p)], qTop = [...q, height(q)];
      const material = edge === 5 || edge === 6 || edge === 8 || edge === 9 ? 1 : 0;
      b.quad(pFoot, qFoot, qTop, pTop, material, [uv5(pFoot), uv5(qFoot), uv5(qTop), uv5(pTop)], [0, 0, 1], material === 1 ? 3 : 4);
    }
  }
}
function buildGroundNativeVolume(builder) {
  switch (builder.spec.shapeProfile) {
    case "fracture-fan":
      fractureFan(builder);
      return;
    case "fallen-bundle":
      fallenBundle(builder);
      return;
    case "clamp-bank":
      clampBank(builder);
      return;
    case "torn-sheet":
      tornSheet(builder);
      return;
    case "compressed-wedge":
      buildCompressedWedge(builder);
      return;
    case "porous-break":
      buildPorousBreak(builder);
      return;
    case "settled-sheet":
      buildSettledSheet(builder);
      return;
    case "settled-fan":
      buildSettledFan(builder);
      return;
    case "settled-bundle":
      buildSettledProjection(builder, fallenBundle, true);
      return;
    case "settled-clamp":
      buildSettledProjection(builder, clampBank, false);
      return;
    default:
      throw new Error("Unknown construction 4 native shape profile");
  }
}

// src/generation/world-study/native-volume-ground-edge.ts
function distance(p, a, b) {
  const x = b.x - a.x, y = b.y - a.y, length2 = x * x + y * y;
  const t = Math.max(0, Math.min(1, ((p.x - a.x) * x + (p.y - a.y) * y) / length2));
  return Math.hypot(p.x - a.x - x * t, p.y - a.y - y * t);
}
function appendNativeGroundEdges(b, context) {
  const width = b.spec.groundEdgeWidth;
  if (width === void 0) return;
  if (!context || !context.polygons.length || typeof context.matterAt !== "function" || !Number.isInteger(context.width / 8) || !Number.isInteger(context.height / 8) || context.width <= 0 || context.height <= 0 || context.width * context.height > 4194304)
    throw new Error("Ground edge requires the complete bounded authoritative terrain context");
  const triangleBudget = context.width <= 1280 && context.height <= 1024 ? 2048 : 20480;
  const cosine = Math.cos(b.spec.rotation), sine = Math.sin(b.spec.rotation);
  const local = (x, y, z) => {
    const dx = x - b.spec.x, dy = y - b.spec.y;
    return [dx * cosine + dy * sine, -dx * sine + dy * cosine, z];
  };
  const nearest = (x, y) => {
    let result = Infinity;
    for (const polygon2 of context.polygons) for (let i = 0; i < polygon2.length; i++) result = Math.min(result, distance({ x, y }, polygon2[i], polygon2[(i + 1) % polygon2.length]));
    return result;
  };
  const heightAt = (x, y) => {
    const t = Math.min(1, nearest(x, y) / width);
    return b.spec.height * (t < 0.3 ? t / 0.3 : (1 - t) / 0.7);
  };
  const normalRunsAcrossX = (x, y) => {
    let nearestSquared = Infinity, acrossX = true;
    for (const polygon2 of context.polygons) for (let i = 0; i < polygon2.length; i++) {
      const a = polygon2[i], c = polygon2[(i + 1) % polygon2.length], dx = c.x - a.x, dy = c.y - a.y;
      const t = Math.max(0, Math.min(1, ((x - a.x) * dx + (y - a.y) * dy) / (dx * dx + dy * dy)));
      const nx = x - a.x - dx * t, ny = y - a.y - dy * t, squared = nx * nx + ny * ny;
      if (squared < nearestSquared) {
        nearestSquared = squared;
        acrossX = squared < 1e-12 ? Math.abs(dy) >= Math.abs(dx) : Math.abs(nx) >= Math.abs(ny);
      }
    }
    return acrossX;
  };
  let previousPeak = 0;
  const cells = /* @__PURE__ */ new Map();
  const horizontalMidpoints = /* @__PURE__ */ new Set(), verticalMidpoints = /* @__PURE__ */ new Set();
  const stride = context.width / 8 + 1;
  for (const polygon2 of context.polygons) {
    const minX = Math.max(0, Math.floor((Math.min(...polygon2.map((p) => p.x)) - width) / 8));
    const maxX = Math.min(context.width / 8 - 1, Math.floor((Math.max(...polygon2.map((p) => p.x)) + width) / 8));
    const minY = Math.max(0, Math.floor((Math.min(...polygon2.map((p) => p.y)) - width) / 8));
    const maxY = Math.min(context.height / 8 - 1, Math.floor((Math.max(...polygon2.map((p) => p.y)) + width) / 8));
    for (let row = minY; row <= maxY; row++) for (let col = minX; col <= maxX; col++) {
      const key = row * (context.width / 8) + col, x = col * 8, y = row * 8;
      if (cells.has(key) || !context.matterAt(x + 4, y + 4) || nearest(x + 4, y + 4) > width + 6) continue;
      previousPeak = Math.max(
        previousPeak,
        heightAt(x, y),
        heightAt(x + 8, y),
        heightAt(x + 8, y + 8),
        heightAt(x, y + 8),
        heightAt(x + 4, y + 4)
      );
      const acrossX = normalRunsAcrossX(x + 4, y + 4);
      const samples = [
        [x, y],
        [x + 8, y],
        [x + 8, y + 8],
        [x, y + 8],
        [x + 4, y],
        [x + 4, y + 8],
        [x, y + 4],
        [x + 8, y + 4]
      ];
      if (samples.every((p) => heightAt(p[0], p[1]) === 0)) continue;
      cells.set(key, { col, row, acrossX });
      if (acrossX) {
        horizontalMidpoints.add(row * stride + col);
        horizontalMidpoints.add((row + 1) * stride + col);
      } else {
        verticalMidpoints.add(row * stride + col);
        verticalMidpoints.add(row * stride + col + 1);
      }
    }
  }
  let triangles = 0, nextPeak = 0;
  const faces = [];
  const face = (polygon2) => {
    triangles += polygon2.length - 2;
    if (triangles > triangleBudget) throw new Error(`Authored ground cut exceeds the ${triangleBudget}-triangle edge budget`);
    faces.push(polygon2);
    for (const p of polygon2) nextPeak = Math.max(nextPeak, heightAt(p[0], p[1]));
  };
  for (const { col, row, acrossX } of cells.values()) {
    const x = col * 8, y = row * 8;
    const a = [x, y], c = [x + 8, y], d = [x + 8, y + 8], e = [x, y + 8];
    const top = [x + 4, y], right = [x + 8, y + 4], bottom = [x + 4, y + 8], left = [x, y + 4];
    if (acrossX) {
      face([top, bottom, e, ...verticalMidpoints.has(row * stride + col) ? [left] : [], a]);
      face([top, c, ...verticalMidpoints.has(row * stride + col + 1) ? [right] : [], d, bottom]);
    } else {
      face([left, a, ...horizontalMidpoints.has(row * stride + col) ? [top] : [], c, right]);
      face([left, right, d, ...horizontalMidpoints.has((row + 1) * stride + col) ? [bottom] : [], e]);
    }
  }
  if (triangles === 0 || nextPeak === 0) throw new Error("Authored ground edge produced no present material");
  const heightScale = previousPeak > 0 ? previousPeak / nextPeak : 1;
  for (const polygon2 of faces) {
    const points = polygon2.map((p) => local(p[0], p[1], heightAt(p[0], p[1]) * heightScale));
    for (let i = 1; i < polygon2.length - 1; i++) b.quad(
      points[0],
      points[i],
      points[i + 1],
      points[i + 1],
      1,
      [polygon2[0], polygon2[i], polygon2[i + 1], polygon2[i + 1]],
      [0, 0, 1],
      3
    );
  }
}

// src/generation/world-study/native-volume-geometry.ts
var NATIVE_VOLUME_REGIONS = { intact: 0, compressed: 1, peeled: 2, fractured: 3, tension: 4, glazed: 5 };
var TAU2 = Math.PI * 2;
var clamp2 = (v, low, high) => Math.max(low, Math.min(high, v));
function phase(seed2, salt) {
  let a = Math.imul((seed2 | 0) ^ salt, 73244475);
  a = Math.imul(a ^ a >>> 16, 73244475);
  return ((a ^ a >>> 16) >>> 0) / 4294967296;
}
function validateNativeVolumeSpec(spec) {
  const numbers = ["id", "seed", "x", "y", "rotation", "length", "width", "height", "thickness", "fold", "branches", "opening", "distortion"];
  const keys = /* @__PURE__ */ new Set([...numbers, "family", "blocking", "constructionVersion", "shapeProfile", "groundEdgeWidth"]);
  if (Object.keys(spec).some((key) => !keys.has(key)) || numbers.some((key) => !Number.isFinite(spec[key])))
    throw new Error("Native volume must contain exactly the known required numeric fields");
  for (const [key, value] of Object.entries(spec)) {
    if (key !== "family" && key !== "shapeProfile" && !((key === "blocking" || key === "constructionVersion") && value === void 0) && (typeof value !== "number" || !Number.isFinite(value))) {
      throw new Error(`Native volume ${key} must be finite`);
    }
  }
  if (!["folded-slab", "fibre-knot", "broken-shell", "granular-ridge", "membrane-rim", "gel-flow"].includes(spec.family)) throw new Error("Unknown native volume family");
  if (!Number.isInteger(spec.id) || spec.id < 1 || spec.id > 2147483647) throw new Error("Volume id must be a positive Int32");
  if (!Number.isInteger(spec.seed)) throw new Error("Volume seed must be an integer");
  if (spec.constructionVersion !== void 0 && ![1, 2, 3, 4].includes(spec.constructionVersion)) throw new Error("Native volume constructionVersion must be 1, 2, 3 or 4");
  const profiles = spec.constructionVersion === 4 ? NATIVE_VOLUME_V4_PROFILES : spec.constructionVersion === 3 ? NATIVE_VOLUME_SHAPE_PROFILES : [];
  if (profiles.length ? !profiles.includes(spec.shapeProfile) : spec.shapeProfile !== void 0)
    throw new Error("Native volume shapeProfile must belong to its explicit construction version");
  if (spec.blocking !== void 0 && spec.blocking !== 0 && spec.blocking !== 1) throw new Error("Native volume blocking must be 0 or 1");
  if (spec.shapeProfile?.startsWith("settled-") && (spec.blocking !== 0 || spec.height > 6))
    throw new Error("Settled material requires explicit nonblocking material with height at most 6");
  if (spec.groundEdgeWidth !== void 0 && (spec.constructionVersion !== 4 || spec.blocking !== 0 || spec.height > 6 || spec.groundEdgeWidth < 8 || spec.groundEdgeWidth > 24)) throw new Error("Native ground edge requires v4 low relief and width 8\u201324px");
  if (spec.length < 16 || spec.width < 12 || spec.height < 2 || spec.thickness < 1 || spec.length > 2048 || spec.width > 2048 || spec.height > 512 || spec.thickness > Math.min(spec.length, spec.width) * 0.45) throw new Error("Native volume dimensions outside bounded construction range");
  for (const key of ["fold", "opening", "distortion"]) {
    if (spec[key] < 0 || spec[key] > 1) throw new Error(`Native volume ${key} must be in [0, 1]`);
  }
  if (!Number.isInteger(spec.branches) || spec.branches < 2 || spec.branches > 8) throw new Error("Native volume branches must be an integer in [2, 8]");
}
var MeshBuilder = class {
  constructor(spec) {
    this.spec = spec;
    this.cosine = Math.cos(spec.rotation);
    this.sine = Math.sin(spec.rotation);
  }
  groundEdgeStart;
  points = [];
  normalData = [];
  texels = [];
  triangles = [];
  slots = [];
  regions = [];
  joints = [];
  bounds = { minX: Infinity, minY: Infinity, maxX: -Infinity, maxY: -Infinity, maxZ: 0 };
  cosine;
  sine;
  vertex(p, uv6, n) {
    const x = this.spec.x + p[0] * this.cosine - p[1] * this.sine;
    const y = this.spec.y + p[0] * this.sine + p[1] * this.cosine;
    const z = Math.max(0, p[2]);
    this.bounds.minX = Math.min(this.bounds.minX, x);
    this.bounds.maxX = Math.max(this.bounds.maxX, x);
    this.bounds.minY = Math.min(this.bounds.minY, y);
    this.bounds.maxY = Math.max(this.bounds.maxY, y);
    this.bounds.maxZ = Math.max(this.bounds.maxZ, z);
    const index = this.points.length / 3;
    this.points.push(x, y, z);
    this.normalData.push(n[0] * this.cosine - n[1] * this.sine, n[0] * this.sine + n[1] * this.cosine, n[2]);
    this.texels.push(uv6[0], uv6[1]);
    return index;
  }
  quad(a, b, c, d, material, uvs, wanted, region = 0) {
    const triangle = (p, q, r, up, uq, ur) => {
      const ux = q[0] - p[0], uy = q[1] - p[1], uz = q[2] - p[2], vx = r[0] - p[0], vy = r[1] - p[1], vz = r[2] - p[2];
      let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
      const size = Math.hypot(nx, ny, nz);
      if (size < 1e-6) return;
      nx /= size;
      ny /= size;
      nz /= size;
      if (wanted && nx * wanted[0] + ny * wanted[1] + nz * wanted[2] < 0) {
        nx = -nx;
        ny = -ny;
        nz = -nz;
      }
      const normal = [nx, ny, nz];
      this.triangles.push(this.vertex(p, up, normal), this.vertex(q, uq, normal), this.vertex(r, ur, normal));
      this.slots.push(material);
      this.regions.push(region);
    };
    triangle(a, b, c, uvs[0], uvs[1], uvs[2]);
    triangle(a, c, d, uvs[0], uvs[2], uvs[3]);
  }
  joint(p) {
    this.joints.push({
      index: this.joints.length,
      x: this.spec.x + p[0] * this.cosine - p[1] * this.sine,
      y: this.spec.y + p[0] * this.sine + p[1] * this.cosine,
      z: p[2]
    });
  }
  beginGroundEdges() {
    this.groundEdgeStart = Object.freeze({ vertex: this.points.length / 3, triangle: this.slots.length });
  }
  finish() {
    const heightScale = this.spec.height / Math.max(1, this.bounds.maxZ);
    for (let i = 0; i < this.points.length; i += 3) {
      this.points[i + 2] = this.points[i + 2] * heightScale;
      const nx = this.normalData[i], ny = this.normalData[i + 1], nz = this.normalData[i + 2] / heightScale;
      const length2 = Math.hypot(nx, ny, nz) || 1;
      this.normalData[i] = nx / length2;
      this.normalData[i + 1] = ny / length2;
      this.normalData[i + 2] = nz / length2;
    }
    for (const joint of this.joints) joint.z *= heightScale;
    this.bounds.maxZ = this.spec.height;
    return {
      spec: Object.freeze({ ...this.spec }),
      positions: new Float32Array(this.points),
      normals: new Float32Array(this.normalData),
      uv: new Float32Array(this.texels),
      indices: new Uint32Array(this.triangles),
      materials: new Uint8Array(this.slots),
      regions: new Uint8Array(this.regions),
      vertexCount: this.points.length / 3,
      triangleCount: this.slots.length,
      ...this.groundEdgeStart ? { groundEdgeStart: this.groundEdgeStart } : {},
      bounds: Object.freeze(this.bounds),
      joints: this.joints
    };
  }
};
function foldedSlab(b) {
  const s = b.spec, l = s.length, w = s.width, h = s.height;
  const shift = (phase(s.seed, 101) - 0.5) * 0.05;
  const thrust = (s.fold - 0.5) * 0.075;
  const px = (x) => (x + shift) * l;
  const py = (y) => y * w;
  const near = (ratio) => Math.min(h * ratio, 19 + s.thickness * 0.22);
  const a = [
    [-l * 0.51, py(-0.14), 0],
    [-l * 0.37, py(-0.37), h * 0.33],
    [px(-0.15), py(-0.43), h * 0.6424],
    [px(0.025), py(-0.2), h * 0.486],
    [px(-0.014), py(0.058 + thrust), near(0.31056 - thrust * 0.68)],
    [px(-0.19), py(0.235), near(0.1902)],
    [-l * 0.42, py(0.135), h * 0.025]
  ];
  const c = [
    [px(0.035), py(-0.3), h * 0.7028],
    [px(0.22), py(-0.49), h * 0.9836],
    [l * 0.49, py(-0.27), h * 0.16],
    [l * 0.46, py(-5e-3), h * 0.025],
    [px(0.24), py(0.095), near(0.1662)],
    [px(0.085), py(-0.025), near(0.3218)]
  ];
  const outlet = [
    [px(-0.26), py(0.3), near(0.11)],
    [px(-0.075), py(0.135 + thrust), near(0.21)],
    [px(0.09), py(0.13 + thrust), near(0.19)],
    [px(0.265), py(0.35), near(0.08)],
    [px(0.095), py(0.535), 0],
    [px(-0.15), py(0.49), h * 0.018]
  ];
  const plane = (outline, peak, dx, dy) => {
    const depth = outline.map((p) => p[0] * dx + p[1] * dy), min = Math.min(...depth), span = Math.max(...depth) - min;
    for (let i = 0; i < outline.length; i++) outline[i] = [outline[i][0], outline[i][1], (depth[i] - min) / span * peak];
    const x = outline.reduce((n, p) => n + p[0], 0) / outline.length, y = outline.reduce((n, p) => n + p[1], 0) / outline.length;
    return [x, y, (x * dx + y * dy - min) / span * peak];
  };
  const aCentre = plane(a, h * 0.73, 0.16, -1);
  const cCentre = plane(c, h, -0.35, -1);
  const outletCentre = plane(outlet, near(0.25), 0.13, -1);
  bedMass(b, a, aCentre, 0, [3, 4], Math.min(24, Math.max(9, w * 0.12)));
  bedMass(b, c, cCentre, 1, [4, 5], Math.min(21, Math.max(8, w * 0.105)));
  bedMass(b, outlet, outletCentre, 2, [0, 1], Math.min(17, Math.max(7, w * 0.085)));
}
function bedMass(b, top, centre, salt, faultEdges, cutWidth) {
  const n = top.length, s = b.spec;
  const lerp2 = (a, c, t) => [a[0] + (c[0] - a[0]) * t, a[1] + (c[1] - a[1]) * t, a[2] + (c[2] - a[2]) * t];
  const footHeight = s.blocking === 1 ? Math.min(s.height * 0.42, 8.5 + salt * 0.9 + phase(s.seed, 810 + salt) * 1.2) : 0;
  const lift = (p) => footHeight > 0 ? [p[0], p[1], footHeight + p[2] * (1 - footHeight / s.height)] : p;
  const surfaceCentre = lift(centre);
  const rim = [];
  let distance3 = 0;
  const mouthPeak = 0.43 + phase(s.seed, 700 + salt) * 0.16;
  for (let i = 0; i < n; i++) {
    const p = top[i], q = top[(i + 1) % n], rank = faultEdges.indexOf(i), fault = rank >= 0;
    const subdivisions = fault ? 5 : 1;
    const edgeLength = Math.hypot(q[0] - p[0], q[1] - p[1]);
    for (let j = 0; j < subdivisions; j++) {
      const t = j / subdivisions, at = lerp2(p, q, t), along = (rank + t) / faultEdges.length;
      const lobe = fault ? clamp2(along < mouthPeak ? along / mouthPeak : (1 - along) / (1 - mouthPeak), 0, 1) : 0;
      const mouth = lobe * lobe * (3 - 2 * lobe);
      const radius = Math.hypot(at[0] - centre[0], at[1] - centre[1]) || 1;
      const nx = (at[0] - centre[0]) / radius, ny = (at[1] - centre[1]) / radius;
      const inset = cutWidth * mouth * (salt === 2 ? 0.52 : 0.78);
      let lip = lerp2(at, centre, Math.min(0.26, inset / radius));
      const burial = clamp2(at[2] / Math.max(3, s.height * 0.16), 0, 1);
      const spread = cutWidth * burial * (fault ? 0.13 + mouth * 1.8 : 0.26);
      const foot = [at[0] + nx * spread, at[1] + ny * spread, 0];
      if (footHeight > 0) {
        const sectionWidth = 6.5 + phase(s.seed, 830 + salt) * 1.5 + (at[0] / s.length + 0.5) * 1.1 + mouth * 0.8;
        const run = Math.hypot(lip[0] - foot[0], lip[1] - foot[1]);
        const lowEnd = 1 - clamp2(at[2] / (footHeight * 2), 0, 1);
        const toCentre = Math.hypot(lip[0] - centre[0], lip[1] - centre[1]) || 1;
        lip = lerp2(lip, centre, clamp2((sectionWidth - run) * lowEnd / toCentre, 0, 0.34));
      }
      const shoulder = lift(lerp2(lip, centre, Math.min(0.34, (5 + cutWidth * 0.7) * mouth / radius)));
      lip = lift(lip);
      rim.push({ top: lip, foot, shoulder, mouth, distance: distance3 + edgeLength * t, fault });
    }
    distance3 += edgeLength;
  }
  let contactPlaced = false;
  for (let i = 0; i < rim.length; i++) {
    const next = (i + 1) % rim.length, a = rim[i], c = rim[next];
    const region = salt === 2 ? NATIVE_VOLUME_REGIONS.compressed : NATIVE_VOLUME_REGIONS.intact;
    const topUv = (p) => [p[0], p[1]];
    b.quad(
      surfaceCentre,
      a.shoulder,
      c.shoulder,
      surfaceCentre,
      0,
      [topUv(surfaceCentre), topUv(a.shoulder), topUv(c.shoulder), topUv(surfaceCentre)],
      [0, 0, 1],
      region
    );
    b.quad(
      a.shoulder,
      a.top,
      c.top,
      c.shoulder,
      0,
      [topUv(a.shoulder), topUv(a.top), topUv(c.top), topUv(c.shoulder)],
      [0, 0, 1],
      NATIVE_VOLUME_REGIONS.peeled
    );
    const endDistance = next === 0 ? distance3 : c.distance;
    const sideUv = (p, d) => [d, p[2]];
    const open = a.fault && Math.max(a.mouth, c.mouth) > 0.08;
    b.quad(
      a.top,
      a.foot,
      c.foot,
      c.top,
      open ? 1 : 0,
      [sideUv(a.top, a.distance), sideUv(a.foot, a.distance), sideUv(c.foot, endDistance), sideUv(c.top, endDistance)],
      [0, 0, 1],
      open ? NATIVE_VOLUME_REGIONS.fractured : region
    );
    b.quad(
      [centre[0], centre[1], 0],
      c.foot,
      a.foot,
      [centre[0], centre[1], 0],
      2,
      [topUv(centre), topUv(c.foot), topUv(a.foot), topUv(centre)],
      [0, 0, -1],
      NATIVE_VOLUME_REGIONS.intact
    );
    if (salt === 0 && !contactPlaced && a.fault && a.mouth > 0.5 && c.mouth > a.mouth) {
      const point = (t, v) => [
        a.top[0] + t * (c.foot[0] - a.top[0]) + v * (a.foot[0] - a.top[0]),
        a.top[1] + t * (c.foot[1] - a.top[1]) + v * (a.foot[1] - a.top[1]),
        a.top[2] + t * (c.foot[2] - a.top[2]) + v * (a.foot[2] - a.top[2]) + 0.055
      ];
      const p0 = point(0.08, 0.08), p1 = point(0.46, 0.08), p2 = point(0.46, 0.42), p3 = point(0.08, 0.42);
      b.quad(p0, p3, p2, p1, 3, [[0, 0], [0, 6], [12, 6], [12, 0]], [0, 0, 1], NATIVE_VOLUME_REGIONS.compressed);
      b.joint([(p0[0] + p1[0] + p2[0] + p3[0]) * 0.25, (p0[1] + p1[1] + p2[1] + p3[1]) * 0.25, (p0[2] + p1[2] + p2[2] + p3[2]) * 0.25]);
      contactPlaced = true;
    }
  }
}
function fibreKnot(b) {
  const s = b.spec, l = s.length, w = s.width, h = s.height;
  const knotX = l * (-0.08 + (phase(s.seed, 211) - 0.5) * 0.045), knotY = w * (0.05 + 0.12 * s.distortion + (phase(s.seed, 213) - 0.5) * 0.035);
  const main = [
    [-l * 0.51, -w * 0.16, s.thickness * 0.6],
    [-l * 0.3, -w * 0.08, h * 0.27],
    [knotX, knotY, h * 0.57],
    [l * 0.18, w * 0.02, h * 0.38],
    [l * 0.5, w * 0.19, s.thickness * 0.63]
  ];
  sweptBundle(b, main, w * 0.145, 0);
  const cross4 = [
    [-l * 0.24, w * 0.48, s.thickness * 0.44],
    [-l * 0.18, w * 0.28, h * 0.29],
    [knotX + w * 0.07, knotY, h * 0.82],
    [l * 0.04, -w * 0.15, h * 0.45],
    [l * 0.15, -w * 0.46, s.thickness * 0.51]
  ];
  sweptBundle(b, cross4, w * 0.08, 1);
  if (s.branches >= 3) {
    const subordinate = [
      [l * 0.41, -w * 0.38, s.thickness * 0.36],
      [l * 0.2, -w * 0.16, h * 0.25],
      [knotX + w * 0.06, knotY - w * 0.045, h * 0.69],
      [-l * 0.13, w * 0.26, h * 0.35]
    ];
    sweptBundle(b, subordinate, w * 0.047, 2);
  }
  b.joint([knotX + w * 0.04, knotY, h * 0.84]);
}
function sweptBundle(b, spine, radius, salt) {
  const s = b.spec, cross4 = 18, steps = (spine.length - 1) * 8;
  const rings = [];
  for (let i = 0; i <= steps; i++) {
    const whole = i / steps * (spine.length - 1), segment = Math.min(spine.length - 2, Math.floor(whole));
    const t = i === steps ? 1 : whole - segment;
    const a = spine[segment], c = spine[segment + 1];
    const before = spine[Math.max(0, segment - 1)], after = spine[Math.min(spine.length - 1, segment + 2)];
    const curve = (channel, q) => 0.5 * (2 * a[channel] + (-before[channel] + c[channel]) * q + (2 * before[channel] - 5 * a[channel] + 4 * c[channel] - after[channel]) * q * q + (-before[channel] + 3 * a[channel] - 3 * c[channel] + after[channel]) * q * q * q);
    const tangent = (channel) => 0.5 * (-before[channel] + c[channel] + 2 * (2 * before[channel] - 5 * a[channel] + 4 * c[channel] - after[channel]) * t + 3 * (-before[channel] + 3 * a[channel] - 3 * c[channel] + after[channel]) * t * t);
    const dx = tangent(0), dy = tangent(1), len = Math.hypot(dx, dy) || 1;
    const vx = -dy / len, vy = dx / len, along = i / steps;
    const clampWidth = 1 - Math.exp(-Math.pow((along - 0.5) / 0.16, 2)) * (salt === 0 ? 0.3 : 0.12);
    const rootTaper = 0.28 + Math.pow(Math.sin(along * Math.PI), 0.7) * 0.75;
    const r = radius * rootTaper * clampWidth;
    const cx = curve(0, t), cy = curve(1, t), cz = Math.max(r * (s.constructionVersion === 2 ? 0.78 : 0.62), curve(2, t));
    const ring = [];
    for (let j = 0; j < cross4; j++) {
      const angle = j / cross4 * TAU2;
      const root = Math.pow(Math.abs(along - 0.5) * 2, 5);
      const flute = 1 + Math.cos(angle * 5 + salt + along * 3) * (0.045 + 0.07 * root);
      ring.push([
        cx + vx * Math.cos(angle) * r * flute,
        cy + vy * Math.cos(angle) * r * flute,
        cz + Math.sin(angle) * r * (0.57 + 0.19 * Math.sin(along * Math.PI))
      ]);
    }
    rings.push(ring);
  }
  for (let i = 0; i < steps; i++) for (let j = 0; j < cross4; j++) {
    const a = rings[i], c = rings[i + 1], k = (j + 1) % cross4;
    const slot = salt > 0 && i > steps * 0.45 && i < steps * 0.54 && j > 2 && j < 5 ? 3 : 0;
    b.quad(
      a[j],
      c[j],
      c[k],
      a[k],
      slot,
      [
        [i * s.length / steps, j * radius * TAU2 / cross4],
        [(i + 1) * s.length / steps, j * radius * TAU2 / cross4],
        [(i + 1) * s.length / steps, (j + 1) * radius * TAU2 / cross4],
        [i * s.length / steps, (j + 1) * radius * TAU2 / cross4]
      ]
    );
    if (s.constructionVersion === 2 && salt === 1 && i === Math.floor(steps * 0.5) && j === 3) {
      b.joint([
        (a[j][0] + c[j][0] + c[k][0]) / 3,
        (a[j][1] + c[j][1] + c[k][1]) / 3,
        (a[j][2] + c[j][2] + c[k][2]) / 3 + 0.055
      ]);
    }
  }
  for (const end of [0, steps]) {
    const r = rings[end];
    const middle = [
      r.reduce((sum, p) => sum + p[0], 0) / cross4,
      r.reduce((sum, p) => sum + p[1], 0) / cross4,
      r.reduce((sum, p) => sum + p[2], 0) / cross4
    ];
    for (let j = 0; j < cross4; j++) {
      const k = (j + 1) % cross4;
      b.quad(middle, r[j], r[k], middle, end === 0 ? 1 : 2, [[0, 0], [j, radius], [j + 1, radius], [0, 0]]);
    }
  }
}
function brokenShell(b) {
  const s = b.spec;
  const gap = 0.82 + s.opening * 1.35;
  shellPetal(b, -s.length * 0.06, -s.width * 0.045, s.length * 0.49, s.width * 0.47, gap * 0.5, TAU2 - gap, 1, 0);
  shellPetal(
    b,
    s.length * 0.22,
    s.width * 0.16,
    s.length * 0.25,
    s.width * 0.31,
    Math.PI * 1.1,
    Math.PI * (1.08 + s.fold * 0.13),
    0.68,
    1
  );
  b.joint([s.length * 0.22, s.width * 0.02, s.height * 0.34]);
}
function shellPetal(b, ox, oy, rx, ry, begin, sweep, heightScale, salt) {
  const s = b.spec, around = 54, radial = 16, seedPhase = phase(s.seed, 53 + salt) * TAU2;
  const rings = [];
  for (let i = 0; i <= around; i++) {
    const angle = begin + i / around * sweep, ca = Math.cos(angle), sa = Math.sin(angle);
    const jointCompression = Math.exp(-Math.pow((i / around - 0.78) / 0.2, 2));
    const lip = 1 + 0.12 * s.distortion * Math.sin(angle * 2 + seedPhase) - jointCompression * 0.1 + 0.045 * Math.sin(angle * 9 + salt);
    const rimZ = s.height * heightScale * (0.6 + 0.26 * Math.sin(angle - 0.5) + 0.12 * Math.cos(angle * 2 + seedPhase));
    const thickness = clamp2(s.thickness / Math.min(rx, ry), 0.1, 0.42);
    const rimInner = 0.69 - thickness * 0.43;
    const profile = [
      [1, 0],
      [0.96, rimZ * 0.22],
      [0.84 * lip, rimZ * 0.68],
      [0.73 * lip, rimZ],
      [rimInner, rimZ * 0.94],
      [rimInner - 0.09, rimZ * 0.6],
      [0.31, rimZ * 0.14],
      [0.15, s.thickness * 0.17],
      [0, s.thickness * 0.13]
    ];
    const ring = [];
    for (let j = 0; j <= radial; j++) {
      const f = j / radial * (profile.length - 1), a = Math.floor(f), t = f - a;
      const p = profile[a], q = profile[Math.min(a + 1, profile.length - 1)];
      const r = p[0] + (q[0] - p[0]) * t, z = p[1] + (q[1] - p[1]) * t;
      const inner = 1 - r;
      const flare = Math.exp(-Math.pow((angle - (begin + 0.32)) / 0.35, 2)) * s.fold;
      ring.push([
        ox + ca * rx * r + inner * rx * (0.24 + s.distortion * 0.17) + flare * rx * 0.1 * r,
        oy + sa * ry * r - inner * ry * (0.13 + s.distortion * 0.08),
        z * (1 - flare * 0.34) * (1 + 0.07 * Math.sin(angle * 7 + seedPhase) * r)
      ]);
    }
    rings.push(ring);
  }
  for (let i = 0; i < around; i++) for (let j = 0; j < radial; j++) {
    const a = rings[i], c = rings[i + 1];
    const slot = j < 6 ? 0 : j < 8 ? 1 : j < 13 ? 2 : 0;
    b.quad(
      a[j],
      c[j],
      c[j + 1],
      a[j + 1],
      salt === 1 && i < 4 && j >= 7 && j < 12 ? 3 : slot,
      [
        [i / around * sweep * (rx + ry) * 0.5, j / radial * s.width],
        [(i + 1) / around * sweep * (rx + ry) * 0.5, j / radial * s.width],
        [(i + 1) / around * sweep * (rx + ry) * 0.5, (j + 1) / radial * s.width],
        [i / around * sweep * (rx + ry) * 0.5, (j + 1) / radial * s.width]
      ],
      [0, 0, 1]
    );
  }
  for (const end of [0, around]) {
    const ring = rings[end];
    for (let j = 0; j < radial; j++) {
      const a = ring[j], c = ring[j + 1];
      const sign = end === 0 ? -1 : 1, angle = begin + end / around * sweep;
      const dx = -Math.sin(angle) * s.thickness * 0.72 * sign, dy = Math.cos(angle) * s.thickness * 0.72 * sign;
      b.quad(
        a,
        c,
        [c[0] + dx, c[1] + dy, 0],
        [a[0] + dx, a[1] + dy, 0],
        1,
        [[j * s.width / radial, a[2]], [(j + 1) * s.width / radial, c[2]], [(j + 1) * s.width / radial, 0], [j * s.width / radial, 0]],
        [0, 0, 1]
      );
    }
  }
}
function granularRidge(b) {
  const s = b.spec, along = 30, across = 14, rows = [];
  const authored = s.constructionVersion === 2;
  const clusters = Array.from({ length: s.branches + 3 }, (_, i) => ({
    x: (i + 0.25 + phase(s.seed, 910 + i) * 0.5) / (s.branches + 3),
    y: 0.24 + phase(s.seed, 950 + i) * 0.5,
    span: 0.09 + phase(s.seed, 980 + i) * 0.08,
    rise: 0.1 + phase(s.seed, 1010 + i) * 0.2
  }));
  for (let i = 0; i <= along; i++) {
    const u = i / along, taper = 0.25 + 0.75 * Math.pow(Math.sin(Math.PI * u), authored ? 0.25 + s.opening * 0.9 : 0.48), row = [];
    const spine = Math.sin(u * (authored ? 2.2 + s.fold * 3 : 4.5) + phase(s.seed, 897) * 2) * s.width * (authored ? 0.025 + s.distortion * 0.13 : 0.11);
    for (let j = 0; j <= across; j++) {
      const v = j / across, edge = Math.min(u * along, (1 - u) * along, v * across, (1 - v) * across);
      const foot = Math.min(1, edge), peak = (authored ? 0.28 + s.fold * 0.3 : 0.43) + 0.08 * Math.sin(u * 5.4);
      const side = v < peak ? v / peak : (1 - v) / (1 - peak);
      let rise = Math.pow(Math.max(0, side), authored ? 0.48 + s.fold * 1.2 : 0.86) * (0.51 + 0.16 * Math.sin(u * 4 + 1));
      for (const c of clusters) {
        const distance3 = Math.abs(u - c.x) / c.span + Math.abs(v - c.y) / 0.26;
        rise += Math.max(0, 1 - distance3) * c.rise * (authored ? 0.45 + s.distortion * 2 : 1);
      }
      const z = (s.blocking === 1 ? Math.min(8, s.height * 0.26) * foot : 0) + s.height * rise * foot * Math.pow(Math.sin(Math.PI * u), 0.34);
      row.push([(u - 0.5) * s.length, (v - 0.5) * s.width * taper + spine, z]);
    }
    rows.push(row);
  }
  for (let i = 0; i < along; i++) for (let j = 0; j < across; j++) {
    const cut = j === 0 || j === across - 1 || i === 0 || i === along - 1;
    const a = rows[i][j], c = rows[i + 1][j], d = rows[i + 1][j + 1], e = rows[i][j + 1];
    b.quad(
      a,
      c,
      d,
      e,
      cut ? 1 : j > 8 ? 2 : 0,
      [
        [i * s.length / along, j * s.width / across],
        [(i + 1) * s.length / along, j * s.width / across],
        [(i + 1) * s.length / along, (j + 1) * s.width / across],
        [i * s.length / along, (j + 1) * s.width / across]
      ],
      [0, 0, 1],
      cut ? NATIVE_VOLUME_REGIONS.fractured : j < 6 ? NATIVE_VOLUME_REGIONS.compressed : NATIVE_VOLUME_REGIONS.intact
    );
  }
  surfaceFracture(b, rows, [[10.1, 5.9], [11.8, 6.1], [12.5, 5.6], [14.2, 5.8], [15.1, 6.4], [17.4, 6.2]], 0.085);
}
function membraneRim(b) {
  const s = b.spec, around = 46, radial = 12, rows = [];
  const begin = 0.2 + s.opening * 0.3, sweep = TAU2 - (1.35 + s.opening * 1.15), offset = phase(s.seed, 1131) * 1.4;
  for (let i = 0; i <= around; i++) {
    const angle = begin + i / around * sweep, ca = Math.cos(angle), sa = Math.sin(angle);
    const uneven = 1 + 0.13 * Math.sin(angle * 3 + offset) + 0.06 * Math.cos(angle * 5 - 0.3);
    const crown = s.height * (0.64 + 0.24 * Math.sin(angle + 0.8) + 0.09 * Math.cos(angle * 2 + offset));
    const profile = [
      [1, 0],
      [0.955, s.blocking === 1 ? Math.min(crown * 0.35, 9) : crown * 0.05],
      [0.875, crown * 0.82],
      [0.78, crown],
      [0.69, crown * 0.62],
      [0.54, crown * 0.15],
      [0, crown * 0.075]
    ];
    const row = [];
    for (let j = 0; j <= radial; j++) {
      const q = j / radial * (profile.length - 1), n = Math.floor(q), f = q - n;
      const p = profile[n], next = profile[Math.min(n + 1, profile.length - 1)];
      const r = p[0] + (next[0] - p[0]) * f, z = p[1] + (next[1] - p[1]) * f;
      const tension = j > 8 ? Math.sin(angle * 11 + r * 5) * s.thickness * 0.12 * r : 0;
      row.push([ca * s.length * 0.5 * r * uneven + (1 - r) * s.length * 0.1, sa * s.width * 0.49 * r * uneven - (1 - r) * s.width * 0.17, z + tension]);
    }
    rows.push(row);
  }
  for (let i = 0; i < around; i++) for (let j = 0; j < radial; j++) {
    const a = rows[i], c = rows[i + 1];
    const slot = j < 2 ? 1 : j < 8 ? 0 : 2;
    b.quad(
      a[j],
      c[j],
      c[j + 1],
      a[j + 1],
      slot,
      [
        [i * s.length / around, j * s.width / radial],
        [(i + 1) * s.length / around, j * s.width / radial],
        [(i + 1) * s.length / around, (j + 1) * s.width / radial],
        [i * s.length / around, (j + 1) * s.width / radial]
      ],
      [0, 0, 1],
      j > 7 ? NATIVE_VOLUME_REGIONS.tension : NATIVE_VOLUME_REGIONS.intact
    );
  }
  surfaceFracture(b, rows, [[12.2, 2.8], [13.5, 3.3], [13.2, 4.4], [14.1, 5], [13.7, 6.3], [14.6, 7.6], [14.4, 8.7]], 0.095);
  for (const i of [0, around]) for (let j = 0; j < radial; j++) {
    const a = rows[i][j], c = rows[i][j + 1], angle = begin + i / around * sweep, sign = i === 0 ? -1 : 1;
    const dx = -Math.sin(angle) * s.thickness * 0.3 * sign, dy = Math.cos(angle) * s.thickness * 0.3 * sign;
    b.quad(
      a,
      c,
      [c[0] + dx, c[1] + dy, 0],
      [a[0] + dx, a[1] + dy, 0],
      1,
      [[j * s.width / radial, a[2]], [(j + 1) * s.width / radial, c[2]], [(j + 1) * s.width / radial, 0], [j * s.width / radial, 0]],
      [0, 0, 1],
      NATIVE_VOLUME_REGIONS.fractured
    );
  }
}
function gelFlow(b) {
  const s = b.spec, along = 32, across = 20, rows = [];
  const profile = [[0, 0], [0.08, 0.11], [0.33, 0.19], [0.58, 0.38], [0.78, 0.78], [0.88, 1], [0.95, 0.52], [1, 0]];
  for (let i = 0; i <= along; i++) {
    const u = i / along, side = Math.pow(Math.sin(Math.PI * u), 0.35), lobes = 0.12 * Math.sin(u * 13 + phase(s.seed, 1207) * 2) + 0.055 * Math.sin(u * 27 + 0.5);
    const row = [];
    for (let j = 0; j <= across; j++) {
      const v = j / across;
      let p = 0;
      while (p + 1 < profile.length && profile[p + 1][0] < v) p++;
      const a = profile[p], c = profile[Math.min(p + 1, profile.length - 1)], f = (v - a[0]) / Math.max(1e-3, c[0] - a[0]);
      const ridge = a[1] + (c[1] - a[1]) * f, edge = Math.min(u * along, (1 - u) * along, v * across, (1 - v) * across);
      const foot = s.blocking === 1 ? Math.min(s.height * 0.22, 7) * Math.min(1, edge) : 0;
      row.push([
        (u - 0.5) * s.length + (v - 0.5) * s.length * 0.08,
        (v - 0.5) * s.width * (0.3 + side * 0.7) + Math.pow(v, 3) * lobes * s.width,
        foot + ridge * s.height * side * (0.75 + 0.19 * Math.sin(u * 8 + 0.2))
      ]);
    }
    rows.push(row);
  }
  for (let i = 0; i < along; i++) for (let j = 0; j < across; j++) {
    const front = j >= 18, thin = j <= 6;
    const a = rows[i][j], c = rows[i + 1][j], d = rows[i + 1][j + 1], e = rows[i][j + 1];
    b.quad(
      a,
      c,
      d,
      e,
      front ? 1 : thin ? 2 : 0,
      [
        [i * s.length / along, j * s.width / across],
        [(i + 1) * s.length / along, j * s.width / across],
        [(i + 1) * s.length / along, (j + 1) * s.width / across],
        [i * s.length / along, (j + 1) * s.width / across]
      ],
      [0, 0, 1],
      thin ? NATIVE_VOLUME_REGIONS.peeled : front ? NATIVE_VOLUME_REGIONS.compressed : NATIVE_VOLUME_REGIONS.glazed
    );
  }
  surfaceFracture(b, rows, [[10.2, 17.4], [11.5, 17.1], [12.1, 17.7], [13.8, 17.8], [14.4, 18.3], [16.5, 18.1]], 0.09);
}
function shearedBeds(b) {
  const s = b.spec, l = s.length, w = s.width, h = s.height;
  const gap = Math.min(w * 0.4, Math.max(30, w * (0.12 + s.opening * 0.15)));
  const shear = l * (0.025 + s.distortion * 0.1), skew = (phase(s.seed, 1301) - 0.5) * w * 0.05;
  const upper = [
    [-l * 0.5, -w * 0.27, 0],
    [-l * 0.36, -w * 0.5, 0],
    [l * 0.36 - shear, -w * 0.44, 0],
    [l * 0.5 - shear, -gap * 0.56 + skew, 0],
    [l * 0.12 - shear, -gap * 0.5 + skew, 0],
    [-l * 0.42, -gap * 0.6, 0]
  ];
  const lower = [
    [-l * 0.43 + shear, gap * 0.62, 0],
    [-l * 0.04 + shear, gap * 0.5 + skew, 0],
    [l * 0.48, gap * 0.6, 0],
    [l * 0.44, w * 0.43, 0],
    [l * 0.16, w * 0.5, 0],
    [-l * 0.5 + shear, w * 0.36, 0]
  ];
  const incline = (outline, peak, dx, dy) => {
    let min = Infinity, max = -Infinity;
    for (const p of outline) {
      const q = p[0] * dx + p[1] * dy;
      min = Math.min(min, q);
      max = Math.max(max, q);
    }
    let x = 0, y = 0;
    for (let i = 0; i < outline.length; i++) {
      const p = outline[i];
      x += p[0];
      y += p[1];
      outline[i] = [p[0], p[1], (p[0] * dx + p[1] * dy - min) / (max - min) * peak];
    }
    x /= outline.length;
    y /= outline.length;
    return [x, y, (x * dx + y * dy - min) / (max - min) * peak];
  };
  bedMass(b, upper, incline(upper, h, 0.12, -1), 0, [3, 4], Math.min(6, w * 0.024));
  bedMass(b, lower, incline(lower, h * (0.32 + s.fold * 0.5), -0.1, 1), 1, [0, 1], Math.min(5, w * 0.022));
  if (s.branches >= 5) {
    const toe = [[-l * 0.42, w * 0.39, 0], [-l * 0.14, w * 0.42, 0], [-l * 0.05, w * 0.57, 0], [-l * 0.36, w * 0.59, 0]];
    bedMass(b, toe, incline(toe, h * 0.17, 0.2, -1), 2, [0, 1], Math.min(8, w * 0.03));
  }
}
function tensileBranches(b) {
  const s = b.spec, l = s.length, w = s.width, h = s.height;
  const pull = s.fold, joinX = l * (-0.18 + 0.18 * s.opening), joinY = w * (phase(s.seed, 1321) - 0.5) * 0.1;
  const radius = Math.max(s.thickness * 0.65, w * (0.068 + 0.028 * (1 - pull)));
  const main = [
    [-l * 0.52, -w * 0.08, s.thickness * 0.65],
    [-l * 0.28, -w * 0.04, h * 0.43],
    [joinX, joinY, h * 0.72],
    [l * 0.25, w * (0.03 + 0.1 * s.distortion), h * 0.48],
    [l * 0.52, w * 0.14, s.thickness * 0.72]
  ];
  sweptBundle(b, main, radius, 0);
  for (let arm = 1; arm < s.branches; arm++) {
    const side = arm % 2 === 1 ? -1 : 1, rank = Math.floor((arm - 1) / 2), spread = 0.27 + rank * 0.12;
    const attachX = joinX + l * (rank * 0.07 - 0.025), attachY = joinY + w * rank * 0.018;
    const endX = l * (0.46 - rank * 0.11) * (arm % 3 === 0 ? -1 : 1);
    const endY = side * w * Math.min(0.5, spread + s.opening * 0.18);
    const branch = [
      [attachX - l * 0.1, attachY, h * 0.55],
      [attachX, attachY, h * (0.74 - rank * 0.06)],
      [attachX + (endX - attachX) * 0.55, endY * (0.37 + 0.3 * (1 - pull)), h * (0.4 - rank * 0.03)],
      [endX, endY, s.thickness * (0.46 + 0.06 * rank)]
    ];
    sweptBundle(b, branch, radius * (0.7 - rank * 0.085), arm);
  }
}
function openShellWall(b) {
  const s = b.spec, around = 56, radial = 8, rows = [];
  const gap = 0.76 + s.opening * 2.4, begin = gap * 0.5, sweep = TAU2 - gap;
  const inner = 0.43 + s.opening * 0.19, phaseOffset = phase(s.seed, 1351) * TAU2;
  for (let i = 0; i <= around; i++) {
    const u = i / around, angle = begin + u * sweep, ca = Math.cos(angle), sa = Math.sin(angle);
    const uneven = 1 + s.distortion * (0.075 * Math.sin(angle * 2 + phaseOffset) + 0.035 * Math.sin(angle * 5));
    const crown = s.height * (0.66 + 0.23 * Math.sin(angle + 0.7) + 0.09 * Math.cos(angle * 2 + phaseOffset));
    const foot = s.blocking === 1 ? Math.min(9, s.height * 0.3) : s.height * 0.05;
    const lip = 0.82 - s.fold * 0.07;
    const profile = [
      [1, 0],
      [0.97, foot],
      [0.91, crown * 0.58],
      [lip, crown],
      [lip - 0.045, crown * 0.97],
      [inner + 0.075, crown * 0.72],
      [inner + 0.025, foot],
      [inner, 0],
      [inner, 0]
    ];
    rows.push(profile.map(([r, z]) => [
      ca * s.length * 0.5 * r * uneven + (1 - r) * s.length * s.distortion * 0.07,
      sa * s.width * 0.5 * r * uneven,
      z
    ]));
  }
  for (let i = 0; i < around; i++) for (let j = 0; j < radial; j++) {
    const a = rows[i], c = rows[i + 1], joint = i === Math.floor(around * 0.69) && j === 4;
    const slot = joint ? 3 : j < 3 ? 0 : j < 5 ? 1 : 2;
    b.quad(a[j], c[j], c[j + 1], a[j + 1], slot, [
      [i * s.length / around, j * s.width / radial],
      [(i + 1) * s.length / around, j * s.width / radial],
      [(i + 1) * s.length / around, (j + 1) * s.width / radial],
      [i * s.length / around, (j + 1) * s.width / radial]
    ], [0, 0, 1], j < 3 ? NATIVE_VOLUME_REGIONS.intact : j < 5 ? NATIVE_VOLUME_REGIONS.fractured : NATIVE_VOLUME_REGIONS.glazed);
    if (joint) b.joint([(a[j][0] + c[j + 1][0]) * 0.5, (a[j][1] + c[j + 1][1]) * 0.5, (a[j][2] + c[j + 1][2]) * 0.5]);
  }
  for (const end of [0, around]) {
    const row = rows[end], angle = begin + end / around * sweep, sign = end === 0 ? -1 : 1;
    for (let j = 0; j < radial - 1; j++) {
      const a = row[j], c = row[j + 1], dx = -Math.sin(angle) * s.thickness * 0.4 * sign, dy = Math.cos(angle) * s.thickness * 0.4 * sign;
      b.quad(
        a,
        c,
        [c[0] + dx, c[1] + dy, 0],
        [a[0] + dx, a[1] + dy, 0],
        1,
        [[j * s.width / radial, a[2]], [(j + 1) * s.width / radial, c[2]], [(j + 1) * s.width / radial, 0], [j * s.width / radial, 0]],
        [0, 0, 1],
        NATIVE_VOLUME_REGIONS.fractured
      );
    }
  }
}
function tornMembrane(b) {
  const s = b.spec, along = 36, across = 12, rows = [];
  const tearAt = 0.36 + phase(s.seed, 1381) * 0.17, tearDepth = 0.3 + s.opening * 0.58;
  for (let i = 0; i <= along; i++) {
    const u = i / along, edgeTaper = 0.63 + 0.37 * Math.sin(Math.PI * u), row = [];
    const tear = tearDepth * Math.pow(Math.max(0, 1 - Math.abs(u - tearAt) / (0.11 + s.distortion * 0.045)), 0.72);
    const second = s.branches >= 5 ? tearDepth * 0.68 * Math.pow(Math.max(0, 1 - Math.abs(u - 0.79) / 0.08), 0.8) : 0;
    const front = 1 - Math.max(tear, second);
    for (let j = 0; j <= across; j++) {
      const v = j / across, local = v * front;
      const taut = Math.pow(Math.sin(Math.PI * u), 0.45), curl = Math.exp(-Math.pow((local - (0.16 + s.fold * 0.09)) / 0.18, 2));
      const fold = Math.pow(Math.max(0, Math.sin(u * Math.PI * (s.branches - 1) + local * 2)), 3) * s.distortion * 0.15;
      const foot = s.blocking === 1 ? Math.min(8, s.height * 0.3) : 0;
      const z = foot + s.height * taut * (curl * (0.5 + s.fold * 0.3) + 0.075 + fold) * (0.55 + 0.45 * Math.sin(Math.PI * v));
      row.push([(u - 0.5) * s.length, (local - 0.5) * s.width * edgeTaper, z]);
    }
    rows.push(row);
  }
  for (let i = 0; i < along; i++) for (let j = 0; j < across; j++) {
    const a = rows[i], c = rows[i + 1], slot = j < 3 ? 0 : j > 9 ? 1 : 2;
    b.quad(a[j], c[j], c[j + 1], a[j + 1], slot, [
      [i * s.length / along, j * s.width / across],
      [(i + 1) * s.length / along, j * s.width / across],
      [(i + 1) * s.length / along, (j + 1) * s.width / across],
      [i * s.length / along, (j + 1) * s.width / across]
    ], [0, 0, 1], j < 3 ? NATIVE_VOLUME_REGIONS.compressed : NATIVE_VOLUME_REGIONS.tension);
  }
  const outline = [];
  for (let i = 0; i <= along; i++) outline.push(rows[i][0]);
  for (let j = 1; j <= across; j++) outline.push(rows[along][j]);
  for (let i = along - 1; i >= 0; i--) outline.push(rows[i][across]);
  for (let j = across - 1; j > 0; j--) outline.push(rows[0][j]);
  for (let i = 0; i < outline.length; i++) {
    const a = outline[i], c = outline[(i + 1) % outline.length], dx = c[0] - a[0], dy = c[1] - a[1], length2 = Math.hypot(dx, dy) || 1;
    const width = s.blocking === 1 ? Math.min(6, s.thickness * 0.55) : 1.5, ox = dy / length2 * width, oy = -dx / length2 * width;
    b.quad(a, [a[0] + ox, a[1] + oy, 0], [c[0] + ox, c[1] + oy, 0], c, 1, [[0, a[2]], [0, 0], [length2, 0], [length2, c[2]]], [0, 0, 1], NATIVE_VOLUME_REGIONS.fractured);
  }
  surfaceFracture(b, rows, [[8.2, 3.4], [9.7, 4], [10.3, 4.5], [11.8, 4.8], [12.3, 5.4]], 0.085);
}
function pooledGel(b) {
  const s = b.spec, along = 38, across = 22, rows = [];
  const lobeCount = Math.max(2, s.branches - 1), offset = phase(s.seed, 1411) * 1.7;
  for (let i = 0; i <= along; i++) {
    const u = i / along, side = Math.pow(Math.sin(Math.PI * u), 0.28), row = [];
    const lobes = Math.pow(0.5 + 0.5 * Math.sin(u * Math.PI * 2 * lobeCount + offset), 2);
    const irregular = 0.045 * Math.sin(u * 19 + offset);
    for (let j = 0; j <= across; j++) {
      const v = j / across, edge = Math.min(u * along, (1 - u) * along, v * across, (1 - v) * across);
      const frontAt = 0.74 + s.opening * 0.13, front = Math.exp(-Math.pow((v - frontAt) / (0.09 + s.fold * 0.09), 2));
      const pool = 0.065 + Math.sin(Math.PI * v) * (0.09 + s.opening * 0.04);
      const ridge = front * (0.42 + s.fold * 0.39) * (0.6 + 0.4 * lobes);
      const foot = s.blocking === 1 ? Math.min(8, s.height * 0.28) * Math.min(1, edge) : 0;
      row.push([
        (u - 0.5) * s.length + (v - 0.5) * s.length * s.distortion * 0.1,
        (v - 0.5) * s.width * (0.5 + side * 0.5) + Math.pow(v, 4) * s.width * (lobes * (0.09 + s.distortion * 0.12) + irregular),
        foot + (pool + ridge) * s.height * side * Math.min(1, edge)
      ]);
    }
    rows.push(row);
  }
  for (let i = 0; i < along; i++) for (let j = 0; j < across; j++) {
    const a = rows[i], c = rows[i + 1], front = j >= across - 2, thin = j < across * 0.48;
    b.quad(
      a[j],
      c[j],
      c[j + 1],
      a[j + 1],
      front ? 1 : thin ? 2 : 0,
      [
        [i * s.length / along, j * s.width / across],
        [(i + 1) * s.length / along, j * s.width / across],
        [(i + 1) * s.length / along, (j + 1) * s.width / across],
        [i * s.length / along, (j + 1) * s.width / across]
      ],
      [0, 0, 1],
      front ? NATIVE_VOLUME_REGIONS.compressed : thin ? NATIVE_VOLUME_REGIONS.peeled : NATIVE_VOLUME_REGIONS.glazed
    );
  }
  surfaceFracture(b, rows, [[12.1, 17.4], [13.2, 17.8], [14.1, 17.7], [15.2, 18.1], [16.4, 18]], 0.09);
}
function surfaceFracture(b, rows, path, halfWidth) {
  const sample = (u, v) => {
    const i = clamp2(Math.floor(u), 0, rows.length - 2), j = clamp2(Math.floor(v), 0, rows[0].length - 2), a = u - i, t = v - j;
    const p = rows[i][j], q = rows[i + 1][j], r = rows[i + 1][j + 1], s = rows[i][j + 1];
    const weights = t <= a ? [1 - a, a - t, t, 0] : [1 - t, 0, a, t - a];
    return [
      p[0] * weights[0] + q[0] * weights[1] + r[0] * weights[2] + s[0] * weights[3],
      p[1] * weights[0] + q[1] * weights[1] + r[1] * weights[2] + s[1] * weights[3],
      p[2] * weights[0] + q[2] * weights[1] + r[2] * weights[2] + s[2] * weights[3] + 0.12
    ];
  };
  for (let i = 1; i < path.length; i++) {
    const a = path[i - 1], c = path[i], dx = c[0] - a[0], dy = c[1] - a[1], length2 = Math.hypot(dx, dy), px = -dy / length2 * halfWidth, py = dx / length2 * halfWidth;
    const uv6 = [[a[0] + px, a[1] + py], [c[0] + px, c[1] + py], [c[0] - px, c[1] - py], [a[0] - px, a[1] - py]];
    b.quad(sample(...uv6[0]), sample(...uv6[1]), sample(...uv6[2]), sample(...uv6[3]), 3, uv6, [0, 0, 1], NATIVE_VOLUME_REGIONS.fractured);
  }
  const centre = path[Math.floor(path.length / 2)];
  b.joint(sample(...centre));
}
function buildNativeVolume(spec, ground) {
  validateNativeVolumeSpec(spec);
  if (spec.groundEdgeWidth !== void 0 && !ground) throw new Error("Native ground edge is missing its authoritative terrain context");
  const builder = new MeshBuilder(spec);
  if (spec.constructionVersion === 4) buildGroundNativeVolume(builder);
  else if (spec.constructionVersion === 3) buildExpandedNativeVolume(builder);
  else if (spec.constructionVersion === 2) {
    if (spec.family === "folded-slab") shearedBeds(builder);
    else if (spec.family === "fibre-knot") tensileBranches(builder);
    else if (spec.family === "broken-shell") openShellWall(builder);
    else if (spec.family === "membrane-rim") tornMembrane(builder);
    else if (spec.family === "gel-flow") pooledGel(builder);
    else granularRidge(builder);
  } else if (spec.family === "folded-slab") foldedSlab(builder);
  else if (spec.family === "fibre-knot") fibreKnot(builder);
  else if (spec.family === "broken-shell") brokenShell(builder);
  else if (spec.family === "granular-ridge") granularRidge(builder);
  else if (spec.family === "membrane-rim") membraneRim(builder);
  else gelFlow(builder);
  if (spec.groundEdgeWidth !== void 0) {
    builder.beginGroundEdges();
    appendNativeGroundEdges(builder, ground);
  }
  const mesh = builder.finish();
  if (spec.constructionVersion === 4 && (spec.shapeProfile === "compressed-wedge" || spec.shapeProfile === "porous-break"))
    return smoothOrganizedSurface(mesh);
  return mesh;
}

// src/generation/world-study/native-spatial-types.ts
var NativeSpatialGeometryWorkBudgetError = class extends Error {
  constructor() {
    super("Native geometry work budget exhausted before compilation");
    this.name = "NativeSpatialGeometryWorkBudgetError";
  }
};

// src/config/constants.ts
var GAME_CONSTANTS = {
  /** Tile size in pixels */
  TILE_SIZE: 32,
  /** Camera. Zoom 1.5 on a 960x640 canvas gives a ~640x427 logical viewport = ~20x13 tiles (DEC-009). */
  CAMERA: {
    ZOOM: 1.5
  },
  /** Player movement (docs/specs/system-movement-vision.md, section M) */
  PLAYER: {
    SPEED: 80,
    // px/s base speed = 2.5 tiles/s (tuned down for deliberate stealth feel)
    MAX_HEALTH: 100,
    INVENTORY_SLOTS: 4,
    MOVE_ACCEL_TIME: 0.08,
    // s from standstill to full speed
    MOVE_DECEL_TIME: 0.1,
    // s from full speed to standstill
    FACING_TURN_RATE: 1080,
    // deg/s the vision cone swings toward the input direction
    FACING_QUANT_HYSTERESIS: 5,
    // deg of dead zone around the 45 degree facing4 boundaries
    BODY_SIZE: 20,
    // px collider edge; < TILE_SIZE so 1-tile gaps stay passable
    BODY_OFFSET: { x: 6, y: 6 },
    // centres the collider inside the 32x32 sprite
    SPEED_MOD_MIN: 0.5
    // floor on the multiplied speed modifier stack
  },
  /**
   * Presentation-only gait (art-direction §3.3). Does not change facingAngle,
   * facing4 snap timing, speeds, or colliders.
   */
  ACTOR_MOTION: {
    FRAME_COUNT: 4,
    TURN_MS: 180,
    LAG_PX: 3,
    LAG_ALPHA: 0.38,
    MOVE_SPEED_FLOOR: 6,
    // px/s; below this the idle cycle plays
    PLAYER_IDLE_FPS: 4,
    PLAYER_WALK_FPS: 8,
    INFILTRATOR_IDLE_FPS: 4,
    INFILTRATOR_WALK_FPS: 4,
    // puppet hitch supplies the step; keep the sheet slow
    REWRITER_IDLE_FPS: 4,
    REWRITER_WALK_FPS: 6
  },
  /** Chaos system (docs/specs/system-chaos-scavenge-extract.md) */
  CHAOS: {
    START_VALUE: 0,
    MAX_VALUE: 100,
    // HUD gauge max (value CAN exceed this)
    HARD_CAP: 150,
    BASE_RATE: 0.5,
    // points per second (DEC-024: calibrated for 80 px/s travel)
    THRESHOLD_1: 50,
    THRESHOLD_2: 75,
    THRESHOLD_3: 100,
    COMBAT_BONUS: 5,
    DETECTION_BONUS: 3,
    DETECTION_BONUS_COOLDOWN: 1e4,
    // ms per-enemy cooldown on detection chaos
    CHASE_RATE_MULT: 2,
    EMIT_STEP: 1,
    // minimum delta before emitting CHAOS_CHANGED
    MODULATOR_STEP: 1
    // minimum delta before calling onModulate callback
  },
  /** Loot / kindling nodes (docs/specs/system-chaos-scavenge-extract.md) */
  LOOT: {
    /** 迭代 10 起退役，见 spec 规则 14。名义参数，代码无引用；由 SEARCH_RADIUS 取代。 */
    PICKUP_RADIUS: 16,
    NODE_COUNT: 8,
    VALUE_SAFE: 1,
    VALUE_CONTESTED: 2,
    VALUE_DEEP: 4,
    SEARCH_CHANNEL_MS: 1200,
    SEARCH_RADIUS: 48,
    SEARCH_NOISE_RADIUS: 96,
    SEARCH_NOISE_LEVEL: "suspicious"
  },
  /** Extraction point (docs/specs/system-chaos-scavenge-extract.md) */
  EXTRACTION: {
    TRIGGER_RADIUS: 48,
    KEY: "E",
    SETTLE_DELAY_MS: 600,
    RESTART_KEY: "R"
  },
  /**
   * Visibility / FOV (docs/specs/system-movement-vision.md, section V).
   * Models a forward cone unioned with an ambient ring, with three fixed-width edge
   * bands. The older single-radius + edge-softness model was replaced rather than
   * extended, so the two parameter sets never coexist.
   */
  VISIBILITY: {
    RADIUS_FORWARD: 224,
    // px straight ahead (7 tiles); must exceed every profile sightRange (I1)
    RADIUS_AMBIENT: 80,
    // px all around (2.5 tiles) = the lamp the player carries
    CONE_HALF_ANGLE: 50,
    // deg half-angle of the full-range sector
    CONE_FALLOFF_ANGLE: 30,
    // deg of transition from forward range down to ambient
    MIN_SOLID_RADIUS: 48,
    // px that stay fully lit no matter what
    EDGE_BAND_WIDTH: 32,
    // px per gradient band (1 tile, art-direction 4.3)
    BAND_ALPHAS: [1, 0.6, 0.2],
    // visibility of core / middle / outer band
    ERASE_ALPHAS: [1, 0.5, 0.2],
    // per-layer erase strength producing those alphas
    RAY_COUNT: 60,
    // architecture ceiling
    RAY_SPLIT_FORWARD: 40,
    // rays inside the cone sector
    RAY_SPLIT_AMBIENT: 20,
    // rays across the remaining angles
    RAY_COUNT_DEGRADED: 40,
    // first degradation step
    RAY_SPLIT_FORWARD_DEGRADED: 28,
    RAY_SPLIT_AMBIENT_DEGRADED: 12,
    MIN_RADIUS_SCALE: 0.4,
    // hard floor for the chaos radius modulator
    CACHE_POS_EPSILON: 0.5,
    // px of movement tolerated before the cache is dropped
    CACHE_ANGLE_EPSILON: 0.5,
    // deg of rotation tolerated before the cache is dropped
    BUDGET_MS: 2,
    // per-frame raycasting budget
    DEGRADE_SAMPLE_FRAMES: 30,
    // consecutive frames over budget before degrading
    /** Void outside the field of view */
    VOID_COLOR: 526860,
    VOID_NOISE_ALPHA: 0.04,
    VOID_NOISE_TILE: 64,
    // px noise texture size
    VOID_NOISE_SCROLL: 2,
    // px/s drift
    /** Warm lamp the player carries - the only warm light inside a rift */
    PLAYER_LAMP_COLOR: 9067562,
    PLAYER_LAMP_ALPHA: 0.12,
    /**
     * Flashlight beam: an additive warm pool pushed forward along facing and clipped to
     * the vision cone by the darkness mask. This is what makes the forward cone read as
     * "lit by a flashlight" rather than merely "revealed" (A-G3 / DEC-018 beam gain).
     */
    FLASHLIGHT_COLOR: 11047018,
    // pale warm; a saturated brown would wash the cold floor out
    FLASHLIGHT_ALPHA: 0.16,
    // low enough that fragment L1 (clinic/metro/soil) still reads under the cone
    FLASHLIGHT_FORWARD_FRAC: 0.34,
    // push the pool centre this fraction of forward range ahead
    FLASHLIGHT_RADIUS_FRAC: 0.85,
    // pool radius as a fraction of forward range
    /** Glow bleeding through the darkness (Slice 1: extraction point only) */
    GLOW_LEAK_ALPHA: 0.25,
    GLOW_LEAK_RADIUS: 48,
    /** Chaos corruption of the vision edge */
    CORRUPTION_COLOR: 1748374,
    CORRUPTION_MAX_MIX: 0.6,
    // alpha of the teal band at corruption 1.0
    CORRUPTION_MAX_DEPTH: 0.35,
    // fraction of the range teal can eat at corruption 1.0
    CORRUPTION_JITTER_PX: 4,
    CORRUPTION_JITTER_HZ: 6,
    /**
     * Overflow (chaos > 100) full-screen teal wash. Persistent base stays well below the
     * old 0.08 epilepsy cap; the jump is a discrete ~2 s pulse (not a strobe), so its
     * peak can read as a "skip" without a rapid flash train.
     */
    FLICKER_BASE_ALPHA: 0.05,
    FLICKER_JUMP_ALPHA: 0.16,
    FLICKER_JUMP_PERIOD_MS: 2200,
    FLICKER_JUMP_WIDTH_MS: 140,
    /** Extra teal bite / edge jitter scale at screenFlicker = 1.0 */
    OVERFLOW_CORRUPTION_DEPTH_BOOST: 0.4,
    OVERFLOW_JITTER_BOOST: 1,
    /** Purification point overrides (omni mode) */
    PURIFY_RADIUS: 400,
    PURIFY_RAY_COUNT: 90
  },
  /**
   * Enemy AI (docs/specs/system-enemy-ai.md, "数值结构"). Every AI number lives here;
   * none are inlined in the systems.
   *
   * Six of these values are load-bearing relations rather than free parameters - the
   * balance invariants I1-I6 that make stealth playable at all. `config/invariants.ts`
   * asserts them at boot so tuning cannot silently break one.
   *
   * The old `SIGHT_ANGLE: 90 // cone half-angle` key was removed rather than kept: its
   * meaning split into a core cone and a peripheral band, and three overlapping angle
   * parameters would have been three ways to be wrong.
   */
  AI: {
    // --- movement and body (shared; per-role speeds live in data/enemies.csv) ---
    TURN_RATE: 360,
    // deg/s; a third of the player's, which is what makes flanking work (I6)
    BODY_SIZE: 20,
    // px collider edge; < TILE_SIZE so 1-tile gaps stay passable
    BODY_OFFSET: { x: 6, y: 6 },
    // centres the collider inside the 32x32 infiltrator sprite
    SEPARATION_RADIUS: 24,
    // px; soft repulsion instead of enemy-vs-enemy physics
    SEPARATION_WEIGHT: 0.35,
    // how strongly separation bends the movement direction
    STANDOFF_DISTANCE: 30,
    // px; where a chaser stops. Must stay under COMBAT.ATTACK_RANGE
    STANDOFF_BAND: 4,
    // px of tolerance around it (26..34)
    STANDOFF_ADJUST_SPEED: 60,
    // px/s used to back off when the player crowds it
    // --- perception (shared; cone / hearing radii / weights live in data/enemies.csv) ---
    DETECT_FILL_TIME: 0.45,
    // s of clear sight to go from 0 to certain; then × visionWeight
    HEAR_FILL_TIME: 2,
    // s of hearing fill baseline; then × hearingWeight × moveMult
    HEARING_STILL_CAP: 0.2,
    // still-hearing cannot push detection past this (below 0.35)
    HEAR_ALERT_THRESHOLD: 0.7,
    // rewriter T0-4b: hearing can push to ALERT, never CHASE
    DETECT_DIST_FACTOR_NEAR: 1.6,
    // detection rate multiplier at point blank
    DETECT_DIST_FACTOR_FAR: 0.5,
    // ...and at the edge of sight range
    DETECT_ZONE_FACTOR_PERIPH: 0.45,
    // peripheral vision fills far slower than the core cone
    SUSPICION_THRESHOLD: 0.35,
    // detection at which it stops and turns - the player's warning
    REACQUIRE_THRESHOLD: 0.5,
    // lower bar to re-lock while already searching
    DETECT_DECAY_RATE: 0.67,
    // per s; ~1.5 s to clear after breaking sight
    DETECT_DECAY_ALERT_SCALE: 0.5,
    // decays half as fast while searching: it is holding a grudge
    HEARING_JITTER: 32,
    // px of positional fuzz, so hearing is not a wall-hack locator
    PERCEPTION_TICK_MS: 100,
    // 10 Hz perception; one raycast per enemy per tick
    PERCEPTION_TICK_MS_FAR: 200,
    // 5 Hz beyond ACTIVE_RANGE (rule N8)
    // --- timers (section "计时器") ---
    LOS_GRACE_MS: 400,
    // how long a chase survives with no line of sight
    LOST_PLAYER_DURATION: 5e3,
    // ms of ALERT searching
    ALERT_DURATION: 3e3,
    // ms a SUSPICIOUS enemy stays wary with no new stimulus
    CHASE_ABANDON_RANGE: 320,
    // px past which an unseen chase is given up
    WAYPOINT_PAUSE_MS: 1200,
    // dwell at a patrol waypoint - the player's window to slip past
    SCAN_HOLD_MS: 600,
    // dwell on each scan heading
    SEARCH_HOLD_MS: 800,
    // dwell at each ALERT search point
    EXTRAPOLATE_SEC: 0.6,
    // how far ahead of the last sighting to guess - punishes running straight
    SEARCH_SPREAD: 96,
    // px radius of the random third search point
    ALERT_EMIT_COOLDOWN_MS: 1e3,
    // suppression window for repeated same-level ENEMY_ALERT
    SUSPICIOUS_TURN_HOLD_MS: 200,
    // minimum standstill when turning to look (rule B2, ">= 0.2 s")
    SCAN_SWEEP_ANGLE: 45,
    // deg to each side when scanning in place
    SCAN_SWEEP_PERIOD_MS: 1500,
    // full left-right-left sweep period
    FACING_ARRIVE_EPSILON: 6,
    // deg within which a turn counts as completed
    // --- pathfinding and performance (section "寻路与性能") ---
    MAX_PATHS_PER_FRAME: 1,
    // architecture hard rule
    REPATH_INTERVAL_MS: 500,
    REPATH_INTERVAL_MS_FAR: 1e3,
    // for requests past SIMPLE_PATH_RANGE (rule N5)
    REPATH_MOVE_THRESHOLD: 48,
    // px of target movement that earns an early chase repath
    SIMPLE_PATH_RANGE: 384,
    // px past which a request drops to the lowest priority
    ASTAR_MAX_NODES: 3e3,
    // expansion ceiling; real cap is the 5ms budget, not node count. Worst cross-map search measured 1050 nodes / 0.31ms, so 3000 stays well under 5ms and leaves RETURN headroom (DEC-022)
    PATH_FAIL_LIMIT: 3,
    // consecutive failures before giving up on the goal
    ACTIVE_RANGE: 640,
    // px; beyond this the FSM runs at 5 Hz and never asks for a path
    ARRIVE_EPSILON: 8,
    // px within which a path point counts as reached
    MAX_ACTIVE_ENEMIES: 8,
    // Slice 1 uses 4; more than this means the map data is wrong
    MAX_PATH_POINTS: 64,
    // capacity of a per-enemy dynamic path buffer
    DT_CLAMP_MS: 100,
    // stops a backgrounded tab from teleporting enemies on return
    /**
     * Stuck watchdog. Rule N4 skips A* whenever the target is in line of sight, but a
     * clear sight line does not prove a 20 px body fits through the diagonal seam it
     * crosses. Instead of pre-emptively restricting N4 to 3 tiles, we detect the
     * symptom (wanting to move but not moving) and fall back to a real path.
     */
    STUCK_REPATH_MS: 400,
    STUCK_PATH_PREFERENCE_MS: 2e3,
    // how long a stuck enemy keeps preferring A* over straight lines
    STUCK_PROGRESS_FRACTION: 0.25,
    // actual/desired speed below which we count as stuck
    // --- placeholder presentation (section "占位期表现", art-direction 12) ---
    BODY_COLOR: 13386820,
    // "low tier enemy"; encodes tier, never state
    INDICATOR_COLOR: 2811592,
    // contamination teal; state lives here
    SUSPICIOUS_BREATH_HZ_MIN: 1.5,
    // breathing rate at the suspicion threshold...
    SUSPICIOUS_BREATH_HZ_MAX: 3,
    // ...and at full certainty (rule R3)
    ALERT_BLINK_HZ: 3,
    // blinking = searching
    AFTERIMAGE_INTERVAL_MS: 100,
    AFTERIMAGE_LIFETIME_MS: 300,
    AFTERIMAGE_ALPHA: 0.3,
    AFTERIMAGE_SLOTS: 4,
    // ring buffer per enemy; lifetime/interval + 1
    /** Rule R5's fallback visualisation. The cone drawing itself is not implemented yet. */
    DEBUG_SHOW_VISION_CONE: false
  },
  /** Map generation */
  MAP: {
    WIDTH: 80,
    // tiles (larger to accommodate multiple fragments)
    HEIGHT: 80,
    // tiles
    /** Voronoi partitioning */
    FRAGMENT_COUNT_MIN: 4,
    FRAGMENT_COUNT_MAX: 6,
    FRAGMENT_MIN_AREA: 150,
    // minimum tiles per fragment
    /** Cellular automata */
    CA_ITERATIONS: 5,
    // smoothing passes
    CA_WALL_THRESHOLD: 4,
    // cells with >= N wall neighbors become wall
    CA_INITIAL_FILL: 0.45,
    // initial random fill ratio (lower = more open)
    /** Fracture connections between fragments */
    FRACTURE_WIDTH: 2,
    // tiles (narrow passage width)
    FRACTURE_MAX_PER_EDGE: 2
    // max connections between two adjacent fragments
  },
  /**
   * Slice 6 C1 land outline. Rectangular tile buffer; walkable land must not fill it.
   * 80×80 MAP.* numbers stay architecture placeholders — do not use them for this generator.
   */
  GENERATION: {
    BUFFER_COLS: 64,
    BUFFER_ROWS: 42,
    MAX_OUTLINE_ATTEMPTS: 28,
    LAND_FILL_MIN: 0.24,
    LAND_FILL_MAX: 0.48,
    BORDER_RING: 2,
    /** Fraction of the outer ring that may be land. Higher = island hugging the rectangle. */
    BORDER_OCCUPANCY_MAX: 0.12,
    /** Land / axis-aligned bbox. Circles sit near 0.78; filled rectangles sit near 1. */
    BBOX_FILL_MAX: 0.8,
    /**
     * Share of land cells that touch void. Large blobs naturally sit lower;
     * this only rejects near-solid blocks (a 1-cell frame around a filled rect).
     */
    ROUGHNESS_MIN: 0.08,
    /** bbox must leave at least this many leftover cells on width+height combined. */
    MIN_BBOX_SLACK: 8,
    MAX_EDGES_TOUCHING: 3,
    MAX_RUIN_ATTEMPTS: 40,
    MIN_FEATURE_SEPARATION: 7,
    WALL_RATIO_MIN: 0.018,
    WALL_RATIO_MAX: 0.22,
    /** Largest leftover open rectangle (tiles). Bigger than this reads as an empty plaza. */
    YARD_AREA_MAX: 64
  },
  /** Purification point (docs/specs/system-purification-impact.md) */
  PURIFICATION: {
    /** Spatial layout */
    MAP_COLS: 14,
    // tiles
    MAP_ROWS: 12,
    // tiles
    INTERACTION_RADIUS: 32,
    // pixels for module/rift-entrance interaction
    /** Module state */
    MODULE_INITIAL_HP: 70,
    /** Tier-0 repair cap / effect denominator baseline (DEC-064). */
    MODULE_BASE_MAX_HP: 100,
    /** Alias of MODULE_BASE_MAX_HP so older call sites still compile. */
    MODULE_MAX_HP: 100,
    /** Each thicken tier adds this many maxHp to every module. */
    MODULE_MAX_HP_PER_TIER: 15,
    /** Highest purchasable thicken tier (maxHp = 100 + 15*3 = 145). */
    MODULE_MAX_HP_TIERS: 3,
    // Thickening purchase costs are authored alongside all other growth steps
    // in data/growth-route.csv, not a separate system-constant price ladder.
    /** All three module effects use this HP reference; thickening does not raise it. */
    MODULE_EFFECT_HP_REF: 100,
    /** Starting chaos when purifier hp = 0 (full integrity → 0). */
    CHAOS_HARD_START: 50,
    REPAIR_PER_KINDLING: 4,
    // 1 kindling = this many hp (tuned for scarcity)
    /** Impact system (intensity now driven by TideSystem, see TIDE constants) */
    BASE_IMPACT_DAMAGE: 30,
    THREAT_FOCUS_RATIO: 0.65,
    // primary target gets this fraction of total damage
    FORECAST_ACCURACY: 0.8,
    // particle prediction accuracy
    /** combust defense mechanic (DEC-030): fixed threshold, not derived from
     * BASE_IMPACT_DAMAGE, so tide-driven damage swings don't shift the trigger point.
     * Value chosen to equal ~2x BASE_IMPACT_DAMAGE(30) per the CSV's "约等于2次满额冲击". */
    COMBUST_BURN_THRESHOLD: 60,
    /** Module effects */
    MAX_CORE_REDUCTION: 0.3,
    // chaosRate reduction at full hp
    MAX_STORAGE_BONUS: 0.5,
    // kindling value bonus at full hp
    /** resonate (Slice 5 gap-fill, DEC-039): "装备期间CORE和STORAGE模块效果上限各提升10%".
     * A flat bump to both caps above while at least one resonate sits in a defense slot -
     * not a multiplier, so it reads the same way the CSV states it ("+10%" alongside two
     * numbers already expressed as flat percentages). "不叠加" is enforced by storing this
     * as a single on/off flag (`GameState.isResonateBonusActive()`), not a per-item count. */
    RESONATE_MODULE_CAP_BONUS: 0.1,
    /** siphon (Slice 5 gap-fill): "装备期间所有薪柴修复模块的效率翻倍(1薪柴=8hp)" - same
     * "装备期间" derivation pattern as RESONATE_MODULE_CAP_BONUS above (owned by
     * `ContaminantSystem.syncRepairEfficiencyMult()` + `GameState`, not a per-impact
     * defense-engine effect), since the CSV names it a standing equip-state bonus rather
     * than a one-impact trigger. 4 (REPAIR_PER_KINDLING) * 2.0 = 8, matching the CSV. */
    SIPHON_REPAIR_EFFICIENCY_MULT: 2,
    /** Boundary atmosphere */
    ATMOSPHERE: {
      PARTICLE_COUNT: 50,
      // active boundary particles
      PARTICLE_ALPHA_MIN: 0.06,
      PARTICLE_ALPHA_MAX: 0.25,
      PARTICLE_SPEED: 8,
      // px/s slow inward drift
      APPARITION_INTERVAL_MIN: 8e3,
      // ms
      APPARITION_INTERVAL_MAX: 15e3,
      APPARITION_DURATION: 3e3,
      // ms (0.5s fade in + 2s hold + 0.5s fade out)
      APPARITION_MAX_SIMULTANEOUS: 3
    },
    /** Dynamic boundary shape (polar pressure blob) */
    BOUNDARY: {
      SHRINK_AT_MAX_INTENSITY: 0.72,
      // tideScale at intensity 3.0 (boundary loses up to 28%)
      PRESSURE_PRIMARY_AMP: 0.2,
      // max inward push fraction (primary Gaussian lobe)
      PRESSURE_SECONDARY_AMP: 0.1,
      // secondary lobe amplitude
      PRESSURE_LOBE_SIGMA: 0.7,
      // radians; width of each Gaussian lobe
      PRESSURE_CREST_BONUS: 0.4,
      // +40% amplitude during crest phase
      PRESSURE_EBB_FACTOR: 0.6,
      // amplitude multiplier during ebb phase
      SAFE_MARGIN_TILES: 1,
      // minimum distance from any interaction point to boundary
      GRADIENT_INNER_START: 0.8,
      // fraction of R where darkening begins
      GRADIENT_MEMBRANE_START: 0.95,
      // fraction where "membrane" teal band begins
      GRADIENT_OUTER_END: 1.15,
      // fraction where full void begins
      /**
       * B4 (Slice 5): the old BREATH_BASE_ALPHA/AMP/FREQ/CREST_FREQ_MULT/EBB_AMP_MULT
       * keys described a single global sinusoidal pulse from a "whole-boundary breathing"
       * design that DEC-028 (Slice 4.5) replaced with localized pressure impacts
       * (`src/systems/boundary-breath.ts`). Those 5 keys had zero consumers and were
       * removed; this nested object holds boundary-breath.ts's real tuning knobs
       * (previously inlined as top-of-file `const`s there) instead. Values unchanged.
       */
      BREATH: {
        SAMPLE_COUNT: 72,
        // angular resolution of the membrane/impact draw
        MAX_IMPACTS: 5,
        // max simultaneous localized impacts
        ARC_HALF_MIN: 0.4,
        // rad; narrowest impact arc half-width
        ARC_HALF_MAX: 0.8,
        // rad; widest impact arc half-width
        SPAWN_DIST_MIN: 14,
        // px; closest impact spawn distance outside the membrane
        SPAWN_DIST_MAX: 30,
        // px; farthest impact spawn distance
        IMPACT_DURATION_MIN: 1800,
        // ms; shortest single-impact lifetime
        IMPACT_DURATION_MAX: 3500,
        // ms; longest single-impact lifetime
        SPAWN_INTERVAL_MIN: 400,
        // ms; shortest gap between new impacts
        SPAWN_INTERVAL_MAX: 1200,
        // ms; longest gap between new impacts (x0.6 during crest)
        WAVE_COLOR: 936511,
        // dark desaturated teal, the inbound wave arcs
        MEMBRANE_COLOR: 1735274,
        // the boundary membrane line itself
        DEFORM_MAX_PX: 8
        // px; max inward push of the membrane at impact center
      }
    },
    /** Scene transition timing */
    IMPACT_RESULT_DISPLAY_MS: 2e3,
    SCENE_TRANSITION_DELAY_MS: 600
  },
  /**
   * Combat (docs/specs/system-combat.md, "数值结构"). Every combat number lives here.
   *
   * The system is a price list, not a fight: the point is that the player can work out
   * what swinging costs before swinging. Three of these relations carry that promise and
   * are asserted at boot by `config/invariants.ts` (K1/K2/K3/K5) - notably
   * `ENEMY_MAX_HEALTH` being an exact multiple of `PLAYER_DAMAGE`, which is what makes
   * "three hits" a fact rather than an average.
   *
   * When combat turns out too cheap in playtesting, the spec's tuning order is
   * `CHAOS.COMBAT_BONUS` and `NOISE_HIT_RADIUS` first, `ENEMY_MAX_HEALTH` second, and
   * `PLAYER_DAMAGE` never (weakening it makes combat expensive *and* unpleasant).
   */
  COMBAT: {
    // --- player attack (section "玩家攻击") ---
    PLAYER_DAMAGE: 25,
    ATTACK_COOLDOWN: 500,
    // ms, counted from the input instant, parallel to the phases
    ATTACK_RANGE: 40,
    // px centre-to-centre; must exceed ENEMY_ATTACK_RANGE (K2)
    ATTACK_HALF_ANGLE: 60,
    // deg -> a 120 deg forward sector
    ATTACK_WINDUP_MS: 100,
    // the player's side of the commitment
    ATTACK_ACTIVE_MS: 50,
    // ~3 frames; exists to tolerate frame jitter, not to widen the hit
    ATTACK_RECOVERY_MS: 70,
    ATTACK_SLOW_MS: 220,
    // derived: windup + active + recovery (asserted, not free)
    ATTACK_SELF_SLOW: 0.35,
    // move speed while swinging - the "cost" that lands on feel
    ATTACK_MIN_ANGLE_BYPASS: 16,
    // px within which the angle test is meaningless and skipped
    /** Key name in `Phaser.Input.Keyboard.KeyCodes`. Read by RiftScene, which owns input. */
    ATTACK_KEY: "SPACE",
    // --- infiltrator (section "敌人（渗透体）") ---
    ENEMY_MAX_HEALTH: 75,
    // = 3 x PLAYER_DAMAGE exactly (K1, DEC-012)
    ENEMY_DAMAGE_BASE: 15,
    ENEMY_ATTACK_RANGE: 38,
    // px; between AI.STANDOFF_DISTANCE and ATTACK_RANGE (K2)
    ENEMY_ATTACK_HALF_ANGLE: 60,
    // deg; symmetric with the player's
    ENEMY_ATTACK_WINDUP_MS: 350,
    // the player's dodge window - the whole of "controllable" (K3)
    ENEMY_ATTACK_COOLDOWN_MS: 1200,
    ENEMY_FIRST_ATTACK_DELAY_MS: 300,
    // "caught up with you" and "hit you" stay two events
    ENEMY_ATTACK_TOKENS: 2,
    // enemies allowed in windup at once; caps unavoidable damage
    ENEMY_HIT_FLASH_MS: 80,
    ENEMY_DEATH_FX_MS: 180,
    // presentation only; the enemy is gone from logic at 0 ms
    // --- player health and hits (section "玩家生命值与受击") ---
    PLAYER_IFRAME_MS: 400,
    // stops two enemies resolving on one frame for 30 damage
    PLAYER_HIT_FLASH_MS: 100,
    // --- noise: the exposure half of the price (section "噪声") ---
    NOISE_SWING_RADIUS: 96,
    // px (3 tiles), 'suspicious' - a whiff is heard, not billed
    NOISE_HIT_RADIUS: 160,
    // px (5 tiles), 'alert' - the main reason a fight is loud
    NOISE_KILL_RADIUS: 192,
    // px (6 tiles), 'alert'
    /**
     * Placeholder presentation (spec V2). White is on loan here: it currently means
     * "player / extraction point" in art-direction 12, and using thin white lines and
     * flashes for combat actions is still awaiting art sign-off (spec escalate 1 and 2).
     * Treat these as stand-ins, not as the visual language.
     */
    FX_COLOR: 16777215,
    ATTACK_FAN_FX_MS: 60,
    // how long the swing outline stays up (spec V2)
    PLAYER_FLASH_PAD: 6,
    // px the hit flash overshoots the body; see report on white-on-white
    FX_POOL_SIZE: 12
    // preallocated flash/death sprites: 8 enemies + headroom
  },
  /**
   * Contamination lexicon (DEC-076). Morph tables stay in CSV.
   * These are system constants: core HP, chaos prices, draw retry, encounter timing.
   */
  CONTAMINATION: {
    CORE_MAX_HEALTH: 50,
    ADJACENT_STRIKE_DAMAGE: 15,
    ADJACENT_STRIKE_WINDUP_MS: 350,
    PAINT_STEP_CHAOS_REST: 2,
    PAINT_STEP_CHAOS_INFLATED: 4,
    VOLUME_CHAOS_PER_SEC: 1,
    VOLUME_SIGHT_MULT: 0.7,
    DRAW_RETRY_LIMIT: 12,
    ENCOUNTER_COOLDOWN_MS: 6e4,
    ENCOUNTER_GAP_MS: 2500,
    ENCOUNTER_HOLD_MS: 2500,
    VOLUME_DEPTH: 40,
    COLONY_NUCLEUS_COUNT_MIN: 2,
    COLONY_NUCLEUS_COUNT_MAX: 3,
    COLONY_NUCLEUS_MIN_TILE_GAP: 3
  },
  /** Audio */
  AUDIO: {
    MAX_SIMULTANEOUS_SFX: 8,
    DEFAULT_SFX_VOLUME: 0.7,
    DEFAULT_BGM_VOLUME: 0.4,
    DEFAULT_AMBIENT_VOLUME: 0.5
  },
  /** Tide system (docs/specs/system-growth-tide.md, section T) */
  TIDE: {
    TIDES: [
      { floor: 1, peak: 1.6, riseCycles: 3, crestCycles: 1, ebbCycles: 2, ebbTarget: 1.2 },
      { floor: 1.2, peak: 2, riseCycles: 4, crestCycles: 1, ebbCycles: 2, ebbTarget: 1.5 },
      { floor: 1.5, peak: 2.4, riseCycles: 4, crestCycles: 2, ebbCycles: 2, ebbTarget: 1.8 },
      { floor: 1.8, peak: 2.8, riseCycles: 4, crestCycles: 2, ebbCycles: 3, ebbTarget: 2 },
      { floor: 2, peak: 3, riseCycles: 5, crestCycles: Infinity, ebbCycles: 0, ebbTarget: 2 }
    ],
    CREST_CHARGE_COST: 3,
    // impact charge cost during Crest phase
    NORMAL_CHARGE_COST: 1,
    // impact charge cost during Rise/Ebb phases
    TRANSFORM_THRESHOLD: 3
    // charges needed to transform defense -> tool
  },
  // Growth / permanent upgrades (docs/specs/system-growth-tide.md, section G):
  // Definitions come from data/upgrades.csv; all step costs come from
  // data/growth-route.csv (including thickening). Both generate upgrade-data.ts
  // under the CSV source rule — no constants block here
  // by design; growth-system.ts reads UPGRADE_DATA directly.
  /** Contaminant system (docs/specs/system-growth-tide.md, section CN) */
  CONTAMINANT: {
    NODES_PER_MAP: 3,
    // contaminant pickup nodes per rift map
    RARITY_WEIGHTS: { common: 60, fine: 30, rare: 10 },
    DEFENSE_SLOTS: 1,
    // base slot; each growth_defense_slot level adds +1
    SORTIE_SLOTS: 3,
    // base slots (2 active + 1 passive); growth_sortie_slot adds +1 active
    MAX_DEFENSE_SLOTS: 4,
    // DEFENSE_SLOTS + max growth_defense_slot bonus (maxLevel 3)
    MAX_SORTIE_SLOTS: 4,
    // SORTIE_SLOTS + max growth_sortie_slot bonus (maxLevel 1)
    USES: { common: 5, fine: 3, rare: 2 },
    // uses remaining after transformation
    /** echo defense mechanic: "单件因此最多+2" — per-tool cap on echo bonus grants. */
    ECHO_MAX_TOOL_USE_BONUS: 2,
    /**
     * Hotkeys for the active sortie slots, in slot order. The passive slot (always the
     * last unlocked slot, see `contaminantSystem.getSortiePassiveSlotIndex()`) never gets
     * an entry here - it has no hotkey by design. G was picked for the 3rd slot
     * (growth_sortie_slot, Slice 5 T5) because it sits directly beside F on the keyboard,
     * the same "one key past the movement cluster" reach as Q/F already use, and every
     * other neighbour (E/R/T) is already taken by extraction/restart/nothing-reserved-but-
     * awkward. Single source of truth for both the RiftScene binding and any UI that needs
     * to render the real key label.
     */
    SORTIE_ACTIVE_KEYS: ["Q", "F", "G"]
  },
  /** Purification stability (docs/specs/system-growth-tide.md, section S) */
  STABILITY: {
    MAX: 100,
    GAIN_EXTRACT: 1,
    // successful extraction (calibrated: ~35 cycles to cap)
    GAIN_GROWTH: 1,
    // purchased an upgrade
    GAIN_CREST_SURVIVED: 3,
    // survived a full Crest with no module at zero
    GAIN_TIDE_ADVANCE: 5,
    // tide advanced to next number
    LOSS_MODULE_ZERO: -1
    // a module reached 0 hp
  },
  /**
   * Fine/Rare active+passive tool numbers not already carried by
   * `src/generated/contaminant-data.ts` (radius/duration/uses read straight from the CSV
   * at the point of use instead of being re-hardcoded here - see `docs/design-notes/
   * slice3-sortie-tools.md`). Everything below is either a multiplier/amount the CSV
   * description states in prose (`data/contaminants.csv`, `description_tool` column) or,
   * where flagged, a placeholder-tier number the CSV leaves unspecified (Slice 5 T1).
   */
  TOOLS: {
    /** compress: "半径2格内敌人移速-60%" */
    COMPRESS_SPEED_MULT: 0.4,
    /** resonate: "弹回3格并眩晕2秒" */
    RESONATE_KNOCKBACK_PX: 96,
    RESONATE_STUN_MS: 2e3,
    /** overwrite: "感知范围缩小50%" */
    OVERWRITE_PERCEPTION_MULT: 0.5,
    /** combust: "感知范围-50%"(烈焰遮蔽视线) */
    COMBUST_PERCEPTION_MULT: 0.5,
    /** combust: "每秒受到持续伤害" - CSV gives no amount; placeholder tuned so an enemy
     * that stays the full 8s duration dies (75 hp / 15 = 5 ticks), matching the tool's
     * rare-tier power level. Flagged for design confirmation (see delivery report). */
    COMBUST_DAMAGE_PER_TICK: 15,
    COMBUST_TICK_MS: 1e3,
    /** mirror: "被敌人接触后碎裂消失" - CSV gives no contact radius; placeholder tuned to
     * roughly one enemy body width. Flagged for design confirmation. */
    MIRROR_CONTACT_RADIUS: 20,
    /** abyss: "使用后5秒内混乱增速+50%" - a second timing value the CSV's single
     * `tool_duration_ms` column cannot carry (that field holds the 10s reveal instead). */
    ABYSS_CHAOS_BOOST_MULT: 1.5,
    ABYSS_CHAOS_BOOST_MS: 5e3,
    /** siphon: "吸取2点薪柴且...混乱值增速减半" */
    SIPHON_KINDLING_GAIN: 2,
    SIPHON_CHAOS_REDUCTION_MULT: 0.5
  },
  /** Persistent save (docs/specs/system-growth-tide.md, section P) */
  SAVE: {
    KEY: "coh-save-v1",
    VERSION: 2
  }
};

// src/generation/world-study/native-volume-erosion.ts
var EPSILON2 = 1e-7;
var LEGACY_TERRAIN_BUDGET = { minPolygons: 1, maxPolygons: 12, maxPoints: 32, maxTotalPoints: 384 };
var FRAGMENT_TERRAIN_BUDGET = Object.freeze({ minPolygons: 0, maxPolygons: 128, maxPoints: 2048, maxTotalPoints: 8192 });
var cross2 = (a, b, c) => (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
function onSegment(a, b, p) {
  return Math.abs(cross2(a, b, p)) <= EPSILON2 && p.x >= Math.min(a.x, b.x) - EPSILON2 && p.x <= Math.max(a.x, b.x) + EPSILON2 && p.y >= Math.min(a.y, b.y) - EPSILON2 && p.y <= Math.max(a.y, b.y) + EPSILON2;
}
function intersects(a, b, c, d) {
  const abC = cross2(a, b, c), abD = cross2(a, b, d), cdA = cross2(c, d, a), cdB = cross2(c, d, b);
  return abC * abD < -EPSILON2 && cdA * cdB < -EPSILON2 || onSegment(a, b, c) || onSegment(a, b, d) || onSegment(c, d, a) || onSegment(c, d, b);
}
function contains(polygon2, point) {
  let inside3 = false;
  for (let i = 0, j = polygon2.length - 1; i < polygon2.length; j = i++) {
    const a = polygon2[i], b = polygon2[j];
    if (a.y > point.y !== b.y > point.y && point.x < (b.x - a.x) * (point.y - a.y) / (b.y - a.y) + a.x) inside3 = !inside3;
  }
  return inside3;
}
function validateNativeErosion(value, width = 1024, height = 768, budget = LEGACY_TERRAIN_BUDGET) {
  if (!Number.isFinite(width) || !Number.isFinite(height) || width <= 0 || height <= 0 || !Array.isArray(value) || value.length < budget.minPolygons || value.length > budget.maxPolygons) throw new Error("Native erosion polygon count exceeds its explicit terrain budget");
  if (value.reduce((total, polygon2) => total + (Array.isArray(polygon2) ? polygon2.length : 0), 0) > budget.maxTotalPoints) throw new Error("Native terrain total vertex budget exceeded");
  for (const polygon2 of value) {
    if (!Array.isArray(polygon2) || polygon2.length < 3 || polygon2.length > budget.maxPoints) throw new Error("Native terrain polygon point budget exceeded");
    for (const point of polygon2) {
      if (!point || typeof point !== "object" || Object.keys(point).sort().join(",") !== "x,y" || !Number.isFinite(point.x) || !Number.isFinite(point.y) || point.x < 0 || point.x > width || point.y < 0 || point.y > height)
        throw new Error("Native erosion point must have only finite in-bounds x/y");
    }
    const points = polygon2;
    if (new Set(points.map((point) => `${point.x}:${point.y}`)).size !== points.length) throw new Error("Native erosion polygon repeats a point");
    const twiceArea = points.reduce((sum, a, i) => {
      const b = points[(i + 1) % points.length];
      return sum + a.x * b.y - a.y * b.x;
    }, 0);
    if (Math.abs(twiceArea) < 128) throw new Error("Native erosion polygon area must be at least 64px\xB2");
    for (let i = 0; i < points.length; i++) {
      const a = points[i], b = points[(i + 1) % points.length], previous = points[(i + points.length - 1) % points.length];
      if (Math.abs(cross2(previous, a, b)) <= EPSILON2 && (previous.x - a.x) * (b.x - a.x) + (previous.y - a.y) * (b.y - a.y) > 0)
        throw new Error("Native erosion adjacent edges overlap");
      for (let j = i + 1; j < points.length; j++) {
        if (j === i + 1 || i === 0 && j === points.length - 1) continue;
        if (intersects(a, b, points[j], points[(j + 1) % points.length])) throw new Error("Native erosion polygon self-intersects");
      }
    }
  }
  const polygons = value;
  for (let i = 0; i < polygons.length; i++) for (let j = i + 1; j < polygons.length; j++) {
    const a = polygons[i], b = polygons[j];
    if (contains(a, b[0]) || contains(b, a[0])) throw new Error("Native erosion polygons contain one another");
    for (let x = 0; x < a.length; x++) for (let y = 0; y < b.length; y++) {
      if (intersects(a[x], a[(x + 1) % a.length], b[y], b[(y + 1) % b.length])) throw new Error("Native erosion polygons overlap or touch");
    }
  }
}
function validateNativeTerrainOutline(value, width, height, erosion = [], budget = LEGACY_TERRAIN_BUDGET) {
  validateNativeErosion([value], width, height, budget);
  const outline = value;
  for (const hole of erosion) {
    if (hole.some((point) => !contains(outline, point))) throw new Error("Terrain erosion must remain inside the positive outline");
    for (let i = 0; i < outline.length; i++) for (let j = 0; j < hole.length; j++) {
      if (intersects(outline[i], outline[(i + 1) % outline.length], hole[j], hole[(j + 1) % hole.length]))
        throw new Error("Terrain erosion must not cross or touch the positive outline");
    }
  }
}
function validateNativeGroundEdgeOwnership(definition, budget = LEGACY_TERRAIN_BUDGET) {
  if (definition.authoredErosion !== void 0 && definition.authoredErosion !== true) throw new Error("Invalid authored erosion marker");
  if (definition.authoredErosion && definition.instances.some((instance) => instance.constructionVersion !== 4)) throw new Error("Authored erosion requires construction 4");
  const holders = definition.instances.filter((instance) => instance.groundEdgeWidth !== void 0);
  if (!holders.length) return;
  const primaryRelief = definition.instances.find((instance) => instance.role === "relief" && (instance.family ?? definition.family) === definition.family);
  if (!definition.authoredErosion || holders.length !== 1 || holders[0] !== primaryRelief || holders[0].constructionVersion !== 4 || holders[0].height > 6 || holders[0].groundEdgeWidth < 8 || holders[0].groundEdgeWidth > 24)
    throw new Error("Authored ground edge must belong to the unique first v4 low primary relief");
  validateNativeErosion(definition.erosion, definition.cols * 32, definition.rows * 32, budget);
}

// src/systems/ai/physical-grid.ts
var BODY_CLEARANCE_EPSILON = 1e-6;
function bodyHasSupport(walk, center, halfWidth, halfHeight) {
  if (![center.x, center.y, halfWidth, halfHeight].every(Number.isFinite) || halfWidth < 0 || halfHeight < 0 || center.x - halfWidth < 0 || center.y - halfHeight < 0 || center.x + halfWidth > walk.cols * walk.tileSize || center.y + halfHeight > walk.rows * walk.tileSize) return false;
  const insetX = Math.min(halfWidth, BODY_CLEARANCE_EPSILON), insetY = Math.min(halfHeight, BODY_CLEARANCE_EPSILON);
  const firstCol = Math.floor((center.x - halfWidth + insetX) / walk.tileSize);
  const lastCol = Math.floor((center.x + halfWidth - insetX) / walk.tileSize);
  const firstRow = Math.floor((center.y - halfHeight + insetY) / walk.tileSize);
  const lastRow = Math.floor((center.y + halfHeight - insetY) / walk.tileSize);
  for (let row = firstRow; row <= lastRow; row++) {
    for (let col = firstCol; col <= lastCol; col++) if (!walk.isWalkable(col, row)) return false;
  }
  return true;
}
function bodyDisplacementFraction(walk, center, halfWidth, halfHeight, dx, dy) {
  if (!Number.isFinite(center.x) || !Number.isFinite(center.y) || !Number.isFinite(halfWidth) || !Number.isFinite(halfHeight) || !Number.isFinite(dx) || !Number.isFinite(dy) || halfWidth < 0 || halfHeight < 0) return 0;
  if (dx === 0 && dy === 0) return 0;
  const size = walk.tileSize, epsilon = BODY_CLEARANCE_EPSILON;
  const firstCol = Math.max(-1, Math.floor((Math.min(center.x, center.x + dx) - halfWidth) / size));
  const lastCol = Math.min(walk.cols, Math.floor((Math.max(center.x, center.x + dx) + halfWidth) / size));
  const firstRow = Math.max(-1, Math.floor((Math.min(center.y, center.y + dy) - halfHeight) / size));
  const lastRow = Math.min(walk.rows, Math.floor((Math.max(center.y, center.y + dy) + halfHeight) / size));
  let fraction = 1;
  for (let row = firstRow; row <= lastRow; row++) {
    for (let col = firstCol; col <= lastCol; col++) {
      if (col >= 0 && row >= 0 && col < walk.cols && row < walk.rows && walk.isWalkable(col, row)) continue;
      const minX = col * size - halfWidth + epsilon, maxX = (col + 1) * size + halfWidth - epsilon;
      const minY = row * size - halfHeight + epsilon, maxY = (row + 1) * size + halfHeight - epsilon;
      let entry = 0, exit = fraction;
      if (dx === 0) {
        if (center.x <= minX || center.x >= maxX) continue;
      } else {
        const a = (minX - center.x) / dx, b = (maxX - center.x) / dx;
        entry = Math.max(entry, Math.min(a, b));
        exit = Math.min(exit, Math.max(a, b));
      }
      if (dy === 0) {
        if (center.y <= minY || center.y >= maxY) continue;
      } else {
        const a = (minY - center.y) / dy, b = (maxY - center.y) / dy;
        entry = Math.max(entry, Math.min(a, b));
        exit = Math.min(exit, Math.max(a, b));
      }
      if (entry < exit && exit > 0) fraction = Math.min(fraction, entry);
    }
  }
  return fraction < 1 ? Math.max(0, fraction - 1e-4 / Math.max(Math.abs(dx), Math.abs(dy))) : 1;
}

// src/systems/tile-grid.ts
var TileGrid = class {
  cols;
  rows;
  tileSize;
  widthPx;
  heightPx;
  data;
  _version = 0;
  constructor(map) {
    this.cols = map.cols;
    this.rows = map.rows;
    this.tileSize = map.tileSize;
    this.widthPx = map.cols * map.tileSize;
    this.heightPx = map.rows * map.tileSize;
    this.data = new Uint8Array(map.cols * map.rows);
    for (let row = 0; row < map.rows; row++) {
      const sourceRow = map.tiles[row];
      if (!sourceRow || sourceRow.length !== map.cols) {
        throw new Error(`TileGrid: row ${row} does not have ${map.cols} tiles`);
      }
      for (let col = 0; col < map.cols; col++) {
        this.data[row * map.cols + col] = sourceRow[col];
      }
    }
  }
  get version() {
    return this._version;
  }
  /**
   * Returns `TileType.WALL` for out-of-bounds so callers never need bounds checks.
   * In-bounds VOID stays VOID (unwalkable; opaque via `isOpaque`).
   */
  getTile(col, row) {
    if (col < 0 || col >= this.cols || row < 0 || row >= this.rows) return 0 /* WALL */;
    return this.data[row * this.cols + col];
  }
  isOpaque(col, row) {
    const tile = this.getTile(col, row);
    return tile === 0 /* WALL */ || tile === 3 /* VOID */;
  }
  isWalkable(col, row) {
    const tile = this.getTile(col, row);
    return tile === 1 /* FLOOR */ || tile === 2 /* FRACTURE */;
  }
  /** True when the world position falls inside a walkable tile. */
  isWalkableAt(x, y) {
    return this.isWalkable(Math.floor(x / this.tileSize), Math.floor(y / this.tileSize));
  }
  /** Mutates a tile and bumps `version` so caches (vision, paths) invalidate. */
  setTile(col, row, tile) {
    if (col < 0 || col >= this.cols || row < 0 || row >= this.rows) return;
    const index = row * this.cols + col;
    if (this.data[index] === tile) return;
    this.data[index] = tile;
    this._version++;
  }
  /** Writes the centre of a tile into `out` (no allocation). */
  tileToWorld(col, row, out) {
    out.x = col * this.tileSize + this.tileSize / 2;
    out.y = row * this.tileSize + this.tileSize / 2;
    return out;
  }
  /** Writes the tile containing a world position into `out` (no allocation). */
  worldToTile(x, y, out) {
    out.col = Math.floor(x / this.tileSize);
    out.row = Math.floor(y / this.tileSize);
    return out;
  }
};

// src/generation/world-study/native-terrain.ts
var TILE = 32;
var SUPPORT = 8;
var HALF_BODY = GAME_CONSTANTS.PLAYER.BODY_SIZE / 2;
var DIRECTIONS = [[1, 0], [-1, 0], [0, 1], [0, -1]];
function insidePolygon(points, x, y) {
  let inside3 = false;
  for (let i = 0, j = points.length - 1; i < points.length; j = i++) {
    const a = points[i], b = points[j];
    if (a.y > y !== b.y > y && x < (b.x - a.x) * (y - a.y) / (b.y - a.y) + a.x) inside3 = !inside3;
  }
  return inside3;
}
function solidCoverage(meshes, cols, rows) {
  const coverage = new Uint8Array(cols * rows), half = SUPPORT / 2;
  for (const mesh of meshes) for (let face = 0; face < mesh.triangleCount; face++) {
    const p = mesh.positions, a = mesh.indices[face * 3] * 3, b = mesh.indices[face * 3 + 1] * 3, c = mesh.indices[face * 3 + 2] * 3;
    const xs = [p[a], p[b], p[c]], ys = [p[a + 1], p[b + 1], p[c + 1]];
    if (Math.abs((xs[1] - xs[0]) * (ys[2] - ys[0]) - (ys[1] - ys[0]) * (xs[2] - xs[0])) < 1e-7) continue;
    const minCol = Math.max(0, Math.floor(Math.min(...xs) / SUPPORT)), maxCol = Math.min(cols - 1, Math.floor(Math.max(...xs) / SUPPORT));
    const minRow = Math.max(0, Math.floor(Math.min(...ys) / SUPPORT)), maxRow = Math.min(rows - 1, Math.floor(Math.max(...ys) / SUPPORT));
    for (let row = minRow; row <= maxRow; row++) for (let col = minCol; col <= maxCol; col++) {
      const index = row * cols + col;
      if (coverage[index]) continue;
      const x = (col + 0.5) * SUPPORT, y = (row + 0.5) * SUPPORT;
      let overlaps3 = true;
      for (let edge = 0; edge < 3; edge++) {
        const next = (edge + 1) % 3, nx = ys[next] - ys[edge], ny = xs[edge] - xs[next];
        const pa = xs[0] * nx + ys[0] * ny, pb = xs[1] * nx + ys[1] * ny, pc = xs[2] * nx + ys[2] * ny;
        const center = x * nx + y * ny, radius = half * (Math.abs(nx) + Math.abs(ny));
        if (Math.max(pa, pb, pc) <= center - radius + 1e-7 || Math.min(pa, pb, pc) >= center + radius - 1e-7) {
          overlaps3 = false;
          break;
        }
      }
      if (overlaps3) coverage[index] = 1;
    }
  }
  return coverage;
}
function compileNativeTerrain(definition, seed2, includeGroundEdges = true) {
  if (!Number.isSafeInteger(seed2) || seed2 < 0 || seed2 > 4294967295) throw new Error("Seed must be a uint32");
  const width = definition.cols * TILE, height = definition.rows * TILE;
  const positiveTerrain = Object.prototype.hasOwnProperty.call(definition, "terrainOutline");
  if (definition.fragmentShapeVersion !== void 0 && (definition.fragmentShapeVersion !== "rectilinear-fragment-v1" || !positiveTerrain)) throw new Error("Invalid compiled fragment terrain identity");
  const terrainBudget = definition.fragmentShapeVersion === "rectilinear-fragment-v1" ? FRAGMENT_TERRAIN_BUDGET : void 0;
  if (positiveTerrain) validateNativeTerrainOutline(definition.terrainOutline, width, height, definition.erosion, terrainBudget);
  const land = new Uint8Array(definition.cols * definition.rows), walls = new Uint8Array(land.length);
  const flowAngle = new Float32Array(land.length), deposition = new Float32Array(land.length);
  for (let row = 0; row < definition.rows; row++) for (let col = 0; col < definition.cols; col++) {
    const i = row * definition.cols + col;
    if (!positiveTerrain) land[i] = col >= 1 && row >= 1 && col < definition.cols - 1 && row < definition.rows - 1 && !(col < 3 && row < 3) && !(col > definition.cols - 4 && row > definition.rows - 4) ? 1 : 0;
    flowAngle[i] = definition.axis + Math.sin(row * 0.34) * 0.06;
    deposition[i] = 0.48 + Math.sin(col * 0.23 + row * 0.1) * 0.15;
  }
  const cols = width / SUPPORT, rows = height / SUPPORT;
  const matter = new Uint8Array(cols * rows), erosion = new Uint8Array(matter.length);
  for (let row = 0; row < rows; row++) for (let col = 0; col < cols; col++) {
    const x = (col + 0.5) * SUPPORT, y = (row + 0.5) * SUPPORT, index = row * cols + col;
    const floor = positiveTerrain ? insidePolygon(definition.terrainOutline, x, y) : land[Math.floor(y / TILE) * definition.cols + Math.floor(x / TILE)] === 1;
    erosion[index] = floor && definition.erosion.some((polygon2) => insidePolygon(polygon2, x, y)) ? 1 : 0;
    matter[index] = floor && !erosion[index] ? 1 : 0;
    if (positiveTerrain && matter[index]) land[Math.floor(y / TILE) * definition.cols + Math.floor(x / TILE)] = 1;
  }
  const matterAt = (x, y) => x >= 0 && y >= 0 && x < width && y < height && matter[Math.floor(y / SUPPORT) * cols + Math.floor(x / SUPPORT)] === 1;
  validateNativeGroundEdgeOwnership(definition, terrainBudget);
  const terrainEdges = positiveTerrain ? [definition.terrainOutline, ...definition.erosion] : definition.erosion;
  const roles = /* @__PURE__ */ new Map();
  const meshes = definition.instances.map((instance) => {
    const { role, ...geometry } = instance;
    roles.set(instance.id, role);
    const { groundEdgeWidth: _groundEdgeWidth, ...withoutEdge } = geometry;
    return buildNativeVolume(
      { ...includeGroundEdges ? geometry : withoutEdge, blocking: role === "solid" ? 1 : 0, family: instance.family ?? definition.family, seed: seed2 ^ Math.imul(instance.id, 104729) },
      !includeGroundEdges || instance.groundEdgeWidth === void 0 ? void 0 : { polygons: terrainEdges, width, height, matterAt }
    );
  });
  const solids = solidCoverage(meshes.filter((mesh) => roles.get(mesh.spec.id) === "solid"), cols, rows);
  const tiles = Array.from({ length: rows }, (_, row) => Array.from({ length: cols }, (_2, col) => !matter[row * cols + col] ? 3 /* VOID */ : solids[row * cols + col] ? 0 /* WALL */ : 1 /* FLOOR */));
  const tileMap = { cols, rows, tileSize: SUPPORT, tiles }, grid = new TileGrid(tileMap);
  const center = (cell) => ({ x: (cell % cols + 0.5) * SUPPORT, y: (Math.floor(cell / cols) + 0.5) * SUPPORT });
  const seats = new Uint8Array(cols * rows);
  for (let i = 0; i < seats.length; i++) seats[i] = grid.isWalkable(i % cols, Math.floor(i / cols)) && bodyHasSupport(grid, center(i), HALF_BODY, HALF_BODY) ? 1 : 0;
  function nearest(target, available) {
    let best = -1, distance3 = Infinity;
    for (let i = 0; i < available.length; i++) {
      if (!available[i]) continue;
      const p = center(i), d = (p.x - target.x) ** 2 + (p.y - target.y) ** 2;
      if (d < distance3) {
        best = i;
        distance3 = d;
      }
    }
    if (best < 0) throw new Error("\u6784\u9020\u6CA1\u6709\u7559\u4E0B\u539F\u751F20px\u8EAB\u4F53\u7684\u5B89\u5168\u7AD9\u4F4D");
    return best;
  }
  const start = nearest({ x: definition.spawn_x, y: definition.spawn_y }, seats), reachable = new Uint8Array(seats.length), queue = [start];
  reachable[start] = 1;
  for (let at = 0; at < queue.length; at++) {
    const cell = queue[at], c = cell % cols, r = Math.floor(cell / cols), p = center(cell);
    for (const [dx, dy] of DIRECTIONS) {
      const x = c + dx, y = r + dy, next = y * cols + x;
      if (x < 0 || y < 0 || x >= cols || y >= rows || !seats[next] || reachable[next]) continue;
      if (bodyDisplacementFraction(grid, p, HALF_BODY, HALF_BODY, dx * SUPPORT, dy * SUPPORT) < 1) continue;
      reachable[next] = 1;
      queue.push(next);
    }
  }
  const spawnPoint = center(start), exitPoint = center(nearest({ x: definition.exit_x, y: definition.exit_y }, reachable));
  const searchPoint = center(nearest({ x: definition.search_x, y: definition.search_y }, reachable));
  const enemyPoint = center(nearest({ x: definition.enemy_x, y: definition.enemy_y }, reachable));
  if (Math.hypot(spawnPoint.x - definition.spawn_x, spawnPoint.y - definition.spawn_y) > 64) throw new Error("\u6BCD\u7248\u5165\u53E3\u88AB\u5DE8\u6784\u6324\u51FA\u540C\u4E00\u89C2\u5BDF\u533A");
  return {
    definition,
    width,
    height,
    cols,
    rows,
    land,
    walls,
    flowAngle,
    deposition,
    matter,
    erosion,
    roles,
    meshes,
    tileMap,
    grid,
    seats,
    reachable,
    start,
    reachableBodySeats: queue.length,
    spawnPoint,
    exitPoint,
    searchPoint,
    enemyPoint,
    matterAt
  };
}

// src/generation/world-study/native-body-collision.ts
var EPSILON3 = 1e-7;
var SEPARATION = 1e-4;
var SOLID_BUCKET_SIZE = 64;
function polygon(points) {
  if (points.length < 3) return null;
  let area3 = 0;
  for (let i = 0; i < points.length; i++) {
    const a = points[i], b = points[(i + 1) % points.length];
    area3 += a.x * b.y - b.x * a.y;
  }
  if (Math.abs(area3) < EPSILON3) return null;
  const normals = [{ x: 1, y: 0 }, { x: 0, y: 1 }];
  for (let i = 0; i < points.length; i++) {
    const a = points[i], b = points[(i + 1) % points.length], x = b.y - a.y, y = a.x - b.x, length2 = Math.hypot(x, y);
    if (length2 > EPSILON3) normals.push({ x: x / length2, y: y / length2 });
  }
  const axes = normals.map(({ x, y }) => {
    let min = Infinity, max = -Infinity;
    for (const point of points) {
      const value = point.x * x + point.y * y;
      min = Math.min(min, value);
      max = Math.max(max, value);
    }
    return { x, y, min, max };
  });
  return { points, axes, minX: axes[0].min, maxX: axes[0].max, minY: axes[1].min, maxY: axes[1].max };
}
function clip(points, axis, limit, greater) {
  const result = [];
  for (let i = 0; i < points.length; i++) {
    const a = points[i], b = points[(i + 1) % points.length];
    const insideA = greater ? a[axis] >= limit : a[axis] <= limit;
    const insideB = greater ? b[axis] >= limit : b[axis] <= limit;
    if (insideA) result.push(a);
    if (insideA !== insideB) {
      const t = (limit - a[axis]) / (b[axis] - a[axis]);
      result.push({ x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t });
    }
  }
  return result;
}
function outsideExemption(p, box2) {
  if (p.maxX <= box2.left || p.minX >= box2.right || p.maxY <= box2.top || p.minY >= box2.bottom) return [p];
  const horizontal = clip(clip(p.points, "x", box2.left, true), "x", box2.right, false);
  return [
    clip(p.points, "x", box2.left, false),
    clip(p.points, "x", box2.right, true),
    clip(horizontal, "y", box2.top, false),
    clip(horizontal, "y", box2.bottom, true)
  ].map(polygon).filter((value) => value !== null);
}
function overlap(p, center, halfW, halfH) {
  if (center.x + halfW <= p.minX + EPSILON3 || center.x - halfW >= p.maxX - EPSILON3 || center.y + halfH <= p.minY + EPSILON3 || center.y - halfH >= p.maxY - EPSILON3) return false;
  for (const axis of p.axes) {
    const at = center.x * axis.x + center.y * axis.y, radius = halfW * Math.abs(axis.x) + halfH * Math.abs(axis.y);
    if (at + radius <= axis.min + EPSILON3 || at - radius >= axis.max - EPSILON3) return false;
  }
  return true;
}
function sweepPolygon(p, center, halfW, halfH, dx, dy, hit) {
  if (Math.max(center.x, center.x + dx) + halfW <= p.minX + EPSILON3 || Math.min(center.x, center.x + dx) - halfW >= p.maxX - EPSILON3 || Math.max(center.y, center.y + dy) + halfH <= p.minY + EPSILON3 || Math.min(center.y, center.y + dy) - halfH >= p.maxY - EPSILON3) return;
  let enter = -Infinity, exit = Infinity, normalX = 0, normalY = 0;
  for (const axis of p.axes) {
    const at = center.x * axis.x + center.y * axis.y, velocity = dx * axis.x + dy * axis.y;
    const radius = halfW * Math.abs(axis.x) + halfH * Math.abs(axis.y);
    const min = axis.min - radius + EPSILON3, max = axis.max + radius - EPSILON3;
    if (Math.abs(velocity) < 1e-12) {
      if (at <= min || at >= max) return;
      continue;
    }
    const a = (min - at) / velocity, b = (max - at) / velocity, start = Math.min(a, b);
    if (start > enter) {
      enter = start;
      const sign = velocity > 0 ? -1 : 1;
      normalX = axis.x * sign;
      normalY = axis.y * sign;
    }
    exit = Math.min(exit, Math.max(a, b));
    if (enter >= exit) return;
  }
  if (exit <= 0 || enter >= hit.fraction || enter > 1) return;
  hit.fraction = Math.max(0, enter);
  hit.normalX = normalX;
  hit.normalY = normalY;
}
var NativeBodyCollision = class {
  constructor(native, map) {
    this.map = map;
    if (map.tileSize !== 8) throw new Error("Native body collision requires the original 8px navigation map");
    const roles = new Map(native.definition.instances.map((instance) => [instance.id, instance.role]));
    const solids = [];
    for (const mesh of native.meshes) {
      if (roles.get(mesh.spec.id) !== "solid") continue;
      for (let face = 0; face < mesh.indices.length; face += 3) {
        const points = [];
        for (let corner = 0; corner < 3; corner++) {
          const index = mesh.indices[face + corner] * 3;
          points.push({ x: mesh.positions[index], y: mesh.positions[index + 1] });
        }
        const value = polygon(points);
        if (value) solids.push(value);
      }
    }
    this.solids = solids;
    this.triangleCount = solids.length;
    this.bucketCols = Math.max(1, Math.ceil(map.cols * map.tileSize / SOLID_BUCKET_SIZE));
    this.bucketRows = Math.max(1, Math.ceil(map.rows * map.tileSize / SOLID_BUCKET_SIZE));
    const counts = new Uint32Array(this.bucketCols * this.bucketRows);
    const visitBuckets = (solid, visit) => {
      const left = this.bucketCoordinate(solid.minX, this.bucketCols), right = this.bucketCoordinate(solid.maxX, this.bucketCols);
      const top = this.bucketCoordinate(solid.minY, this.bucketRows), bottom = this.bucketCoordinate(solid.maxY, this.bucketRows);
      for (let row = top; row <= bottom; row++) for (let col = left; col <= right; col++) visit(row * this.bucketCols + col);
    };
    for (const solid of solids) visitBuckets(solid, (bucket) => {
      counts[bucket] = counts[bucket] + 1;
    });
    this.bucketOffsets = new Uint32Array(counts.length + 1);
    for (let i = 0; i < counts.length; i++) this.bucketOffsets[i + 1] = this.bucketOffsets[i] + counts[i];
    this.bucketSolids = new Uint32Array(this.bucketOffsets[counts.length]);
    const writeAt = this.bucketOffsets.slice(0, counts.length);
    for (let i = 0; i < solids.length; i++) visitBuckets(solids[i], (bucket) => {
      const at = writeAt[bucket];
      this.bucketSolids[at] = i;
      writeAt[bucket] = at + 1;
    });
    this.candidateBits = new Uint32Array(Math.ceil(solids.length / 32));
    this.cell = { points: [], axes: [{ x: 1, y: 0, min: 0, max: 0 }, { x: 0, y: 1, min: 0, max: 0 }], minX: 0, minY: 0, maxX: 0, maxY: 0 };
  }
  solids;
  bucketCols;
  bucketRows;
  bucketOffsets;
  bucketSolids;
  candidateBits;
  hit = { fraction: 1, normalX: 0, normalY: 0 };
  at = { x: 0, y: 0 };
  cell;
  triangleCount;
  supports(center, halfW, halfH) {
    if (!this.validBody(center, halfW, halfH)) return false;
    const size = this.map.tileSize;
    for (let row = Math.floor((center.y - halfH + EPSILON3) / size); row <= Math.floor((center.y + halfH - EPSILON3) / size); row++)
      for (let col = Math.floor((center.x - halfW + EPSILON3) / size); col <= Math.floor((center.x + halfW - EPSILON3) / size); col++)
        if (this.map.tiles[row][col] === 3 /* VOID */) return false;
    this.collectCandidates(center.x - halfW, center.y - halfH, center.x + halfW, center.y + halfH);
    for (let word = 0; word < this.candidateBits.length; word++) {
      let bits = this.candidateBits[word];
      while (bits !== 0) {
        const index = word * 32 + 31 - Math.clz32(bits & -bits);
        if (overlap(this.solids[index], center, halfW, halfH)) return false;
        bits &= bits - 1;
      }
    }
    return true;
  }
  displacementFraction(center, halfW, halfH, dx, dy, exemption) {
    if (!this.supports(center, halfW, halfH) || !Number.isFinite(dx) || !Number.isFinite(dy)) return 0;
    return this.trace(center, halfW, halfH, dx, dy, exemption).fraction;
  }
  resolveMotion(center, halfW, halfH, dx, dy, velocity, out) {
    out.x = center.x;
    out.y = center.y;
    out.velocityX = velocity.x;
    out.velocityY = velocity.y;
    out.collided = false;
    if (!this.supports(center, halfW, halfH) || (!Number.isFinite(dx) || !Number.isFinite(dy) || !Number.isFinite(velocity.x) || !Number.isFinite(velocity.y))) {
      out.velocityX = 0;
      out.velocityY = 0;
      out.collided = true;
      return;
    }
    let remainingX = dx, remainingY = dy;
    for (let iteration = 0; iteration < 4 && Math.abs(remainingX) + Math.abs(remainingY) > EPSILON3; iteration++) {
      this.at.x = out.x;
      this.at.y = out.y;
      const hit = this.trace(this.at, halfW, halfH, remainingX, remainingY);
      out.x += remainingX * hit.fraction;
      out.y += remainingY * hit.fraction;
      if (hit.fraction === 1) break;
      out.collided = true;
      remainingX *= 1 - hit.fraction;
      remainingY *= 1 - hit.fraction;
      const inward = remainingX * hit.normalX + remainingY * hit.normalY;
      if (inward >= 0) break;
      remainingX -= inward * hit.normalX;
      remainingY -= inward * hit.normalY;
      const velocityInward = out.velocityX * hit.normalX + out.velocityY * hit.normalY;
      if (velocityInward < 0) {
        out.velocityX -= velocityInward * hit.normalX;
        out.velocityY -= velocityInward * hit.normalY;
      }
    }
  }
  validBody(center, halfW, halfH) {
    return Number.isFinite(center.x) && Number.isFinite(center.y) && Number.isFinite(halfW) && Number.isFinite(halfH) && halfW > 0 && halfH > 0 && center.x - halfW >= 0 && center.y - halfH >= 0 && center.x + halfW <= this.map.cols * this.map.tileSize && center.y + halfH <= this.map.rows * this.map.tileSize;
  }
  bucketCoordinate(value, extent) {
    return Math.max(0, Math.min(extent - 1, Math.floor(value / SOLID_BUCKET_SIZE)));
  }
  /** Reused bitset deduplicates bucket overlap and enumerates original solid
   * indices in ascending order, preserving equal-time contact normals. */
  collectCandidates(minX, minY, maxX, maxY) {
    const bits = this.candidateBits;
    bits.fill(0);
    if (!bits.length) return;
    const left = this.bucketCoordinate(minX, this.bucketCols), right = this.bucketCoordinate(maxX, this.bucketCols);
    const top = this.bucketCoordinate(minY, this.bucketRows), bottom = this.bucketCoordinate(maxY, this.bucketRows);
    for (let row = top; row <= bottom; row++) for (let col = left; col <= right; col++) {
      const bucket = row * this.bucketCols + col, end = this.bucketOffsets[bucket + 1];
      for (let at = this.bucketOffsets[bucket]; at < end; at++) {
        const index = this.bucketSolids[at], word = index >>> 5;
        bits[word] = bits[word] | 1 << (index & 31);
      }
    }
  }
  trace(center, halfW, halfH, dx, dy, exemption) {
    const hit = this.hit;
    hit.fraction = 1;
    hit.normalX = 0;
    hit.normalY = 0;
    const size = this.map.tileSize;
    const minCol = Math.max(-1, Math.floor((Math.min(center.x, center.x + dx) - halfW) / size));
    const maxCol = Math.min(this.map.cols, Math.floor((Math.max(center.x, center.x + dx) + halfW) / size));
    const minRow = Math.max(-1, Math.floor((Math.min(center.y, center.y + dy) - halfH) / size));
    const maxRow = Math.min(this.map.rows, Math.floor((Math.max(center.y, center.y + dy) + halfH) / size));
    for (let row = minRow; row <= maxRow; row++) for (let col = minCol; col <= maxCol; col++) {
      if (row >= 0 && col >= 0 && row < this.map.rows && col < this.map.cols && this.map.tiles[row][col] !== 3 /* VOID */) continue;
      const cell = this.cell;
      cell.minX = col * size;
      cell.maxX = (col + 1) * size;
      cell.minY = row * size;
      cell.maxY = (row + 1) * size;
      cell.axes[0].min = cell.minX;
      cell.axes[0].max = cell.maxX;
      cell.axes[1].min = cell.minY;
      cell.axes[1].max = cell.maxY;
      sweepPolygon(cell, center, halfW, halfH, dx, dy, hit);
    }
    this.collectCandidates(
      Math.min(center.x, center.x + dx) - halfW,
      Math.min(center.y, center.y + dy) - halfH,
      Math.max(center.x, center.x + dx) + halfW,
      Math.max(center.y, center.y + dy) + halfH
    );
    for (let word = 0; word < this.candidateBits.length; word++) {
      let bits = this.candidateBits[word];
      while (bits !== 0) {
        const solid = this.solids[word * 32 + 31 - Math.clz32(bits & -bits)];
        if (exemption) for (const piece of outsideExemption(solid, exemption)) sweepPolygon(piece, center, halfW, halfH, dx, dy, hit);
        else sweepPolygon(solid, center, halfW, halfH, dx, dy, hit);
        bits &= bits - 1;
      }
    }
    if (hit.fraction < 1) hit.fraction = Math.max(0, hit.fraction - SEPARATION / Math.max(Math.abs(dx), Math.abs(dy), SEPARATION));
    return hit;
  }
};

// src/generation/world-study/native-spatial-geometry.ts
var NATIVE_SPATIAL_CELL = 8;
var NATIVE_SPATIAL_BODY_HALF = 10;
var NATIVE_SPATIAL_DIRECTIONS = [[1, 0], [0, 1], [-1, 0], [0, -1], [1, 1], [-1, 1], [-1, -1], [1, -1]];
var NATIVE_SPATIAL_EDGE_COSTS = [8e3, 8e3, 8e3, 8e3, 11314, 11314, 11314, 11314];
var step = NATIVE_SPATIAL_CELL;
var nativeCellPoint = (cell, cols) => ({ x: (cell % cols + 0.5) * step, y: (Math.floor(cell / cols) + 0.5) * step });
function nativePrimitive(points, objectId) {
  const xs = points.filter((_, index) => index % 2 === 0), ys = points.filter((_, index) => index % 2 === 1);
  return { points, objectId, minX: Math.min(...xs), minY: Math.min(...ys), maxX: Math.max(...xs), maxY: Math.max(...ys) };
}
function nativeVoidCellBoundary(cells, cols, rows, objectId) {
  const members = new Set(cells), result = [];
  for (const cell of cells) {
    const x = cell % cols, y = Math.floor(cell / cols), l = x * step, t = y * step, r = l + step, b = t + step;
    if (x === 0 || !members.has(cell - 1)) result.push(nativePrimitive([l, t, l, b], objectId));
    if (x === cols - 1 || !members.has(cell + 1)) result.push(nativePrimitive([r, t, r, b], objectId));
    if (y === 0 || !members.has(cell - cols)) result.push(nativePrimitive([l, t, r, t], objectId));
    if (y === rows - 1 || !members.has(cell + cols)) result.push(nativePrimitive([l, b, r, b], objectId));
  }
  return result;
}
function nativePrimitiveTree(items) {
  const bounds3 = { minX: Infinity, minY: Infinity, maxX: -Infinity, maxY: -Infinity };
  for (const item of items) {
    bounds3.minX = Math.min(bounds3.minX, item.minX);
    bounds3.minY = Math.min(bounds3.minY, item.minY);
    bounds3.maxX = Math.max(bounds3.maxX, item.maxX);
    bounds3.maxY = Math.max(bounds3.maxY, item.maxY);
  }
  if (items.length <= 8) return { ...bounds3, items };
  const horizontal = bounds3.maxX - bounds3.minX >= bounds3.maxY - bounds3.minY;
  const sorted = [...items].sort((a, b) => horizontal ? a.minX + a.maxX - b.minX - b.maxX : a.minY + a.maxY - b.minY - b.maxY);
  const middle = Math.floor(sorted.length / 2);
  return { ...bounds3, left: nativePrimitiveTree(sorted.slice(0, middle)), right: nativePrimitiveTree(sorted.slice(middle)) };
}
function segmentDistanceSq(x, y, ax, ay, bx, by) {
  const dx = bx - ax, dy = by - ay, size = dx * dx + dy * dy;
  const t = size === 0 ? 0 : Math.max(0, Math.min(1, ((x - ax) * dx + (y - ay) * dy) / size));
  return (x - ax - t * dx) ** 2 + (y - ay - t * dy) ** 2;
}
function distanceSq(x, y, p) {
  const a = p.points;
  if (a.length === 4) return segmentDistanceSq(x, y, a[0], a[1], a[2], a[3]);
  const e0 = (a[2] - a[0]) * (y - a[1]) - (a[3] - a[1]) * (x - a[0]);
  const e1 = (a[4] - a[2]) * (y - a[3]) - (a[5] - a[3]) * (x - a[2]);
  const e2 = (a[0] - a[4]) * (y - a[5]) - (a[1] - a[5]) * (x - a[4]);
  if (e0 >= 0 && e1 >= 0 && e2 >= 0 || e0 <= 0 && e1 <= 0 && e2 <= 0) return 0;
  return Math.min(segmentDistanceSq(x, y, a[0], a[1], a[2], a[3]), segmentDistanceSq(x, y, a[2], a[3], a[4], a[5]), segmentDistanceSq(x, y, a[4], a[5], a[0], a[1]));
}
function boundsDistanceSq(x, y, p) {
  return Math.max(p.minX - x, 0, x - p.maxX) ** 2 + Math.max(p.minY - y, 0, y - p.maxY) ** 2;
}
function nativePrimitiveDistance(root, x, y) {
  return Math.sqrt(visitPrimitiveDistance(root, x, y, Infinity));
}
function visitPrimitiveDistance(node, x, y, best) {
  if (boundsDistanceSq(x, y, node) >= best) return best;
  if (node.items) {
    for (const item of node.items) best = Math.min(best, distanceSq(x, y, item));
    return best;
  }
  const left = node.left, right = node.right;
  if (boundsDistanceSq(x, y, left) <= boundsDistanceSq(x, y, right)) {
    best = visitPrimitiveDistance(left, x, y, best);
    return visitPrimitiveDistance(right, x, y, best);
  }
  best = visitPrimitiveDistance(right, x, y, best);
  return visitPrimitiveDistance(left, x, y, best);
}
function nativeSolidPrimitives(terrain, includeRelief = false) {
  const ids = new Set(terrain.definition.instances.filter((item) => includeRelief || item.role === "solid").map((item) => item.id)), result = [];
  for (const mesh of terrain.meshes) {
    if (!ids.has(mesh.spec.id)) continue;
    for (let face = 0; face < (mesh.groundEdgeStart?.triangle ?? mesh.triangleCount); face++) {
      const points = [];
      for (let corner = 0; corner < 3; corner++) {
        const at = mesh.indices[face * 3 + corner] * 3;
        points.push(mesh.positions[at], mesh.positions[at + 1]);
      }
      const area3 = (points[2] - points[0]) * (points[5] - points[1]) - (points[3] - points[1]) * (points[4] - points[0]);
      if (Math.abs(area3) > 1e-7) result.push(nativePrimitive(points, mesh.spec.id));
    }
  }
  return result;
}
function nativeVoidPrimitives(terrain) {
  const grid = terrain.tileMap, result = [];
  const matter = (x, y) => x >= 0 && y >= 0 && x < grid.cols && y < grid.rows && grid.tiles[y][x] !== 3 /* VOID */;
  for (let y = 0; y < grid.rows; y++) for (let x = 0; x < grid.cols; x++) {
    if (!matter(x, y)) continue;
    const left = x * step, top = y * step, right = left + step, bottom = top + step;
    if (!matter(x - 1, y)) result.push(nativePrimitive([left, top, left, bottom], -1));
    if (!matter(x + 1, y)) result.push(nativePrimitive([right, top, right, bottom], -1));
    if (!matter(x, y - 1)) result.push(nativePrimitive([left, top, right, top], -1));
    if (!matter(x, y + 1)) result.push(nativePrimitive([left, bottom, right, bottom], -1));
  }
  return result;
}
function buildNativeSpatialGeometry(definition, seed2) {
  const terrain = compileNativeTerrain(definition, seed2, false), { cols, rows } = terrain, count = cols * rows;
  const collision = new NativeBodyCollision({ definition, meshes: terrain.meshes }, terrain.tileMap);
  const supported2 = new Uint8Array(count), reachable = new Uint8Array(count), links8 = new Uint8Array(count);
  let supportedCount = 0;
  for (let i = 0; i < count; i++) {
    supported2[i] = Number(collision.supports(nativeCellPoint(i, cols), 10, 10));
    supportedCount += supported2[i];
  }
  for (let cell = 0; cell < count; cell++) if (supported2[cell]) {
    const p = nativeCellPoint(cell, cols), col = cell % cols, row = Math.floor(cell / cols);
    for (let direction = 0; direction < 8; direction++) {
      const [dx, dy] = NATIVE_SPATIAL_DIRECTIONS[direction], x = col + dx, y = row + dy, next = y * cols + x;
      if (x < 0 || y < 0 || x >= cols || y >= rows || !supported2[next]) continue;
      if (collision.displacementFraction(p, 10, 10, dx * step, dy * step) >= 1 - 1e-9) links8[cell] = links8[cell] | 1 << direction;
    }
  }
  const start = Math.floor(terrain.spawnPoint.y / step) * cols + Math.floor(terrain.spawnPoint.x / step), queue = new Int32Array(count);
  if (!supported2[start]) throw new Error("Native spatial candidate has no supported initial probe");
  let head = 0, tail = 1;
  queue[0] = start;
  reachable[start] = 1;
  while (head < tail) {
    const cell = queue[head++];
    for (let direction = 0; direction < 8; direction++) if (links8[cell] & 1 << direction) {
      const [dx, dy] = NATIVE_SPATIAL_DIRECTIONS[direction], next = cell + dx + dy * cols;
      if (!reachable[next]) {
        reachable[next] = 1;
        queue[tail++] = next;
      }
    }
  }
  const solids = nativeSolidPrimitives(terrain), solidTree = nativePrimitiveTree(solids), voidTree = nativePrimitiveTree(nativeVoidPrimitives(terrain));
  return {
    terrain,
    collision,
    supported: supported2,
    reachable,
    links8,
    supportedCount,
    reachableCount: tail,
    solidPrimitives: solids,
    solidDistance: (p) => nativePrimitiveDistance(solidTree, p.x, p.y),
    voidDistance: (p) => nativePrimitiveDistance(voidTree, p.x, p.y),
    sight: { cols, rows, tileSize: step, version: 0, isOpaque: (x, y) => x < 0 || y < 0 || x >= cols || y >= rows || !terrain.matter[y * cols + x] }
  };
}
function createNativeSpatialActualVoidFeedback(geometry, groups, placements) {
  const { cols, rows, matter } = geometry.terrain, count = cols * rows, labels = groups.holeLabelByCell;
  const exteriorLabels = /* @__PURE__ */ new Set(), byLabel = /* @__PURE__ */ new Map();
  for (let cell = 0; cell < count; cell++) if (!matter[cell] && (cell < cols || cell >= count - cols || cell % cols === 0 || cell % cols === cols - 1)) exteriorLabels.add(labels[cell]);
  for (const structure of groups.structures) if (structure.kind === "hole") {
    const label = labels[structure.cells[0]];
    if (structure.componentCount !== 1 || label < 0 || exteriorLabels.has(label) || byLabel.has(label)) return { reason: "actual-void-hole-component-ambiguous" };
    byLabel.set(label, structure);
  }
  if (byLabel.size !== placements.length) return { reason: "actual-void-hole-count-mismatch" };
  const usedLabels = /* @__PURE__ */ new Set(), usedIds = /* @__PURE__ */ new Set(), holes = [];
  for (const placement of placements) {
    const found = /* @__PURE__ */ new Set();
    for (const [x, y, w, h] of placement.rects) for (let row = Math.max(0, Math.floor(y / 8)); row < Math.min(rows, Math.ceil((y + h) / 8)); row++) for (let col = Math.max(0, Math.floor(x / 8)); col < Math.min(cols, Math.ceil((x + w) / 8)); col++) {
      const px = col * 8 + 4, py = row * 8 + 4, cell = row * cols + col;
      if (px >= x && px < x + w && py >= y && py < y + h && !matter[cell]) found.add(labels[cell]);
    }
    const label = found.size === 1 ? [...found][0] : void 0, structure = label === void 0 ? void 0 : byLabel.get(label);
    if (!structure || usedLabels.has(label) || usedIds.has(placement.holeId)) return { reason: "actual-void-hole-authoring-ambiguous" };
    usedLabels.add(label);
    usedIds.add(placement.holeId);
    holes.push({ holeId: placement.holeId, cells: [...structure.cells] });
  }
  const exteriorMask = new Uint8Array(count);
  for (let cell = 0; cell < count; cell++) if (!matter[cell]) {
    if (usedLabels.has(labels[cell])) continue;
    if (!exteriorLabels.has(labels[cell])) return { reason: "actual-void-unassigned-closed-component" };
    exteriorMask[cell] = 1;
  }
  return { feedback: { cols, rows, exteriorMask, holes } };
}

// src/generation/world-study/fragment-shape/types.ts
var RECTILINEAR_FRAGMENT_VERSION = "rectilinear-fragment-v1";
var FragmentShapeError = class extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
    this.name = "FragmentShapeError";
  }
};
var FRAGMENT_SHAPE_LIMITS = Object.freeze({
  maxRectangles: 128,
  maxGridCells: 65536,
  maxFrameDimension: 16384,
  maxSourceVertices: 2048,
  maxOutputVertices: 8192
});

// src/generation/world-study/fragment-shape/validation.ts
function validateFragmentRequest(request) {
  if (!request || typeof request !== "object") throw new FragmentShapeError("INVALID_INPUT", "A fragment request is required");
  if (request.algorithmVersion !== RECTILINEAR_FRAGMENT_VERSION) throw new FragmentShapeError("UNSUPPORTED_VERSION", `Unsupported fragment algorithm: ${String(request.algorithmVersion)}`);
  if (!Number.isInteger(request.edgeSeed) || request.edgeSeed < 0 || request.edgeSeed > 4294967295) throw new FragmentShapeError("INVALID_INPUT", "edgeSeed must be an unsigned 32-bit integer");
  const layout = request.layout;
  if (!layout || typeof layout !== "object" || Array.isArray(layout) || layout.worldScale !== 2) throw new FragmentShapeError("INVALID_INPUT", "v1 requires a layout object with worldScale: 2; coordinates must be authoring units, not world pixels");
  if (!Array.isArray(layout.authoringFrame) || layout.authoringFrame.length !== 2 || ![layout.authoringFrame[0], layout.authoringFrame[1]].every((n) => Number.isFinite(n) && n > 0)) throw new FragmentShapeError("INVALID_INPUT", "authoringFrame must contain two finite positive dimensions");
  if (layout.authoringFrame.some((n) => n > FRAGMENT_SHAPE_LIMITS.maxFrameDimension)) throw new FragmentShapeError("BUDGET_EXCEEDED", "Authoring frame exceeds the v1 coordinate budget");
  if (!Array.isArray(layout.landRects) || !Array.isArray(layout.voidRects) || layout.landRects.length === 0) throw new FragmentShapeError("INVALID_INPUT", "landRects must be nonempty and voidRects must be an array");
  if (layout.landRects.length + layout.voidRects.length > FRAGMENT_SHAPE_LIMITS.maxRectangles) throw new FragmentShapeError("BUDGET_EXCEEDED", "Rectangle count exceeds the v1 budget");
  const xs = /* @__PURE__ */ new Set();
  const ys = /* @__PURE__ */ new Set();
  for (const rectangle of [...layout.landRects, ...layout.voidRects]) {
    if (!Array.isArray(rectangle) || rectangle.length !== 4 || ![rectangle[0], rectangle[1], rectangle[2], rectangle[3]].every(Number.isFinite)) throw new FragmentShapeError("INVALID_INPUT", "Every rectangle must contain four finite coordinates");
    const [x, y, width, height] = rectangle;
    if (x < 0 || y < 0 || width <= 0 || height <= 0 || x + width > layout.authoringFrame[0] || y + height > layout.authoringFrame[1]) throw new FragmentShapeError("INVALID_INPUT", "Rectangles must have positive size and lie within authoringFrame");
    xs.add(x);
    xs.add(x + width);
    ys.add(y);
    ys.add(y + height);
  }
  if ((xs.size - 1) * (ys.size - 1) > FRAGMENT_SHAPE_LIMITS.maxGridCells) throw new FragmentShapeError("BUDGET_EXCEEDED", "Rectangle partition exceeds the v1 grid budget");
}
var area = (points) => points.reduce((total, point, index) => {
  const next = points[(index + 1) % points.length];
  return total + point[0] * next[1] - next[0] * point[1];
}, 0) / 2;
var orientation = (a, b, c) => (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
var onSegment2 = (p, a, b) => orientation(a, b, p) === 0 && p[0] >= Math.min(a[0], b[0]) && p[0] <= Math.max(a[0], b[0]) && p[1] >= Math.min(a[1], b[1]) && p[1] <= Math.max(a[1], b[1]);
function intersects2(a, b, c, d) {
  const abC = orientation(a, b, c), abD = orientation(a, b, d), cdA = orientation(c, d, a), cdB = orientation(c, d, b);
  if ((abC > 0 && abD < 0 || abC < 0 && abD > 0) && (cdA > 0 && cdB < 0 || cdA < 0 && cdB > 0)) return true;
  return onSegment2(c, a, b) || onSegment2(d, a, b) || onSegment2(a, c, d) || onSegment2(b, c, d);
}
function contains2(point, loop) {
  let inside3 = false;
  for (let i = 0, j = loop.length - 1; i < loop.length; j = i++) {
    const a = loop[i], b = loop[j];
    if (a[1] > point[1] !== b[1] > point[1] && point[0] < (b[0] - a[0]) * (point[1] - a[1]) / (b[1] - a[1]) + a[0]) inside3 = !inside3;
  }
  return inside3;
}
function validateFragmentContours(contours, stage) {
  const code = stage === "source" ? "UNSUPPORTED_TOPOLOGY" : "INVALID_OUTPUT";
  const vertices2 = contours.reduce((sum, points) => sum + points.length, 0);
  const budget = stage === "source" ? FRAGMENT_SHAPE_LIMITS.maxSourceVertices : FRAGMENT_SHAPE_LIMITS.maxOutputVertices;
  if (vertices2 > budget) throw new FragmentShapeError("BUDGET_EXCEEDED", `${stage} contour vertex budget exceeded`);
  if (contours.length === 0 || contours.filter((loop) => area(loop) > 0).length !== 1 || area(contours[0]) <= 0) throw new FragmentShapeError(code, "v1 requires one nonempty outer land contour; disconnected or empty layouts are rejected");
  const segments = [];
  contours.forEach((loop, contour) => {
    if (loop.length < 4 || !Number.isFinite(area(loop)) || area(loop) === 0) throw new FragmentShapeError(code, "Degenerate contour");
    loop.forEach((point, index) => {
      const next = loop[(index + 1) % loop.length];
      if (!point.every(Number.isFinite) || point[0] === next[0] && point[1] === next[1]) throw new FragmentShapeError(code, "Nonfinite or zero-length contour edge");
      segments.push({ a: point, b: next, contour, index, count: loop.length });
    });
    if (contour > 0 && (area(loop) >= 0 || !contains2(loop[0], contours[0]))) throw new FragmentShapeError(code, "Hole is not strictly inside the outer contour");
  });
  for (let i = 0; i < segments.length; i++) for (let j = i + 1; j < segments.length; j++) {
    const a = segments[i], b = segments[j];
    if (a.contour === b.contour && (Math.abs(a.index - b.index) === 1 || Math.abs(a.index - b.index) === a.count - 1)) continue;
    if (intersects2(a.a, a.b, b.a, b.b)) throw new FragmentShapeError(code, "Contour edges cross or touch; no automatic repair is performed");
  }
  for (let i = 1; i < contours.length; i++) for (let j = i + 1; j < contours.length; j++) {
    if (contains2(contours[i][0], contours[j]) || contains2(contours[j][0], contours[i])) throw new FragmentShapeError(code, "Nested holes are unsupported");
  }
}

// src/generation/world-study/fragment-shape/rectilinear-fragment.ts
var cross3 = (a, b, c) => (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0]);
var length = (a, b) => Math.hypot(b[0] - a[0], b[1] - a[1]);
var signedArea = (points) => points.reduce((sum, p, i) => {
  const q = points[(i + 1) % points.length];
  return sum + p[0] * q[1] - q[0] * p[1];
}, 0) / 2;
var pointKey = (point) => `${point[0]},${point[1]}`;
var insideRect = (x, y, [rx, ry, rw, rh]) => x > rx && x < rx + rw && y > ry && y < ry + rh;
var round = (value) => Math.round(value * 100) / 100;
function randomGenerator(seed2) {
  let state = seed2 >>> 0;
  return () => {
    state += 1831565813;
    let x = Math.imul(state ^ state >>> 15, 1 | state);
    x ^= x + Math.imul(x ^ x >>> 7, 61 | x);
    return ((x ^ x >>> 14) >>> 0) / 4294967296;
  };
}
function rectangleContours(geometry) {
  const rects = [...geometry.landRects, ...geometry.voidRects];
  const xs = [...new Set(rects.flatMap(([x, , w]) => [x, x + w]))].sort((a, b) => a - b);
  const ys = [...new Set(rects.flatMap(([, y, , h]) => [y, y + h]))].sort((a, b) => a - b);
  const width = xs.length - 1;
  const height = ys.length - 1;
  const cells = new Uint8Array(width * height);
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
    const px = (xs[x] + xs[x + 1]) / 2;
    const py = (ys[y] + ys[y + 1]) / 2;
    cells[y * width + x] = Number(geometry.landRects.some((r) => insideRect(px, py, r)) && !geometry.voidRects.some((r) => insideRect(px, py, r)));
  }
  const occupied = (x, y) => x >= 0 && y >= 0 && x < width && y < height && cells[y * width + x] === 1;
  const edges2 = [];
  const starts = /* @__PURE__ */ new Map();
  const addEdge = (a, b) => {
    const index = edges2.length;
    edges2.push({ a, b, used: false });
    const key = pointKey(a);
    if (!starts.has(key)) starts.set(key, []);
    starts.get(key).push(index);
  };
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) if (occupied(x, y)) {
    if (!occupied(x, y - 1)) addEdge([xs[x], ys[y]], [xs[x + 1], ys[y]]);
    if (!occupied(x + 1, y)) addEdge([xs[x + 1], ys[y]], [xs[x + 1], ys[y + 1]]);
    if (!occupied(x, y + 1)) addEdge([xs[x + 1], ys[y + 1]], [xs[x], ys[y + 1]]);
    if (!occupied(x - 1, y)) addEdge([xs[x], ys[y + 1]], [xs[x], ys[y]]);
  }
  const contours = [];
  for (let start = 0; start < edges2.length; start++) {
    if (edges2[start].used) continue;
    const points = [];
    let current = start;
    for (let count = 0; count <= edges2.length; count++) {
      const edge = edges2[current];
      if (edge.used) throw new FragmentShapeError("UNSUPPORTED_TOPOLOGY", "Rectangle boundary unexpectedly revisited");
      edge.used = true;
      points.push(edge.a);
      if (pointKey(edge.b) === pointKey(edges2[start].a)) break;
      const candidates = (starts.get(pointKey(edge.b)) ?? []).filter((i) => !edges2[i].used);
      if (candidates.length === 0) throw new FragmentShapeError("UNSUPPORTED_TOPOLOGY", "Rectangle boundary is open");
      if (candidates.length > 1) throw new FragmentShapeError("UNSUPPORTED_TOPOLOGY", "Point-touching boundary is unsupported");
      candidates.sort((a, b) => cross3(edge.a, edge.b, edges2[b].b) - cross3(edge.a, edge.b, edges2[a].b));
      current = candidates[0];
    }
    const simplified = points.filter((p, i) => cross3(points[(i + points.length - 1) % points.length], p, points[(i + 1) % points.length]) !== 0);
    contours.push(simplified);
  }
  return contours.sort((a, b) => Math.abs(signedArea(b)) - Math.abs(signedArea(a)));
}
function pointSegmentDistance(point, a, b) {
  const dx = b[0] - a[0];
  const dy = b[1] - a[1];
  const t = Math.max(0, Math.min(1, ((point[0] - a[0]) * dx + (point[1] - a[1]) * dy) / (dx * dx + dy * dy)));
  return Math.hypot(point[0] - a[0] - t * dx, point[1] - a[1] - t * dy);
}
function otherBoundaryClearance(point, allContours, contourIndex, vertexIndex) {
  let nearest = Infinity;
  allContours.forEach((points, ci) => points.forEach((a, i) => {
    if (ci === contourIndex && (i === vertexIndex || (i + 1) % points.length === vertexIndex)) return;
    nearest = Math.min(nearest, pointSegmentDistance(point, a, points[(i + 1) % points.length]));
  }));
  return nearest;
}
function generateEdgeStudy(geometry, seed2) {
  const normalizedSeed = seed2 >>> 0;
  const random = randomGenerator(normalizedSeed);
  const rawContours = rectangleContours(geometry);
  validateFragmentContours(rawContours, "source");
  const allPoints = rawContours.flat();
  const patches = Array.from({ length: 4 }, (_, i) => {
    const candidates = i < 2 ? rawContours[0] : allPoints;
    const p = candidates[Math.floor(random() * candidates.length)];
    return { point: p, reach: 135 + random() * 190, strength: 0.65 + random() * 0.35, bias: random() * 2 - 1, style: i % 3 };
  });
  const damageAt = (point) => {
    let winner = patches[0];
    let intensity = 0;
    for (const patch of patches) {
      const weight = Math.exp(-Math.pow(length(point, patch.point) / patch.reach, 2)) * patch.strength;
      if (weight > intensity) {
        intensity = weight;
        winner = patch;
      }
    }
    return { intensity, bias: winner.bias, style: winner.style };
  };
  const counts = { retained: 0, bevel: 0, broken: 0, blunt: 0, edgeBreaks: 0 };
  let retainedAxisLength = 0;
  let sourcePerimeter = 0;
  const contours = rawContours.map((points, ci) => {
    const corners = points.map((vertex, i) => {
      const previous = points[(i + points.length - 1) % points.length];
      const next = points[(i + 1) % points.length];
      const incomingLength = length(vertex, previous);
      const outgoingLength = length(vertex, next);
      const clearance = otherBoundaryClearance(vertex, rawContours, ci, i);
      const damage = damageAt(vertex);
      const chance = random();
      if (chance < 0.15 + (1 - damage.intensity) * 0.37 || Math.min(incomingLength, outgoingLength) < 9) {
        counts.retained++;
        return { start: vertex, end: vertex, points: [vertex], type: "retained" };
      }
      const maximum = Math.min(68, clearance * 0.43);
      const scale = (0.56 + damage.intensity * 0.74) * (0.72 + random() * 0.48);
      const a = Math.min(incomingLength * 0.34, maximum * scale * (1 + damage.bias * 0.44));
      const b = Math.min(outgoingLength * 0.34, maximum * scale * (1 - damage.bias * 0.44));
      const inUnit = [(previous[0] - vertex[0]) / incomingLength, (previous[1] - vertex[1]) / incomingLength];
      const outUnit = [(next[0] - vertex[0]) / outgoingLength, (next[1] - vertex[1]) / outgoingLength];
      const local = (u, v) => [round(vertex[0] + inUnit[0] * a * u + outUnit[0] * b * v), round(vertex[1] + inUnit[1] * a * u + outUnit[1] * b * v)];
      const start = local(1, 0);
      const end = local(0, 1);
      const styleRoll = random();
      let style = damage.style;
      if (styleRoll < 0.35) style = Math.floor(random() * 3);
      let treatment;
      if (style === 0) {
        counts.bevel++;
        treatment = [start, end];
      } else if (style === 1) {
        counts.broken++;
        treatment = [start, local(0.64 + random() * 0.15, 0.07 + random() * 0.14), local(0.52 + random() * 0.1, 0.42 + random() * 0.14), local(0.11 + random() * 0.15, 0.56 + random() * 0.11), end];
      } else {
        counts.blunt++;
        treatment = [start, local(0.68 + random() * 0.13, 0.22 + random() * 0.12), local(0.2 + random() * 0.14, 0.73 + random() * 0.12), end];
      }
      return { start, end, points: treatment, type: ["bevel", "broken", "blunt"][style] };
    });
    if (signedArea(points) < 0 && points.length === 4 && Math.abs(signedArea(points)) < 3e3) {
      const smallRandom = randomGenerator(normalizedSeed ^ Math.imul(ci + 1, 2654435761));
      const first = Math.floor(smallRandom() * 4);
      const keepCount = smallRandom() < 0.3 ? 3 : 2;
      const opposite = smallRandom() < 0.5;
      const preserve = keepCount === 3 ? [first, (first + 1) % 4, (first + 2) % 4] : [first, (first + (opposite ? 2 : 1)) % 4];
      for (const i of preserve) if (corners[i].type !== "retained") {
        counts[corners[i].type]--;
        counts.retained++;
        corners[i] = { start: points[i], end: points[i], points: [points[i]], type: "retained" };
      }
    }
    const treated = [];
    const edgeCandidates = corners.map((corner, i) => {
      const next = corners[(i + 1) % corners.length];
      const midpoint = [(corner.end[0] + next.start[0]) / 2, (corner.end[1] + next.start[1]) / 2];
      return { i, length: length(corner.end, next.start), priority: damageAt(midpoint).intensity * 0.8 + random() * 0.2 };
    }).filter((edge) => edge.length >= 145).sort((a, b) => b.priority - a.priority);
    const brokenEdges = new Set(edgeCandidates.slice(0, ci === 0 ? 3 : 0).map((edge) => edge.i));
    for (let i = 0; i < points.length; i++) {
      const current = corners[i];
      const next = corners[(i + 1) % points.length];
      treated.push(...current.points);
      const edgeLength = length(current.end, next.start);
      const sourceLength = length(points[i], points[(i + 1) % points.length]);
      sourcePerimeter += sourceLength;
      retainedAxisLength += edgeLength;
      const midpoint = [(current.end[0] + next.start[0]) / 2, (current.end[1] + next.start[1]) / 2];
      const damage = damageAt(midpoint);
      if (!brokenEdges.has(i)) continue;
      const direction = [(next.start[0] - current.end[0]) / edgeLength, (next.start[1] - current.end[1]) / edgeLength];
      const inward = [-direction[1], direction[0]];
      const width = Math.min(48, edgeLength * (0.14 + random() * 0.13));
      const center = edgeLength * (0.33 + random() * 0.34);
      const clearance = Math.min(...rawContours.flatMap((loop, index) => loop.map((a, ei) => index === ci && ei === i ? Infinity : pointSegmentDistance(midpoint, a, loop[(ei + 1) % loop.length]))));
      const depth = Math.min(7 + damage.intensity * 13, clearance * 0.18);
      const edgePoint = (along, inset) => [round(current.end[0] + direction[0] * along + inward[0] * inset), round(current.end[1] + direction[1] * along + inward[1] * inset)];
      treated.push(edgePoint(center - width / 2, 0), edgePoint(center - width * 0.18, depth * 0.72), edgePoint(center + width * 0.25, depth), edgePoint(center + width / 2, 0));
      retainedAxisLength -= width;
      counts.edgeBreaks++;
    }
    return { kind: signedArea(points) > 0 ? "outer" : "hole", points: treated, sourcePoints: points };
  });
  validateFragmentContours(contours.map((contour) => contour.points), "output");
  const pathD = contours.map(({ points }) => `M${points.map((p) => p.join(" ")).join("L")}Z`).join("");
  const originalArea = rawContours.reduce((total, points) => total + signedArea(points), 0);
  const treatedArea = contours.reduce((total, { points }) => total + signedArea(points), 0);
  return {
    seed: normalizedSeed,
    contours: contours.map((contour) => contour.points),
    contourKinds: contours.map((contour) => contour.kind),
    pathD,
    stats: {
      ...counts,
      outerContours: contours.filter((c) => c.kind === "outer").length,
      holeContours: contours.filter((c) => c.kind === "hole").length,
      sourceCorners: rawContours.reduce((sum, points) => sum + points.length, 0),
      originalArea,
      treatedArea: round(treatedArea),
      areaChangePercent: round((treatedArea - originalArea) / originalArea * 100),
      originalAxisLengthPercent: round(retainedAxisLength / sourcePerimeter * 100),
      coordinateSpace: "authoringFrame; multiply by worldScale for world pixels"
    }
  };
}
function generateRectilinearFragment(request) {
  validateFragmentRequest(request);
  const study = generateEdgeStudy(request.layout, request.edgeSeed);
  return { algorithmVersion: RECTILINEAR_FRAGMENT_VERSION, worldScale: 2, ...study };
}
function fragmentContoursToWorld(result) {
  if (result.algorithmVersion !== RECTILINEAR_FRAGMENT_VERSION || result.worldScale !== 2) throw new FragmentShapeError("INVALID_INPUT", "World conversion requires a v1 result in authoring units");
  return result.contours.map((loop) => loop.map(([x, y]) => [x * result.worldScale, y * result.worldScale]));
}

// src/generation/world-study/r100-fragment-shape.ts
var object = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
var keysAre = (value, keys) => Object.keys(value).length === keys.length && keys.every((key) => Object.prototype.hasOwnProperty.call(value, key));
var seed = (value) => typeof value === "number" && Number.isInteger(value) && value >= 0 && value <= 4294967295;
function compileR100FragmentShape(value, requestedSeed) {
  if (!object(value) || !keysAre(value, ["algorithmVersion", "layoutId", "sourceHash", "seedMode", "seedSalt", "edgeSeed", "layout"]) || value.algorithmVersion !== RECTILINEAR_FRAGMENT_VERSION || typeof value.layoutId !== "string" || !/^[a-z][a-z0-9-]{0,95}$/.test(value.layoutId) || typeof value.sourceHash !== "string" || !/^[0-9a-f]{64}$/.test(value.sourceHash) || value.seedMode !== "run-seed" || !seed(value.seedSalt) || !seed(value.edgeSeed) || !object(value.layout) || !keysAre(value.layout, ["authoringFrame", "worldScale", "landRects", "voidRects"])) throw new Error("Invalid frozen fragment authoring snapshot");
  if (requestedSeed !== void 0 && (!seed(requestedSeed) || value.edgeSeed !== requestedSeed + value.seedSalt >>> 0)) throw new Error("Fragment edge seed must remain tied to the original departure");
  const snapshot = value;
  const result = generateRectilinearFragment({ algorithmVersion: snapshot.algorithmVersion, layout: snapshot.layout, edgeSeed: snapshot.edgeSeed });
  const polygons = fragmentContoursToWorld(result).map((loop) => loop.map(([x, y]) => ({ x, y })));
  const outerIndex = result.contourKinds.indexOf("outer");
  if (outerIndex < 0 || result.contourKinds.filter((kind) => kind === "outer").length !== 1) throw new Error("Fragment compiler did not produce one ground body");
  return { snapshot, terrainOutline: polygons[outerIndex], erosion: polygons.filter((_, index) => result.contourKinds[index] === "hole") };
}

// src/generation/world-study/native-spatial-wide-domain.ts
function nativeSpatialConstraintScore(violations, mean) {
  return { maximum: Math.max(0, ...violations), sum: violations.reduce((sum, value) => sum + value, 0), mean };
}
function compareNativeSpatialConstraintScores(a, b) {
  for (const key of ["maximum", "sum", "mean"]) {
    if (a[key] < b[key]) return -1;
    if (a[key] > b[key]) return 1;
  }
  return 0;
}
var NativeSpatialWideDomain = class {
  cols;
  rows;
  coast;
  occupancy;
  wide;
  seen;
  queue;
  masks;
  sites;
  version = 0;
  constructor(feedback, objects, radius) {
    const step2 = NATIVE_SPATIAL_CELL;
    if (!Number.isFinite(radius) || radius < Math.SQRT2 * (NATIVE_SPATIAL_BODY_HALF + step2)) throw new Error("Wide-domain radius cannot prove safe body links");
    this.cols = feedback.cols;
    this.rows = feedback.rows;
    const count = this.cols * this.rows;
    if (feedback.exteriorMask.length !== count) throw new Error("Actual VOID feedback has inconsistent dimensions");
    this.coast = feedback.exteriorMask.slice();
    this.occupancy = new Uint16Array(count);
    this.wide = new Uint8Array(count);
    this.seen = new Uint32Array(count);
    this.queue = new Int32Array(count);
    const offsets = [], reach = Math.ceil(radius / step2) + 1;
    for (let y = -reach; y <= reach; y++) for (let x = -reach; x <= reach; x++) if (Math.hypot(Math.max(0, Math.abs(x) * step2 - step2 / 2), Math.max(0, Math.abs(y) * step2 - step2 / 2)) < radius) offsets.push({ x, y });
    const expand = (cells) => {
      const set = new Set(cells), result = new Set(cells);
      for (const cell of cells) {
        const x = cell % this.cols, y = Math.floor(cell / this.cols);
        if (x > 0 && x < this.cols - 1 && y > 0 && y < this.rows - 1 && set.has(cell - 1) && set.has(cell + 1) && set.has(cell - this.cols) && set.has(cell + this.cols)) continue;
        for (const d of offsets) {
          const xx = x + d.x, yy = y + d.y;
          if (xx >= 0 && yy >= 0 && xx < this.cols && yy < this.rows) result.add(yy * this.cols + xx);
        }
      }
      return result;
    };
    const exterior = [];
    for (let cell = 0; cell < count; cell++) if (feedback.exteriorMask[cell]) exterior.push(cell);
    for (const cell of expand(exterior)) this.coast[cell] = 1;
    for (let y = 0; y < this.rows; y++) for (let x = 0; x < this.cols; x++) if (Math.min((x + 0.5) * step2, (y + 0.5) * step2, (this.cols - x - 0.5) * step2, (this.rows - y - 0.5) * step2) < radius) this.coast[y * this.cols + x] = 1;
    this.sites = objects.map((o) => ({ x: o.site.x, y: o.site.y }));
    this.masks = objects.map((object2) => {
      if (!Number.isInteger(object2.site.x / step2) || !Number.isInteger(object2.site.y / step2)) throw new Error("Wide-domain translation must preserve the real grid phase");
      const local = [];
      if (object2.holeId) {
        const hole = feedback.holes.find((h) => h.holeId === object2.holeId);
        if (!hole) throw new Error(`Actual VOID feedback is missing ${object2.holeId}`);
        const stride = this.cols + 2 * reach, expanded = /* @__PURE__ */ new Set();
        for (const cell of hole.cells) {
          const x = cell % this.cols, y = Math.floor(cell / this.cols);
          for (const d of offsets) expanded.add((y + d.y + reach) * stride + x + d.x + reach);
        }
        for (const cell of expanded) local.push(cell % stride - reach - object2.site.x / step2, Math.floor(cell / stride) - reach - object2.site.y / step2);
      } else {
        if (!object2.blocking.length) throw new Error("Wide-domain solid has no projected footprint");
        const tree = nativePrimitiveTree(object2.blocking), minX = Math.floor((Math.min(...object2.blocking.map((p) => p.minX)) - radius) / step2), maxX = Math.ceil((Math.max(...object2.blocking.map((p) => p.maxX)) + radius) / step2), minY = Math.floor((Math.min(...object2.blocking.map((p) => p.minY)) - radius) / step2), maxY = Math.ceil((Math.max(...object2.blocking.map((p) => p.maxY)) + radius) / step2);
        for (let y = minY; y < maxY; y++) for (let x = minX; x < maxX; x++) if (nativePrimitiveDistance(tree, (x + 0.5) * step2, (y + 0.5) * step2) < radius) local.push(x, y);
      }
      return Int32Array.from(local);
    });
    objects.forEach((_, index) => this.apply(index, this.sites[index], 1));
  }
  apply(index, site, delta) {
    const x = site.x / NATIVE_SPATIAL_CELL, y = site.y / NATIVE_SPATIAL_CELL, mask = this.masks[index];
    if (!Number.isInteger(x) || !Number.isInteger(y)) throw new Error("Wide-domain trial is off the actual grid phase");
    for (let i = 0; i < mask.length; i += 2) {
      const xx = x + mask[i], yy = y + mask[i + 1];
      if (xx >= 0 && yy >= 0 && xx < this.cols && yy < this.rows) {
        const cell = yy * this.cols + xx;
        this.occupancy[cell] = this.occupancy[cell] + delta;
      }
    }
  }
  validateTrial(index, site) {
    if (!Number.isInteger(index) || index < 0 || index >= this.sites.length) throw new Error("Unknown wide-domain object");
    if (!Number.isFinite(site.x) || !Number.isFinite(site.y) || !Number.isInteger(site.x / NATIVE_SPATIAL_CELL) || !Number.isInteger(site.y / NATIVE_SPATIAL_CELL)) throw new Error("Wide-domain trial is off the actual grid phase");
  }
  /** Snapshot and validate the whole operation before touching any occupancy.
   * Two entries may overlap spatially, but cannot name the same object twice. */
  prepareTrials(entries) {
    if (entries.length < 1 || entries.length > 2) throw new Error("Wide-domain batch requires one or two objects");
    const indices = /* @__PURE__ */ new Set();
    return entries.map((entry) => {
      this.validateTrial(entry.index, entry.site);
      if (indices.has(entry.index)) throw new Error("Duplicate wide-domain object in one batch");
      indices.add(entry.index);
      return { index: entry.index, site: { x: entry.site.x, y: entry.site.y }, previous: this.sites[entry.index] };
    });
  }
  evaluateMany(entries) {
    const trials = this.prepareTrials(entries);
    let removed = 0, added = 0;
    try {
      for (const trial of trials) {
        this.apply(trial.index, trial.previous, -1);
        removed++;
      }
      for (const trial of trials) {
        this.apply(trial.index, trial.site, 1);
        added++;
      }
      return this.measure();
    } finally {
      for (let i = 0; i < added; i++) {
        const trial = trials[i];
        this.apply(trial.index, trial.site, -1);
      }
      for (let i = 0; i < removed; i++) {
        const trial = trials[i];
        this.apply(trial.index, trial.previous, 1);
      }
    }
  }
  commitMany(entries) {
    const trials = this.prepareTrials(entries);
    let removed = 0, added = 0;
    try {
      for (const trial of trials) {
        this.apply(trial.index, trial.previous, -1);
        removed++;
      }
      for (const trial of trials) {
        this.apply(trial.index, trial.site, 1);
        added++;
      }
    } catch (error) {
      for (let i = 0; i < added; i++) {
        const trial = trials[i];
        this.apply(trial.index, trial.site, -1);
      }
      for (let i = 0; i < removed; i++) {
        const trial = trials[i];
        this.apply(trial.index, trial.previous, 1);
      }
      throw error;
    }
    for (const trial of trials) this.sites[trial.index] = { x: trial.site.x, y: trial.site.y };
  }
  evaluate(index, site) {
    return this.evaluateMany([{ index, site }]);
  }
  commit(index, site) {
    this.commitMany([{ index, site }]);
  }
  /** A copy for deterministic mask comparison; no caller can mutate the cache. */
  wideMask() {
    this.measure();
    return this.wide.slice();
  }
  measure() {
    if (++this.version === 4294967295) {
      this.seen.fill(0);
      this.version = 1;
    }
    let wideCount = 0, largest = 0;
    for (let cell = 0; cell < this.wide.length; cell++) {
      const wide = Number(!this.coast[cell] && !this.occupancy[cell]);
      this.wide[cell] = wide;
      wideCount += wide;
    }
    for (let start = 0; start < this.wide.length; start++) if (this.wide[start] && this.seen[start] !== this.version) {
      let head = 0, tail = 1;
      this.queue[0] = start;
      this.seen[start] = this.version;
      while (head < tail) {
        const cell = this.queue[head++], x = cell % this.cols, y = Math.floor(cell / this.cols);
        for (let yy = Math.max(0, y - 1); yy <= Math.min(this.rows - 1, y + 1); yy++) for (let xx = Math.max(0, x - 1); xx <= Math.min(this.cols - 1, x + 1); xx++) {
          const next = yy * this.cols + xx;
          if (this.wide[next] && this.seen[next] !== this.version) {
            this.seen[next] = this.version;
            this.queue[tail++] = next;
          }
        }
      }
      largest = Math.max(largest, tail);
    }
    return { wideCount, largestWideRatio: wideCount ? largest / wideCount : 0 };
  }
};

// src/generation/world-study/native-spatial-void-identity.ts
function identifyNativeSpatialVoid(matter, cols, rows) {
  if (!Number.isSafeInteger(cols) || !Number.isSafeInteger(rows) || cols <= 0 || rows <= 0 || matter.length !== cols * rows) throw new Error("Invalid native VOID raster dimensions");
  const count = cols * rows, components2 = [], labels = new Int32Array(count).fill(-1);
  for (let start = 0; start < count; start++) if (!matter[start] && labels[start] === -1) {
    const label = components2.length, cells = [start];
    labels[start] = label;
    for (let at = 0; at < cells.length; at++) {
      const cell = cells[at], x = cell % cols, y = Math.floor(cell / cols);
      for (let d = 0; d < 4; d++) {
        const [dx, dy] = NATIVE_SPATIAL_DIRECTIONS[d], nx = x + dx, ny = y + dy, next = ny * cols + nx;
        if (nx < 0 || ny < 0 || nx >= cols || ny >= rows || matter[next] || labels[next] !== -1) continue;
        labels[next] = label;
        cells.push(next);
      }
    }
    components2.push(cells);
  }
  const parent = components2.map((_, i) => i);
  const root = (index) => {
    while (parent[index] !== index) {
      parent[index] = parent[parent[index]];
      index = parent[index];
    }
    return index;
  };
  for (let cell = 0; cell < count; cell++) if (labels[cell] >= 0) {
    const x = cell % cols, y = Math.floor(cell / cols), label = labels[cell];
    for (let dy = -3; dy <= 3; dy++) for (let dx = -3; dx <= 3; dx++) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= cols || ny >= rows) continue;
      const other = labels[ny * cols + nx];
      if (other >= 0 && other !== label && Math.max(Math.max(0, Math.abs(dx) * 8 - 8), Math.max(0, Math.abs(dy) * 8 - 8)) < 20) {
        const a = root(label), b = root(other);
        if (a !== b) parent[Math.max(a, b)] = Math.min(a, b);
      }
    }
  }
  const cellsByLabel = /* @__PURE__ */ new Map(), componentCountByLabel = /* @__PURE__ */ new Map(), exteriorLabels = /* @__PURE__ */ new Set();
  components2.forEach((cells, index) => {
    const id = root(index), group = cellsByLabel.get(id) ?? [];
    group.push(...cells);
    cellsByLabel.set(id, group);
    componentCountByLabel.set(id, (componentCountByLabel.get(id) ?? 0) + 1);
    if (cells.some((cell) => cell % cols === 0 || cell % cols === cols - 1 || cell < cols || cell >= count - cols)) exteriorLabels.add(id);
    cells.forEach((cell) => {
      labels[cell] = id;
    });
  });
  return { cols, rows, labels, cellsByLabel, componentCountByLabel, exteriorLabels };
}
function nativeSpatialPolygonContains(points, x, y) {
  let inside3 = false;
  for (let i = 0, j = points.length - 1; i < points.length; j = i++) {
    const a = points[i], b = points[j];
    if (a.y > y !== b.y > y && x < (b.x - a.x) * (y - a.y) / (b.y - a.y) + a.x) inside3 = !inside3;
  }
  return inside3;
}
function identifyNativeSpatialHoles(cols, rows, labels, erosion, placements) {
  const labelStats = /* @__PURE__ */ new Map();
  for (let cell = 0; cell < labels.length; cell++) if (labels[cell] >= 0) {
    const label = labels[cell], x = cell % cols, y = Math.floor(cell / cols), stat = labelStats.get(label) ?? { area: 0, minX: Infinity, minY: Infinity, maxX: -Infinity, maxY: -Infinity, exterior: false };
    stat.area += 64;
    stat.minX = Math.min(stat.minX, x * 8);
    stat.minY = Math.min(stat.minY, y * 8);
    stat.maxX = Math.max(stat.maxX, (x + 1) * 8);
    stat.maxY = Math.max(stat.maxY, (y + 1) * 8);
    stat.exterior ||= x === 0 || y === 0 || x === cols - 1 || y === rows - 1;
    labelStats.set(label, stat);
  }
  const initial = placements.map((placement) => {
    const found = /* @__PURE__ */ new Set();
    for (const [x, y, w, h] of placement.rects) for (let row = Math.max(0, Math.floor(y / 8)); row < Math.min(rows, Math.ceil((y + h) / 8)); row++) for (let col = Math.max(0, Math.floor(x / 8)); col < Math.min(cols, Math.ceil((x + w) / 8)); col++) {
      const px = col * 8 + 4, py = row * 8 + 4, label = labels[row * cols + col];
      if (px >= x && px <= x + w && py >= y && py <= y + h && label >= 0) found.add(label);
    }
    const contourIndices = erosion.flatMap((loop, index) => placement.rects.some(([x, y, w, h]) => nativeSpatialPolygonContains(loop, x + w / 2, y + h / 2)) ? [index] : []);
    const finalLabel = found.size === 1 ? [...found][0] : null, stat = finalLabel === null ? void 0 : labelStats.get(finalLabel);
    return { holeId: placement.holeId, finalLabel, stat, contourIndices, valid: !!placement.rects.length && found.size === 1 && !!stat && !stat.exterior && contourIndices.length === 1 };
  });
  const records2 = initial.map((row) => ({ ...row, duplicate: initial.some((other) => other !== row && (other.holeId === row.holeId || row.finalLabel !== null && other.finalLabel === row.finalLabel || row.contourIndices.some((index) => other.contourIndices.includes(index)))) }));
  const assignedLabels = new Set(records2.map((row) => row.finalLabel)), assignedContours = new Set(records2.flatMap((row) => row.contourIndices));
  return { records: records2, orphanLabels: [...labelStats].filter(([label, stat]) => !stat.exterior && !assignedLabels.has(label)).map(([label]) => label), orphanContours: erosion.flatMap((_, index) => assignedContours.has(index) ? [] : [index]) };
}
function rasterNativeSpatialFragment(width, height, outline, erosion) {
  const cols = width / NATIVE_SPATIAL_CELL, rows = height / NATIVE_SPATIAL_CELL;
  if (!Number.isSafeInteger(cols) || !Number.isSafeInteger(rows) || cols <= 0 || rows <= 0) throw new Error("Invalid native fragment raster dimensions");
  const matter = new Uint8Array(cols * rows);
  for (let row = 0; row < rows; row++) for (let col = 0; col < cols; col++) {
    const x = (col + 0.5) * NATIVE_SPATIAL_CELL, y = (row + 0.5) * NATIVE_SPATIAL_CELL;
    matter[row * cols + col] = Number(nativeSpatialPolygonContains(outline, x, y) && !erosion.some((loop) => nativeSpatialPolygonContains(loop, x, y)));
  }
  return { matter, cols, rows };
}

// src/generation/world-study/native-spatial-hole-qualification.ts
function qualifyNativeSpatialHoles(fragment, requestedSeed, placements, expectedHoleCount) {
  if (!Number.isSafeInteger(expectedHoleCount) || expectedHoleCount < 1 || placements.length !== expectedHoleCount) throw new Error("Native hole qualification requires complete H authoring");
  let compiled;
  try {
    compiled = compileR100FragmentShape(fragment, requestedSeed);
  } catch (error) {
    if (!(error instanceof FragmentShapeError)) throw error;
    return { accepted: false, reasons: [`hole-identity-fragment-${error.code}`], invalidHoleIds: placements.map((p) => p.holeId) };
  }
  const { matter, cols, rows } = rasterNativeSpatialFragment(fragment.layout.authoringFrame[0] * 2, fragment.layout.authoringFrame[1] * 2, compiled.terrainOutline, compiled.erosion);
  const identities = identifyNativeSpatialVoid(matter, cols, rows), holes = identifyNativeSpatialHoles(cols, rows, identities.labels, compiled.erosion, placements), reasons = [];
  if (holes.records.some((row) => !row.valid)) reasons.push("hole-profile-final-identity");
  if (holes.records.some((row) => row.duplicate)) reasons.push("hole-profile-merged-identity");
  if (holes.orphanLabels.length || holes.orphanContours.length) reasons.push("hole-profile-unassigned-final-hole");
  return { accepted: !reasons.length, reasons, invalidHoleIds: holes.records.filter((row) => !row.valid || row.duplicate).map((row) => row.holeId) };
}
var NATIVE_SPATIAL_SITE_EVALUATION_LIMIT = 12;
function selectNativeSpatialQualifiedSite(evaluated, qualify) {
  if (evaluated.length > NATIVE_SPATIAL_SITE_EVALUATION_LIMIT) throw new Error("Native hole qualification exceeds the existing full-score quota");
  let checks = 0, rejected = 0;
  for (const entry of [...evaluated].sort((a, b) => compareNativeSpatialConstraintScores(a.score, b.score))) {
    const result = qualify(entry.site);
    checks++;
    if (result.accepted) return { site: entry.site, checks, rejected };
    rejected++;
  }
  return { checks, rejected };
}

// src/generation/world-study/native-spatial-initial-placement.ts
var NativeSpatialInitialPlacementError = class extends Error {
  constructor(initialPlacement) {
    super(`Native initial capacity ${initialPlacement.status} on its fixed finite graph`);
    this.initialPlacement = initialPlacement;
  }
};
var STATE_LIMIT = 12;
var LOCAL_LIMIT = 12;
var orderPoint = (a, b) => a.y - b.y || a.x - b.x;
var siteKey = (id, p) => `${id}@${p.x},${p.y}`;
var distanceSquared = (a, b) => (a.x - b.x) ** 2 + (a.y - b.y) ** 2;
var snapPoint = (p) => ({ x: Math.round(p.x / 8) * 8, y: Math.round(p.y / 8) * 8 });
function vertices(primitives) {
  const unique = /* @__PURE__ */ new Map();
  for (const p of primitives) for (let i = 0; i < p.points.length; i += 2) {
    const x = p.points[i], y = p.points[i + 1];
    unique.set(`${x}:${y}`, { x, y });
  }
  return [...unique.values()];
}
function translate(primitives, p) {
  return primitives.map((t) => nativePrimitive(t.points.map((v, i) => v + (i % 2 ? p.y : p.x)), t.objectId));
}
function overlaps(a, b) {
  for (const p of [a, b]) for (let i = 0; i < p.points.length; i += 2) {
    const j = (i + 2) % p.points.length, nx = p.points[i + 1] - p.points[j + 1], ny = p.points[j] - p.points[i];
    let amin = Infinity, amax = -Infinity, bmin = Infinity, bmax = -Infinity;
    for (let k = 0; k < a.points.length; k += 2) {
      const d = a.points[k] * nx + a.points[k + 1] * ny;
      amin = Math.min(amin, d);
      amax = Math.max(amax, d);
    }
    for (let k = 0; k < b.points.length; k += 2) {
      const d = b.points[k] * nx + b.points[k + 1] * ny;
      bmin = Math.min(bmin, d);
      bmax = Math.max(bmax, d);
    }
    if (amax < bmin || bmax < amin) return false;
  }
  return true;
}
function tooClose(a, b, radius) {
  for (const p of a) for (const q of b) {
    if (Math.hypot(Math.max(p.minX - q.maxX, q.minX - p.maxX, 0), Math.max(p.minY - q.maxY, q.minY - p.maxY, 0)) >= radius) continue;
    if (overlaps(p, q)) return true;
    const pt = { ...p, items: [p] }, qt = { ...q, items: [q] };
    for (let i = 0; i < p.points.length; i += 2) if (nativePrimitiveDistance(qt, p.points[i], p.points[i + 1]) < radius) return true;
    for (let i = 0; i < q.points.length; i += 2) if (nativePrimitiveDistance(pt, q.points[i], q.points[i + 1]) < radius) return true;
  }
  return false;
}
function minimumAssignment(costs, limit, checkpoint) {
  const n = costs.length, u = new Float64Array(n + 1), v = new Float64Array(n + 1), p = new Int32Array(n + 1), way = new Int32Array(n + 1);
  for (let i = 1; i <= n; i++) {
    checkpoint();
    p[0] = i;
    let j0 = 0;
    const min = new Float64Array(n + 1).fill(Infinity), used = new Uint8Array(n + 1);
    do {
      used[j0] = 1;
      const i0 = p[j0];
      let delta = Infinity, j1 = 0;
      for (let j = 1; j <= n; j++) if (!used[j]) {
        const raw = costs[i0 - 1][j - 1], cur = raw <= limit ? raw * raw - u[i0] - v[j] : Infinity;
        if (cur < min[j]) {
          min[j] = cur;
          way[j] = j0;
        }
        if (min[j] < delta) {
          delta = min[j];
          j1 = j;
        }
      }
      if (!Number.isFinite(delta)) return void 0;
      for (let j = 0; j <= n; j++) if (used[j]) {
        u[p[j]] = u[p[j]] + delta;
        v[j] = v[j] - delta;
      } else min[j] = min[j] - delta;
      j0 = j1;
    } while (p[j0] !== 0);
    do {
      const j1 = way[j0];
      p[j0] = p[j1];
      j0 = j1;
    } while (j0 !== 0);
  }
  const assignment = Array(n);
  for (let j = 1; j <= n; j++) assignment[p[j] - 1] = j - 1;
  return assignment;
}
function solveNativeSpatialInitialMatching(matrix, forbidden, checkpoint) {
  const costs = matrix.map((row) => row.map((e) => forbidden.has(siteKey(e.objectId, e.site)) ? Infinity : e.cost)), thresholds = [...new Set(costs.flat().filter(Number.isFinite))].sort((a, b) => a - b);
  let lo = 0, hi = thresholds.length - 1, best;
  while (lo <= hi) {
    const mid = lo + hi >> 1, assignment = minimumAssignment(costs, thresholds[mid], checkpoint);
    if (assignment) {
      best = assignment;
      hi = mid - 1;
    } else lo = mid + 1;
  }
  if (!best) return void 0;
  const indices = minimumAssignment(costs, thresholds[lo], checkpoint);
  return indices.map((j, i) => matrix[i][j]);
}
function createNativeSpatialInitialPlacement(context) {
  const { ground, gapPx, checkpoint } = context, objects = [...context.objects].sort((a, b) => a.id.localeCompare(b.id)), field = [...context.field];
  if (!objects.length || new Set(objects.map((o) => o.id)).size !== objects.length || field.length < objects.length) throw new Error("Invalid native initial assignment domain");
  if (!Number.isInteger(context.firstAnchorIndex) || context.firstAnchorIndex < 0 || context.firstAnchorIndex >= field.length) throw new Error("Invalid native first coverage anchor");
  const trace = { status: "planning", field, objectIds: objects.map((o) => o.id), anchors: [], responsibilities: [], domains: [], matrix: [], states: [], localCandidates: [], timings: { domainMs: 0, matrixMs: 0, matchingMs: 0, localMs: 0, globalMs: 0 }, counts: { supportChecks: 0, matrixDistanceChecks: 0, matchingStates: 0, updateStates: 0, legalStates: 0, localScores: 0, globalScores: 0 } };
  const supportVertices = objects.map((o) => vertices(o.support)), trees = objects.map((o) => nativePrimitiveTree(o.blocking)), supportCache = objects.map(() => /* @__PURE__ */ new Map()), worldCache = objects.map(() => /* @__PURE__ */ new Map());
  const supported2 = (i, p) => {
    const key = siteKey(objects[i].id, p), cached = supportCache[i].get(key);
    if (cached !== void 0) return cached;
    if ((trace.counts.supportChecks++ & 63) === 0) checkpoint();
    const okay = Number.isFinite(p.x) && Number.isFinite(p.y) && p.x % 8 === 0 && p.y % 8 === 0 && ground.margin(p) >= 24 && supportVertices[i].every((q) => ground.margin({ x: q.x + p.x, y: q.y + p.y }) >= 24) && ground.supportsFootprint(objects[i].support, p);
    supportCache[i].set(key, okay);
    return okay;
  };
  const world = (i, p) => {
    const key = siteKey(objects[i].id, p);
    let value = worldCache[i].get(key);
    if (!value) {
      value = { blocking: translate(objects[i].blocking, p), support: translate(objects[i].support, p) };
      worldCache[i].set(key, value);
    }
    return value;
  };
  const conflict2 = (sites2) => {
    for (let i = 0; i < objects.length; i++) {
      checkpoint();
      for (let j = i + 1; j < objects.length; j++) {
        const a = world(i, sites2[i]), b = world(j, sites2[j]);
        if (tooClose(a.blocking, b.blocking, gapPx) || objects[i].kind === "hole" && tooClose(a.blocking, b.support, 24) || objects[j].kind === "hole" && tooClose(b.blocking, a.support, 24)) return { a: { id: objects[i].id, site: sites2[i] }, b: { id: objects[j].id, site: sites2[j] } };
      }
    }
    return void 0;
  };
  const started = performance.now(), siteMap = /* @__PURE__ */ new Map();
  for (const p of field) {
    const site = snapPoint(p);
    siteMap.set(`${site.x}:${site.y}`, site);
  }
  const sites = [...siteMap.values()].sort(orderPoint);
  const domains = objects.map((object2, i) => {
    const domain = sites.filter((p) => supported2(i, p));
    trace.domains.push({ id: object2.id, count: domain.length, checked: sites.length, bounds: domain.length ? { minX: Math.min(...domain.map((p) => p.x)), minY: Math.min(...domain.map((p) => p.y)), maxX: Math.max(...domain.map((p) => p.x)), maxY: Math.max(...domain.map((p) => p.y)) } : null });
    return domain;
  });
  trace.timings.domainMs = performance.now() - started;
  if (domains.some((d) => !d.length)) {
    trace.status = "empty-domain";
    throw new NativeSpatialInitialPlacementError(trace);
  }
  trace.anchors.push(field[context.firstAnchorIndex]);
  const nearest = field.map((p) => distanceSquared(p, trace.anchors[0]));
  while (trace.anchors.length < objects.length) {
    checkpoint();
    let selected2 = 0;
    for (let i = 1; i < field.length; i++) if (nearest[i] > nearest[selected2] || nearest[i] === nearest[selected2] && orderPoint(field[i], field[selected2]) < 0) selected2 = i;
    const anchor = field[selected2];
    trace.anchors.push(anchor);
    for (let i = 0; i < field.length; i++) nearest[i] = Math.min(nearest[i], distanceSquared(field[i], anchor));
  }
  const regions = trace.anchors.map(() => []);
  field.forEach((p, index) => {
    let selected2 = 0;
    for (let j = 1; j < trace.anchors.length; j++) if (distanceSquared(p, trace.anchors[j]) < distanceSquared(p, trace.anchors[selected2])) selected2 = j;
    trace.responsibilities.push(selected2);
    regions[selected2].push(index);
  });
  const nearestSite = (i, target) => {
    let best2 = domains[i][0], distance3 = distanceSquared(best2, target);
    for (const p of domains[i]) {
      if ((trace.counts.matrixDistanceChecks++ & 1023) === 0) checkpoint();
      const next = distanceSquared(p, target);
      if (next < distance3 || next === distance3 && orderPoint(p, best2) < 0) {
        best2 = p;
        distance3 = next;
      }
    }
    return best2;
  };
  const domainCost = (i, p, indices) => {
    let maximum = 0, sum = 0;
    for (let k = 0; k < indices.length; k++) {
      if ((k & 255) === 0) checkpoint();
      const q = field[indices[k]], distance3 = nativePrimitiveDistance(trees[i], q.x - p.x, q.y - p.y);
      maximum = Math.max(maximum, distance3);
      sum += distance3 * distance3;
    }
    return { maximum, mean: sum / Math.max(1, indices.length) };
  };
  const matrixStart = performance.now();
  for (let i = 0; i < objects.length; i++) trace.matrix.push(trace.anchors.map((anchor, region) => {
    const site = nearestSite(i, anchor);
    return { objectId: objects[i].id, region, site, cost: domainCost(i, site, regions[region]).maximum };
  }));
  trace.timings.matrixMs = performance.now() - matrixStart;
  const queue = [], visited = /* @__PURE__ */ new Set();
  let truncated = false;
  const solve = (forbidden) => {
    const key = JSON.stringify(forbidden);
    if (visited.has(key)) return;
    if (trace.states.length >= STATE_LIMIT) {
      truncated = true;
      return;
    }
    visited.add(key);
    checkpoint();
    const start = performance.now(), assignment = solveNativeSpatialInitialMatching(trace.matrix, new Set(forbidden), checkpoint);
    trace.counts.matchingStates++;
    if (!assignment) {
      trace.states.push({ kind: "matching", forbidden, legal: false, reason: "no-complete-matching" });
      trace.timings.matchingMs += performance.now() - start;
      return;
    }
    const positions = assignment.map((e) => e.site), collision = conflict2(positions), bottleneck = Math.max(...assignment.map((e) => e.cost)), sum = assignment.reduce((n, e) => n + e.cost * e.cost, 0), index = trace.states.length;
    trace.states.push({ kind: "matching", forbidden, assignment, bottleneck, squaredCost: sum, legal: !collision, ...collision ? { conflict: collision } : {} });
    if (!collision) trace.counts.legalStates++;
    queue.push({ forbidden, assignment, index, bottleneck, sum });
    trace.timings.matchingMs += performance.now() - start;
  };
  solve([]);
  let base;
  while (queue.length) {
    checkpoint();
    queue.sort((a, b) => a.bottleneck - b.bottleneck || a.sum - b.sum || JSON.stringify(a.forbidden).localeCompare(JSON.stringify(b.forbidden)));
    const node = queue.shift(), collision = trace.states[node.index].conflict;
    if (!collision) {
      base = node;
      break;
    }
    for (const pose of [collision.a, collision.b]) solve([.../* @__PURE__ */ new Set([...node.forbidden, siteKey(pose.id, pose.site)])].sort());
  }
  if (!base) {
    trace.status = truncated ? "state-budget" : "fixed-graph-unresolved";
    throw new NativeSpatialInitialPlacementError(trace);
  }
  const evaluate = (positions) => {
    checkpoint();
    const start = performance.now(), score = context.evaluate(positions.map((site, i) => ({ id: objects[i].id, site })));
    trace.timings.globalMs += performance.now() - start;
    trace.counts.globalScores++;
    checkpoint();
    return score;
  };
  const baseSites = base.assignment.map((e) => e.site);
  let selected = baseSites, best = evaluate(baseSites), selectedState = base.index;
  trace.states[base.index].score = best;
  if (best.maximum > 0 && trace.states.length < STATE_LIMIT) {
    const localStart = performance.now(), responsibilities = objects.map(() => []);
    trace.updatedResponsibilities = [];
    const labels = [];
    for (let k = 0; k < field.length; k++) {
      if ((k & 255) === 0) checkpoint();
      const p = field[k];
      let owner = 0, distance3 = Infinity;
      for (let i = 0; i < objects.length; i++) {
        const site = baseSites[i], d = nativePrimitiveDistance(trees[i], p.x - site.x, p.y - site.y);
        if (d < distance3) {
          owner = i;
          distance3 = d;
        }
      }
      responsibilities[owner].push(k);
      labels.push(objects[owner].id);
    }
    trace.updatedResponsibilities = labels;
    const targets = objects.map((object2, i) => {
      const indices = responsibilities[i], baseSite = baseSites[i];
      if (!indices.length) return baseSite;
      let farthest = indices[0], farDistance = -Infinity, minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
      for (const index of indices) {
        const p = field[index], d = nativePrimitiveDistance(trees[i], p.x - baseSite.x, p.y - baseSite.y);
        if (d > farDistance || d === farDistance && orderPoint(p, field[farthest]) < 0) {
          farthest = index;
          farDistance = d;
        }
        minX = Math.min(minX, p.x);
        minY = Math.min(minY, p.y);
        maxX = Math.max(maxX, p.x);
        maxY = Math.max(maxY, p.y);
      }
      const centre = { x: (minX + maxX) / 2, y: (minY + maxY) / 2 }, far = field[farthest], candidates = /* @__PURE__ */ new Map();
      for (const anchor of [baseSite, centre, far]) for (const alpha of [0, 0.25, 0.5, 1]) {
        const target = { x: baseSite.x + (anchor.x - baseSite.x) * alpha, y: baseSite.y + (anchor.y - baseSite.y) * alpha }, site = nearestSite(i, target);
        candidates.set(siteKey(object2.id, site), site);
      }
      let chosen = baseSite, score = { maximum: Infinity, mean: Infinity };
      const considered = [...candidates.values()].slice(0, LOCAL_LIMIT);
      for (const site of considered) {
        const next = domainCost(i, site, indices);
        trace.counts.localScores++;
        if (next.maximum < score.maximum || next.maximum === score.maximum && (next.mean < score.mean || next.mean === score.mean && orderPoint(site, chosen) < 0)) {
          chosen = site;
          score = next;
        }
      }
      trace.localCandidates.push({ id: object2.id, sites: considered, ...score });
      return chosen;
    });
    trace.timings.localMs = performance.now() - localStart;
    for (const alpha of [1, 0.5, 0.25]) {
      if (trace.states.length >= STATE_LIMIT) break;
      checkpoint();
      const positions = baseSites.map((p, i) => snapPoint({ x: p.x + (targets[i].x - p.x) * alpha, y: p.y + (targets[i].y - p.y) * alpha })), placements = positions.map((site, i) => ({ id: objects[i].id, site }));
      const unsupported = positions.some((site, i) => !supported2(i, site)), collision = unsupported ? void 0 : conflict2(positions), row = { kind: "update", alpha, sites: placements, legal: !unsupported && !collision, ...unsupported ? { reason: "ground-support" } : {}, ...collision ? { conflict: collision } : {} };
      trace.states.push(row);
      trace.counts.updateStates++;
      if (!row.legal) continue;
      trace.counts.legalStates++;
      const score = evaluate(positions);
      row.score = score;
      if (compareNativeSpatialConstraintScores(score, best) < 0) {
        selected = positions;
        best = score;
        selectedState = trace.states.length - 1;
      }
    }
  }
  trace.status = "selected";
  trace.selectedState = selectedState;
  return { placements: selected.map((site, i) => ({ id: objects[i].id, site })), trace };
}

// src/generation/world-study/native-spatial-g1-field.ts
function nativeSpatialG1FilledDistance(tree, contains3, x, y) {
  return contains3?.(x, y) ? 0 : nativePrimitiveDistance(tree, x, y);
}
function nativeSpatialG1ExteriorRadius(feedback) {
  const { cols, rows, exteriorMask } = feedback, count = cols * rows;
  if (!Number.isSafeInteger(cols) || !Number.isSafeInteger(rows) || cols <= 0 || rows <= 0 || exteriorMask.length !== count) throw new Error("G1 actual exterior dimensions mismatch");
  const cells = [];
  for (let cell = 0; cell < count; cell++) {
    if (exteriorMask[cell] !== 0 && exteriorMask[cell] !== 1) throw new Error("G1 actual exterior mask is not binary");
    if (exteriorMask[cell]) cells.push(cell);
  }
  const tree = nativePrimitiveTree(nativeVoidCellBoundary(cells, cols, rows, -1)), width = cols * 8, height = rows * 8;
  return (point) => {
    if (point.x < 0 || point.y < 0 || point.x >= width || point.y >= height || exteriorMask[Math.floor(point.y / 8) * cols + Math.floor(point.x / 8)]) return 0;
    return Math.min(point.x, point.y, width - point.x, height - point.y, nativePrimitiveDistance(tree, point.x, point.y));
  };
}
var NativeSpatialG1Field = class {
  constructor(width, height, margin, assessmentPoints, checkpoint = () => {
  }, exteriorDistance) {
    this.checkpoint = checkpoint;
    this.exteriorDistance = exteriorDistance;
    const points = [], keys = /* @__PURE__ */ new Set();
    let checked = 0;
    for (let y = 4; y < height; y += 8) for (let x = 4; x < width; x += 8) {
      if (checked++ % 1024 === 0) this.checkpoint();
      const point = { x, y };
      if (margin(point) < 12) continue;
      points.push(point);
      keys.add(`${x}:${y}`);
    }
    this.gridPointCount = points.length;
    let added = 0, outside = 0;
    for (const point of assessmentPoints) {
      const key = `${point.x}:${point.y}`;
      if (keys.has(key)) continue;
      points.push({ ...point });
      keys.add(key);
      added++;
      if (margin(point) < 12) outside++;
    }
    this.points = points;
    this.assessmentPointsAdded = added;
    this.assessmentPointsOutsideRawSupport = outside;
    this.exteriorRadii = new Float64Array(points.length);
    for (let i = 0; i < points.length; i++) {
      if (i % 1024 === 0) this.checkpoint();
      this.exteriorRadii[i] = this.exteriorRadius(points[i]);
    }
  }
  points;
  gridPointCount;
  assessmentPointsAdded;
  assessmentPointsOutsideRawSupport;
  maximumEvaluations = 0;
  maximumDistanceQueries = 0;
  cachedDistanceQueries = 0;
  lastEvaluatedMaximumPx = null;
  exteriorRadii;
  /** Runtime prediction, not a replacement for final supported-body gating. */
  exteriorRadius(point) {
    if (!this.exteriorDistance) return Infinity;
    const radius = this.exteriorDistance(point);
    if (Number.isNaN(radius)) throw new Error("G1 exterior radius is NaN");
    return Math.max(0, radius);
  }
  /** Cache all other objects once per single-object scan. */
  distances(distance3) {
    const values = new Float64Array(this.points.length);
    for (let i = 0; i < this.points.length; i++) {
      if (i % 1024 === 0) this.checkpoint();
      values[i] = Math.min(this.exteriorRadii[i], distance3(this.points[i], i));
      this.cachedDistanceQueries++;
    }
    return values;
  }
  /** Sort the unchanged-object upper bounds once for a complete site scan. */
  descendingIndices(remaining) {
    if (remaining.length !== this.points.length) throw new Error("G1 remaining field length mismatch");
    this.checkpoint();
    let comparisons = 0;
    return Uint32Array.from(remaining, (_, index) => index).sort((a, b) => {
      if (comparisons++ % 1024 === 0) this.checkpoint();
      return remaining[b] - remaining[a] || a - b;
    });
  }
  /** Exact max(min(remaining, moved)): every unvisited term is bounded by
   * its descending remaining distance. No gate threshold enters this bound. */
  maximumWithRemaining(remaining, descending, movedDistance) {
    if (remaining.length !== this.points.length || descending.length !== this.points.length) throw new Error("G1 remaining field length mismatch");
    let maximum = 0;
    this.maximumEvaluations++;
    for (let order = 0; order < descending.length; order++) {
      if (order % 1024 === 0) this.checkpoint();
      const index = descending[order], upper = remaining[index];
      if (upper <= maximum) break;
      maximum = Math.max(maximum, Math.min(upper, this.exteriorRadii[index], movedDistance(this.points[index], index)));
      this.maximumDistanceQueries++;
    }
    this.lastEvaluatedMaximumPx = maximum;
    return maximum;
  }
  maximum(distance3) {
    let maximum = 0;
    this.maximumEvaluations++;
    for (let i = 0; i < this.points.length; i++) {
      if (i % 1024 === 0) this.checkpoint();
      maximum = Math.max(maximum, Math.min(this.exteriorRadii[i], distance3(this.points[i], i)));
      this.maximumDistanceQueries++;
    }
    this.lastEvaluatedMaximumPx = maximum;
    return maximum;
  }
  trace() {
    return {
      gridPointCount: this.gridPointCount,
      assessmentPointsAdded: this.assessmentPointsAdded,
      assessmentPointsOutsideRawSupport: this.assessmentPointsOutsideRawSupport,
      maximumEvaluations: this.maximumEvaluations,
      maximumDistanceQueries: this.maximumDistanceQueries,
      cachedDistanceQueries: this.cachedDistanceQueries,
      lastEvaluatedMaximumPx: this.lastEvaluatedMaximumPx
    };
  }
};
function nativeSpatialG1HoleShapes(feedback, placements) {
  const { cols, rows, exteriorMask, holes } = feedback, count = cols * rows;
  if (!Number.isSafeInteger(cols) || !Number.isSafeInteger(rows) || cols <= 0 || rows <= 0 || exteriorMask.length !== count) throw new Error("G1 actual VOID dimensions mismatch");
  const ids = new Set(placements.map((p) => p.holeId));
  if (ids.size !== placements.length || holes.length !== placements.length || new Set(holes.map((h) => h.holeId)).size !== holes.length || holes.some((h) => !ids.has(h.holeId))) throw new Error("G1 actual VOID hole identity mismatch");
  const claimed = /* @__PURE__ */ new Set(), result = /* @__PURE__ */ new Map();
  placements.forEach((placement, index) => {
    if (!Number.isFinite(placement.site.x) || !Number.isFinite(placement.site.y) || !Number.isInteger(placement.site.x / 8) || !Number.isInteger(placement.site.y / 8)) throw new Error("G1 actual VOID placement is off grid");
    const hole = holes.find((h) => h.holeId === placement.holeId);
    if (!hole.cells.length) throw new Error("G1 actual VOID hole has no cells");
    for (const cell of hole.cells) {
      if (!Number.isSafeInteger(cell) || cell < 0 || cell >= count || claimed.has(cell) || exteriorMask[cell]) throw new Error("G1 actual VOID cell identity mismatch");
      claimed.add(cell);
    }
    const members = new Set(hole.cells), originCol = placement.site.x / 8, originRow = placement.site.y / 8;
    result.set(placement.holeId, {
      boundary: nativeVoidCellBoundary(hole.cells, cols, rows, index).map((p) => nativePrimitive(p.points.map((v, i) => v - (i % 2 ? placement.site.y : placement.site.x)), p.objectId)),
      contains: (x, y) => {
        const col = Math.floor(x / 8) + originCol, row = Math.floor(y / 8) + originRow;
        return col >= 0 && row >= 0 && col < cols && row < rows && members.has(row * cols + col);
      }
    });
  });
  return result;
}

// src/generation/world-study/native-spatial-land.ts
var snap = (value) => Math.round(value / 8) * 8;
var contained = (r, x, y) => x >= r[0] && y >= r[1] && x <= r[0] + r[2] && y <= r[1] + r[3];
function nativeRectUnionArea(rects) {
  const xs = [...new Set(rects.flatMap((r) => [r[0], r[0] + r[2]]))].sort((a, b) => a - b);
  let result = 0;
  for (let i = 0; i < xs.length - 1; i++) {
    const x = (xs[i] + xs[i + 1]) / 2, spans = rects.filter((r) => x > r[0] && x < r[0] + r[2]).map((r) => [r[1], r[1] + r[3]]).sort((a, b) => a[0] - b[0]);
    let end = -Infinity, length2 = 0;
    for (const [start, stop] of spans) {
      length2 += Math.max(0, stop - Math.max(start, end));
      end = Math.max(end, stop);
    }
    result += (xs[i + 1] - xs[i]) * length2;
  }
  return result;
}
function nativeSpatialExposedShore(rects) {
  const xs = [...new Set(rects.flatMap((r) => [r[0], r[0] + r[2]]))].sort((a, b) => a - b), ys = [...new Set(rects.flatMap((r) => [r[1], r[1] + r[3]]))].sort((a, b) => a - b), result = [];
  const present = (x, y) => x >= 0 && y >= 0 && x < xs.length - 1 && y < ys.length - 1 && rects.some((r) => contained(r, (xs[x] + xs[x + 1]) / 2, (ys[y] + ys[y + 1]) / 2));
  for (let y = 0; y < ys.length - 1; y++) for (let x = 0; x < xs.length - 1; x++) if (present(x, y)) {
    const l = xs[x], r = xs[x + 1], t = ys[y], b = ys[y + 1];
    const add = (direction, x1, y1, x2, y2, insideX, insideY) => {
      const parent = rects.findIndex((rect) => contained(rect, insideX, insideY));
      if (parent >= 0) result.push({ direction, x1, y1, x2, y2, parent });
    };
    if (!present(x - 1, y)) add(0, l, t, l, b, l + 0.5, (t + b) / 2);
    if (!present(x + 1, y)) add(1, r, t, r, b, r - 0.5, (t + b) / 2);
    if (!present(x, y - 1)) add(2, l, t, r, t, (l + r) / 2, t + 0.5);
    if (!present(x, y + 1)) add(3, l, b, r, b, (l + r) / 2, b - 0.5);
  }
  return result;
}
function box(rects) {
  return { minX: Math.min(...rects.map((r) => r[0])), minY: Math.min(...rects.map((r) => r[1])), maxX: Math.max(...rects.map((r) => r[0] + r[2])), maxY: Math.max(...rects.map((r) => r[1] + r[3])) };
}
function consumedShoreLength(shore, rect) {
  const vertical = shore.direction < 2, axis = vertical ? shore.x1 : shore.y1;
  const low = vertical ? rect[0] : rect[1], high = low + (vertical ? rect[2] : rect[3]);
  if (axis <= low || axis >= high) return 0;
  return Math.max(0, Math.min(vertical ? shore.y2 : shore.x2, vertical ? rect[1] + rect[3] : rect[0] + rect[2]) - Math.max(vertical ? shore.y1 : shore.x1, vertical ? rect[1] : rect[0]));
}
function createNativeSpatialLand(input, random, counts, native, bayAreaEstimatePx2 = 0) {
  const w = input.world, overlap2 = w.landRectMinOverlapPx, countOptions = [];
  if (w.landShoulderAttachment !== "core-outward-normal-v1") throw new Error("Unsupported native shoulder attachment");
  for (let core = w.landCoreMinCount; core <= w.landCoreMaxCount; core++) for (let shoulder = w.landShoulderMinCount; shoulder <= w.landShoulderMaxCount; shoulder++) if (core + shoulder >= w.landRectMinCount && core + shoulder <= w.landRectMaxCount) countOptions.push({ core, shoulder });
  const selectedCounts = random.choose(countOptions), number = selectedCounts.core;
  const motherArea = input.assemblies.reduce((sum, a) => sum + a.sourceInstanceIds.reduce((n, id) => {
    const i = native.instances.find((item) => item.id === id);
    return n + i.length * i.width * a.sourceScale * a.sourceScale * 0.38;
  }, 0), 0);
  const holeArea = counts.holes * input.holeProfiles.reduce((sum, h) => sum + h.weight * h.maxAreaPx2 * 0.75, 0) / input.holeProfiles.reduce((sum, h) => sum + h.weight, 0);
  const target = w.targetWalkAreaPx2 + motherArea + (counts.solids - input.assemblies.length) * 16e3 + holeArea + 12e4 + bayAreaEstimatePx2;
  const shoulderShapes = Array.from({ length: selectedCounts.shoulder }, () => ({ span: random.integer(w.landShoulderMinSpanPx / 8, w.landShoulderMaxSpanPx / 8) * 8, thickness: random.integer(w.landShoulderMinThicknessPx / 8, w.landShoulderMaxThicknessPx / 8) * 8 }));
  const expectedShoulderArea = shoulderShapes.reduce((sum, d) => sum + d.thickness * (w.landShoulderMinExtensionPx + Math.min(w.landShoulderMaxExtensionPx, d.span - overlap2)) / 2, 0);
  const coreTarget = target - expectedShoulderArea;
  const ranks = Array.from({ length: number }, (_, i) => i);
  for (let i = number - 1; i > 0; i--) {
    const j = random.integer(0, i);
    [ranks[i], ranks[j]] = [ranks[j], ranks[i]];
  }
  const dimensions = Array.from({ length: number }, (_, i) => {
    const span = snap(w.landRectMinSpanPx + (w.landRectMaxSpanPx - w.landRectMinSpanPx) * (i + random.next()) / number);
    const thickness = snap(w.landRectMinThicknessPx + (w.landRectMaxThicknessPx - w.landRectMinThicknessPx) * (ranks[i] + random.next()) / number);
    return { span, thickness };
  });
  dimensions.sort((a, b) => b.span * b.thickness - a.span * a.thickness);
  const first = dimensions.shift(), rects = [[0, 0, first.span, first.thickness]], plates = [{ role: "core", parentIndex: null }];
  for (let i = 1; i < number; i++) {
    const shape = dimensions.shift(), shore = nativeSpatialExposedShore(rects), currentArea = nativeRectUnionArea(rects);
    const remainingArea = shape.span * shape.thickness + dimensions.reduce((sum, d) => sum + d.span * d.thickness, 0);
    const desired = (coreTarget - currentArea) * shape.span * shape.thickness / remainingArea, options = [];
    for (let draw = 0; draw < 96; draw++) {
      const edge = random.choose(shore), parent = rects[edge.parent], vertical = random.next() < 0.5, width = vertical ? shape.thickness : shape.span, height = vertical ? shape.span : shape.thickness;
      const normal = edge.direction < 2 ? width : height, tangent = edge.direction < 2 ? height : width;
      const parentNormal = edge.direction < 2 ? parent[2] : parent[3];
      const extension = snap(Math.max(8, Math.min(normal - overlap2, desired / tangent * random.range(0.7, 1.35))));
      const depth = normal - extension;
      if (depth > parentNormal) continue;
      let x, y;
      if (edge.direction < 2) {
        const minimum = parent[1] + overlap2 - height, maximum = parent[1] + parent[3] - overlap2;
        if (maximum < minimum) continue;
        y = snap(Math.max(minimum, Math.min(maximum, (edge.y1 + edge.y2) / 2 - height / 2 + random.range(-height * 0.32, height * 0.32))));
        x = edge.direction === 0 ? edge.x1 - extension : edge.x1 - depth;
      } else {
        const minimum = parent[0] + overlap2 - width, maximum = parent[0] + parent[2] - overlap2;
        if (maximum < minimum) continue;
        x = snap(Math.max(minimum, Math.min(maximum, (edge.x1 + edge.x2) / 2 - width / 2 + random.range(-width * 0.32, width * 0.32))));
        y = edge.direction === 2 ? edge.y1 - extension : edge.y1 - depth;
      }
      const rect = [snap(x), snap(y), width, height], next = [...rects, rect], bounds4 = box(next);
      if (bounds4.maxX - bounds4.minX > w.frameWidthPx - 96 || bounds4.maxY - bounds4.minY > w.frameHeightPx - 96) continue;
      if (!rects.some((old) => Math.min(old[0] + old[2], rect[0] + rect[2]) - Math.max(old[0], rect[0]) >= overlap2 && Math.min(old[1] + old[3], rect[1] + rect[3]) - Math.max(old[1], rect[1]) >= overlap2)) continue;
      const area3 = nativeRectUnionArea(next), added = area3 - currentArea;
      if (added <= 0) continue;
      if (next.some((_, index) => area3 === nativeRectUnionArea(next.filter((__, j) => j !== index)))) continue;
      const visible = nativeSpatialExposedShore(next).some((s) => s.parent === i);
      if (!visible) continue;
      const unrelated = shore.reduce((sum, s) => sum + (s.parent === edge.parent && s.direction === edge.direction ? 0 : consumedShoreLength(s, rect)), 0);
      const score = Math.abs(added - desired) / Math.max(1, desired) + unrelated / Math.max(1, tangent) + random.range(0, 0.08);
      options.push({ rect, score, parentIndex: edge.parent });
    }
    options.sort((a, b) => a.score - b.score || a.rect[1] - b.rect[1] || a.rect[0] - b.rect[0]);
    if (!options.length) throw new Error("Native broad-plate attachment has no framed visible supported candidate");
    rects.push(options[0].rect);
    plates.push({ role: "core", parentIndex: options[0].parentIndex });
  }
  for (const [shoulderIndex, shape] of shoulderShapes.entries()) {
    const rawShore = nativeSpatialExposedShore(rects).filter((s) => s.parent < number), shore = [];
    const groups = /* @__PURE__ */ new Map();
    for (const s of rawShore) {
      const key = `${s.parent}:${s.direction}:${s.direction < 2 ? s.x1 : s.y1}`, list = groups.get(key) ?? [];
      list.push(s);
      groups.set(key, list);
    }
    for (const list of groups.values()) {
      list.sort((a, b) => a.direction < 2 ? a.y1 - b.y1 : a.x1 - b.x1);
      let current = list[0];
      for (const next of list.slice(1)) if (current.x2 === next.x1 && current.y2 === next.y1) current = { ...current, x2: next.x2, y2: next.y2 };
      else {
        shore.push(current);
        current = next;
      }
      shore.push(current);
    }
    const currentArea = nativeRectUnionArea(rects), desired = (target - currentArea) / (shoulderShapes.length - shoulderIndex), options = [];
    for (let draw = 0; draw < 128; draw++) {
      const edge = random.choose(shore), parent = rects[edge.parent], normalX = edge.direction < 2, parentNormal = normalX ? parent[2] : parent[3];
      const minExtension = Math.max(w.landShoulderMinExtensionPx, shape.span - parentNormal), maxExtension = Math.min(w.landShoulderMaxExtensionPx, shape.span - overlap2);
      const minUnits = Math.ceil(minExtension / 8), maxUnits = Math.floor(maxExtension / 8);
      if (minUnits > maxUnits) continue;
      const extension = random.integer(minUnits, maxUnits) * 8, depth = shape.span - extension;
      const edgeStart = normalX ? edge.y1 : edge.x1, edgeEnd = normalX ? edge.y2 : edge.x2;
      if (edgeEnd - edgeStart < overlap2) continue;
      const minimum = Math.max((normalX ? parent[1] : parent[0]) + overlap2 - shape.thickness, edgeStart + overlap2 - shape.thickness), maximum = Math.min((normalX ? parent[1] + parent[3] : parent[0] + parent[2]) - overlap2, edgeEnd - overlap2);
      if (Math.ceil(minimum / 8) > Math.floor(maximum / 8)) continue;
      const tangent = random.integer(Math.ceil(minimum / 8), Math.floor(maximum / 8)) * 8;
      const rect = normalX ? [edge.direction === 0 ? edge.x1 - extension : edge.x1 - depth, tangent, shape.span, shape.thickness] : [tangent, edge.direction === 2 ? edge.y1 - extension : edge.y1 - depth, shape.thickness, shape.span];
      const next = [...rects, rect], bounds4 = box(next);
      if (bounds4.maxX - bounds4.minX > w.frameWidthPx - 96 || bounds4.maxY - bounds4.minY > w.frameHeightPx - 96) continue;
      const overlapX = Math.min(parent[0] + parent[2], rect[0] + rect[2]) - Math.max(parent[0], rect[0]), overlapY = Math.min(parent[1] + parent[3], rect[1] + rect[3]) - Math.max(parent[1], rect[1]);
      if (overlapX < overlap2 || overlapY < overlap2) continue;
      const area3 = nativeRectUnionArea(next), added = area3 - currentArea;
      if (added <= 0 || next.some((_, index) => area3 === nativeRectUnionArea(next.filter((__, j) => j !== index)))) continue;
      const lost = rawShore.reduce((sum, s) => sum + (s.parent === edge.parent && s.direction === edge.direction ? 0 : consumedShoreLength(s, rect)), 0);
      options.push({ rect, edge, extension, score: Math.abs(added - desired) / Math.max(1, Math.abs(desired)) + lost / shape.thickness + random.range(0, 0.08) });
    }
    options.sort((a, b) => a.score - b.score || a.edge.parent - b.edge.parent || a.rect[1] - b.rect[1] || a.rect[0] - b.rect[0]);
    const selected = options[0];
    if (!selected) throw new Error("Native shoulder has no core-facing size/extension/overlap intersection");
    rects.push(selected.rect);
    plates.push({ role: "shoulder", parentIndex: selected.edge.parent, sourceShore: selected.edge, extensionPx: selected.extension });
  }
  const bounds3 = box(rects), offsetX = snap((w.frameWidthPx - (bounds3.maxX - bounds3.minX)) / 2 - bounds3.minX), offsetY = snap((w.frameHeightPx - (bounds3.maxY - bounds3.minY)) / 2 - bounds3.minY);
  return { rects: rects.map(([x, y, width, height]) => [x + offsetX, y + offsetY, width, height]), plates: plates.map((p) => p.sourceShore ? { ...p, sourceShore: { ...p.sourceShore, x1: p.sourceShore.x1 + offsetX, x2: p.sourceShore.x2 + offsetX, y1: p.sourceShore.y1 + offsetY, y2: p.sourceShore.y2 + offsetY } } : p) };
}

// src/generation/world-study/native-spatial-bay-layout.ts
var snap2 = (value) => Math.round(value / 8) * 8;
var inside = (rects, x, y) => rects.some((r) => x >= r[0] && y >= r[1] && x <= r[0] + r[2] && y <= r[1] + r[3]);
function intersect(a, b) {
  const x = Math.max(a[0], b[0]), y = Math.max(a[1], b[1]), w = Math.min(a[0] + a[2], b[0] + b[2]) - x, h = Math.min(a[1] + a[3], b[1] + b[3]) - y;
  return w > 0 && h > 0 ? [x, y, w, h] : void 0;
}
function nativeSpatialRemovedLand(land, cuts) {
  return land.flatMap((l) => cuts.flatMap((c) => {
    const r = intersect(l, c);
    return r ? [r] : [];
  }));
}
function nativeSpatialLandJoins(land, width, parents) {
  return land.slice(1).map((child, i) => {
    const childIndex = i + 1, options = land.slice(0, childIndex).flatMap((parent, parentIndex) => {
      if (parents && parents[childIndex] !== parentIndex) return [];
      const r = intersect(parent, child);
      return r && r[2] >= width && r[3] >= width ? [{ parentIndex, r }] : [];
    });
    options.sort((a, b) => b.r[2] * b.r[3] - a.r[2] * a.r[3] || a.parentIndex - b.parentIndex);
    const selected = options[0];
    if (!selected) throw new Error("Native plate has no protected wide join");
    return { parentIndex: selected.parentIndex, childIndex, rect: [selected.r[0] + (selected.r[2] - width) / 2, selected.r[1] + (selected.r[3] - width) / 2, width, width] };
  });
}
function createNativeSpatialPlanningGround(land, cuts) {
  const all = [...land, ...cuts], xs = [...new Set(all.flatMap((r) => [r[0], r[0] + r[2]]))].sort((a, b) => a - b), ys = [...new Set(all.flatMap((r) => [r[1], r[1] + r[3]]))].sort((a, b) => a - b), segments = [];
  const contains3 = (p) => inside(land, p.x, p.y) && !inside(cuts, p.x, p.y);
  const present = (x, y) => x >= 0 && y >= 0 && x < xs.length - 1 && y < ys.length - 1 && contains3({ x: (xs[x] + xs[x + 1]) / 2, y: (ys[y] + ys[y + 1]) / 2 });
  for (let y = 0; y < ys.length - 1; y++) for (let x = 0; x < xs.length - 1; x++) if (present(x, y)) {
    const l = xs[x], r = xs[x + 1], t = ys[y], b = ys[y + 1];
    if (!present(x - 1, y)) segments.push(nativePrimitive([l, t, l, b], -1));
    if (!present(x + 1, y)) segments.push(nativePrimitive([r, t, r, b], -1));
    if (!present(x, y - 1)) segments.push(nativePrimitive([l, t, r, t], -1));
    if (!present(x, y + 1)) segments.push(nativePrimitive([l, b, r, b], -1));
  }
  const tree = nativePrimitiveTree(segments);
  const supportsFootprint = (primitives, offset) => primitives.every((triangle) => {
    const p = triangle.points;
    if (p.length !== 6) throw new Error("Planning support expects projected triangles");
    for (let i = 0; i < 6; i += 2) if (!contains3({ x: p[i] + offset.x, y: p[i + 1] + offset.y })) return false;
    const orientation2 = Math.sign((p[2] - p[0]) * (p[5] - p[1]) - (p[3] - p[1]) * (p[4] - p[0]));
    if (!orientation2) return true;
    for (const edge of segments) {
      if (edge.maxX <= triangle.minX + offset.x || edge.minX >= triangle.maxX + offset.x || edge.maxY <= triangle.minY + offset.y || edge.minY >= triangle.maxY + offset.y) continue;
      const ax = edge.points[0] - offset.x, ay = edge.points[1] - offset.y, bx = edge.points[2] - offset.x, by = edge.points[3] - offset.y;
      let lo = 0, hi = 1;
      for (let i = 0; i < 6 && lo < hi; i += 2) {
        const j = (i + 2) % 6, dx = p[j] - p[i], dy = p[j + 1] - p[i + 1], start = orientation2 * (dx * (ay - p[i + 1]) - dy * (ax - p[i])), slope = orientation2 * (dx * (by - ay) - dy * (bx - ax));
        if (Math.abs(slope) < 1e-9) {
          if (start <= 1e-7) {
            lo = 1;
            hi = 0;
          }
        } else if (slope > 0) lo = Math.max(lo, (1e-7 - start) / slope);
        else hi = Math.min(hi, (1e-7 - start) / slope);
      }
      if (lo < hi) return false;
    }
    return true;
  });
  return { contains: contains3, margin: (p) => contains3(p) ? nativePrimitiveDistance(tree, p.x, p.y) : -1, supportsFootprint };
}
function mergedShore(land) {
  const segments = nativeSpatialExposedShore(land), groups = /* @__PURE__ */ new Map();
  for (const s of segments) {
    const key = `${s.direction}:${s.direction < 2 ? s.x1 : s.y1}`, list = groups.get(key) ?? [];
    list.push(s);
    groups.set(key, list);
  }
  const result = [];
  for (const list of groups.values()) {
    list.sort((a, b) => a.direction < 2 ? a.y1 - b.y1 : a.x1 - b.x1);
    let current = list[0];
    for (const next of list.slice(1)) if (current.x2 === next.x1 && current.y2 === next.y1) current = { ...current, x2: next.x2, y2: next.y2 };
    else {
      result.push(current);
      current = next;
    }
    result.push(current);
  }
  return result;
}
function backedByLand(land, allCuts, bay, profile) {
  const outward = bay.sourceShore.outward, normal = { x: -outward.x, y: -outward.y }, pieces = nativeSpatialRemovedLand(land, bay.rects);
  if (!pieces.length) return false;
  const tips = pieces.map((r) => normal.x ? { x: normal.x > 0 ? r[0] + r[2] : r[0], y: r[1] + r[3] / 2 } : { x: r[0] + r[2] / 2, y: normal.y > 0 ? r[1] + r[3] : r[1] });
  const depth = Math.max(...tips.map((p) => p.x * normal.x + p.y * normal.y)), terminal = tips.filter((p) => p.x * normal.x + p.y * normal.y === depth);
  return terminal.every((tip) => {
    const breaks = [0, profile.minBacklandPx, ...[...land, ...allCuts].flatMap((r) => normal.x ? [(r[0] - tip.x) / normal.x, (r[0] + r[2] - tip.x) / normal.x] : [(r[1] - tip.y) / normal.y, (r[1] + r[3] - tip.y) / normal.y])].filter((v) => v >= 0 && v <= profile.minBacklandPx).sort((a, b) => a - b);
    return breaks.slice(1).every((stop, i) => {
      if (stop <= breaks[i]) return true;
      const d = (breaks[i] + stop) / 2, x = tip.x + normal.x * d, y = tip.y + normal.y * d;
      return inside(land, x, y) && !inside(allCuts, x, y);
    });
  });
}
function nativeSpatialBayHasBodySideClearance(land, allCuts, bay) {
  const bodySize = 20, normalX = bay.sourceShore.outward.x !== 0, rects = [...land, ...allCuts];
  const normals = [...new Set(rects.flatMap((r) => normalX ? [r[0], r[0] + r[2]] : [r[1], r[1] + r[3]]))].sort((a, b) => a - b);
  const tangents = [...new Set(rects.flatMap((r) => normalX ? [r[1], r[1] + r[3]] : [r[0], r[0] + r[2]]))].sort((a, b) => a - b);
  const point = (n, t) => normalX ? { x: n, y: t } : { x: t, y: n };
  let previous = /* @__PURE__ */ new Map();
  for (let row = 1; row < normals.length; row++) {
    const start = normals[row - 1], end = normals[row], normal = (start + end) / 2, current = /* @__PURE__ */ new Map();
    let runStart;
    const visit = (left, right) => {
      if (right - left >= bodySize) return true;
      const a = point(normal, left - 1e-4), b = point(normal, right + 1e-4);
      if (!inside(bay.rects, a.x, a.y) && !inside(bay.rects, b.x, b.y)) return true;
      const key = `${left}:${right}`, old = previous.get(key), spanStart = old?.end === start ? old.start : start;
      if (end - spanStart >= bodySize) return false;
      current.set(key, { start: spanStart, end });
      return true;
    };
    for (let col = 1; col < tangents.length; col++) {
      const left = tangents[col - 1], right = tangents[col], p = point(normal, (left + right) / 2), present = inside(land, p.x, p.y) && !inside(allCuts, p.x, p.y);
      if (present) {
        runStart ??= left;
      } else if (runStart !== void 0) {
        if (!visit(runStart, left)) return false;
        runStart = void 0;
      }
    }
    if (runStart !== void 0 && !visit(runStart, tangents[tangents.length - 1])) return false;
    previous = current;
  }
  return true;
}
function createNativeSpatialBays(land, joins, profiles, random, frame) {
  const shores = mergedShore(land), placed = [];
  for (const [index, profile] of profiles.entries()) {
    const options = [];
    for (let attempt = 0; attempt < 160; attempt++) {
      const shore = random.choose(shores), vertical = shore.direction < 2, shoreLength = vertical ? shore.y2 - shore.y1 : shore.x2 - shore.x1;
      const mouth = snap2(random.range(profile.minMouthPx, profile.maxMouthPx));
      if (shoreLength < mouth) continue;
      const minimum = (vertical ? shore.y1 : shore.x1) + mouth / 2, maximum = (vertical ? shore.y2 : shore.x2) - mouth / 2;
      const center = Math.max(minimum, Math.min(maximum, snap2(random.range(minimum, maximum)))), normalSign = shore.direction % 2 === 0 ? 1 : -1;
      const outward = vertical ? { x: -normalSign, y: 0 } : { x: 0, y: -normalSign }, anchor = vertical ? { x: shore.x1, y: center } : { x: center, y: shore.y1 };
      const points = vertical ? [{ x: shore.x1, y: center - mouth / 2 }, { x: shore.x1, y: center + mouth / 2 }] : [{ x: center - mouth / 2, y: shore.y1 }, { x: center + mouth / 2, y: shore.y1 }];
      const count = random.integer(profile.minRectCount, profile.maxRectCount), targetDepth = snap2(random.range(profile.minDepthPx, profile.maxDepthPx));
      const outside = profile.minFinalThroatPx, partDepth = snap2((targetDepth + outside) / (1 + (count - 1) * (1 - (profile.minOverlapRatio + profile.maxOverlapRatio) / 2)));
      const local = [[-outside, -mouth / 2, partDepth, mouth]];
      for (let child = 1; child < count; child++) {
        const parent = local[child - 1], length2 = snap2(partDepth * random.range(0.85, 1.1)), width = snap2(random.range(profile.minMouthPx, Math.min(profile.maxMouthPx, parent[3]))), shorterDepth = Math.min(parent[2], length2), shorterWidth = Math.min(parent[3], width);
        const overlap2 = snap2(shorterDepth * random.range(profile.minOverlapRatio, profile.maxOverlapRatio)), offset = snap2(shorterWidth * random.range(profile.minOffsetRatio, profile.maxOffsetRatio));
        if (overlap2 / shorterDepth < profile.minOverlapRatio || overlap2 / shorterDepth > profile.maxOverlapRatio || offset / shorterWidth < profile.minOffsetRatio || offset / shorterWidth > profile.maxOffsetRatio) break;
        local.push([parent[0] + parent[2] - overlap2, parent[1] + parent[3] / 2 - width / 2 + (random.next() < 0.5 ? -offset : offset), length2, width]);
      }
      if (local.length !== count) continue;
      const rects = local.map(([depth, tangent, length2, width]) => vertical ? [anchor.x + (normalSign > 0 ? depth : -depth - length2), anchor.y + tangent, length2, width] : [anchor.x + tangent, anchor.y + (normalSign > 0 ? depth : -depth - length2), width, length2]);
      const minX = Math.min(...rects.map((r) => r[0])), minY = Math.min(...rects.map((r) => r[1])), maxX = Math.max(...rects.map((r) => r[0] + r[2])), maxY = Math.max(...rects.map((r) => r[1] + r[3]));
      if (minX < 0 || minY < 0 || maxX > frame.width || maxY > frame.height) continue;
      if (Math.max(maxX - minX, maxY - minY) > profile.maxUnionSpanPx) continue;
      const removed = nativeSpatialRemovedLand(land, rects), area3 = nativeRectUnionArea(removed);
      if (area3 < profile.minRemovedLandAreaPx2 || area3 > profile.maxRemovedLandAreaPx2) continue;
      const actualDepth = Math.max(...removed.map((r) => vertical ? normalSign > 0 ? r[0] + r[2] - anchor.x : anchor.x - r[0] : normalSign > 0 ? r[1] + r[3] - anchor.y : anchor.y - r[1]));
      if (actualDepth < profile.minDepthPx || actualDepth > profile.maxDepthPx) continue;
      if (joins.some((join) => rects.some((r) => intersect(join.rect, r)))) continue;
      if (placed.some((old) => nativeSpatialRemovedLand(removed, old.rects).length)) continue;
      const bay = { bayId: `bay-${index}`, profileId: profile.id, sourceShore: { points, outward }, rects };
      const allCuts = [...placed.flatMap((b) => b.rects.map((r) => [...r])), ...rects];
      if (!backedByLand(land, allCuts, bay, profile)) continue;
      if (!nativeSpatialBayHasBodySideClearance(land, allCuts, bay)) continue;
      const shoulderDistance = Math.min(center - mouth / 2 - (vertical ? shore.y1 : shore.x1), (vertical ? shore.y2 : shore.x2) - center - mouth / 2);
      const repeated = placed.filter((b) => b.sourceShore.outward.x === outward.x && b.sourceShore.outward.y === outward.y).length;
      const targetArea = (profile.minRemovedLandAreaPx2 + profile.maxRemovedLandAreaPx2) / 2;
      options.push({ bay, score: Math.abs(area3 - targetArea) / targetArea + shoulderDistance / Math.max(1, shoreLength) + repeated * 0.2 + random.range(0, 0.08) });
    }
    options.sort((a, b) => a.score - b.score || a.bay.rects[0][1] - b.bay.rects[0][1] || a.bay.rects[0][0] - b.bay.rects[0][0]);
    if (!options.length) throw new Error(`bay-no-source-shore: ${profile.id} has no supported finite cut`);
    placed.push(options[0].bay);
  }
  return placed;
}

// src/generation/world-study/native-spatial-joint-refinement.ts
function nativeSpatialConstraintsImproved(before, after) {
  return after.maximum < before.maximum || after.maximum === before.maximum && after.sum < before.sum;
}
function worldPrimitives(primitives, site) {
  return primitives.map((p) => nativePrimitive(p.points.map((value, index) => value + (index % 2 ? site.y : site.x)), p.objectId));
}
function overlaps2(a, b) {
  for (const p of [a, b]) for (let i = 0; i < p.points.length; i += 2) {
    const next = (i + 2) % p.points.length, nx = p.points[i + 1] - p.points[next + 1], ny = p.points[next] - p.points[i];
    let amin = Infinity, amax = -Infinity, bmin = Infinity, bmax = -Infinity;
    for (let j = 0; j < a.points.length; j += 2) {
      const value = a.points[j] * nx + a.points[j + 1] * ny;
      amin = Math.min(amin, value);
      amax = Math.max(amax, value);
    }
    for (let j = 0; j < b.points.length; j += 2) {
      const value = b.points[j] * nx + b.points[j + 1] * ny;
      bmin = Math.min(bmin, value);
      bmax = Math.max(bmax, value);
    }
    if (amax < bmin || bmax < amin) return false;
  }
  return true;
}
function tooClose2(a, b, radius) {
  for (const p of a) for (const q of b) {
    if (Math.hypot(Math.max(p.minX - q.maxX, q.minX - p.maxX, 0), Math.max(p.minY - q.maxY, q.minY - p.maxY, 0)) >= radius) continue;
    if (overlaps2(p, q)) return true;
    const pt = { ...p, items: [p] }, qt = { ...q, items: [q] };
    for (let i = 0; i < p.points.length; i += 2) if (nativePrimitiveDistance(qt, p.points[i], p.points[i + 1]) < radius) return true;
    for (let i = 0; i < q.points.length; i += 2) if (nativePrimitiveDistance(pt, q.points[i], q.points[i + 1]) < radius) return true;
  }
  return false;
}
function supported(object2, site, ground) {
  if (!Number.isFinite(site.x) || !Number.isFinite(site.y) || site.x % 8 !== 0 || site.y % 8 !== 0 || ground.margin(site) < 24) return false;
  for (const p of object2.support) for (let i = 0; i < p.points.length; i += 2) if (ground.margin({ x: p.points[i] + site.x, y: p.points[i + 1] + site.y }) < 24) return false;
  return ground.supportsFootprint(object2.support, site);
}
function conflict(a, as, b, bs, gap) {
  const ap = worldPrimitives(a.blocking, as), bp = worldPrimitives(b.blocking, bs);
  if (tooClose2(ap, bp, gap)) return true;
  if (a.kind === "hole" && tooClose2(ap, worldPrimitives(b.support, bs), 24)) return true;
  if (b.kind === "hole" && tooClose2(bp, worldPrimitives(a.support, as), 24)) return true;
  return false;
}
function nativeSpatialPlacementRejections(objects, entries, ground, gapPx) {
  if (entries.length < 1 || entries.length > 2 || new Set(entries.map((e) => e.index)).size !== entries.length) return ["invalid-object-pair"];
  const sites = new Map(entries.map((e) => [e.index, e.site]));
  const reasons = [];
  for (const entry of entries) {
    const object2 = objects[entry.index];
    if (!object2) {
      reasons.push("unknown-object");
      continue;
    }
    if (!supported(object2, entry.site, ground)) reasons.push(`${object2.id}:ground-support`);
    for (let j = 0; j < objects.length; j++) {
      if (j === entry.index) continue;
      const other = objects[j];
      if (conflict(object2, entry.site, other, sites.get(j) ?? other.site, gapPx)) reasons.push(`${object2.id}:${other.id}:${sites.has(j) ? "moved" : "fixed"}-conflict`);
    }
  }
  return reasons;
}
function directedSites(from, to, distances, snapStep) {
  const dx = to.x - from.x, dy = to.y - from.y, length2 = Math.hypot(dx, dy);
  if (!length2) return [];
  const seen = /* @__PURE__ */ new Set(), result = [];
  for (const distance3 of distances) {
    const site = { x: Math.round((from.x + distance3 * dx / length2) / snapStep) * snapStep, y: Math.round((from.y + distance3 * dy / length2) / snapStep) * snapStep }, key = `${site.x}:${site.y}`;
    if (site.x === from.x && site.y === from.y || seen.has(key)) continue;
    seen.add(key);
    result.push(site);
  }
  return result;
}
var pointOrder = (a, b) => a.y - b.y || a.x - b.x;
function targetEnvelope(kind, points, limit, oldDeepLabelsTouched) {
  const centre = { x: (Math.min(...points.map((p) => p.x)) + Math.max(...points.map((p) => p.x))) / 2, y: (Math.min(...points.map((p) => p.y)) + Math.max(...points.map((p) => p.y))) / 2 };
  const radius = Math.max(...points.map((p) => Math.hypot(p.x - centre.x, p.y - centre.y)));
  return { kind, points, centre, radius, limit, envelopeRadius: limit - radius, ...limit <= radius ? { unavailableReason: "nonpositive-target-envelope" } : {}, ...oldDeepLabelsTouched === void 0 ? {} : { oldDeepLabelsTouched } };
}
function createNativeSpatialJointTargetSelector(field, baseFieldCount, cellSize, oldDistances, coverLimit, deepLimit) {
  if (!Number.isInteger(baseFieldCount) || baseFieldCount < 0 || baseFieldCount > field.length || oldDistances.length !== field.length || !Number.isFinite(cellSize) || cellSize <= 0 || ![coverLimit, deepLimit].every((n) => Number.isFinite(n) && n > 0)) throw new Error("Invalid joint witness field");
  const points = field.slice(0, baseFieldCount), cols = Math.max(1, ...points.map((p) => Math.floor(p.x / cellSize) + 1)), rows = Math.max(1, ...points.map((p) => Math.floor(p.y / cellSize) + 1));
  const indexByCell = new Int32Array(cols * rows).fill(-1), cells = points.map((p, index) => {
    const cell = Math.floor(p.y / cellSize) * cols + Math.floor(p.x / cellSize);
    if (indexByCell[cell] !== -1) throw new Error("Duplicate joint witness base cell");
    indexByCell[cell] = index;
    return cell;
  });
  const neighbours = points.map((_, index) => {
    const cell = cells[index], x = cell % cols, y = Math.floor(cell / cols), adjacent = [];
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
      if (!dx && !dy) continue;
      const xx = x + dx, yy = y + dy;
      if (xx < 0 || yy < 0 || xx >= cols || yy >= rows) continue;
      const next = indexByCell[yy * cols + xx];
      if (next < 0 || dx && dy && (indexByCell[y * cols + xx] === -1 || indexByCell[yy * cols + x] === -1)) continue;
      adjacent.push(next);
    }
    return adjacent;
  });
  const components2 = (mask) => {
    const labels = new Int32Array(baseFieldCount).fill(-1), groups = [];
    for (let i = 0; i < baseFieldCount; i++) if (mask[i] && labels[i] === -1) {
      const group = [i], label = groups.length;
      labels[i] = label;
      for (let head = 0; head < group.length; head++) for (const next of neighbours[group[head]]) if (mask[next] && labels[next] === -1) {
        labels[next] = label;
        group.push(next);
      }
      groups.push(group);
    }
    return { labels, groups };
  };
  const old = components2(points.map((_, i) => oldDistances[i] > deepLimit));
  return (next) => {
    if (next.length !== field.length) throw new Error("Incomplete joint witness distances");
    const gained = components2(points.map((_, i) => oldDistances[i] <= deepLimit && next[i] > deepLimit));
    const candidates = gained.groups.map((indices) => {
      const touched = /* @__PURE__ */ new Set();
      for (const index of indices) for (const other of neighbours[index]) if (old.labels[other] >= 0) touched.add(old.labels[other]);
      const gainOrder = (a, b) => next[b] - oldDistances[b] - (next[a] - oldDistances[a]) || pointOrder(points[a], points[b]);
      const p1 = [...indices].sort(gainOrder)[0], p2 = [...indices].sort((a, b) => Math.hypot(points[b].x - points[p1].x, points[b].y - points[p1].y) - Math.hypot(points[a].x - points[p1].x, points[a].y - points[p1].y) || pointOrder(points[a], points[b]))[0];
      const minimum = [...indices].sort((a, b) => pointOrder(points[a], points[b]))[0];
      return { indices, touched: touched.size, gain: next[p1] - oldDistances[p1], minimum: points[minimum], representatives: p1 === p2 ? [points[p1]] : [points[p1], points[p2]] };
    }).sort((a, b) => Number(b.touched >= 2) - Number(a.touched >= 2) || b.gain - a.gain || pointOrder(a.minimum, b.minimum));
    let coverIndex = -1, coverGain = -Infinity;
    for (let i = 0; i < field.length; i++) if (next[i] > oldDistances[i] && next[i] > coverLimit) {
      const gain = Math.max(0, next[i] - coverLimit) - Math.max(0, oldDistances[i] - coverLimit);
      if (gain > coverGain || gain === coverGain && (next[i] > next[coverIndex] || next[i] === next[coverIndex] && pointOrder(field[i], field[coverIndex]) < 0)) {
        coverIndex = i;
        coverGain = gain;
      }
    }
    const selected = candidates[0];
    return {
      newDeepPointCount: gained.groups.reduce((sum, group) => sum + group.length, 0),
      newDeepComponentCount: gained.groups.length,
      ...selected ? { deep: targetEnvelope("deep", selected.representatives, deepLimit, selected.touched) } : {},
      ...coverIndex < 0 ? {} : { cover: targetEnvelope("cover", [field[coverIndex]], coverLimit) }
    };
  };
}
function nativeSpatialJointAnalyticMove(object2, target, snapStep) {
  if (!Number.isFinite(snapStep) || snapStep <= 0) throw new Error("Invalid joint alignment step");
  if (target.envelopeRadius <= 0) return void 0;
  const q = { x: target.centre.x - object2.site.x, y: target.centre.y - object2.site.y };
  if (nativePrimitiveDistance(nativePrimitiveTree(object2.blocking), q.x, q.y) <= target.envelopeRadius) return void 0;
  let squared = Infinity, z;
  for (const primitive of object2.blocking) for (let i = 0; i < primitive.points.length; i += 2) {
    const j = (i + 2) % primitive.points.length, ax = primitive.points[i], ay = primitive.points[i + 1], dx2 = primitive.points[j] - ax, dy2 = primitive.points[j + 1] - ay;
    const length2 = dx2 * dx2 + dy2 * dy2, t = length2 ? Math.max(0, Math.min(1, ((q.x - ax) * dx2 + (q.y - ay) * dy2) / length2)) : 0, p = { x: ax + t * dx2, y: ay + t * dy2 }, d = (p.x - q.x) ** 2 + (p.y - q.y) ** 2;
    if (d < squared || d === squared && (!z || pointOrder(p, z) < 0)) {
      squared = d;
      z = p;
    }
  }
  if (!z || !Number.isFinite(squared)) return void 0;
  const distance3 = Math.sqrt(squared), requiredTranslation = distance3 - target.envelopeRadius, dx = (q.x - z.x) / distance3, dy = (q.y - z.y) / distance3;
  const t0 = requiredTranslation + snapStep / Math.SQRT2, moves = [t0, t0 + snapStep].map((translation) => ({ translation, site: { x: Math.round((object2.site.x + translation * dx) / snapStep) * snapStep, y: Math.round((object2.site.y + translation * dy) / snapStep) * snapStep } }));
  return { nearestPoint: { x: z.x + object2.site.x, y: z.y + object2.site.y }, distance: distance3, requiredTranslation, moves };
}
function refineNativeSpatialJointObjects(context) {
  const { objects, field, ground, gapPx, witness, snapStep } = context, before = context.evaluate([]), trees = objects.map((o) => nativePrimitiveTree(o.blocking));
  const distance3 = (index, point, site = objects[index].site) => nativePrimitiveDistance(trees[index], point.x - site.x, point.y - site.y);
  const objectDistances = objects.map((_, i) => field.map((p) => distance3(i, p))), baseDistances = field.map((_, p) => Math.min(...objectDistances.map((d) => d[p])));
  const selectTargets = createNativeSpatialJointTargetSelector(field, context.baseFieldCount, context.baseFieldCellPx, baseDistances, context.coverPlanningLimit, context.deepPlanningLimit);
  const first = objects.map((o, index) => ({ index, id: o.id, d: distance3(index, witness) })).sort((a, b) => a.d - b.d || a.id.localeCompare(b.id)).slice(0, 3);
  const completeStates = /* @__PURE__ */ new Set(), pairs = /* @__PURE__ */ new Set(), siteTraces = [], trials = [];
  let best = before, selected = [], precheckCount = 0;
  const cap = Math.min(48, 12 * objects.length);
  for (const primary of first) {
    const a = primary.index, object2 = objects[a], remaining = field.map((_, p) => Math.min(...objectDistances.flatMap((d, i) => i === a ? [] : [d[p]])));
    for (const as of directedSites(object2.site, witness, [16, 32, 64, 96], snapStep)) {
      const empty = { targetsComputed: false, newDeepPointCount: 0, newDeepComponentCount: 0, primaryId: object2.id, site: as, blockerIds: [], prechecks: [] };
      if (!supported(object2, as, ground)) {
        siteTraces.push({ ...empty, skippedReason: "primary-ground-support" });
        continue;
      }
      const blockers = objects.flatMap((other, index) => index !== a && conflict(object2, as, other, other.site, gapPx) ? [index] : []).sort((i, j) => objects[i].id.localeCompare(objects[j].id));
      if (blockers.length > 1) {
        siteTraces.push({ ...empty, blockerIds: blockers.map((i) => objects[i].id), skippedReason: "multiple-blockers" });
        continue;
      }
      const next = field.map((p, i) => Math.min(remaining[i], distance3(a, p, as))), targets = selectTargets(next), prechecks = [];
      siteTraces.push({ ...targets, targetsComputed: true, primaryId: object2.id, site: as, blockerIds: blockers.map((i) => objects[i].id), prechecks });
      const partnerMoves = (target) => !target ? [] : objects.flatMap((other, index) => {
        if (index === a || blockers.length && index !== blockers[0]) return [];
        const move = nativeSpatialJointAnalyticMove(other, target, snapStep);
        return move ? [{ index, id: other.id, ...move }] : [];
      }).sort((left, right) => left.requiredTranslation - right.requiredTranslation || left.id.localeCompare(right.id)).slice(0, 3);
      const deep = partnerMoves(targets.deep), cover = partnerMoves(targets.cover);
      for (let slot = 0; slot < 4; slot++) {
        if (trials.length >= cap) break;
        const release = slot === 3 && blockers.length === 1, target = slot < 2 ? targets.deep : targets.cover;
        const name = release ? "release" : ["deep-t0", "deep-t1", "cover-t0", "cover-t1"][slot];
        const candidates = release ? [{ index: blockers[0], id: objects[blockers[0]].id, move: { site: { x: objects[blockers[0]].site.x + as.x - object2.site.x, y: objects[blockers[0]].site.y + as.y - object2.site.y } }, analytic: void 0 }] : (slot < 2 ? deep : cover).map((analytic) => ({ index: analytic.index, id: analytic.id, move: analytic.moves[slot % 2], analytic }));
        for (const candidate of candidates) {
          const entries = [{ index: a, site: as }, { index: candidate.index, site: candidate.move.site }], reasons = [];
          if (++precheckCount > 144) throw new Error("Joint precheck budget exceeded");
          if (!release && target.points.some((p) => distance3(candidate.index, p, candidate.move.site) > target.limit)) reasons.push("target-coverage");
          if (!reasons.length) reasons.push(...nativeSpatialPlacementRejections(objects, entries, ground, gapPx));
          const key = entries.map((entry) => `${objects[entry.index].id}@${entry.site.x},${entry.site.y}`).sort().join("|"), duplicate = !reasons.length && completeStates.has(key);
          if (duplicate) reasons.push("duplicate-complete-state");
          prechecks.push({ slot: name, partnerId: candidate.id, site: candidate.move.site, ...candidate.analytic ? { distance: candidate.analytic.distance, nearestPoint: candidate.analytic.nearestPoint, requiredTranslation: candidate.analytic.requiredTranslation, translation: candidate.move.translation } : {}, reasons });
          if (duplicate) break;
          if (reasons.length) continue;
          completeStates.add(key);
          pairs.add(`${object2.id}:${candidate.id}`);
          const score = context.evaluate(entries);
          trials.push({ ids: [object2.id, candidate.id], entries, cause: blockers.length ? "blocker" : "coverage", lossPoint: release ? null : target.points[0], legal: true, score, slot: name, ...!release ? { target } : {} });
          if (nativeSpatialConstraintsImproved(before, score) && compareNativeSpatialConstraintScores(score, best) < 0) {
            best = score;
            selected = entries;
          }
          break;
        }
      }
    }
  }
  return { entries: selected, before, after: best, pairCount: pairs.size, primaryCount: first.length, precheckCount, sites: siteTraces, trialCount: trials.length, evaluatedCount: trials.length, trials };
}

// src/utils/grid-raycast.ts
function createRayHit() {
  return { x: 0, y: 0, dist: 0, hit: false };
}
var CORNER_MARGIN = 1;
var losScratch = createRayHit();
function castRayDirection(grid, originX, originY, dirX, dirY, maxDist, out) {
  const tileSize = grid.tileSize;
  let col = Math.floor(originX / tileSize);
  let row = Math.floor(originY / tileSize);
  if (grid.isOpaque(col, row)) {
    out.x = originX;
    out.y = originY;
    out.dist = 0;
    out.hit = true;
    return out;
  }
  const stepCol = dirX > 0 ? 1 : dirX < 0 ? -1 : 0;
  const stepRow = dirY > 0 ? 1 : dirY < 0 ? -1 : 0;
  const invX = stepCol !== 0 ? 1 / Math.abs(dirX) : Infinity;
  const invY = stepRow !== 0 ? 1 / Math.abs(dirY) : Infinity;
  const deltaX = tileSize * invX;
  const deltaY = tileSize * invY;
  let nextX = stepCol > 0 ? ((col + 1) * tileSize - originX) * invX : stepCol < 0 ? (originX - col * tileSize) * invX : Infinity;
  let nextY = stepRow > 0 ? ((row + 1) * tileSize - originY) * invY : stepRow < 0 ? (originY - row * tileSize) * invY : Infinity;
  const maxSteps = grid.cols + grid.rows + 2;
  for (let step2 = 0; step2 < maxSteps; step2++) {
    const throughVertex = stepCol !== 0 && stepRow !== 0 && Math.abs(nextX - nextY) <= CORNER_MARGIN;
    if (throughVertex) {
      const dist2 = nextX < nextY ? nextX : nextY;
      if (dist2 > maxDist) break;
      if (grid.isOpaque(col + stepCol, row) && grid.isOpaque(col, row + stepRow)) {
        return writeHit(out, originX, originY, dirX, dirY, dist2, true);
      }
      col += stepCol;
      row += stepRow;
      nextX += deltaX;
      nextY += deltaY;
      if (grid.isOpaque(col, row)) {
        return writeHit(out, originX, originY, dirX, dirY, dist2, true);
      }
      continue;
    }
    let dist;
    if (nextX < nextY) {
      dist = nextX;
      if (dist > maxDist) break;
      col += stepCol;
      nextX += deltaX;
    } else {
      dist = nextY;
      if (dist > maxDist) break;
      row += stepRow;
      nextY += deltaY;
    }
    if (grid.isOpaque(col, row)) {
      return writeHit(out, originX, originY, dirX, dirY, dist, true);
    }
  }
  return writeHit(out, originX, originY, dirX, dirY, maxDist, false);
}
function hasLineOfSight(grid, from, to, maxDist) {
  const deltaX = to.x - from.x;
  const deltaY = to.y - from.y;
  const length2 = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
  if (length2 < 1e-6) {
    return !grid.isOpaque(Math.floor(from.x / grid.tileSize), Math.floor(from.y / grid.tileSize));
  }
  if (maxDist !== void 0 && length2 > maxDist) return false;
  castRayDirection(grid, from.x, from.y, deltaX / length2, deltaY / length2, length2, losScratch);
  return !losScratch.hit || losScratch.dist >= length2 - 1e-3;
}
function writeHit(out, originX, originY, dirX, dirY, dist, hit) {
  out.x = originX + dirX * dist;
  out.y = originY + dirY * dist;
  out.dist = dist;
  out.hit = hit;
  return out;
}

// src/generation/world-study/native-spatial-visibility.ts
function nativeSpatialShortestPaths(geometry, starts, limitPx = Infinity) {
  const count = geometry.reachable.length, cols = geometry.terrain.cols, distance3 = new Float64Array(count), parent = new Int32Array(count);
  distance3.fill(Infinity);
  parent.fill(-1);
  const heap = [], visited = [];
  const before = (a, b) => a.cost < b.cost || a.cost === b.cost && a.cell < b.cell;
  function push(cell, cost) {
    const value = { cell, cost };
    let at = heap.length;
    heap.push(value);
    while (at > 0) {
      const up = at - 1 >> 1;
      if (!before(value, heap[up])) break;
      heap[at] = heap[up];
      at = up;
    }
    heap[at] = value;
  }
  function pop() {
    const first = heap[0], last = heap.pop();
    if (heap.length) {
      let at = 0;
      while (at * 2 + 1 < heap.length) {
        let next = at * 2 + 1;
        if (next + 1 < heap.length && before(heap[next + 1], heap[next])) next++;
        if (!before(heap[next], last)) break;
        heap[at] = heap[next];
        at = next;
      }
      heap[at] = last;
    }
    return first;
  }
  for (const cell of [...new Set(starts)].sort((a, b) => a - b)) if (geometry.reachable[cell]) {
    distance3[cell] = 0;
    push(cell, 0);
  }
  while (heap.length) {
    const item = pop(), cell = item.cell;
    if (item.cost !== distance3[cell]) continue;
    visited.push(cell);
    for (let direction = 0; direction < 8; direction++) if (geometry.links8[cell] & 1 << direction) {
      const [dx, dy] = NATIVE_SPATIAL_DIRECTIONS[direction], next = cell + dx + dy * cols, cost = item.cost + NATIVE_SPATIAL_EDGE_COSTS[direction];
      if (!geometry.reachable[next] || cost > limitPx * 1e3) continue;
      if (cost < distance3[next]) {
        distance3[next] = cost;
        parent[next] = cell;
        push(next, cost);
      } else if (cost === distance3[next] && (parent[next] === -1 || cell < parent[next])) parent[next] = cell;
    }
  }
  return { distance: distance3, parent, visited };
}
function evaluateNativeSpatialVisibility(geometry, structures, policy) {
  const { cols, rows } = geometry.terrain, stride = policy.probeStepPx / 8;
  if (!Number.isInteger(stride) || stride < 1) throw new Error("Native spatial probe step must align with support cells");
  const probes = [];
  for (let row = 0; row < rows; row += stride) for (let col = 0; col < cols; col += stride) {
    const cell = row * cols + col;
    if (geometry.reachable[cell]) probes.push(cell);
  }
  const qUnion = /* @__PURE__ */ new Set(), holeReports = [], reasons = [];
  const maxQT = policy.referenceSightPx;
  for (const hole of structures.filter((item) => item.kind === "hole").sort((a, b) => a.id.localeCompare(b.id))) {
    const removed = new Set(hole.cells), ablated = { ...geometry.sight, isOpaque: (col, row) => col < 0 || row < 0 || col >= cols || row >= rows || !removed.has(row * cols + col) && geometry.sight.isOpaque(col, row) };
    const witnesses2 = [], failureCounts = { outsideWitnessBound: 0, noAttributedTarget: 0, noReachableReveal: 0 };
    let testedQ = 0;
    for (const q of probes) {
      const qp = nativeCellPoint(q, cols);
      if (hole.distance(qp) > maxQT) {
        failureCounts.outsideWitnessBound++;
        continue;
      }
      testedQ++;
      const targets = [];
      for (const [dx, dy] of NATIVE_SPATIAL_DIRECTIONS) for (let radius = stride; Math.hypot(dx * radius, dy * radius) * 8 <= maxQT; radius += stride) {
        const col = q % cols + dx * radius, row = Math.floor(q / cols) + dy * radius, t = row * cols + col;
        if (col < 0 || row < 0 || col >= cols || row >= rows || !geometry.reachable[t]) continue;
        const tp = nativeCellPoint(t, cols);
        if (!hasLineOfSight(geometry.sight, qp, tp) && hasLineOfSight(ablated, qp, tp)) targets.push(t);
      }
      if (!targets.length) {
        failureCounts.noAttributedTarget++;
        continue;
      }
      const paths = nativeSpatialShortestPaths(geometry, [q], policy.revealRouteMaxPx);
      const reveals = paths.visited.filter((v) => paths.distance[v] >= policy.revealRouteMinPx * 1e3 && v % cols % stride === 0 && Math.floor(v / cols) % stride === 0);
      let witness;
      for (const t of targets) {
        const tp = nativeCellPoint(t, cols);
        for (const v of reveals) {
          const vp = nativeCellPoint(v, cols), length2 = Math.hypot(vp.x - tp.x, vp.y - tp.y);
          if (length2 <= policy.referenceSightPx && hasLineOfSight(geometry.sight, vp, tp)) {
            witness = { q, v, t, routePx: paths.distance[v] / 1e3, sightPx: length2 };
            break;
          }
        }
        if (witness) break;
      }
      if (witness) {
        witnesses2.push(witness);
        qUnion.add(q);
      } else failureCounts.noReachableReveal++;
    }
    if (!witnesses2.length) reasons.push(`hole:${hole.id}:no-witness-in-frozen-probes`);
    holeReports.push({ id: hole.id, testedQ, witnesses: witnesses2, failureCounts });
  }
  const qCells = [...qUnion].sort((a, b) => a - b), coverage = nativeSpatialShortestPaths(geometry, qCells);
  let maxPx = 0, overLimit = 0, unreachable = 0, worstCell = -1;
  for (let cell = 0; cell < geometry.reachable.length; cell++) if (geometry.reachable[cell]) {
    const d = coverage.distance[cell] / 1e3;
    if (!Number.isFinite(d)) unreachable++;
    if (d > maxPx) {
      maxPx = d;
      worstCell = cell;
    }
    if (d > policy.maxCoverRoutePx) overLimit++;
  }
  if (!qCells.length) reasons.push("no-attributed-cover-positions");
  if (overLimit) reasons.push("body-route-to-cover-exceeds-limit");
  return { accepted: reasons.length === 0, reasons, metrics: { algorithm: "native-spatial-v1", probeStepPx: policy.probeStepPx, probeOriginPx: [4, 4], targetEnumeration: "E,S,W,N,SE,SW,NW,NE; increasing 32px grid offsets; |qt| <= referenceSightPx", revealOrder: "shortest integer route then y,x", qProbeCount: probes.length, qCells, holes: holeReports, coverage: { maxRoutePx: Number.isFinite(maxPx) ? maxPx : null, worstCell, overLimit, unreachable, checkedBodyCenters: geometry.reachableCount }, scope: "All passing q in the frozen sampling domain; v/t do not contribute coverage. No-witness is a sampling failure, not proof that continuous space has no cover." } };
}

// src/generation/world-study/native-spatial-routes.ts
function classifyNativeRouteHoleShare(holes, total, policy) {
  const { minRouteHoleShare: min, maxRouteHoleShare: max, holeToSolidRatio: ratio } = policy;
  if (!Number.isSafeInteger(holes) || !Number.isSafeInteger(total) || total <= 0 || holes < 0 || holes > total || !Number.isFinite(min) || !Number.isFinite(max) || min < 0 || min > max || max > 1 || !Number.isSafeInteger(ratio) || ratio <= 0 || !Number.isSafeInteger(ratio + 1) || !Number.isSafeInteger(ratio * total))
    throw new Error("Invalid native route hole-share count or frozen cycle");
  const share = holes / total, continuousAccepted = share >= min && share <= max, ideal = ratio * total / (ratio + 1);
  const phaseAccepted = holes >= Math.floor(ideal) && holes <= Math.ceil(ideal);
  return { accepted: continuousAccepted || phaseAccepted, continuousAccepted, phaseAccepted, basis: continuousAccepted ? "continuous-band" : phaseAccepted ? "periodic-phase" : "outside" };
}
var distance2 = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
var cellAt = (p, cols) => Math.floor(p.y / 8) * cols + Math.floor(p.x / 8);
function project(p, ax, ay, bx, by) {
  const dx = bx - ax, dy = by - ay, n = dx * dx + dy * dy, t = n ? Math.max(0, Math.min(1, ((p.x - ax) * dx + (p.y - ay) * dy) / n)) : 0;
  return { x: ax + t * dx, y: ay + t * dy };
}
function edges(p) {
  const a = p.points;
  return a.length === 4 ? [a] : [[a[0], a[1], a[2], a[3]], [a[2], a[3], a[4], a[5]], [a[4], a[5], a[0], a[1]]];
}
function encounters(p, structure, geometry, radius) {
  if (structure.distance(p) > radius) return false;
  for (const primitive of structure.boundary) {
    if (Math.max(primitive.minX - p.x, 0, p.x - primitive.maxX) ** 2 + Math.max(primitive.minY - p.y, 0, p.y - primitive.maxY) ** 2 > radius * radius) continue;
    for (const [ax, ay, bx, by] of edges(primitive)) {
      const near = project(p, ax, ay, bx, by), length2 = distance2(p, near);
      if (length2 > radius || length2 < 1e-7) continue;
      const facing = { x: near.x + (p.x - near.x) / length2 * 0.5, y: near.y + (p.y - near.y) / length2 * 0.5 };
      if (!geometry.sight.isOpaque(Math.floor(facing.x / 8), Math.floor(facing.y / 8)) && (structure.kind !== "solid" || geometry.solidDistance(facing) > 1e-7) && hasLineOfSight(geometry.sight, p, facing)) return true;
    }
  }
  return false;
}
function eventBodyEdge(point, at, cells, cols) {
  if (at === 0 || cells.length < 2) return `vertex:${cells[0]}`;
  let best = Infinity, key = "";
  for (let i = 1; i < cells.length; i++) {
    const a = cells[i - 1], b = cells[i], pa = nativeCellPoint(a, cols), pb = nativeCellPoint(b, cols);
    const nearest = project(point, pa.x, pa.y, pb.x, pb.y), d = (nearest.x - point.x) ** 2 + (nearest.y - point.y) ** 2;
    if (d < best) {
      best = d;
      key = a < b ? `${a}:${b}` : `${b}:${a}`;
    }
  }
  return key;
}
function rawPath(target, parent) {
  const result = [];
  let cell = target;
  while (cell >= 0) {
    result.push(cell);
    cell = parent[cell];
  }
  return result.reverse();
}
function smooth(cells, geometry) {
  if (!cells.length) return [];
  const points = cells.map((cell) => nativeCellPoint(cell, geometry.terrain.cols)), result = [points[0]];
  let from = 0;
  while (from < points.length - 1) {
    let to = points.length - 1;
    for (; to > from + 1; to--) {
      const a = points[from], b = points[to];
      if (geometry.collision.displacementFraction(a, 10, 10, b.x - a.x, b.y - a.y) >= 1 - 1e-9) break;
    }
    result.push(points[to]);
    from = to;
  }
  return result;
}
function samplePath(points) {
  const offsets = [0];
  for (let i = 1; i < points.length; i++) offsets.push(offsets[i - 1] + distance2(points[i - 1], points[i]));
  const length2 = offsets[offsets.length - 1] ?? 0;
  const at = (d) => {
    d = Math.max(0, Math.min(length2, d));
    let i = 1;
    while (i < offsets.length && offsets[i] < d) i++;
    if (i === offsets.length) return { ...points[points.length - 1] };
    const a = points[i - 1], b = points[i], span = offsets[i] - offsets[i - 1], t = span ? (d - offsets[i - 1]) / span : 0;
    return { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t };
  };
  const samples = [];
  for (let d = 0; d < length2; d += 8) samples.push({ point: at(d), at: d, span: Math.min(8, length2 - d) });
  if (!samples.length && points.length) samples.push({ point: { ...points[0] }, at: 0, span: 0 });
  return { samples, length: length2, at };
}
function solidRay(root, p, dx, dy, limit) {
  let best = limit;
  function visit(node) {
    let lo = 0, hi = best;
    for (const [v, d, min, max] of [[p.x, dx, node.minX, node.maxX], [p.y, dy, node.minY, node.maxY]]) {
      if (Math.abs(d) < 1e-10) {
        if (v < min || v > max) return;
      } else {
        let a = (min - v) / d, b = (max - v) / d;
        if (a > b) [a, b] = [b, a];
        lo = Math.max(lo, a);
        hi = Math.min(hi, b);
        if (lo > hi) return;
      }
    }
    if (node.items) {
      for (const primitive of node.items) for (const [ax, ay, bx, by] of edges(primitive)) {
        const ex = bx - ax, ey = by - ay, den = dx * ey - dy * ex;
        if (Math.abs(den) < 1e-9) continue;
        const rx = ax - p.x, ry = ay - p.y, t = (rx * ey - ry * ex) / den, u = (rx * dy - ry * dx) / den;
        if (t >= 0 && t < best && u >= 0 && u <= 1) best = t;
      }
      return;
    }
    visit(node.left);
    visit(node.right);
  }
  visit(root);
  return best;
}
function crossSections(points, geometry, solidTree, policy) {
  const path = samplePath(points), records2 = [], hit = createRayHit();
  let narrowPx = 0, uncertainPx = 0, run = 0, maxRun = 0;
  for (const sample of path.samples) {
    const p = sample.point, a = path.at(sample.at - 32), b = path.at(sample.at + 32), inX = p.x - a.x, inY = p.y - a.y, outX = b.x - p.x, outY = b.y - p.y, inLength = Math.hypot(inX, inY), outLength = Math.hypot(outX, outY), axisX = b.x - a.x, axisY = b.y - a.y, axisLength = Math.hypot(axisX, axisY);
    const turn = inLength > 1e-7 && outLength > 1e-7 ? (inX * outX + inY * outY) / (inLength * outLength) : 1;
    if (axisLength < 1e-7 || turn < 0.5) {
      uncertainPx += sample.span;
      run += sample.span;
      maxRun = Math.max(maxRun, run);
      records2.push({ at: sample.at, kind: "uncertain-turn", span: sample.span });
      continue;
    }
    const nx = -axisY / axisLength, ny = axisX / axisLength, sides = [];
    for (const sign of [-1, 1]) {
      castRayDirection(geometry.sight, p.x, p.y, nx * sign, ny * sign, policy.referenceSightPx, hit);
      sides.push(Math.min(hit.dist, solidRay(solidTree, p, nx * sign, ny * sign, policy.referenceSightPx)));
    }
    const width = sides[0] + sides[1], clipped = sides.some((d) => d >= policy.referenceSightPx - 1e-7), narrow = width < policy.narrowWidthPx;
    if (narrow) {
      narrowPx += sample.span;
      run += sample.span;
    } else run = 0;
    maxRun = Math.max(maxRun, run);
    records2.push({ at: sample.at, widthLowerPx: width, closed: !clipped, kind: narrow ? "narrow" : "wide", sides });
  }
  return { lengthPx: path.length, narrowPx, narrowRatio: path.length ? narrowPx / path.length : 0, maxNarrowOrUncertainRunPx: maxRun, uncertainPx, sections: records2, accepted: (path.length ? narrowPx / path.length : 0) <= policy.maxNarrowRatio && maxRun <= policy.maxNarrowRunPx };
}
function evaluateNativeSpatialRoutes(geometry, structures, policy, layout) {
  const { cols } = geometry.terrain, start = cellAt(layout.spawnPoint, cols), exit = cellAt(layout.extractionPoint.position, cols), reasons = [];
  if (!geometry.reachable[start] || !geometry.reachable[exit]) return { accepted: false, reasons: ["route-endpoint-outside-body-domain"], metrics: { start, exit } };
  const fromSpawn = nativeSpatialShortestPaths(geometry, [start]), fromExit = nativeSpatialShortestPaths(geometry, [exit]);
  const ordered = [...structures].sort((a, b) => a.id.localeCompare(b.id)), solidTree = nativePrimitiveTree(geometry.solidPrimitives), reachable = [];
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (let cell = 0; cell < geometry.reachable.length; cell++) if (geometry.reachable[cell]) {
    reachable.push(cell);
    const p = nativeCellPoint(cell, cols);
    minX = Math.min(minX, p.x);
    minY = Math.min(minY, p.y);
    maxX = Math.max(maxX, p.x);
    maxY = Math.max(maxY, p.y);
  }
  const regionOf = (p) => Math.min(2, Math.floor((p.y - minY) / Math.max(1, maxY - minY + 8) * 3)) * 4 + Math.min(3, Math.floor((p.x - minX) / Math.max(1, maxX - minX + 8) * 4));
  const regions = Array.from({ length: 12 }, () => []);
  for (const cell of reachable) regions[regionOf(nativeCellPoint(cell, cols))].push(cell);
  const routes = [{ id: "direct-exit", target: exit, kind: "exit", cells: rawPath(exit, fromSpawn.parent), legs: [rawPath(exit, fromSpawn.parent)] }];
  function add(id, target, kind, interactionSeats) {
    const outward = rawPath(target, fromSpawn.parent), homeward = rawPath(target, fromExit.parent).reverse();
    routes.push({ id, target, kind, interactionSeats, cells: [...outward, ...homeward.slice(1)], legs: [outward, homeward] });
  }
  for (const node of [...layout.kindlingNodes, ...layout.contaminantNodes].sort((a, b) => a.id.localeCompare(b.id))) {
    let target = -1, cost = Infinity, seats = 0;
    const radius = GAME_CONSTANTS.LOOT.SEARCH_RADIUS;
    for (const cell of reachable) {
      const p = nativeCellPoint(cell, cols);
      if (distance2(p, node.position) > radius || !hasLineOfSight(geometry.sight, p, node.position, radius + 1e-3)) continue;
      seats++;
      const value = fromSpawn.distance[cell] + fromExit.distance[cell];
      if (value < cost || value === cost && cell < target) {
        cost = value;
        target = cell;
      }
    }
    if (target < 0) reasons.push(`node:${node.id}:no-legal-interaction-seat`);
    else add(`node:${node.id}`, target, "search", seats);
  }
  regions.forEach((cells, index) => {
    if (!cells.length) return;
    let x = 0, y = 0;
    for (const cell of cells) {
      const p = nativeCellPoint(cell, cols);
      x += p.x;
      y += p.y;
    }
    const center = { x: x / cells.length, y: y / cells.length };
    let best = cells[0], d = Infinity;
    for (const cell of cells) {
      const candidate = distance2(nativeCellPoint(cell, cols), center);
      if (candidate < d) {
        d = candidate;
        best = cell;
      }
    }
    add(`explore:${index}`, best, "explore");
  });
  const results = [], uniqueEdges = /* @__PURE__ */ new Map();
  const firstEvents = [];
  let sufficient = 0;
  for (const route of routes) {
    for (let i = 1; i < route.cells.length; i++) {
      const a = route.cells[i - 1], b = route.cells[i], key = a < b ? `${a}:${b}` : `${b}:${a}`;
      if (!uniqueEdges.has(key)) uniqueEdges.set(key, [a, b]);
    }
    const legPaths = route.legs.map((leg) => smooth(leg, geometry)), points = legPaths.flatMap((leg, i) => i ? leg.slice(1) : leg), path = samplePath(points), seen = /* @__PURE__ */ new Set(), events = [];
    for (const sample of path.samples) for (const structure of ordered) if (!seen.has(structure.id) && encounters(sample.point, structure, geometry, policy.encounterRadiusPx)) {
      seen.add(structure.id);
      const event = { id: structure.id, kind: structure.kind, at: sample.at, region: regionOf(sample.point), bodyEdge: eventBodyEdge(sample.point, sample.at, route.cells, cols) };
      events.push(event);
      firstEvents.push({ ...event, routeId: route.id });
    }
    const holes = events.filter((event) => event.kind === "hole").length, eligible = path.length >= policy.minRouteLengthPx && events.length >= policy.minRouteEncounters, share = events.length ? holes / events.length : null, windowFailures = [];
    const holeShareAdmission = eligible ? classifyNativeRouteHoleShare(holes, events.length, policy) : null;
    if (eligible) {
      sufficient++;
      if (!holeShareAdmission.accepted) reasons.push(`${route.id}:hole-share`);
      for (let i = 0; i + policy.windowSize <= events.length; i++) if (events.slice(i, i + policy.windowSize).filter((e) => e.kind === "hole").length < policy.minWindowHoles) windowFailures.push(i);
      if (windowFailures.length) reasons.push(`${route.id}:six-encounter-window`);
    }
    const sections = crossSections(points, geometry, solidTree, policy);
    if (!sections.accepted) reasons.push(`${route.id}:narrow-transverse-opening`);
    const legs = legPaths.map((leg) => {
      const sampled = samplePath(leg), identities = /* @__PURE__ */ new Set();
      for (const point of sampled.samples) for (const structure of ordered) if (!identities.has(structure.id) && encounters(point.point, structure, geometry, policy.encounterRadiusPx)) identities.add(structure.id);
      return { lengthPx: sampled.length, encounters: [...identities], diagnosticOnly: true, short: sampled.length < policy.minRouteLengthPx };
    });
    results.push({ id: route.id, kind: route.kind, target: route.target, interactionSeats: route.interactionSeats, cells: route.cells, smoothedPoints: points, lengthPx: path.length, events, holeShare: share, holeShareAdmission, eligible, windowFailures, legs, transverse: sections });
  }
  const regional = Array.from({ length: 12 }, () => /* @__PURE__ */ new Map()), sharedTrunkEvents = /* @__PURE__ */ new Set();
  const regionalEvents = [];
  let repeatedTrunkEvents = 0, repeatedRegionEvents = 0;
  for (const event of firstEvents) {
    const trunkKey = `${event.bodyEdge}|${event.id}`;
    if (sharedTrunkEvents.has(trunkKey)) {
      repeatedTrunkEvents++;
      continue;
    }
    sharedTrunkEvents.add(trunkKey);
    if (regional[event.region].has(event.id)) {
      repeatedRegionEvents++;
      continue;
    }
    regional[event.region].set(event.id, event.kind);
    regionalEvents.push(event);
  }
  const regionReports = regional.map((identities, id) => {
    const holes = [...identities.values()].filter((k) => k === "hole").length;
    return { id, structures: [...identities.keys()], holes, solids: identities.size - holes, eligible: identities.size >= policy.minRouteEncounters, holeShare: identities.size ? holes / identities.size : null };
  });
  const eligibleRegions = regionReports.filter((row) => row.eligible);
  if (!sufficient) reasons.push("insufficient-complete-route-encounter-evidence");
  return { accepted: reasons.length === 0, reasons, metrics: { algorithm: "native-spatial-v1", pathOrder: "direct exit; node ID; 4x3 region row/column", pathTie: "integer 8-neighbour cost then y,x; equal parent y,x", interactionChoice: "minimum complete spawn-seat-exit graph distance among every legal 48px LOS seat; y,x ties", smoothing: "per leg, greedy farthest feasible 20px swept-body segment", routes: results, qualifyingCompleteRoutes: sufficient, uniqueUndirectedEdges: uniqueEdges.size, regionalEventBasis: "first encounters on the same smoothed complete routes; shared body-edge + identity, then original event region + identity", regionalEvents, repeatedTrunkEvents, repeatedRegionEvents, regions: regionReports, excludedRegions: 12 - eligibleRegions.length, regionalMeanHoleShare: eligibleRegions.length ? eligibleRegions.reduce((sum, row) => sum + row.holeShare, 0) / eligibleRegions.length : null, regionalCalibrationOnly: true, shoreBays: "Excluded from H/S; no bays promoted to internal holes", transverseScope: "8px samples; +/-32px local axis; first actual VOID or solid boundary each side within224px; clipped widths are lower bounds; uncertain turns cannot reset a narrow run" } };
}

// src/generation/world-study/native-spatial-route-layout.ts
var LIMIT = 48;
var snap3 = (value) => Math.round(value / 8) * 8;
function routeDistance(point, path) {
  let minimum = Infinity;
  for (let i = 0; i < path.length; i++) {
    const a = path[i], b = path[i + 1] ?? a, dx = b.x - a.x, dy = b.y - a.y, n = dx * dx + dy * dy, t = n ? Math.max(0, Math.min(1, ((point.x - a.x) * dx + (point.y - a.y) * dy) / n)) : 0;
    minimum = Math.min(minimum, Math.hypot(point.x - a.x - t * dx, point.y - a.y - t * dy));
  }
  return minimum;
}
function excessKind(witness, policy) {
  if (witness.kind === "window") return "solid";
  if (witness.kind !== "hole-share" || !witness.events.length) return;
  const n = witness.events.length, h = witness.events.filter((e) => e.kind === "hole").length;
  let nearest = -1, distance3 = Infinity;
  for (let k = 0; k <= n; k++) if (classifyNativeRouteHoleShare(k, n, policy).accepted && Math.abs(k - h) < distance3) {
    nearest = k;
    distance3 = Math.abs(k - h);
  }
  return nearest < 0 || nearest === h ? void 0 : h > nearest ? "hole" : "solid";
}
function shareDeficit(holes, count, policy) {
  let distance3 = Infinity;
  for (let k = 0; k <= count; k++) if (classifyNativeRouteHoleShare(k, count, policy).accepted) distance3 = Math.min(distance3, Math.abs(k - holes));
  return Number.isFinite(distance3) ? distance3 / Math.max(1, count) : 0;
}
function footprintSize(object2) {
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const p of object2.support) {
    minX = Math.min(minX, p.minX);
    minY = Math.min(minY, p.minY);
    maxX = Math.max(maxX, p.maxX);
    maxY = Math.max(maxY, p.maxY);
  }
  return [maxX - minX, maxY - minY];
}
function selectNativeSpatialRoutePlacement(context) {
  const { objects, ground, policy, feedback, checkpoint } = context, ordinal = feedback.refinementOrdinal;
  if (!Number.isSafeInteger(ordinal) || ordinal < 0) throw new Error("Invalid native route refinement ordinal");
  const budget = feedback.remainingTupleBudget;
  if (!Number.isSafeInteger(budget) || budget < 0 || budget > LIMIT) throw new Error("Invalid native route remaining tuple budget");
  if (feedback.gate.accepted || !feedback.comparable) throw new Error("Native route refinement requires a comparable rejected actual probe");
  const byId = new Map(objects.map((o, index) => [o.id, index]));
  if (byId.size !== objects.length) throw new Error("Native route objects require unique identities");
  const resolve = (ids, kind) => {
    const matches = [...new Set(ids.flatMap((id) => byId.has(id) ? [byId.get(id)] : []))];
    return matches.length === 1 && objects[matches[0]].kind === kind ? matches[0] : void 0;
  };
  const unavailable = [], raw = [];
  const trials = [], seen = new Set(feedback.seenTupleKeys ?? []);
  if (seen.size > LIMIT) throw new Error("Native route tuple history exceeds its bounded epoch");
  let nextOrdinal = ordinal, selected, selectedIndex = null, candidateCount = 0;
  const trace = () => ({ ordinal, nextOrdinal, consumedTuples: trials.length, seenTupleKeys: [...seen], candidateCount, legalCount: selected ? 1 : 0, exhausted: !selected, entries: selected?.entries ?? [], selectedIndex, trials, unavailable });
  try {
    const sorted = [...feedback.witnesses].sort((a, b) => a.routeId.localeCompare(b.routeId) || a.kind.localeCompare(b.kind));
    const orderedEvents = (events) => [...events].sort((a, b) => a.at - b.at || a.structureId.localeCompare(b.structureId));
    const eventObjects = (events, kind) => {
      const seen2 = /* @__PURE__ */ new Set();
      return orderedEvents(events).flatMap((event) => {
        if (event.kind !== kind) return [];
        const index = resolve(event.objectIds, kind);
        if (index === void 0 || seen2.has(index)) return [];
        seen2.add(index);
        return [{ index, event }];
      });
    };
    const propose = (w, at, cause, variant, sourceStructureIds, entries) => {
      raw.push({ routeId: w.routeId, witnessKind: w.kind, at, cause, variant, sourceStructureIds, objectIds: entries.map((e) => objects[e.index].id), entries });
    };
    for (const witness of sorted) {
      checkpoint();
      if (witness.kind === "hole-share" || witness.kind === "window") {
        const surplus = excessKind(witness, policy);
        if (!surplus) {
          unavailable.push({ routeId: witness.routeId, reason: "no-excess-type" });
          continue;
        }
        const missing = surplus === "hole" ? "solid" : "hole", primaries = eventObjects(witness.kind === "window" ? witness.windowEvents ?? [] : witness.events, surplus);
        if (!primaries.length) {
          unavailable.push({ routeId: witness.routeId, reason: "no-unique-excess-object" });
          continue;
        }
        const reverse = sorted.filter((w) => w.kind === "hole-share" && excessKind(w, policy) === missing).flatMap((w) => eventObjects(w.events, missing).map((entry) => ({ ...entry, witness: w })));
        const partners = objects.map((o, index) => ({ index, id: o.id, kind: o.kind })).filter((o) => o.kind === missing);
        for (const primary of primaries) for (const partner of partners) {
          const a = objects[primary.index], b = objects[partner.index], as = footprintSize(a), bs = footprintSize(b), reverseSources = reverse.filter((r) => r.index === partner.index);
          let correctionValue = 0;
          const scored = /* @__PURE__ */ new Set();
          for (const w of sorted) {
            if (w.kind === "narrow") continue;
            const events = w.kind === "window" ? w.windowEvents ?? [] : w.events, key = `${w.routeId}|${w.kind}|${events.map((e) => e.structureId).join(",")}`;
            if (scored.has(key) || !events.length) continue;
            scored.add(key);
            const h = events.filter((e) => e.kind === "hole").length;
            let delta = 0;
            for (const e of events) {
              const index = resolve(e.objectIds, e.kind);
              if (index === primary.index) delta += b.kind === "hole" ? 1 : -1;
              else if (index === partner.index) delta += a.kind === "hole" ? 1 : -1;
            }
            correctionValue += w.kind === "window" ? (Math.max(0, policy.minWindowHoles - h) - Math.max(0, policy.minWindowHoles - h - delta)) / policy.minWindowHoles : shareDeficit(h, events.length, policy) - shareDeficit(h + delta, events.length, policy);
          }
          const sources2 = (reverseSources.length ? reverseSources : [void 0]).map((r) => ({ routeId: witness.routeId, kind: witness.kind, primaryObjectId: a.id, primaryStructureId: primary.event.structureId, at: primary.event.at, partnerObjectId: b.id, ...r ? { reverseRouteId: r.witness.routeId, partnerStructureId: r.event.structureId } : {} }));
          raw.push({
            routeId: witness.routeId,
            witnessKind: witness.kind,
            at: primary.event.at,
            cause: "type-swap",
            variant: 0,
            sourceStructureIds: [primary.event.structureId],
            objectIds: [a.id, b.id],
            entries: [{ index: primary.index, site: { ...b.site } }, { index: partner.index, site: { ...a.site } }],
            swapRank: { correctionValue, reverseEvidenceCount: new Set(reverseSources.map((r) => r.witness.routeId)).size, footprintMismatch: Math.abs(as[0] - bs[0]) / Math.max(1, as[0], bs[0]) + Math.abs(as[1] - bs[1]) / Math.max(1, as[1], bs[1]), distance: Math.hypot(a.site.x - b.site.x, a.site.y - b.site.y) + routeDistance(b.site, witness.points), sources: sources2 }
          });
        }
        continue;
      }
      const section2 = [...witness.crossSections ?? []].filter((s) => s.closed && Number.isFinite(s.widthLowerPx) && s.widthLowerPx >= 0).sort((a, b) => a.widthLowerPx - b.widthLowerPx || a.at - b.at)[0];
      if (!section2) {
        unavailable.push({ routeId: witness.routeId, reason: "no-owned-closed-section" });
        continue;
      }
      const [left, right] = section2.hits, dx = right.point.x - left.point.x, dy = right.point.y - left.point.y, length2 = Math.hypot(dx, dy);
      if (length2 <= 1e-7) {
        unavailable.push({ routeId: witness.routeId, reason: "degenerate-section-normal" });
        continue;
      }
      const indices = section2.hits.map((hit) => hit.owner.kind === "exterior" ? void 0 : resolve(hit.owner.objectIds, hit.owner.kind)), amount = Math.ceil(Math.max(8, policy.narrowWidthPx - section2.widthLowerPx) / 8) * 8;
      if (section2.hits.some((hit, i) => hit.owner.kind !== "exterior" && indices[i] === void 0) || indices[0] !== void 0 && indices[0] === indices[1]) {
        unavailable.push({ routeId: witness.routeId, reason: "ambiguous-section-object" });
        continue;
      }
      const move = (index, sign, distance3) => ({ index, site: { x: snap3(objects[index].site.x + sign * distance3 * dx / length2), y: snap3(objects[index].site.y + sign * distance3 * dy / length2) } }), sources = section2.hits.flatMap((h) => h.owner.structureId ? [h.owner.structureId] : []);
      if (section2.hits.some((hit) => hit.owner.kind === "exterior")) {
        const side = indices[0] !== void 0 ? 0 : 1, index = indices[side];
        if (index === void 0 || objects[index].kind !== "hole") {
          unavailable.push({ routeId: witness.routeId, reason: "exterior-without-owned-hole" });
          continue;
        }
        for (let tier = 0; tier < 2; tier++) propose(witness, section2.at, "narrow-single", tier, sources, [move(index, side === 0 ? -1 : 1, amount + tier * 8)]);
      } else {
        const a = indices[0], b = indices[1];
        for (let tier = 0; tier < 2; tier++) {
          const distance3 = amount + tier * 8;
          propose(witness, section2.at, "narrow-single", tier * 3, sources, [move(a, -1, distance3)]);
          propose(witness, section2.at, "narrow-single", tier * 3 + 1, sources, [move(b, 1, distance3)]);
          propose(witness, section2.at, "narrow-pair", tier * 3 + 2, sources, [move(a, -1, distance3 / 2), move(b, 1, distance3 / 2)]);
        }
      }
    }
    raw.sort((a, b) => a.routeId.localeCompare(b.routeId) || a.at - b.at || a.objectIds.join("|").localeCompare(b.objectIds.join("|")) || a.variant - b.variant || a.cause.localeCompare(b.cause));
    const keyOf = (entries) => [...entries].sort((a, b) => a.index - b.index).map((e) => `${e.index}@${e.site.x},${e.site.y}`).join("|");
    const unique = /* @__PURE__ */ new Map();
    for (const candidate of raw) {
      const key = keyOf(candidate.entries), existing = unique.get(key);
      if (!existing) {
        unique.set(key, candidate);
        continue;
      }
      if (existing.swapRank && candidate.swapRank) {
        const sources = [...existing.swapRank.sources, ...candidate.swapRank.sources], sourceKeys = /* @__PURE__ */ new Set();
        unique.set(key, { ...existing, swapRank: { ...existing.swapRank, reverseEvidenceCount: Math.max(existing.swapRank.reverseEvidenceCount, candidate.swapRank.reverseEvidenceCount), distance: Math.min(existing.swapRank.distance, candidate.swapRank.distance), sources: sources.filter((source) => {
          const identity = JSON.stringify(source);
          if (sourceKeys.has(identity)) return false;
          sourceKeys.add(identity);
          return true;
        }) } });
      }
    }
    const stable = (a, b) => a.routeId.localeCompare(b.routeId) || a.at - b.at || a.objectIds.join("|").localeCompare(b.objectIds.join("|")) || a.variant - b.variant || a.cause.localeCompare(b.cause);
    const swaps = [...unique.values()].filter((c) => c.swapRank), narrow = [...unique.values()].filter((c) => !c.swapRank), uses = /* @__PURE__ */ new Map(), orderedSwaps = [];
    while (swaps.length && orderedSwaps.length < LIMIT) {
      checkpoint();
      const use = (c) => c.entries.map((e) => uses.get(e.index) ?? 0);
      swaps.sort((a, b) => Math.max(...use(a)) - Math.max(...use(b)) || use(a).reduce((s, n) => s + n, 0) - use(b).reduce((s, n) => s + n, 0) || b.swapRank.correctionValue - a.swapRank.correctionValue || b.swapRank.reverseEvidenceCount - a.swapRank.reverseEvidenceCount || a.swapRank.footprintMismatch - b.swapRank.footprintMismatch || a.swapRank.distance - b.swapRank.distance || stable(a, b));
      const chosen = swaps.shift();
      orderedSwaps.push(chosen);
      for (const e of chosen.entries) uses.set(e.index, (uses.get(e.index) ?? 0) + 1);
    }
    const domain = [];
    for (let i = 0; domain.length < LIMIT && (i < orderedSwaps.length || i < narrow.length); i++) {
      if (i < orderedSwaps.length) domain.push(orderedSwaps[i]);
      if (domain.length < LIMIT && i < narrow.length) domain.push(narrow[i]);
    }
    candidateCount = domain.length;
    const consider = (candidate) => {
      checkpoint();
      if (trials.length >= budget) return;
      const key = keyOf(candidate.entries);
      if (seen.has(key)) return;
      seen.add(key);
      const stationary = candidate.entries.every((e) => e.site.x === objects[e.index].site.x && e.site.y === objects[e.index].site.y);
      const index = trials.length;
      trials.push({ ...candidate, reasons: ["evaluation-incomplete"] });
      const reasons = stationary ? ["unchanged-complete-state"] : nativeSpatialPlacementRejections(objects, candidate.entries, ground, policy.wideRadiusPx * 1.5), trial = { ...candidate, reasons };
      trials[index] = trial;
      return trial;
    };
    for (let index = ordinal; index < domain.length && trials.length < budget; index++) {
      nextOrdinal = index + 1;
      const candidate = domain[index], trial = consider(candidate);
      if (!trial) continue;
      if (!trial.reasons.length) {
        selected = trial;
        selectedIndex = index;
        break;
      }
      if (trial.entries.length !== 1) continue;
      const first = trial.entries[0], primary = objects[first.index], blockers = objects.flatMap((o, i) => i !== first.index && trial.reasons.includes(`${primary.id}:${o.id}:fixed-conflict`) ? [i] : []);
      if (blockers.length !== 1 || trial.reasons.some((reason) => reason !== `${primary.id}:${objects[blockers[0]].id}:fixed-conflict`)) continue;
      const partner = blockers[0], other = objects[partner], delta = { x: first.site.x - primary.site.x, y: first.site.y - primary.site.y };
      const released = consider({ ...candidate, cause: "blocker-release", objectIds: [primary.id, other.id], entries: [first, { index: partner, site: { x: other.site.x + delta.x, y: other.site.y + delta.y } }] });
      if (released && !released.reasons.length) {
        selected = released;
        selectedIndex = index;
        break;
      }
    }
    return trace();
  } catch (error) {
    throw Object.assign(error instanceof Error ? error : new Error(String(error)), { routeRefinement: trace() });
  }
}

// src/generation/world-study/native-spatial-layout.ts
var Stream = class {
  constructor(seed2, at = 0) {
    this.seed = seed2;
    this.at = at;
  }
  get drawCount() {
    return this.at;
  }
  next() {
    return mix32(this.seed, `native-layout-draw-${this.at++}`) / 4294967296;
  }
  range(min, max) {
    return min + (max - min) * this.next();
  }
  integer(min, max) {
    return min + Math.floor(this.next() * (max - min + 1));
  }
  choose(items) {
    if (!items.length) throw new Error("Empty native authoring choice");
    return items[this.integer(0, items.length - 1)];
  }
};
var snap4 = (v) => Math.round(v / 8) * 8;
function rectArea(rects) {
  const xs = [...new Set(rects.flatMap((r) => [r[0], r[0] + r[2]]))].sort((a, b) => a - b);
  let area3 = 0;
  for (let i = 0; i < xs.length - 1; i++) {
    const x = (xs[i] + xs[i + 1]) / 2, spans = rects.filter((r) => x > r[0] && x < r[0] + r[2]).map((r) => [r[1], r[1] + r[3]]).sort((a, b) => a[0] - b[0]);
    let start = 0, end = 0, length2 = 0;
    spans.forEach((s, j) => {
      if (j === 0) {
        start = s[0];
        end = s[1];
      } else if (s[0] <= end) end = Math.max(end, s[1]);
      else {
        length2 += end - start;
        start = s[0];
        end = s[1];
      }
    });
    if (spans.length) length2 += end - start;
    area3 += (xs[i + 1] - xs[i]) * length2;
  }
  return area3;
}
function nativeSpatialCountPairs(input) {
  const { policy: p, world: w } = input, n = Math.round(w.targetWalkAreaPx2 / (p.planningCellFactor * p.spacingPx * p.spacingPx)), pairs = [];
  for (let total = Math.ceil(n * (1 - p.countToleranceRatio)); total <= Math.floor(n * (1 + p.countToleranceRatio)); total++) for (let solids = Math.max(p.minSolidCount, input.assemblies.length); solids < total; solids++) {
    const holes = total - solids;
    if (p.requireMoreHoles && holes <= solids) continue;
    if (Math.abs(holes - p.holeToSolidRatio * solids) <= Math.max(p.holeCountAbsTolerance, p.holeCountRelTolerance * solids)) pairs.push({ holes, solids });
  }
  return pairs.sort((a, b) => Math.abs(a.holes / a.solids - p.holeToSolidRatio) - Math.abs(b.holes / b.solids - p.holeToSolidRatio) || a.holes + a.solids - (b.holes + b.solids) || a.solids - b.solids);
}
function meshPrimitives(instances, native, seed2, includeRelief = false) {
  const result = [];
  for (const instance of instances) {
    if (instance.role !== "solid" && !includeRelief) continue;
    const { role: _role, groundEdgeWidth: _edge, ...source } = instance;
    const mesh = buildNativeVolume({ ...source, family: instance.family ?? native.family, blocking: instance.role === "solid" ? 1 : 0, seed: seed2 ^ Math.imul(instance.id, 104729) });
    for (let t = 0; t < mesh.triangleCount; t++) {
      const points = [];
      for (let c = 0; c < 3; c++) {
        const at = mesh.indices[t * 3 + c] * 3;
        points.push(mesh.positions[at], mesh.positions[at + 1]);
      }
      if (Math.abs((points[2] - points[0]) * (points[5] - points[1]) - (points[3] - points[1]) * (points[4] - points[0])) > 1e-7) result.push(nativePrimitive(points, instance.id));
    }
  }
  return result;
}
function shifted(primitives, x, y) {
  return primitives.map((p) => nativePrimitive(p.points.map((v, i) => v + (i % 2 ? y : x)), p.objectId));
}
function rectPrimitives(rects, id) {
  return rects.flatMap(([x, y, w, h]) => [nativePrimitive([x, y, x + w, y, x + w, y + h], id), nativePrimitive([x, y, x + w, y + h, x, y + h], id)]);
}
function pointCloud(primitives) {
  const keys = /* @__PURE__ */ new Set(), points = [];
  for (const p of primitives) for (let i = 0; i < p.points.length; i += 2) {
    const x = p.points[i], y = p.points[i + 1], key = `${Math.round(x)}:${Math.round(y)}`;
    if (!keys.has(key)) {
      keys.add(key);
      points.push({ x, y });
    }
  }
  return points;
}
function nativeSpatialSiteCandidates(site, field, preferred, random) {
  const candidates = [];
  for (const point of preferred) for (const [dx, dy] of [[0, 0], [64, 0], [-64, 0], [0, 64], [0, -64]]) candidates.push({ x: snap4(point.x + dx), y: snap4(point.y + dy) });
  candidates.push({ ...site });
  for (const distance3 of [16, 32, 64]) for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]]) candidates.push({ x: snap4(site.x + dx * distance3), y: snap4(site.y + dy * distance3) });
  for (let i = 0; i < 160; i++) {
    const at = random.choose(field);
    candidates.push({ x: snap4(at.x + random.range(-24, 24)), y: snap4(at.y + random.range(-24, 24)) });
  }
  return candidates;
}
function nativeSpatialInitialOrder(kinds, mode) {
  const indices = kinds.map((_, index) => index);
  return mode === "author" ? indices : [...indices.filter((i) => kinds[i] === "solid"), ...indices.filter((i) => kinds[i] === "hole")];
}
function planningObject(source, native, seed2) {
  const blocking = source.kind === "hole" ? rectPrimitives(source.rects, -1) : meshPrimitives(source.instances, native, seed2);
  return { source, support: source.kind === "hole" ? blocking : meshPrimitives(source.instances, native, seed2, true), blocking, g1Blocking: blocking };
}
function planningField(ground, input, seed2) {
  const points = [];
  for (let cy = 0; cy < input.world.frameHeightPx; cy += 16) for (let cx = 0; cx < input.world.frameWidthPx; cx += 16) {
    const phase2 = mix32(seed2, `${input.world.worldId}:native-plan:${cx}:${cy}`), p = { x: cx + 4 + 8 * (phase2 & 1), y: cy + 4 + 8 * (phase2 >>> 1 & 1) };
    if (ground.margin(p) >= 12) points.push(p);
  }
  return points;
}
function planningWideRatio(points, ground, primitives, radius) {
  const tree = nativePrimitiveTree(primitives);
  let walk = 0, wide = 0;
  for (const p of points) {
    const distance3 = nativePrimitiveDistance(tree, p.x, p.y);
    if (distance3 < 10) continue;
    walk++;
    if (Math.min(distance3, ground.margin(p)) >= radius) wide++;
  }
  return wide / Math.max(1, walk);
}
function createNativeDeepSpanProxy(points, thresholdPx) {
  const cellSize = 16, cols = Math.max(1, ...points.map((p) => Math.floor(p.x / cellSize) + 1)), rows = Math.max(1, ...points.map((p) => Math.floor(p.y / cellSize) + 1)), count = cols * rows;
  const pointByCell = new Int32Array(count).fill(-1), cells = [];
  points.forEach((p, index) => {
    const cell = Math.floor(p.y / cellSize) * cols + Math.floor(p.x / cellSize);
    if (pointByCell[cell] !== -1) throw new Error("Duplicate native planning-field cell");
    pointByCell[cell] = index;
    cells.push(cell);
  });
  const neighbors = new Int32Array(count * 8).fill(-1), directions = [[-1, 0], [1, 0], [0, -1], [0, 1], [-1, -1], [1, -1], [-1, 1], [1, 1]];
  for (const cell of cells) {
    const x = cell % cols, y = Math.floor(cell / cols);
    for (let d = 0; d < directions.length; d++) {
      const [dx, dy] = directions[d], nx = x + dx, ny = y + dy, next = ny * cols + nx;
      if (nx < 0 || ny < 0 || nx >= cols || ny >= rows || pointByCell[next] === -1) continue;
      if (dx && dy && (pointByCell[y * cols + nx] === -1 || pointByCell[ny * cols + x] === -1)) continue;
      neighbors[cell * 8 + d] = next;
    }
  }
  const seen = new Uint32Array(count), deep = new Uint8Array(count), queue = new Int32Array(cells.length);
  let version = 0;
  return (distances) => {
    if (distances.length < points.length) throw new Error("Missing native planning-field distances");
    if (++version === 4294967295) {
      seen.fill(0);
      version = 1;
    }
    for (const cell of cells) deep[cell] = Number(distances[pointByCell[cell]] + Math.SQRT2 * 4 > thresholdPx);
    let maximum = 0;
    for (const start of cells) if (deep[start] && seen[start] !== version) {
      let head = 0, tail = 1, minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
      queue[0] = start;
      seen[start] = version;
      while (head < tail) {
        const cell = queue[head++], x = cell % cols, y = Math.floor(cell / cols);
        minX = Math.min(minX, x);
        minY = Math.min(minY, y);
        maxX = Math.max(maxX, x);
        maxY = Math.max(maxY, y);
        for (let d = 0; d < 8; d++) {
          const next = neighbors[cell * 8 + d];
          if (next < 0 || !deep[next] || seen[next] === version) continue;
          seen[next] = version;
          queue[tail++] = next;
        }
      }
      maximum = Math.max(maximum, (maxX - minX + 1) * cellSize, (maxY - minY + 1) * cellSize);
    }
    return maximum;
  };
}
function nativeSpatialPlanningWideRatio(rawRatio, correction, measurement, supportedBodySeats) {
  if (!measurement) return Math.max(Number.EPSILON, rawRatio + correction);
  if (!Number.isSafeInteger(supportedBodySeats) || supportedBodySeats <= 0) throw new Error("Measured native wide estimate requires the previous actual body count");
  return measurement.wideCount / supportedBodySeats;
}
function completePlanningScore(placed, entries, ground, input, field, g1Field, areaPointCount, deepSpan, wideCorrection, domain, supportedBodySeats) {
  const sites = new Map(entries.map((e) => [e.index, e.site])), tree = nativePrimitiveTree(placed.flatMap((o, index) => {
    const site = sites.get(index) ?? o.source.site;
    return shifted(o.blocking, site.x, site.y);
  }));
  const g1Tree = nativePrimitiveTree(placed.flatMap((o, index) => {
    const site = sites.get(index) ?? o.source.site;
    return shifted(o.g1Blocking, site.x, site.y);
  }));
  const g1Holes = placed.flatMap((o, index) => o.g1Void ? [{ contains: o.g1Void, site: sites.get(index) ?? o.source.site }] : []), inVoid = (x, y) => g1Holes.some((o) => o.contains(x - o.site.x, y - o.site.y));
  const distances = field.map((p) => nativePrimitiveDistance(tree, p.x, p.y)), maximum = g1Field.maximum((p) => nativeSpatialG1FilledDistance(g1Tree, inVoid, p.x, p.y));
  let mean = 0, walk = 0, areaWalk = 0, wide = 0;
  for (let index = 0; index < field.length; index++) {
    const d = distances[index];
    if (d < 10) continue;
    walk++;
    mean += Math.max(0, d - input.policy.deepEmptyThresholdPx) ** 2;
    if (index < areaPointCount) {
      areaWalk++;
      if (Math.min(d, ground.margin(field[index])) >= input.policy.wideRadiusPx) wide++;
    }
  }
  const measurement = domain ? entries.length ? domain.evaluateMany(entries) : domain.measure() : void 0;
  const estimate = nativeSpatialPlanningWideRatio(wide / Math.max(1, areaWalk), wideCorrection, measurement, supportedBodySeats), largest = measurement?.largestWideRatio;
  return nativeSpatialConstraintScore([Math.max(0, maximum / (input.policy.maxEmptyRadiusPx - 8) - 1), Math.max(0, deepSpan(distances) / input.policy.maxDeepEmptySpanPx - 1), Math.max(0, 1 - estimate / input.policy.minWideRatio), ...largest === void 0 ? [] : [Math.max(0, 1 - largest / input.policy.minLargestWideRatio)]], mean / Math.max(1, walk));
}
function selectNativeSpatialSite(candidates, evaluate, incumbent, qualify) {
  let chosen, best, legalCount = 0;
  const seen = /* @__PURE__ */ new Set(), evaluated = [];
  if (qualify && !incumbent) throw new Error("Native refinement qualification requires a valid incumbent");
  const consider = (site) => {
    const key = `${site.x}:${site.y}`;
    if (seen.has(key)) return;
    seen.add(key);
    const score = evaluate(site);
    if (!score) return;
    legalCount++;
    if (qualify) evaluated.push({ site, score });
    if (!best || compareNativeSpatialConstraintScores(score, best) < 0) {
      best = score;
      chosen = site;
    }
  };
  if (incumbent) {
    consider(incumbent);
    if (!chosen) throw new Error("Native refinement incumbent is no longer legal");
  }
  for (const site of candidates) {
    if (legalCount >= NATIVE_SPATIAL_SITE_EVALUATION_LIMIT) break;
    consider(site);
  }
  if (!chosen) throw new Error("Joint layout has no supported non-overlapping site for the next complete object");
  if (qualify) {
    const incumbentScore = evaluated[0].score;
    const selected = selectNativeSpatialQualifiedSite(evaluated.filter((entry) => compareNativeSpatialConstraintScores(entry.score, incumbentScore) < 0), qualify);
    return selected?.site ? { ...selected.site } : incumbent;
  }
  return chosen;
}
function selectNativeSpatialInitialSite(candidates, fieldSites, evaluate, objectIndex, checkpoint, qualify) {
  const seen = /* @__PURE__ */ new Set(), evaluated = [];
  let checked = 0, fallbackSitesChecked = 0;
  const consider = (site2, fromField) => {
    if (checked++ % 64 === 0) checkpoint();
    const key = `${site2.x}:${site2.y}`;
    if (seen.has(key)) return;
    seen.add(key);
    if (fromField) fallbackSitesChecked++;
    const score = evaluate(site2);
    if (score) evaluated.push({ site: site2, score });
  };
  checkpoint();
  for (const site2 of candidates) {
    if (evaluated.length >= NATIVE_SPATIAL_SITE_EVALUATION_LIMIT) break;
    consider(site2, false);
  }
  const originalLegalCount = evaluated.length, fallbackUsed = originalLegalCount === 0;
  if (fallbackUsed) for (const site2 of fieldSites()) {
    if (evaluated.length >= NATIVE_SPATIAL_SITE_EVALUATION_LIMIT) break;
    consider(site2, true);
  }
  let qualification;
  const selected = qualify ? selectNativeSpatialQualifiedSite(evaluated, (site2) => {
    checkpoint();
    return qualification = qualify(site2);
  }) : void 0;
  const site = qualify ? selected?.site : [...evaluated].sort((a, b) => compareNativeSpatialConstraintScores(a.score, b.score))[0]?.site;
  const trace = { objectIndex, originalCandidateCount: candidates.length, originalLegalCount, fallbackUsed, fallbackSitesChecked, evaluatedSites: evaluated.length, identityChecks: selected?.checks ?? 0, identityRejected: selected?.rejected ?? 0, selectedFrom: site ? fallbackUsed ? "field" : "original" : "none" };
  if (!site) throw Object.assign(new Error(`Native initial placement exhausted bounded domain: original=${originalLegalCount}, fieldChecked=${fallbackSitesChecked}, evaluated=${evaluated.length}, identityRejected=${trace.identityRejected}`), { placementSearch: trace, ...qualification ? { qualification } : {} });
  return { site: { ...site }, trace };
}
function siteFor(object2, ground, others, input, random, field, g1Field, deepSpan, areaPointCount, wideCorrection, preferred = [], measuredWide, incumbent, initial, qualifyRefinement) {
  const blocking = others.flatMap((o) => shifted(o.blocking, o.source.site.x, o.source.site.y));
  const relief = object2.source.kind === "hole" ? others.flatMap((o) => {
    const ids = new Set(o.source.instances.filter((i) => i.role === "relief").map((i) => i.id));
    return shifted(o.support.filter((p) => ids.has(p.objectId)), o.source.site.x, o.source.site.y);
  }) : [];
  const forbiddenTree = nativePrimitiveTree(blocking), coverageTree = forbiddenTree, reliefTree = nativePrimitiveTree(relief);
  const blockingPoints = pointCloud(blocking), reliefPoints = pointCloud(relief);
  const holes = nativePrimitiveTree(others.filter((o) => o.source.kind === "hole").flatMap((o) => shifted(o.blocking, o.source.site.x, o.source.site.y)));
  const support = pointCloud(object2.support), body = pointCloud(object2.blocking), bodyTree = nativePrimitiveTree(object2.blocking);
  const remaining = field.map((p) => nativePrimitiveDistance(coverageTree, p.x, p.y)), coast = field.map((p) => ground.margin(p)), openCoast = field.map((p) => g1Field.exteriorRadius(p));
  const fineCoverageTree = nativePrimitiveTree(others.flatMap((o) => shifted(o.g1Blocking, o.source.site.x, o.source.site.y))), fineBodyTree = nativePrimitiveTree(object2.g1Blocking);
  const inOtherVoid = (x, y) => others.some((o) => o.g1Void?.(x - o.source.site.x, y - o.source.site.y));
  const fineRemaining = g1Field.distances((p) => nativeSpatialG1FilledDistance(fineCoverageTree, inOtherVoid, p.x, p.y)), fineDescending = g1Field.descendingIndices(fineRemaining);
  const xs = body.map((p) => p.x), ys = body.map((p) => p.y), cx = (Math.min(...xs) + Math.max(...xs)) / 2, cy = (Math.min(...ys) + Math.max(...ys)) / 2;
  const rx = (Math.max(...xs) - Math.min(...xs)) / 2, ry = (Math.max(...ys) - Math.min(...ys)) / 2;
  const candidates = initial?.candidates ?? nativeSpatialSiteCandidates(object2.source.site, field, preferred, random);
  const roughIndices = field.flatMap((_, i) => i % 4 === 0 ? [i] : []);
  const cost = (distances, indices, measurement, fineMaximum) => {
    let score = 0, maximum = 0, walk = 0, areaWalk = 0, wide = 0;
    for (let i = 0; i < distances.length; i++) {
      const d = distances[i];
      if (d < 10) continue;
      walk++;
      const excess = Math.max(0, d - input.policy.deepEmptyThresholdPx);
      score += excess * excess;
      const fieldIndex = indices?.[i] ?? i;
      maximum = Math.max(maximum, Math.min(d, openCoast[fieldIndex]));
      if (fieldIndex < areaPointCount) {
        areaWalk++;
        if (Math.min(d, coast[fieldIndex]) >= input.policy.wideRadiusPx) wide++;
      }
    }
    const estimatedWide = nativeSpatialPlanningWideRatio(wide / Math.max(1, areaWalk), wideCorrection, measurement, measuredWide?.supportedBodySeats);
    const coverExcess = Math.max(0, (fineMaximum ?? maximum) / (input.policy.maxEmptyRadiusPx - 8) - 1), wideExcess = Math.max(0, 1 - estimatedWide / input.policy.minWideRatio);
    const deepExcess = indices ? 0 : Math.max(0, deepSpan(distances) / input.policy.maxDeepEmptySpanPx - 1);
    const connectivity = measurement === void 0 ? [] : [Math.max(0, 1 - measurement.largestWideRatio / input.policy.minLargestWideRatio)];
    return nativeSpatialConstraintScore([coverExcess, deepExcess, wideExcess, ...connectivity], score / Math.max(1, walk));
  };
  const rough = candidates.map((p) => ({ p, score: cost(roughIndices.map((i) => {
    const q = field[i];
    return Math.min(remaining[i], Math.hypot(Math.max(0, Math.abs(q.x - p.x - cx) - rx), Math.max(0, Math.abs(q.y - p.y - cy) - ry)));
  }), roughIndices) })).sort((a, b) => compareNativeSpatialConstraintScores(a.score, b.score) || a.p.y - b.p.y || a.p.x - b.p.x);
  const evaluate = (p) => {
    if (ground.margin(p) < 24) return;
    if (support.some((q) => ground.margin({ x: p.x + q.x, y: p.y + q.y }) < 24 || nativePrimitiveDistance(holes, p.x + q.x, p.y + q.y) < 24)) return;
    if (!ground.supportsFootprint(object2.support, p)) return;
    if (body.some((q) => nativePrimitiveDistance(forbiddenTree, p.x + q.x, p.y + q.y) < input.policy.wideRadiusPx * 1.5 || nativePrimitiveDistance(reliefTree, p.x + q.x, p.y + q.y) < 24)) return;
    const shiftedTree = nativePrimitiveTree(shifted(object2.blocking, p.x, p.y));
    if (blockingPoints.some((q) => nativePrimitiveDistance(shiftedTree, q.x, q.y) < input.policy.wideRadiusPx * 1.5) || reliefPoints.some((q) => nativePrimitiveDistance(shiftedTree, q.x, q.y) < 24)) return;
    const fineMaximum = g1Field.maximumWithRemaining(fineRemaining, fineDescending, (q) => nativeSpatialG1FilledDistance(fineBodyTree, object2.g1Void, q.x - p.x, q.y - p.y));
    const score = cost(field.map((q, i) => Math.min(remaining[i], nativePrimitiveDistance(bodyTree, q.x - p.x, q.y - p.y))), void 0, measuredWide?.evaluate(p), fineMaximum);
    return score;
  };
  if (initial) {
    const result = selectNativeSpatialInitialSite(rough.map((entry) => entry.p), () => field.map((p) => ({ x: snap4(p.x), y: snap4(p.y) })), evaluate, initial.objectIndex, initial.checkpoint, initial.qualify);
    initial.record(result.trace);
    return result.site;
  }
  return selectNativeSpatialSite(rough.map((entry) => entry.p), evaluate, incumbent, qualifyRefinement);
}
function holeRects(profile, random, axis) {
  const count = random.integer(profile.minRectCount, profile.maxRectCount), snapLocal = (v) => Math.round(v / 4) * 4;
  const maximumSpan = profile.maxSpanPx - 8, maximumArea = profile.maxAreaPx2 * 0.94;
  const bounds3 = (rects) => ({ x: Math.min(...rects.map((r) => r[0])), y: Math.min(...rects.map((r) => r[1])), right: Math.max(...rects.map((r) => r[0] + r[2])), bottom: Math.max(...rects.map((r) => r[1] + r[3])) });
  const extent = (rects) => {
    const b = bounds3(rects);
    return { span: Math.max(b.right - b.x, b.bottom - b.y), thickness: Math.min(b.right - b.x, b.bottom - b.y) };
  };
  for (let attempt = 0; attempt < 48; attempt++) {
    const target = random.range(profile.minSpanPx, maximumSpan), initialWidth = snapLocal(random.range(80, Math.min(112, maximumSpan / (1 + (count - 1) * (1 - profile.maxOverlapRatio))))), initialHeight = snapLocal(random.range(80, Math.max(80, profile.maxThicknessPx / (1 + profile.minOffsetRatio))));
    const rects = [[0, 0, initialWidth, initialHeight]];
    for (let index = 1; index < count; index++) {
      const choices = [];
      for (let draw = 0; draw < 96; draw++) {
        const parent = rects[profile.sizeClass === "large" && index === count - 1 && random.next() < 0.4 ? random.integer(0, index - 1) : index - 1];
        const direction = random.next() < 0.8 ? random.integer(0, 1) : random.integer(2, 3), normalX = direction < 2, sign = direction % 2 === 0 ? -1 : 1, offsetSign = random.next() < 0.5 ? -1 : 1;
        const width = snapLocal(random.range(80, Math.min(128, maximumSpan))), height = snapLocal(random.range(80, Math.max(80, profile.maxThicknessPx / (1 + profile.minOffsetRatio))));
        const shorterNormal = Math.min(normalX ? parent[2] : parent[3], normalX ? width : height), shorterTangent = Math.min(normalX ? parent[3] : parent[2], normalX ? height : width);
        const overlap2 = snapLocal(shorterNormal * random.range(profile.minOverlapRatio, profile.maxOverlapRatio)), offset = snapLocal(shorterTangent * random.range(profile.minOffsetRatio, profile.maxOffsetRatio));
        if (overlap2 / shorterNormal < profile.minOverlapRatio || overlap2 / shorterNormal > profile.maxOverlapRatio || offset / shorterTangent < profile.minOffsetRatio || offset / shorterTangent > profile.maxOffsetRatio) continue;
        const x = normalX ? sign < 0 ? parent[0] - width + overlap2 : parent[0] + parent[2] - overlap2 : parent[0] + parent[2] / 2 - width / 2 + offsetSign * offset;
        const y = normalX ? parent[1] + parent[3] / 2 - height / 2 + offsetSign * offset : sign < 0 ? parent[1] - height + overlap2 : parent[1] + parent[3] - overlap2;
        const rect = [x, y, width, height], next = [...rects, rect], size = extent(next), area3 = rectArea(next);
        if (size.span > maximumSpan || size.thickness > profile.maxThicknessPx || area3 > maximumArea || area3 <= rectArea(rects)) continue;
        if (next.some((_, j) => rectArea(next.filter((__, k) => k !== j)) === area3)) continue;
        if (index === count - 1 && (size.span < profile.minSpanPx || size.thickness < profile.minThicknessPx)) continue;
        const desired = initialWidth + (target - initialWidth) * index / (count - 1);
        choices.push({ rect, score: Math.abs(size.span - desired) / Math.max(1, target) + random.range(0, 0.12) });
      }
      if (!choices.length) break;
      choices.sort((a, b2) => a.score - b2.score);
      rects.push(choices[0].rect);
    }
    if (rects.length !== count) continue;
    const b = bounds3(rects), cx = (b.x + b.right) / 2, cy = (b.y + b.bottom) / 2, vertical = Math.abs(Math.sin(axis)) > Math.abs(Math.cos(axis));
    return rects.map(([x, y, width, height]) => vertical ? [y - cy, x - cx, height, width] : [x - cx, y - cy, width, height]);
  }
  throw new Error(`No bounded offset-rectangle grammar sample for hole profile ${profile.id}`);
}
function createNativeSpatialLayout(native, input, requestedSeed, geometrySeed, candidate, previous, countPairIndex, bayCountIndex, geometryWork) {
  return buildNativeSpatialLayout(native, input, requestedSeed, geometrySeed, candidate, previous, countPairIndex, bayCountIndex, geometryWork);
}
function buildNativeSpatialLayout(native, input, requestedSeed, geometrySeed, candidate, previous, countPairIndex, bayCountIndex, geometryWork, frozen, initial) {
  if (input.world.landGrammar !== "offset-overlap-v1" || input.world.bayGrammar !== "shore-rect-cut-v1") throw new Error("Unsupported native plate grammar");
  const layoutSeed = initial?.fixture.layoutSeed ?? frozen?.layoutSeed ?? mix32(requestedSeed, `${input.policy.algorithm}:${input.policy.version}:${input.policy.sourceHash}:${input.world.worldId}:${geometrySeed}:${candidate}`), random = new Stream(layoutSeed, initial?.fixture.randomDrawCount), pairs = nativeSpatialCountPairs(input);
  if (!pairs.length) throw new Error("Intent count/assembly contract has no integer solution");
  const reuse = !!previous, retained = frozen ?? previous?.layout;
  const selectedPairIndex = reuse ? previous.layout.countPairIndex ?? pairs.findIndex((p) => p.holes === previous.layout.requestedCounts.holes && p.solids === previous.layout.requestedCounts.solids) : countPairIndex ?? candidate % pairs.length;
  if (!Number.isSafeInteger(selectedPairIndex) || selectedPairIndex < 0 || selectedPairIndex >= pairs.length) throw new Error("Invalid native count pair index");
  const counts = initial?.fixture.requestedCounts ?? retained?.requestedCounts ?? pairs[selectedPairIndex];
  if (counts.solids > 32) throw new Error("Native count pair exceeds solid capacity");
  const selectedBayIndex = reuse ? previous.layout.bayCountIndex : bayCountIndex ?? candidate % input.world.bayCountOptions.length;
  if (!Number.isSafeInteger(selectedBayIndex) || selectedBayIndex < 0 || selectedBayIndex >= input.world.bayCountOptions.length) throw new Error("Invalid native bay count index");
  const bayCount = input.world.bayCountOptions[selectedBayIndex], bayRandom = new Stream(mix32(layoutSeed, "native-bay-geometry"));
  const availableBayProfiles = input.bayProfiles.filter((p) => input.world.bayProfileIds.includes(p.id));
  const bayProfiles = retained || initial ? [] : Array.from({ length: bayCount }, () => bayRandom.choose(availableBayProfiles));
  const bayAreaEstimate = bayProfiles.reduce((sum, p) => sum + (p.minRemovedLandAreaPx2 + p.maxRemovedLandAreaPx2) / 2, 0);
  const landPlan = initial ? { rects: initial.fixture.land, plates: initial.fixture.landPlates } : retained ? { rects: retained.plan.land, plates: retained.plan.landPlates } : createNativeSpatialLand(input, random, counts, native, bayAreaEstimate);
  const land = landPlan.rects, landPlates = landPlan.plates;
  const landJoins = initial?.fixture.landJoins ?? (retained ? retained.landJoins : nativeSpatialLandJoins(land, input.world.landRectMinOverlapPx, landPlates.map((p) => p.parentIndex)));
  const bays = initial?.fixture.bays ?? (retained ? retained.bays : createNativeSpatialBays(land, landJoins, bayProfiles, bayRandom, { width: input.world.frameWidthPx, height: input.world.frameHeightPx }));
  const bayRects = bays.flatMap((b) => b.rects.map((r) => [...r])), ground = createNativeSpatialPlanningGround(land, bayRects), objects = initial ? [...initial.fixture.objects] : retained ? [...retained.plan.objects] : [];
  const assessmentPoints = reuse ? [...previous.layout.plan.assessmentPoints ?? []] : [];
  const hotspots = reuse ? [previous.gate.metrics.worstDeepPoint, previous.gate.metrics.worstEmptyPoint].filter((point) => !!point) : [];
  for (const hotspot of hotspots) if (!assessmentPoints.some((p) => p.x === hotspot.x && p.y === hotspot.y)) assessmentPoints.push({ ...hotspot });
  const g1Exterior = previous?.actualVoid ? nativeSpatialG1ExteriorRadius(previous.actualVoid) : (p) => ground.margin(p);
  const g1Field = new NativeSpatialG1Field(input.world.frameWidthPx, input.world.frameHeightPx, (p) => ground.margin(p), assessmentPoints, () => geometryWork?.checkpoint(), g1Exterior);
  const baseField = planningField(ground, input, geometrySeed), deepSpan = createNativeDeepSpanProxy(baseField, input.policy.deepEmptyThresholdPx), field = [...baseField, ...assessmentPoints], placed = [];
  const placementSearch = [];
  let wideCorrection = 0, supportedBodySeats, wideDomain, refinement, initialPlacement;
  const seedSalt = initial?.fixture.seedSalt ?? (retained ? retained.fragmentShape.seedSalt : mix32(layoutSeed, "native-fragment-edge"));
  const fragmentFor = (sources) => ({
    algorithmVersion: "rectilinear-fragment-v1",
    layoutId: `${input.world.worldId}-native`,
    sourceHash: input.policy.sourceHash,
    seedMode: "run-seed",
    seedSalt,
    edgeSeed: requestedSeed + seedSalt >>> 0,
    layout: { worldScale: 2, authoringFrame: [input.world.frameWidthPx / 2, input.world.frameHeightPx / 2], landRects: land.map((r) => r.map((v) => v / 2)), voidRects: [...bayRects, ...sources.flatMap((o) => o.rects.map(([x, y, w, h]) => [x + o.site.x, y + o.site.y, w, h]))].map((r) => r.map((v) => v / 2)) }
  });
  const holePlacements = (sources) => sources.filter((o) => o.kind === "hole").map((o, index) => {
    if (!o.profileId) throw new Error("Native hole has no authoring profile");
    return { holeId: `hole-${index}`, profileId: o.profileId, rects: o.rects.map(([x, y, w, h]) => [x + o.site.x, y + o.site.y, w, h]) };
  });
  let nextId = Math.max(...native.instances.map((i) => i.id)) + 1;
  try {
    if (!reuse) {
      if (!frozen && !initial) {
        for (const assembly of input.assemblies) {
          const sourceIds = /* @__PURE__ */ new Set([...assembly.sourceInstanceIds, ...assembly.attachedReliefIds]), source = native.instances.filter((i) => sourceIds.has(i.id));
          const anchor = assembly.sourceInstanceIds.map((id) => native.instances.find((i) => i.id === id)), cx = anchor.reduce((n, i) => n + i.x, 0) / anchor.length, cy = anchor.reduce((n, i) => n + i.y, 0) / anchor.length;
          const scale = assembly.sourceScale * random.range(assembly.minScale, assembly.maxScale), rotation = random.choose(assembly.rotationOffsetsRad), c = Math.cos(rotation), s = Math.sin(rotation);
          const local = source.map((i) => ({ ...i, x: ((i.x - cx) * c - (i.y - cy) * s) * scale, y: ((i.x - cx) * s + (i.y - cy) * c) * scale, rotation: i.rotation + rotation, length: i.length * scale, width: i.width * scale, height: i.role === "solid" ? i.height * scale : i.height, thickness: i.role === "solid" ? i.thickness * scale : i.thickness }));
          objects.push({ kind: "solid", instances: local, rects: [], assembly: { assemblyId: assembly.id, instanceIds: assembly.sourceInstanceIds, maxSpanPx: assembly.maxSpanPx }, site: { x: 0, y: 0 } });
        }
        const totalWeight = input.holeProfiles.reduce((n, p) => n + p.weight, 0), alloc = input.holeProfiles.map((p) => ({ profile: p, count: Math.floor(counts.holes * p.weight / totalWeight), remainder: counts.holes * p.weight / totalWeight % 1 }));
        const missing = counts.holes - alloc.reduce((n, a) => n + a.count, 0);
        [...alloc].sort((a, b) => b.remainder - a.remainder || a.profile.id.localeCompare(b.profile.id)).slice(0, missing).forEach((a) => a.count++);
        const profiles = alloc.flatMap((a) => Array(a.count).fill(a.profile));
        for (let i = profiles.length - 1; i > 0; i--) {
          const j = random.integer(0, i);
          [profiles[i], profiles[j]] = [profiles[j], profiles[i]];
        }
        const kinds = [...Array(counts.holes).fill("hole"), ...Array(counts.solids - input.assemblies.length).fill("solid")];
        for (let i = kinds.length - 1; i > 0; i--) {
          const j = random.integer(0, i);
          [kinds[i], kinds[j]] = [kinds[j], kinds[i]];
        }
        for (const kind of kinds) {
          if (kind === "hole") {
            const profile = profiles.pop();
            objects.push({ kind, profileId: profile.id, instances: [], rects: holeRects(profile, random, input.world.materialAxisRad + (random.next() < 0.28 ? Math.PI / 2 : 0)), site: { x: 0, y: 0 } });
          } else {
            const p = random.choose(input.subordinateProfiles), id = nextId++, instance = { id, role: "solid", family: p.family, constructionVersion: 4, shapeProfile: p.shapeProfile, x: 0, y: 0, rotation: input.world.materialAxisRad + p.rotationOffsetRad + random.range(-0.25, 0.25), length: random.range(p.minLengthPx, p.maxLengthPx), width: random.range(p.minWidthPx, p.maxWidthPx), height: random.range(p.minHeightPx, p.maxHeightPx), thickness: p.thicknessPx, fold: p.fold, branches: p.branches, opening: p.opening, distortion: p.distortion };
            objects.push({ kind, instances: [instance], rects: [], assembly: { assemblyId: `subordinate-${id}`, instanceIds: [id], maxSpanPx: 512 }, site: { x: 0, y: 0 } });
          }
        }
      }
      if (!geometryWork) throw new Error("Native initial placement requires a shared geometry-work budget");
      if (frozen) {
        placed.push(...objects.map((o) => planningObject(o, native, geometrySeed)));
        let holeIndex = 0;
        const ids = objects.map((o) => o.kind === "hole" ? `hole-${holeIndex++}` : o.assembly.assemblyId), byId = new Map(ids.map((id, index) => [id, index]));
        const result = createNativeSpatialInitialPlacement({ objects: placed.map((o, index) => ({ id: ids[index], kind: o.source.kind, support: o.support, blocking: o.blocking })), ground, field: baseField, firstAnchorIndex: mix32(layoutSeed, "native-initial-anchors") % baseField.length, gapPx: input.policy.wideRadiusPx * 1.5, checkpoint: () => geometryWork.checkpoint(), evaluate: (placements) => completePlanningScore(placed, placements.map((p) => ({ index: byId.get(p.id), site: p.site })), ground, input, field, g1Field, baseField.length, deepSpan, 0) });
        initialPlacement = result.trace;
        for (const entry of result.placements) {
          const index = byId.get(entry.id);
          objects[index] = { ...objects[index], site: entry.site };
          placed[index] = { ...placed[index], source: objects[index] };
        }
        const qualification = geometryWork.run({ kind: "initial-hole-identity", candidate }, () => qualifyNativeSpatialHoles(fragmentFor(objects), requestedSeed, holePlacements(objects), counts.holes));
        if (!qualification.accepted) throw Object.assign(new Error("Native initial complete assignment failed final hole identity"), { initialPlacement, qualification });
      } else {
        const candidatePools = initial?.fixture.candidatePools ?? objects.map((o) => {
          geometryWork.checkpoint();
          return nativeSpatialSiteCandidates(o.site, field, [], random);
        });
        const order = initial?.order ?? nativeSpatialInitialOrder(objects.map((o) => o.kind), "author");
        const lastHole = [...order].reverse().find((i) => objects[i].kind === "hole");
        const placedByIndex = new Array(objects.length);
        for (const i of order) {
          geometryWork.checkpoint();
          const object2 = planningObject(objects[i], native, geometrySeed);
          const prior = placedByIndex.filter((o) => !!o);
          const qualify = i === lastHole ? (site2) => {
            const sources = objects.flatMap((source, index) => index === i ? [{ ...source, site: site2 }] : placedByIndex[index] ? [placedByIndex[index].source] : []);
            return geometryWork.run({ kind: "initial-hole-identity", candidate, objectIndex: i, site: site2 }, () => qualifyNativeSpatialHoles(fragmentFor(sources), requestedSeed, holePlacements(sources), counts.holes));
          } : void 0;
          const site = siteFor(object2, ground, prior, input, random, field, g1Field, deepSpan, baseField.length, 0, [], void 0, void 0, { objectIndex: i, candidates: candidatePools[i], checkpoint: () => geometryWork.checkpoint(), qualify, record: (trace) => placementSearch.push(trace) });
          objects[i] = { ...objects[i], site };
          placedByIndex[i] = { ...object2, source: objects[i] };
        }
        placed.push(...placedByIndex.filter((o) => !!o));
      }
    } else {
      placed.push(...objects.map((o) => planningObject(o, native, geometrySeed)));
      if (previous.actualVoid) {
        const holeSources = placed.filter((o) => o.source.kind === "hole").map((o, index) => ({ holeId: `hole-${index}`, site: o.source.site })), shapes = nativeSpatialG1HoleShapes(previous.actualVoid, holeSources);
        let g1Hole = 0;
        for (let i = 0; i < placed.length; i++) if (placed[i].source.kind === "hole") {
          const shape = shapes.get(`hole-${g1Hole++}`);
          placed[i] = { ...placed[i], g1Blocking: shape.boundary, g1Void: shape.contains };
        }
        supportedBodySeats = Number(previous.gate.metrics.supportedBodySeats);
        if (!Number.isSafeInteger(supportedBodySeats) || supportedBodySeats <= 0) throw new Error("Actual VOID feedback requires a positive measured body count");
        let holeIndex = 0;
        wideDomain = new NativeSpatialWideDomain(previous.actualVoid, placed.map((o) => ({ site: o.source.site, blocking: o.blocking, ...o.source.kind === "hole" ? { holeId: `hole-${holeIndex++}` } : {} })), input.policy.wideRadiusPx);
      }
      const actualWide = previous.gate.metrics.wideRatio;
      if (typeof actualWide === "number" && Number.isFinite(actualWide)) {
        const priorRaw = previous.layout.plan.wideEstimate?.rawRatio ?? planningWideRatio(baseField, ground, placed.flatMap((o) => shifted(o.blocking, o.source.site.x, o.source.site.y)), input.policy.wideRadiusPx);
        wideCorrection = actualWide - priorRaw;
      }
      const worst = previous.gate.metrics.worstEmptyPoint;
      const evaluate = (entries) => completePlanningScore(placed, entries, ground, input, field, g1Field, baseField.length, deepSpan, wideCorrection, wideDomain, supportedBodySeats);
      if (previous.routeFeedback) {
        if (!previous.gate.accepted || !wideDomain) throw new Error("Route refinement requires accepted actual geometry and actual VOID feedback");
        const before = evaluate([]);
        let holeIndex = 0;
        const route = selectNativeSpatialRoutePlacement({ objects: placed.map((o) => {
          const reliefIds = new Set(o.source.instances.filter((i) => i.role === "relief").map((i) => i.id));
          return { id: o.source.kind === "hole" ? `hole-${holeIndex++}` : o.source.assembly.assemblyId, kind: o.source.kind, site: o.source.site, support: o.support, blocking: o.blocking, relief: o.support.filter((p) => reliefIds.has(p.objectId)) };
        }), ground, policy: input.policy, feedback: previous.routeFeedback, checkpoint: () => geometryWork?.checkpoint() });
        refinement = { kind: "route", before, after: before, constraintsImproved: false, route };
        if (route.exhausted) throw Object.assign(new Error("Native route refinement exhausted its bounded actual-witness domain"), { routeRefinement: route });
        const after = evaluate(route.entries);
        wideDomain.commitMany(route.entries);
        for (const entry of route.entries) {
          objects[entry.index] = { ...objects[entry.index], site: entry.site };
          placed[entry.index] = { ...placed[entry.index], source: objects[entry.index] };
        }
        refinement = { kind: "route", before, after, constraintsImproved: nativeSpatialConstraintsImproved(before, after), route };
      } else if (previous.allowJoint) {
        const before = evaluate([]), deepWitness = previous.gate.metrics.worstDeepPoint;
        const emptyViolation = Math.max(0, Number(previous.gate.metrics.maxEmptyUpperPx) / input.policy.maxEmptyRadiusPx - 1), deepViolation = Math.max(0, Number(previous.gate.metrics.maxDeepSpanPx) / input.policy.maxDeepEmptySpanPx - 1);
        const witnessKind = deepWitness && deepViolation > emptyViolation ? "deep" : "empty", witness = witnessKind === "deep" ? deepWitness : worst;
        if (wideDomain && witness) {
          let holeIndex = 0;
          const joint = refineNativeSpatialJointObjects({ objects: placed.map((o) => {
            const reliefIds = new Set(o.source.instances.filter((i) => i.role === "relief").map((i) => i.id));
            return { id: o.source.kind === "hole" ? `hole-${holeIndex++}` : o.source.assembly.assemblyId, kind: o.source.kind, site: o.source.site, support: o.support, blocking: o.blocking, relief: o.support.filter((p) => reliefIds.has(p.objectId)) };
          }), ground, gapPx: input.policy.wideRadiusPx * 1.5, field, baseFieldCount: baseField.length, baseFieldCellPx: 16, snapStep: 8, coverPlanningLimit: input.policy.maxEmptyRadiusPx - 8, deepPlanningLimit: input.policy.deepEmptyThresholdPx - 4 * Math.SQRT2, witness, witnessKind, deepWitness, evaluate });
          if (joint.entries.length) {
            wideDomain.commitMany(joint.entries);
            for (const entry of joint.entries) {
              objects[entry.index] = { ...objects[entry.index], site: entry.site };
              placed[entry.index] = { ...placed[entry.index], source: objects[entry.index] };
            }
          }
          refinement = { kind: "joint", before: joint.before, after: joint.after, constraintsImproved: nativeSpatialConstraintsImproved(joint.before, joint.after), joint };
        } else refinement = { kind: "joint", before, after: before, constraintsImproved: false, reason: wideDomain ? "missing-actual-witness" : "missing-actual-void-feedback" };
      } else {
        if (!geometryWork) throw new Error("Native refinement requires a shared geometry-work budget");
        const before = evaluate([]);
        const order = objects.map((_, i) => i).sort((a, b) => worst ? Math.hypot(objects[a].site.x - worst.x, objects[a].site.y - worst.y) - Math.hypot(objects[b].site.x - worst.x, objects[b].site.y - worst.y) : a - b);
        for (const i of order) {
          const qualify = objects[i].kind === "hole" ? (site) => {
            const sources = objects.map((source, index) => index === i ? { ...source, site } : source);
            return geometryWork.run({ kind: "refinement-hole-identity", candidate, objectIndex: i, site }, () => qualifyNativeSpatialHoles(fragmentFor(sources), requestedSeed, holePlacements(sources), counts.holes));
          } : void 0;
          try {
            const site = siteFor(placed[i], ground, placed.filter((_, j) => j !== i), input, random, field, g1Field, deepSpan, baseField.length, wideCorrection, hotspots, wideDomain ? { supportedBodySeats, evaluate: (p) => wideDomain.evaluate(i, p) } : void 0, objects[i].site, void 0, qualify);
            wideDomain?.commit(i, site);
            objects[i] = { ...objects[i], site };
            placed[i] = { ...placed[i], source: objects[i] };
          } catch (error) {
            if (error instanceof NativeSpatialGeometryWorkBudgetError) throw error;
            geometryWork.checkpoint();
          }
        }
        const after = evaluate([]);
        refinement = { kind: "single", before, after, constraintsImproved: nativeSpatialConstraintsImproved(before, after) };
      }
    }
    const instances = objects.flatMap((o) => o.instances.map((i) => ({ ...i, x: i.x + o.site.x, y: i.y + o.site.y }))), assemblies = objects.flatMap((o) => o.assembly ? [o.assembly] : []), voidRects = [...bayRects, ...objects.flatMap((o) => o.rects.map(([x, y, w, h]) => [x + o.site.x, y + o.site.y, w, h]))];
    const holes = holePlacements(objects);
    if (instances.length > 48 || land.length + voidRects.length > 128) throw new Error("Native complete layout exceeds instance/fragment capacity");
    const fragmentShape = fragmentFor(objects);
    const compiled = compileR100FragmentShape(fragmentShape, requestedSeed), all = nativePrimitiveTree(placed.flatMap((o) => shifted(o.blocking, o.source.site.x, o.source.site.y))), probes = field.filter((p) => ground.margin(p) >= 32 && nativePrimitiveDistance(all, p.x, p.y) >= 24);
    if (!probes.length) throw new Error("Native complete layout has no initial body probe");
    const probe = random.choose(probes);
    const definition = { ...native, cols: input.world.frameWidthPx / 32, rows: input.world.frameHeightPx / 32, instances, erosion: compiled.erosion, terrainOutline: compiled.terrainOutline, fragmentShapeVersion: "rectilinear-fragment-v1", spawn_x: probe.x, spawn_y: probe.y, exit_x: probe.x, exit_y: probe.y, search_x: probe.x, search_y: probe.y, enemy_x: probe.x, enemy_y: probe.y };
    const deepSpanProxyPx = deepSpan(baseField.map((p) => nativePrimitiveDistance(all, p.x, p.y)));
    const rawRatio = planningWideRatio(baseField, ground, placed.flatMap((o) => shifted(o.blocking, o.source.site.x, o.source.site.y)), input.policy.wideRadiusPx);
    const measurement = wideDomain?.measure();
    const wideEstimate = { rawRatio, correction: wideCorrection, correctedRatio: measurement ? nativeSpatialPlanningWideRatio(rawRatio, wideCorrection, measurement, supportedBodySeats) : Math.max(0, Math.min(1, rawRatio + wideCorrection)), feedbackCandidate: reuse ? previous.layout.candidate : null, source: measurement ? "actual-void-fixed-body" : "raw-field", wideCount: measurement?.wideCount ?? null, supportedBodySeats: supportedBodySeats ?? null };
    const largestWideRatioProxy = measurement?.largestWideRatio ?? null;
    return { candidate, countPairIndex: selectedPairIndex, bayCountIndex: selectedBayIndex, layoutSeed, definition, fragmentShape, assemblies, requestedCounts: counts, holes, bays, landJoins, plan: { land, landPlates, bays, objects, assessmentPoints, g1Field: { ...g1Field.trace(), footprintSource: previous?.actualVoid ? "previous-actual-void-translation" : "raw-authoring", feedbackCandidate: previous?.actualVoid ? previous.layout.candidate : null }, deepSpanProxyPx, wideEstimate, largestWideRatioProxy, ...refinement ? { refinement } : {}, ...initialPlacement ? { initialPlacement } : {}, ...placementSearch.length ? { placementSearch } : {} } };
  } catch (error) {
    if (refinement?.route) throw Object.assign(error instanceof Error ? error : new Error(String(error)), { routeRefinement: refinement.route });
    throw error;
  }
}

// src/generation/world-study/native-spatial-final-support.ts
function overlapsCell(p, col, row) {
  const x = col * 8 + 4, y = row * 8 + 4, epsilon = 1e-7;
  if (p.maxX <= x - 4 + epsilon || p.minX >= x + 4 - epsilon || p.maxY <= y - 4 + epsilon || p.minY >= y + 4 - epsilon) return false;
  const v = p.points;
  for (let i = 0; i < 6; i += 2) {
    const j = (i + 2) % 6, nx = v[j + 1] - v[i + 1], ny = v[i] - v[j], a = v[0] * nx + v[1] * ny, b = v[2] * nx + v[3] * ny, c = v[4] * nx + v[5] * ny;
    const center = x * nx + y * ny, radius = 4 * (Math.abs(nx) + Math.abs(ny));
    if (Math.max(a, b, c) <= center - radius + epsilon || Math.min(a, b, c) >= center + radius - epsilon) return false;
  }
  return true;
}
function evaluateNativeSpatialFinalSupport(geometry) {
  const { terrain } = geometry, { cols, rows, matter } = terrain, failed = /* @__PURE__ */ new Set();
  const unsupportedSources = [];
  let checkedTriangles = 0, voidCellTests = 0;
  for (const triangle of nativeSolidPrimitives(terrain, true)) {
    if (failed.has(triangle.objectId)) continue;
    checkedTriangles++;
    let failure;
    if (triangle.minX < 0 || triangle.minY < 0 || triangle.maxX > cols * 8 || triangle.maxY > rows * 8) {
      const at = [0, 2, 4].find((i) => triangle.points[i] < 0 || triangle.points[i] > cols * 8 || triangle.points[i + 1] < 0 || triangle.points[i + 1] > rows * 8);
      failure = { reason: "source-footprint-outside-frame", point: { x: triangle.points[at], y: triangle.points[at + 1] } };
    } else for (let row = Math.max(0, Math.floor(triangle.minY / 8)); row < Math.min(rows, Math.ceil(triangle.maxY / 8)) && !failure; row++) {
      for (let col = Math.max(0, Math.floor(triangle.minX / 8)); col < Math.min(cols, Math.ceil(triangle.maxX / 8)); col++) if (!matter[row * cols + col]) {
        voidCellTests++;
        if (overlapsCell(triangle, col, row)) {
          failure = { reason: "source-footprint-over-final-void", point: { x: col * 8 + 4, y: row * 8 + 4 } };
          break;
        }
      }
    }
    if (failure) {
      failed.add(triangle.objectId);
      unsupportedSources.push({ instanceId: triangle.objectId, role: terrain.roles.get(triangle.objectId) ?? "unknown", ...failure });
    }
  }
  return { accepted: !unsupportedSources.length, reasons: unsupportedSources.length ? ["final-source-footprint-unsupported"] : [], metrics: { finalSourceSupportViolationCount: unsupportedSources.length, unsupportedSources, finalSourceSupportCheckedTriangles: checkedTriangles, finalSourceSupportVoidCellTests: voidCellTests } };
}

// src/generation/world-study/native-spatial-bay-measure.ts
var EDGE_INFLUENCE_PX = Math.ceil(68 * 1.3 * 1.2 * 1.44 * 2) + 8;
var inside2 = (rects, x, y) => rects.some((r) => x >= r[0] && y >= r[1] && x < r[0] + r[2] && y < r[1] + r[3]);
function intersection(a, b) {
  const x = Math.max(a[0], b[0]), y = Math.max(a[1], b[1]), w = Math.min(a[0] + a[2], b[0] + b[2]) - x, h = Math.min(a[1] + a[3], b[1] + b[3]) - y;
  return w > 0 && h > 0 ? [x, y, w, h] : void 0;
}
function area2(rects) {
  const xs = [...new Set(rects.flatMap((r) => [r[0], r[0] + r[2]]))].sort((a, b) => a - b);
  let result = 0;
  for (let i = 1; i < xs.length; i++) {
    const x = (xs[i - 1] + xs[i]) / 2, spans = rects.filter((r) => x > r[0] && x < r[0] + r[2]).map((r) => [r[1], r[1] + r[3]]).sort((a, b) => a[0] - b[0]);
    let end = -Infinity, length2 = 0;
    for (const [a, b] of spans) {
      length2 += Math.max(0, b - Math.max(a, end));
      end = Math.max(end, b);
    }
    result += (xs[i] - xs[i - 1]) * length2;
  }
  return result;
}
function bounds(rects) {
  return { minX: Math.min(...rects.map((r) => r[0])), minY: Math.min(...rects.map((r) => r[1])), maxX: Math.max(...rects.map((r) => r[0] + r[2])), maxY: Math.max(...rects.map((r) => r[1] + r[3])) };
}
function validSource(land, bay) {
  const { points, outward } = bay.sourceShore;
  if (points.length < 2 || Math.abs(outward.x) + Math.abs(outward.y) !== 1 || outward.x !== 0 && outward.y !== 0) return false;
  for (let i = 1; i < points.length; i++) {
    const a = points[i - 1], b = points[i], dx = b.x - a.x, dy = b.y - a.y;
    if (dx === 0 && dy === 0 || dx !== 0 && dy !== 0) return false;
    const length2 = Math.abs(dx) + Math.abs(dy);
    if (dx * outward.x + dy * outward.y !== 0) return false;
    for (let at = 0; at < length2; at += 8) {
      const t = (at + Math.min(8, length2 - at) / 2) / length2, x = a.x + dx * t, y = a.y + dy * t;
      if (inside2(land, x + outward.x * 0.5, y + outward.y * 0.5) || !inside2(land, x - outward.x * 0.5, y - outward.y * 0.5)) return false;
      if (!inside2(bay.rects, x - outward.x * 0.5, y - outward.y * 0.5)) return false;
    }
  }
  return true;
}
function backland(land, allCuts, removed, normal, required) {
  if (!removed.length) return 0;
  const horizontal = normal.x !== 0, sign = horizontal ? normal.x : normal.y, tangents = [...new Set(removed.flatMap((r) => horizontal ? [r[1], r[1] + r[3]] : [r[0], r[0] + r[2]]))].sort((a, b) => a - b);
  let minimum = Infinity;
  for (let i = 1; i < tangents.length; i++) {
    const tangent = (tangents[i - 1] + tangents[i]) / 2, strips = removed.filter((r) => horizontal ? tangent > r[1] && tangent < r[1] + r[3] : tangent > r[0] && tangent < r[0] + r[2]);
    if (!strips.length) continue;
    const tip = Math.max(...strips.map((r) => sign > 0 ? horizontal ? r[0] + r[2] : r[1] + r[3] : -(horizontal ? r[0] : r[1]))), point = horizontal ? { x: tip * sign, y: tangent } : { x: tangent, y: tip * sign };
    const breaks = [.../* @__PURE__ */ new Set([0, required, ...[...land, ...allCuts].flatMap((r) => horizontal ? [(r[0] - point.x) / sign, (r[0] + r[2] - point.x) / sign] : [(r[1] - point.y) / sign, (r[1] + r[3] - point.y) / sign])])].filter((v) => v >= 0 && v <= required).sort((a, b) => a - b);
    let reached = 0;
    for (let j = 1; j < breaks.length; j++) {
      const end = breaks[j], d = (breaks[j - 1] + end) / 2, x = point.x + normal.x * d, y = point.y + normal.y * d;
      if (!inside2(land, x, y) || inside2(allCuts, x, y)) break;
      reached = end;
    }
    minimum = Math.min(minimum, reached);
  }
  return Number.isFinite(minimum) ? minimum : 0;
}
function evaluateNativeSpatialBays(geometry, groups, input) {
  const { cols, rows, matter } = geometry.terrain, count = cols * rows, land = input.landRects, cuts = input.placements.flatMap((b) => b.rects), profileById = new Map(input.profiles.map((p) => [p.id, p]));
  const point = (cell) => ({ x: (cell % cols + 0.5) * 8, y: (Math.floor(cell / cols) + 0.5) * 8 }), landMask = new Uint8Array(count), externalLabels = /* @__PURE__ */ new Set();
  for (let cell = 0; cell < count; cell++) {
    const p = point(cell);
    landMask[cell] = Number(inside2(land, p.x, p.y));
    if (cell < cols || cell >= count - cols || cell % cols === 0 || cell % cols === cols - 1) externalLabels.add(groups.holeLabelByCell[cell]);
  }
  const overallReasons = [];
  if (!input.allowedCounts.includes(input.placements.length)) overallReasons.push("bay-count-outside-frozen-domain");
  for (const join of input.landJoins) {
    const parent = land[join.parentIndex], child = land[join.childIndex], valid = parent && child && join.rect[2] >= input.minWideJoinPx && join.rect[3] >= input.minWideJoinPx && intersection(parent, join.rect) && intersection(child, join.rect);
    if (!valid || area2([intersection(parent, join.rect)].filter(Boolean)) !== join.rect[2] * join.rect[3] || area2([intersection(child, join.rect)].filter(Boolean)) !== join.rect[2] * join.rect[3]) {
      overallReasons.push("bay-invalid-wide-join");
      continue;
    }
    if (cuts.some((cut) => intersection(join.rect, cut))) overallReasons.push("bay-cut-wide-join");
  }
  const localCellsByBay = [];
  const records2 = input.placements.map((bay) => {
    const profile = profileById.get(bay.profileId), reasons2 = [], removed = land.flatMap((l) => bay.rects.flatMap((r) => {
      const v = intersection(l, r);
      return v ? [v] : [];
    })), removedLandAreaPx2 = area2(removed), box2 = bounds(bay.rects);
    const source = bay.sourceShore.points[0] ?? { x: NaN, y: NaN }, outward = bay.sourceShore.outward, normal = { x: -outward.x, y: -outward.y }, tangent = { x: -normal.y, y: normal.x };
    const sourceProjection = bay.sourceShore.points.map((p) => p.x * tangent.x + p.y * tangent.y), mouthPx = Math.max(...sourceProjection) - Math.min(...sourceProjection), unionSpanPx = Math.max(box2.maxX - box2.minX, box2.maxY - box2.minY);
    const depthPx = removed.length ? Math.max(...removed.flatMap(([x, y, w, h]) => [{ x, y }, { x: x + w, y: y + h }].map((p) => (p.x - source.x) * normal.x + (p.y - source.y) * normal.y))) : 0;
    if (!profile) reasons2.push("bay-profile-missing");
    if (!validSource(land, bay)) reasons2.push("bay-no-source-shore");
    if (!removedLandAreaPx2) reasons2.push("bay-no-real-land-loss");
    const backlandPx = profile ? backland(land, cuts, removed, normal, profile.minBacklandPx) : 0;
    if (profile && (bay.rects.length < profile.minRectCount || bay.rects.length > profile.maxRectCount || unionSpanPx > profile.maxUnionSpanPx || removedLandAreaPx2 < profile.minRemovedLandAreaPx2 || removedLandAreaPx2 > profile.maxRemovedLandAreaPx2 || mouthPx < profile.minMouthPx || mouthPx > profile.maxMouthPx || depthPx < profile.minDepthPx || depthPx > profile.maxDepthPx)) reasons2.push("bay-profile-size");
    if (profile && backlandPx < profile.minBacklandPx) reasons2.push("bay-insufficient-backland");
    const rawDeleted = /* @__PURE__ */ new Set(), rawMask = new Uint8Array(count), localMask = new Uint8Array(count);
    for (let cell = 0; cell < count; cell++) {
      const p = point(cell), inBay = inside2(bay.rects, p.x, p.y), inEnvelope = p.x >= box2.minX - EDGE_INFLUENCE_PX && p.x <= box2.maxX + EDGE_INFLUENCE_PX && p.y >= box2.minY - EDGE_INFLUENCE_PX && p.y <= box2.maxY + EDGE_INFLUENCE_PX;
      rawMask[cell] = Number(landMask[cell] && inBay);
      localMask[cell] = Number(!matter[cell] && inEnvelope);
      if (rawMask[cell] && !matter[cell]) {
        rawDeleted.add(cell);
      }
    }
    if (!rawDeleted.size) reasons2.push("bay-no-final-land-loss");
    if ([...rawDeleted].some((cell) => !externalLabels.has(groups.holeLabelByCell[cell]))) reasons2.push("bay-sealed");
    const grid = (mask) => ({ cols, rows, tileSize: 8, version: 0, isWalkable: (x, y) => x >= 0 && y >= 0 && x < cols && y < rows && mask[y * cols + x] === 1 });
    const localGrid = grid(localMask), rawGrid = grid(rawMask), oceanGrid = grid(Uint8Array.from(landMask, (v) => v ? 0 : 1)), half = (profile?.minFinalThroatPx ?? 64) / 2, centres = new Uint8Array(count), parent = new Int32Array(count).fill(-1), queue = [];
    for (let cell = 0; cell < count; cell++) if (localMask[cell]) {
      const p = point(cell);
      if (bodyHasSupport(localGrid, p, half, half)) {
        centres[cell] = 1;
        if (rawMask[cell] && bodyHasSupport(rawGrid, p, half, half)) {
          parent[cell] = cell;
          queue.push(cell);
        }
      }
    }
    let terminal = -1;
    for (let at = 0; at < queue.length && terminal < 0; at++) {
      const cell = queue[at], p = point(cell);
      if (!landMask[cell] && bodyHasSupport(oceanGrid, p, half, half) && (p.x - source.x) * outward.x + (p.y - source.y) * outward.y >= half) {
        terminal = cell;
        break;
      }
      const x = cell % cols, y = Math.floor(cell / cols);
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = x + dx, ny = y + dy, n = ny * cols + nx;
        if (nx >= 0 && ny >= 0 && nx < cols && ny < rows && centres[n] && parent[n] === -1 && bodyDisplacementFraction(localGrid, p, half, half, dx * 8, dy * 8) >= 1) {
          parent[n] = cell;
          queue.push(n);
        }
      }
    }
    if (terminal < 0) reasons2.push("bay-mouth-too-thin");
    let start = terminal, routeSteps = 0;
    if (start >= 0) while (parent[start] !== start) {
      start = parent[start];
      routeSteps++;
    }
    const finalCells = [...rawDeleted], localVisited = new Set(finalCells);
    for (let at = 0; at < finalCells.length; at++) {
      const cell = finalCells[at], x = cell % cols, y = Math.floor(cell / cols);
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = x + dx, ny = y + dy, next = ny * cols + nx;
        if (nx >= 0 && ny >= 0 && nx < cols && ny < rows && localMask[next] && landMask[next] && !localVisited.has(next)) {
          localVisited.add(next);
          finalCells.push(next);
        }
      }
    }
    localCellsByBay.push(localVisited);
    return {
      bayId: bay.bayId,
      profileId: bay.profileId,
      sourceShore: bay.sourceShore,
      sourceRects: bay.rects,
      removedLandAreaPx2,
      unionSpanPx,
      mouthPx,
      depthPx,
      backlandPx,
      finalRawCutVoidAreaPx2: rawDeleted.size * 64,
      finalLocalVoidAreaPx2: finalCells.length * 64,
      finalLocalVoidBounds: finalCells.length ? bounds(finalCells.map((cell) => {
        const p = point(cell);
        return [p.x - 4, p.y - 4, 8, 8];
      })) : null,
      throatSquarePx: half * 2,
      throatStart: start < 0 ? null : point(start),
      throatEnd: terminal < 0 ? null : point(terminal),
      throatRoutePx: routeSteps * 8,
      edgeInfluenceBoundPx: EDGE_INFLUENCE_PX,
      reasons: reasons2
    };
  });
  for (let a = 0; a < records2.length; a++) for (let b = a + 1; b < records2.length; b++) if (records2[a].bayId === records2[b].bayId || [...localCellsByBay[a]].some((cell) => localCellsByBay[b].has(cell))) {
    records2[a].reasons.push("bay-merged-inside-positive-land");
    records2[b].reasons.push("bay-merged-inside-positive-land");
  }
  const globalViolationCount = overallReasons.length;
  overallReasons.push(...records2.flatMap((row) => row.reasons));
  const reasons = [...new Set(overallReasons)];
  return { accepted: !reasons.length, reasons, metrics: { bayCount: records2.length, bayMeasurements: records2, bayViolationCount: records2.filter((row) => row.reasons.length).length + globalViolationCount, positiveLandAreaPx2: area2(land) } };
}

// src/generation/world-study/native-spatial-measure.ts
var CELL = 8;
var CORNER_ERROR = Math.SQRT2 * 4;
var Groups = class {
  parent;
  constructor(count) {
    this.parent = Array.from({ length: count }, (_, i) => i);
  }
  root(i) {
    while (this.parent[i] !== i) {
      this.parent[i] = this.parent[this.parent[i]];
      i = this.parent[i];
    }
    return i;
  }
  join(a, b) {
    a = this.root(a);
    b = this.root(b);
    if (a !== b) this.parent[Math.max(a, b)] = Math.min(a, b);
  }
};
function components(mask, cols, rows, links) {
  const seen = new Uint8Array(mask.length), result = [];
  for (let start = 0; start < mask.length; start++) if (mask[start] && !seen[start]) {
    const group = [start];
    seen[start] = 1;
    for (let at = 0; at < group.length; at++) {
      const cell = group[at], x = cell % cols, y = Math.floor(cell / cols);
      for (let d = 0; d < (links ? 8 : 4); d++) {
        if (links && !(links[cell] & 1 << d)) continue;
        const [dx, dy] = NATIVE_SPATIAL_DIRECTIONS[d], nx = x + dx, ny = y + dy, next = ny * cols + nx;
        if (nx < 0 || ny < 0 || nx >= cols || ny >= rows || !mask[next] || seen[next]) continue;
        seen[next] = 1;
        group.push(next);
      }
    }
    result.push(group);
  }
  return result;
}
function bounds2(primitives) {
  return { minX: Math.min(...primitives.map((p) => p.minX)), minY: Math.min(...primitives.map((p) => p.minY)), maxX: Math.max(...primitives.map((p) => p.maxX)), maxY: Math.max(...primitives.map((p) => p.maxY)) };
}
function nearbyReachable(cells, geometry) {
  const { cols, rows } = geometry.terrain;
  return cells.some((cell) => {
    const x = cell % cols, y = Math.floor(cell / cols);
    for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) {
      const nx = x + dx, ny = y + dy;
      if (nx >= 0 && ny >= 0 && nx < cols && ny < rows && geometry.reachable[ny * cols + nx]) return true;
    }
    return false;
  });
}
function cellInsideTriangle(x, y, triangle, half = 4) {
  const p = triangle.points;
  if (p.length !== 6) return false;
  if (x - half < triangle.minX || x + half > triangle.maxX || y - half < triangle.minY || y + half > triangle.maxY) return false;
  return [[-half, -half], [half, -half], [-half, half], [half, half]].every(([dx, dy]) => {
    const px = x + dx, py = y + dy, cross4 = (i, j) => (p[j] - p[i]) * (py - p[i + 1]) - (p[j + 1] - p[i + 1]) * (px - p[i]);
    const a = cross4(0, 2), b = cross4(2, 4), c = cross4(4, 0);
    return a >= -1e-7 && b >= -1e-7 && c >= -1e-7 || a <= 1e-7 && b <= 1e-7 && c <= 1e-7;
  });
}
function bodyGapClosed(a, b) {
  if (a.maxX + 20 <= b.minX || b.maxX + 20 <= a.minX || a.maxY + 20 <= b.minY || b.maxY + 20 <= a.minY) return false;
  const axes = [[1, 0], [0, 1]];
  for (const triangle of [a, b]) for (let i = 0; i < 6; i += 2) {
    const j = (i + 2) % 6;
    axes.push([triangle.points[j + 1] - triangle.points[i + 1], -(triangle.points[j] - triangle.points[i])]);
  }
  for (const [nx, ny] of axes) {
    if (Math.abs(nx) + Math.abs(ny) < 1e-9) continue;
    const projection = (p) => [0, 2, 4].map((i) => p.points[i] * nx + p.points[i + 1] * ny), pa = projection(a), pb = projection(b), padding = 20 * (Math.abs(nx) + Math.abs(ny));
    if (Math.max(...pa) + padding <= Math.min(...pb) + 1e-7 || Math.max(...pb) + padding <= Math.min(...pa) + 1e-7) return false;
  }
  return true;
}
function identifyNativeSpatialStructures(geometry, assemblies, policy) {
  const { cols, rows, matter } = geometry.terrain, count = cols * rows, rejected = [];
  const identities = identifyNativeSpatialVoid(matter, cols, rows), voidLabels = identities.labels;
  const holeCells = identities.cellsByLabel, exterior = identities.exteriorLabels;
  const structures = [];
  let exteriorVoidCells = 0;
  for (const [label, cells] of holeCells) {
    if (exterior.has(label)) {
      exteriorVoidCells += cells.length;
      continue;
    }
    const boundary = nativeVoidCellBoundary(cells, cols, rows, label), tree = nativePrimitiveTree(boundary), id = `H-${Math.min(...cells)}`;
    let core = 0;
    for (const cell of cells) {
      const p = nativeCellPoint(cell, cols);
      core = Math.max(core, nativePrimitiveDistance(tree, p.x, p.y));
    }
    const reasons = [];
    if (core < policy.minHoleCoreRadiusPx) reasons.push("hole-has-no-thick-core");
    if (!nearbyReachable(cells, geometry)) reasons.push("hole-is-not-approachable");
    if (reasons.length) {
      rejected.push({ id, reasons });
      continue;
    }
    structures.push({
      id,
      kind: "hole",
      assemblyIds: [],
      instanceIds: [],
      cells,
      boundary,
      bounds: bounds2(boundary),
      areaLowerPx2: cells.length * 64,
      areaUpperPx2: cells.length * 64,
      componentCount: identities.componentCountByLabel.get(label),
      thickRadiusLowerPx: core,
      distance: (p) => nativePrimitiveDistance(tree, p.x, p.y)
    });
  }
  const ids = /* @__PURE__ */ new Set(), assemblyCells = [], assemblyPrimitives = [];
  for (const assembly of assemblies) {
    for (const id of assembly.instanceIds) {
      if (ids.has(id)) throw new Error(`Solid ${id} belongs to more than one authored assembly`);
      ids.add(id);
    }
    const idSet = new Set(assembly.instanceIds), primitives = geometry.solidPrimitives.filter((p) => idSet.has(p.objectId)), tree = nativePrimitiveTree(primitives), box2 = bounds2(primitives), cells = [];
    if (!primitives.length) throw new Error(`Assembly ${assembly.assemblyId} contains no actual solid footprint`);
    if (Math.max(box2.maxX - box2.minX, box2.maxY - box2.minY) > assembly.maxSpanPx) throw new Error(`Assembly ${assembly.assemblyId} exceeds its authored span`);
    for (let y = Math.max(0, Math.floor(box2.minY / 8)); y < Math.min(rows, Math.ceil(box2.maxY / 8)); y++) for (let x = Math.max(0, Math.floor(box2.minX / 8)); x < Math.min(cols, Math.ceil(box2.maxX / 8)); x++) {
      const p = nativeCellPoint(y * cols + x, cols);
      if (nativePrimitiveDistance(tree, p.x, p.y) <= CORNER_ERROR) cells.push(y * cols + x);
    }
    assemblyCells.push(cells);
    assemblyPrimitives.push(primitives);
  }
  for (const instance of geometry.terrain.definition.instances) if (instance.role === "solid" && !ids.has(instance.id)) throw new Error(`Solid ${instance.id} has no frozen assembly identity`);
  const solidGroups = new Groups(assemblies.length);
  for (let a = 0; a < assemblies.length; a++) for (let b = a + 1; b < assemblies.length; b++) {
    if (assemblyPrimitives[a].some((pa) => assemblyPrimitives[b].some((pb) => bodyGapClosed(pa, pb)))) solidGroups.join(a, b);
  }
  const grouped = /* @__PURE__ */ new Map();
  assemblies.forEach((_, i) => {
    const root = solidGroups.root(i), list = grouped.get(root) ?? [];
    list.push(i);
    grouped.set(root, list);
  });
  for (const indices of grouped.values()) {
    const primitives = indices.flatMap((i) => assemblyPrimitives[i]), tree = nativePrimitiveTree(primitives), box2 = bounds2(primitives), cells = [...new Set(indices.flatMap((i) => assemblyCells[i]))], mask = new Uint8Array(count);
    let lower = 0;
    for (const cell of cells) {
      mask[cell] = 1;
      const p = nativeCellPoint(cell, cols);
      if (primitives.some((triangle) => cellInsideTriangle(p.x, p.y, triangle))) lower += 64;
      else for (let dy = -3; dy <= 3; dy += 2) for (let dx = -3; dx <= 3; dx += 2) if (primitives.some((triangle) => cellInsideTriangle(p.x + dx, p.y + dy, triangle, 1))) lower += 4;
    }
    const id = `S-${indices.map((i) => assemblies[i].assemblyId).sort().join("+")}`, reasons = [];
    if (lower < policy.minSolidAreaPx2) reasons.push("solid-effective-area-too-small");
    if (Math.max(box2.maxX - box2.minX, box2.maxY - box2.minY) < policy.minSolidSpanPx) reasons.push("solid-effective-span-too-small");
    if (!nearbyReachable(cells, geometry)) reasons.push("solid-is-not-approachable");
    if (reasons.length) {
      rejected.push({ id, reasons });
      continue;
    }
    structures.push({
      id,
      kind: "solid",
      assemblyIds: indices.map((i) => assemblies[i].assemblyId),
      instanceIds: indices.flatMap((i) => assemblies[i].instanceIds),
      cells,
      boundary: primitives,
      bounds: box2,
      areaLowerPx2: lower,
      areaUpperPx2: cells.length * 64,
      componentCount: components(mask, cols, rows).length,
      thickRadiusLowerPx: 0,
      distance: (p) => nativePrimitiveDistance(tree, p.x, p.y)
    });
  }
  structures.sort((a, b) => a.id.localeCompare(b.id));
  return { structures, rejected, exteriorVoidCells, holeLabelByCell: voidLabels };
}
function evaluateNativeSpatialGeometry(geometry, groups, policy, world, holeAuthoring, bayAuthoring, observe) {
  const { cols, rows } = geometry.terrain, structuralTree = nativePrimitiveTree(groups.structures.flatMap((s) => s.boundary)), count = cols * rows;
  const wide = new Uint8Array(count), deep = new Uint8Array(count), distances = new Float32Array(count);
  let maxEmptyUpperPx = 0, internalMaxEmptyUpperPx = 0, wideCount = 0;
  let worstCell = -1, internalWorstCell = -1;
  for (let cell = 0; cell < count; cell++) if (geometry.supported[cell]) {
    const p = nativeCellPoint(cell, cols), distance3 = nativePrimitiveDistance(structuralTree, p.x, p.y);
    distances[cell] = distance3;
    if (distance3 + CORNER_ERROR > internalMaxEmptyUpperPx) {
      internalMaxEmptyUpperPx = distance3 + CORNER_ERROR;
      internalWorstCell = cell;
    }
    const openDistance = Math.min(geometry.solidDistance(p), geometry.voidDistance(p));
    if (openDistance + CORNER_ERROR > maxEmptyUpperPx) {
      maxEmptyUpperPx = openDistance + CORNER_ERROR;
      worstCell = cell;
    }
    deep[cell] = Number(distance3 + CORNER_ERROR > policy.deepEmptyThresholdPx);
    if (openDistance >= policy.wideRadiusPx) {
      wide[cell] = 1;
      wideCount++;
    }
  }
  const deepBody = new Uint8Array(count);
  for (let cell = 0; cell < count; cell++) if (deep[cell]) {
    const x = cell % cols, y = Math.floor(cell / cols);
    let all = true;
    for (let dy = -1; dy <= 1 && all; dy++) for (let dx = -1; dx <= 1; dx++) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= cols || ny >= rows || !deep[ny * cols + nx]) {
        all = false;
        break;
      }
    }
    deepBody[cell] = Number(all);
  }
  const deepGroups = components(deepBody, cols, rows, geometry.links8), wideGroups = components(wide, cols, rows, geometry.links8);
  let maxDeepSpanPx = 0, worstDeepCell = -1, worstDeepBounds = null;
  for (const cells of deepGroups) {
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const cell of cells) {
      const p = nativeCellPoint(cell, cols);
      minX = Math.min(minX, p.x);
      minY = Math.min(minY, p.y);
      maxX = Math.max(maxX, p.x);
      maxY = Math.max(maxY, p.y);
    }
    const span = Math.max(maxX - minX + 8, maxY - minY + 8);
    if (span > maxDeepSpanPx) {
      maxDeepSpanPx = span;
      worstDeepBounds = { minX: minX - 4, minY: minY - 4, maxX: maxX + 4, maxY: maxY + 4 };
      const cx = (minX + maxX) / 2, cy = (minY + maxY) / 2;
      let distance3 = Infinity;
      for (const cell of cells) {
        const p = nativeCellPoint(cell, cols), d = (p.x - cx) ** 2 + (p.y - cy) ** 2;
        if (d < distance3 || d === distance3 && cell < worstDeepCell) {
          distance3 = d;
          worstDeepCell = cell;
        }
      }
    }
  }
  const holes = groups.structures.filter((s) => s.kind === "hole").length, solids = groups.structures.filter((s) => s.kind === "solid").length, walkAreaPx2 = geometry.supportedCount * 64;
  const wideRatio = wideCount / geometry.supportedCount, largestWideRatio = wideCount ? Math.max(0, ...wideGroups.map((c) => c.length)) / wideCount : 0;
  if (observe) observe({
    cols,
    rows,
    cellSizePx: CELL,
    deepThresholdPx: policy.deepEmptyThresholdPx,
    distanceCellUpperErrorPx: CORNER_ERROR,
    deep: deep.slice(),
    deepBody: deepBody.slice(),
    wide: wide.slice(),
    distances: distances.slice(),
    deepComponents: deepGroups.map((cells) => [...cells])
  });
  const reasons = [];
  const targetCount = Math.round(world.targetWalkAreaPx2 / (policy.planningCellFactor * policy.spacingPx * policy.spacingPx));
  const minCount = Math.ceil(targetCount * (1 - policy.countToleranceRatio)), maxCount = Math.floor(targetCount * (1 + policy.countToleranceRatio));
  if (holes + solids < minCount || holes + solids > maxCount) reasons.push("effective-structure-count-outside-intent");
  if (groups.rejected.length) reasons.push("ineffective-spatial-objects");
  if (geometry.reachableCount !== geometry.supportedCount) reasons.push("disconnected-body-domain");
  if (Math.abs(walkAreaPx2 - world.targetWalkAreaPx2) > world.targetWalkAreaPx2 * policy.areaToleranceRatio) reasons.push("walk-area-outside-intent");
  if (solids < policy.minSolidCount || policy.requireMoreHoles && holes <= solids || Math.abs(holes - policy.holeToSolidRatio * solids) > Math.max(policy.holeCountAbsTolerance, policy.holeCountRelTolerance * solids)) reasons.push("whole-world-hole-solid-ratio");
  if (maxEmptyUpperPx > policy.maxEmptyRadiusPx) reasons.push("G1-largest-empty-radius");
  if (maxDeepSpanPx > policy.maxDeepEmptySpanPx) reasons.push("G1-long-deep-empty-region");
  if (wideRatio < policy.minWideRatio) reasons.push("G3-wide-domain-area");
  if (largestWideRatio < policy.minLargestWideRatio) reasons.push("G3-wide-domain-connectivity");
  const holeContract = holeAuthoring ? evaluateNativeSpatialHoleProfiles(geometry, groups, holeAuthoring.placements, holeAuthoring.profiles) : void 0;
  if (holeContract) reasons.push(...holeContract.reasons);
  const bayContract = bayAuthoring ? evaluateNativeSpatialBays(geometry, groups, bayAuthoring) : void 0;
  if (bayContract) reasons.push(...bayContract.reasons);
  const sourceSupport = evaluateNativeSpatialFinalSupport(geometry);
  reasons.push(...sourceSupport.reasons);
  return { accepted: !reasons.length, reasons, metrics: {
    holes,
    solids,
    targetCount,
    minCount,
    maxCount,
    walkAreaPx2,
    targetWalkAreaPx2: world.targetWalkAreaPx2,
    maxEmptyUpperPx,
    maxDeepSpanPx,
    worstEmptyPoint: worstCell < 0 ? null : nativeCellPoint(worstCell, cols),
    internalMaxEmptyUpperPx,
    internalWorstEmptyPoint: internalWorstCell < 0 ? null : nativeCellPoint(internalWorstCell, cols),
    worstDeepPoint: worstDeepCell < 0 ? null : nativeCellPoint(worstDeepCell, cols),
    worstDeepBounds,
    wideRatio,
    largestWideRatio,
    reachableBodySeats: geometry.reachableCount,
    supportedBodySeats: geometry.supportedCount,
    effectiveStructures: groups.structures.map(({ distance: _distance, boundary: _boundary, cells: _cells, ...structure }) => structure),
    rejectedObjects: groups.rejected,
    ...holeContract?.metrics ?? {},
    ...bayContract?.metrics ?? {},
    ...sourceSupport.metrics,
    cellSizePx: 8,
    distanceCellUpperErrorPx: CORNER_ERROR
  } };
}
function evaluateNativeSpatialHoleProfiles(geometry, groups, placements, profiles) {
  const { cols, rows, definition } = geometry.terrain, labels = groups.holeLabelByCell;
  const profileById = new Map(profiles.map((p) => [p.id, p]));
  const identity = identifyNativeSpatialHoles(cols, rows, labels, definition.erosion ?? [], placements);
  const unionArea = (rects) => {
    const xs = [...new Set(rects.flatMap((r) => [r[0], r[0] + r[2]]))].sort((a, b) => a - b);
    let area3 = 0;
    for (let i = 1; i < xs.length; i++) {
      const x = (xs[i - 1] + xs[i]) / 2, spans = rects.filter((r) => x > r[0] && x < r[0] + r[2]).map((r) => [r[1], r[1] + r[3]]).sort((a, b) => a[0] - b[0]);
      let end = -Infinity, length2 = 0;
      for (const [a, b] of spans) {
        length2 += Math.max(0, b - Math.max(a, end));
        end = Math.max(end, b);
      }
      area3 += (xs[i] - xs[i - 1]) * length2;
    }
    return area3;
  };
  const records2 = placements.map((placement, index) => {
    const profile = profileById.get(placement.profileId), reasons2 = [];
    const association = identity.records[index], { finalLabel, stat } = association;
    const loops = association.contourIndices.map((index2) => ({ loop: definition.erosion[index2], index: index2 }));
    if (!profile) reasons2.push("hole-profile-missing");
    if (!association.valid) reasons2.push("hole-profile-final-identity");
    const sourceSpanPx = placement.rects.length ? Math.max(Math.max(...placement.rects.map((r) => r[0] + r[2])) - Math.min(...placement.rects.map((r) => r[0])), Math.max(...placement.rects.map((r) => r[1] + r[3])) - Math.min(...placement.rects.map((r) => r[1]))) : Infinity;
    const sourceAreaPx2 = unionArea(placement.rects), finalAreaPx2 = stat?.area ?? Infinity, finalSpanPx = stat ? Math.max(stat.maxX - stat.minX, stat.maxY - stat.minY) : Infinity;
    const contourPoints = loops.flatMap(({ loop }) => loop), contourSpanPx = contourPoints.length ? Math.max(Math.max(...contourPoints.map((p) => p.x)) - Math.min(...contourPoints.map((p) => p.x)), Math.max(...contourPoints.map((p) => p.y)) - Math.min(...contourPoints.map((p) => p.y))) : Infinity;
    const contourAreaPx2 = loops.reduce((sum, { loop }) => sum + Math.abs(loop.reduce((a, p, i) => {
      const q = loop[(i + 1) % loop.length];
      return a + p.x * q.y - q.x * p.y;
    }, 0)) / 2, 0);
    if (profile) {
      if (sourceAreaPx2 > profile.maxAreaPx2 || finalAreaPx2 > profile.maxAreaPx2 || contourAreaPx2 > profile.maxAreaPx2) reasons2.push("hole-profile-area");
      if (sourceSpanPx > profile.maxSpanPx || finalSpanPx > profile.maxSpanPx || contourSpanPx > profile.maxSpanPx) reasons2.push("hole-profile-span");
    }
    return { holeId: placement.holeId, profileId: placement.profileId, finalLabel, contourIndices: loops.map((row) => row.index), sourceAreaPx2, sourceSpanPx, finalAreaPx2, finalSpanPx, contourAreaPx2, contourSpanPx, reasons: reasons2 };
  });
  records2.forEach((row, index) => {
    if (identity.records[index].duplicate) row.reasons.push("hole-profile-merged-identity");
  });
  const { orphanLabels, orphanContours } = identity;
  const reasons = [...new Set(records2.flatMap((row) => row.reasons))];
  if (orphanLabels.length || orphanContours.length) reasons.push("hole-profile-unassigned-final-hole");
  return { accepted: !reasons.length, reasons, metrics: { holeProfileMeasurements: records2, holeProfileViolationCount: records2.filter((row) => row.reasons.length).length + orphanLabels.length + orphanContours.length, orphanHoleLabels: orphanLabels, orphanHoleContours: orphanContours } };
}

// src/generation/world-study/native-spatial-route-feedback.ts
function records(gate) {
  const routes = gate.metrics.routes;
  if (!Array.isArray(routes)) return [];
  return routes;
}
function routeLayout(probe) {
  return { spawnPoint: probe.spawnPoint, extractionPoint: { position: probe.exitPoint }, kindlingNodes: probe.nodes.filter((n) => n.kind === "kindling"), contaminantNodes: probe.nodes.filter((n) => n.kind === "contaminant") };
}
function pointAt(points, at) {
  if (!points.length) throw new Error("Native route witness has no actual path");
  let left = Math.max(0, at);
  for (let i = 1; i < points.length; i++) {
    const a = points[i - 1], b = points[i], span = Math.hypot(b.x - a.x, b.y - a.y);
    if (left <= span) {
      const t = span ? left / span : 0;
      return { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t };
    }
    left -= span;
  }
  return { ...points[points.length - 1] };
}
function nativeSpatialRouteViolationVector(probe, gate, policy) {
  const routes = records(gate), byId = new Map(routes.map((r) => [r.id, r])), reasons = [], violations = [];
  for (const id of probe.baselineEligibleRouteIds) if (!byId.get(id)?.eligible) reasons.push(`${id}:lost-baseline-eligibility`);
  for (const id of probe.baselineExploreRouteIds) if (!byId.has(id)) reasons.push(`${id}:lost-baseline-region`);
  for (const node of probe.nodes) if (!byId.has(`node:${node.id}`)) reasons.push(`node:${node.id}:lost-legal-seat`);
  if (!byId.has("direct-exit")) reasons.push("direct-exit:missing");
  if (!routes.some((route) => route.eligible)) reasons.push("insufficient-complete-route-encounter-evidence");
  const ids = ["direct-exit", ...probe.nodes.map((n) => `node:${n.id}`), ...Array.from({ length: 12 }, (_, i) => `explore:${i}`)];
  for (const id of ids) {
    const r = byId.get(id);
    if (!r) {
      violations.push(0, 0, 0, 0);
      continue;
    }
    let share = 0, window = 0;
    if (r.eligible) {
      const n = r.events.length, h = r.events.filter((e) => e.kind === "hole").length;
      let missing = Infinity;
      for (let k = 0; k <= n; k++) if (classifyNativeRouteHoleShare(k, n, policy).accepted) missing = Math.min(missing, Math.abs(k - h));
      share = missing / n;
      for (let i = 0; i + policy.windowSize <= n; i++) {
        const holes = r.events.slice(i, i + policy.windowSize).filter((e) => e.kind === "hole").length;
        window = Math.max(window, Math.max(0, policy.minWindowHoles - holes) / policy.minWindowHoles);
      }
    }
    violations.push(share, window, Math.max(0, r.transverse.narrowRatio / policy.maxNarrowRatio - 1), Math.max(0, r.transverse.maxNarrowOrUncertainRunPx / policy.maxNarrowRunPx - 1));
  }
  return { violations, comparabilityReasons: reasons };
}
function witnesses(gate, geometry, groups, ground, policy) {
  const structures = new Map(groups.structures.map((s) => [s.id, s]));
  const profiles = Array.isArray(ground.metrics.holeProfileMeasurements) ? ground.metrics.holeProfileMeasurements : [];
  const objectIds = (id) => {
    const s = structures.get(id);
    if (!s) return [];
    if (s.kind === "solid") return s.assemblyIds;
    const label = groups.holeLabelByCell[s.cells[0]];
    return profiles.filter((p) => p.finalLabel === label).map((p) => p.holeId);
  };
  const owner = (p) => {
    const matches = groups.structures.filter((s) => s.distance(p) < 1e-5);
    if (matches.length === 1) {
      const s = matches[0], ids = objectIds(s.id);
      return ids.length ? { kind: s.kind, structureId: s.id, objectIds: ids } : void 0;
    }
    if (matches.length === 0 && geometry.voidDistance(p) < 1e-5) return { kind: "exterior", objectIds: [] };
    return void 0;
  };
  const result = [];
  for (const r of records(gate)) {
    const events = r.events.map((e) => ({ structureId: e.id, kind: e.kind, at: e.at, point: pointAt(r.smoothedPoints, e.at), objectIds: objectIds(e.id) }));
    if (gate.reasons.includes(`${r.id}:hole-share`)) result.push({ routeId: r.id, kind: "hole-share", severity: 1, points: r.smoothedPoints, events });
    for (const offset of r.windowFailures) result.push({ routeId: r.id, kind: "window", severity: 1, points: r.smoothedPoints, events, windowEvents: events.slice(offset, offset + policy.windowSize) });
    if (!gate.reasons.includes(`${r.id}:narrow-transverse-opening`)) continue;
    let current = [], longest = [], length2 = 0, maxLength = -1;
    const keep = () => {
      if (length2 > maxLength) {
        maxLength = length2;
        longest = current;
      }
      current = [];
      length2 = 0;
    };
    for (const section2 of r.transverse.sections) {
      if (section2.kind === "wide") {
        keep();
        continue;
      }
      current.push(section2);
      length2 += Math.min(8, Math.max(0, r.lengthPx - section2.at));
    }
    keep();
    const crossSections2 = [];
    for (const s of longest) {
      if (!s.closed || s.kind !== "narrow" || s.widthLowerPx === void 0 || s.sides?.length !== 2) continue;
      const center = pointAt(r.smoothedPoints, s.at), a = pointAt(r.smoothedPoints, s.at - 32), b = pointAt(r.smoothedPoints, s.at + 32), dx = b.x - a.x, dy = b.y - a.y, n = Math.hypot(dx, dy);
      if (n < 1e-7) continue;
      const hits = [-1, 1].map((sign, i) => {
        const point = { x: center.x - dy / n * sign * s.sides[i], y: center.y + dx / n * sign * s.sides[i] };
        return { point, owner: owner(point) };
      });
      if (hits[0].owner && hits[1].owner) crossSections2.push({ at: s.at, center, widthLowerPx: s.widthLowerPx, closed: true, hits: [{ point: hits[0].point, owner: hits[0].owner }, { point: hits[1].point, owner: hits[1].owner }] });
    }
    crossSections2.sort((a, b) => a.widthLowerPx - b.widthLowerPx || a.at - b.at);
    result.push({ routeId: r.id, kind: "narrow", severity: Math.max(r.transverse.narrowRatio / policy.maxNarrowRatio, r.transverse.maxNarrowOrUncertainRunPx / policy.maxNarrowRunPx), points: r.smoothedPoints, events, crossSections: crossSections2 });
  }
  return result;
}
function assessNativeSpatialRouteFeedback(probe, gate, geometry, groups, ground, policy) {
  const score = nativeSpatialRouteViolationVector(probe, gate, policy), reasons = [...score.comparabilityReasons];
  for (const [id, point] of [["spawn", probe.spawnPoint], ["exit", probe.exitPoint]])
    if (!geometry.collision.supports(point, 10, 10)) reasons.push(`${id}:lost-body-support`);
  const comparable = reasons.length === 0, violations = score.violations;
  return {
    probe,
    gate,
    comparable,
    comparabilityReasons: reasons,
    violations,
    maximum: comparable ? Math.max(0, ...violations) : Infinity,
    sum: comparable ? violations.reduce((a, b) => a + b, 0) : Infinity,
    witnesses: comparable ? witnesses(gate, geometry, groups, ground, policy) : [],
    refinementOrdinal: 0,
    remainingTupleBudget: 48,
    seenTupleKeys: []
  };
}
function evaluateNativeSpatialRouteProbe(probe, geometry, groups, ground, policy, checkpoint) {
  checkpoint();
  const gate = evaluateNativeSpatialRoutes(geometry, groups.structures, policy, routeLayout(probe));
  checkpoint();
  const result = assessNativeSpatialRouteFeedback(probe, gate, geometry, groups, ground, policy);
  checkpoint();
  return result;
}

// src/generation/world-study/native-spatial-generation.ts
function createNativeSpatialGeometryWorkBudget(attempt, limit, checkpoint) {
  if (!Number.isSafeInteger(limit) || limit < 1) throw new Error("Invalid native geometry work budget");
  attempt.geometryWorkBudget = limit;
  attempt.finalGeometryEvaluations ??= 0;
  attempt.geometryWork ??= [];
  return { checkpoint, run(request, work) {
    checkpoint();
    if (attempt.geometryEvaluations >= limit) {
      attempt.stopReason = "geometry-work-budget";
      throw new NativeSpatialGeometryWorkBudgetError();
    }
    const started = performance.now(), measurementCount = attempt.finalGeometryEvaluations;
    const trace = { ...request, ...request.site ? { site: { ...request.site } } : {}, ordinal: ++attempt.geometryEvaluations, outcome: "running", elapsedMs: 0, reasons: [] };
    attempt.geometryWork.push(trace);
    try {
      const result = work();
      trace.outcome = result.accepted ? "accepted" : "rejected";
      trace.reasons = [...result.reasons];
      if (result.invalidHoleIds) trace.invalidHoleIds = [...result.invalidHoleIds];
      return result;
    } catch (error) {
      trace.outcome = "exception";
      trace.error = error instanceof Error ? error.message : String(error);
      throw error;
    } finally {
      trace.elapsedMs = performance.now() - started;
      if (request.kind === "final-geometry") trace.finalMeasurementStarted = attempt.finalGeometryEvaluations > measurementCount;
      try {
        checkpoint();
      } catch (error) {
        trace.deadlineExceeded = true;
        throw error;
      }
    }
  } };
}
function nativeSpatialGeometryFingerprint(geometry, layout) {
  const { terrain } = geometry;
  const canonical = JSON.stringify({
    cols: terrain.cols,
    rows: terrain.rows,
    matter: Array.from(terrain.matter),
    reachable: Array.from(geometry.reachable),
    meshes: terrain.meshes.map((mesh) => ({ seed: mesh.spec.seed, role: terrain.roles.get(mesh.spec.id), positions: Array.from(mesh.positions), indices: Array.from(mesh.indices) })),
    outline: terrain.definition.terrainOutline,
    erosion: terrain.definition.erosion,
    assemblies: layout.assemblies,
    holes: layout.holes,
    bays: layout.bays,
    landJoins: layout.landJoins
  });
  let a = 2166136261, b = 2654435769;
  for (let i = 0; i < canonical.length; i++) {
    const code = canonical.charCodeAt(i);
    a = Math.imul(a ^ code, 16777619);
    b = Math.imul(b ^ code, 2246822519);
  }
  return { hash: (a >>> 0).toString(16).padStart(8, "0") + (b >>> 0).toString(16).padStart(8, "0"), canonical };
}
export {
  buildNativeSpatialGeometry,
  createNativeSpatialActualVoidFeedback,
  createNativeSpatialGeometryWorkBudget,
  createNativeSpatialLayout,
  evaluateNativeSpatialGeometry,
  evaluateNativeSpatialRouteProbe,
  evaluateNativeSpatialVisibility,
  identifyNativeSpatialStructures,
  nativeSpatialGeometryFingerprint
};
