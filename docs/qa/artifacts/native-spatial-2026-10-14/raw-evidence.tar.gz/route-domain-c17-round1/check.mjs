// src/generation/world-study/native-volume-cellular.ts
var TAU = Math.PI * 2;
var uv = (point) => [point[0], point[1]];
var lerp = (a, b, t) => a + (b - a) * t;
function variation(seed, salt) {
  let value = Math.imul(seed ^ salt, 73244475);
  value = Math.imul(value ^ value >>> 16, 73244475);
  return ((value ^ value >>> 16) >>> 0) / 4294967296;
}
function buildCellularShell(builder) {
  const spec = builder.spec, count = Math.min(4, Math.max(2, spec.branches));
  for (let cell = 0; cell < count; cell++) {
    const scale = cell % 3 === 0 ? 1.25 : cell % 3 === 1 ? 0.91 : 0.9;
    const rx = spec.length / count * 0.45 * scale;
    const ry = spec.width * (cell % 3 === 0 ? 0.38 : cell % 3 === 1 ? 0.23 : 0.29);
    const ox = ((cell + 0.5) / count - 0.5) * spec.length;
    const oy = (cell % 2 ? -0.15 : 0.1) * spec.width;
    const opening = (cell % 2 ? -0.5 : 0.5) * Math.PI + (variation(spec.seed, 2700 + cell) - 0.5) * 0.27;
    const gap = 1.2 + spec.opening * 1.38 + (cell % 3 === 1 ? 0.9 : cell % 3 === 0 ? -0.26 : -0.43);
    const mouthBias = cell % 3 === 0 ? 0.32 : cell % 3 === 1 ? 0.62 : 0.38;
    const start = opening + gap * mouthBias, end = opening + TAU - gap * (1 - mouthBias);
    const steps = 48, rows = [];
    const phase2 = variation(spec.seed, 2730 + cell) * 0.6 + cell * 1.9;
    for (let index = 0; index <= steps; index++) {
      const t = index / steps, angle = lerp(start, end, t);
      const ca = Math.cos(angle), sa = Math.sin(angle);
      const shoulder = Math.pow(0.5 + 0.5 * Math.cos(angle - phase2), 3);
      const outerRadius = 0.94 + shoulder * (0.31 + spec.distortion * 0.13) + Math.sin(angle * 2 + phase2) * 0.085 + Math.sin(angle * 3 - phase2) * 0.045;
      const outerX = ox + rx * ca * outerRadius;
      const outerY = oy + ry * sa * outerRadius;
      const hollowRadius = 0.62 + 0.08 * Math.sin(angle + phase2 + 0.65) + 0.06 * Math.sin(angle * 2 - phase2) + 0.025 * Math.sin(angle * 3 - phase2);
      const innerX = ox + rx * 0.045 * Math.cos(phase2) + rx * ca * hollowRadius;
      const innerY = oy - ry * 0.055 * Math.sin(phase2) + ry * sa * (hollowRadius + 0.08);
      const seam = Math.pow(Math.abs(Math.sin(t * Math.PI)), 0.48);
      const tornLip = 0.29 + 0.71 * Math.min(1, t / (cell % 3 === 1 ? 0.43 : 0.29));
      const height = spec.height * (cell % 3 === 1 ? 0.48 : cell % 3 === 2 ? 0.79 : 1) * (0.39 + shoulder * 0.36 + seam * 0.22 + 0.1 * Math.sin(angle + phase2)) * tornLip;
      const foot = spec.blocking === 1 ? Math.min(8, height * 0.35) : 0;
      const point = (across, z) => [lerp(outerX, innerX, across), lerp(outerY, innerY, across), z];
      rows.push([
        point(0, 0),
        point(0.035, foot),
        point(0.16, height * 0.63),
        point(0.42 + shoulder * 0.08, height),
        point(0.79, height * (0.81 + shoulder * 0.08)),
        point(0.96, Math.max(foot, height * 0.22)),
        point(1, 0)
      ]);
    }
    for (let index = 0; index < steps; index++) {
      for (let across = 0; across < rows[index].length - 1; across++) {
        const a = rows[index][across], b = rows[index + 1][across];
        const c = rows[index + 1][across + 1], d = rows[index][across + 1];
        builder.quad(a, b, c, d, across < 4 ? 0 : 2, [uv(a), uv(b), uv(c), uv(d)], [0, 0, 1], across < 2 ? 1 : across < 4 ? 0 : 5);
        if (cell === 0 && index === Math.floor(steps * 0.47) && across === 3) {
          const onFace = (u, v) => [
            a[0] + (b[0] - a[0]) * u + (c[0] - a[0]) * v,
            a[1] + (b[1] - a[1]) * u + (c[1] - a[1]) * v,
            a[2] + (b[2] - a[2]) * u + (c[2] - a[2]) * v + 0.08
          ];
          const p = onFace(0.08, 0.12), q = onFace(0.57, 0.12), r = onFace(0.4, 0.4), s = onFace(0.08, 0.4);
          builder.quad(p, q, r, s, 3, [uv(p), uv(q), uv(r), uv(s)], [0, 0, 1], 3);
          builder.joint(onFace(0.28, 0.27));
        }
      }
    }
    for (const at of [0, steps]) {
      const row = rows[at], angle = at === 0 ? start : end, sign = at === 0 ? -1 : 1;
      for (let across = 0; across < row.length - 1; across++) {
        const a = row[across], b = row[across + 1];
        const run = Math.min(6, spec.thickness * 0.42) * (at === 0 ? 0.72 : 1.12);
        const dx = -Math.sin(angle) * run * sign, dy = Math.cos(angle) * run * sign;
        const c = [b[0] + dx, b[1] + dy, 0], d = [a[0] + dx, a[1] + dy, 0];
        builder.quad(a, b, c, d, 1, [uv(a), uv(b), uv(c), uv(d)], [0, 0, 1], 3);
      }
    }
  }
}

// src/generation/world-study/native-volume-pleated-tear.ts
var uv2 = (p) => [p[0], p[1]];
var EPSILON = 1e-7;
function createPleatedTear(builder, centre, tangent) {
  const magnitude = Math.hypot(...tangent);
  if (magnitude < EPSILON) throw new Error("Pleated tear needs a real surface direction");
  const direction = [tangent[0] / magnitude, tangent[1] / magnitude];
  const normal = [-direction[1], direction[0]];
  const length = Math.min(12, builder.spec.length * 0.15, builder.spec.width * 0.15);
  const halfWidth = Math.min(1.3, length * 0.11), depth = Math.min(1.4, builder.spec.height * 0.06);
  const local = (p, axis) => {
    const basis = axis === 0 ? direction : normal;
    return (p[0] - centre[0]) * basis[0] + (p[1] - centre[1]) * basis[1];
  };
  const planes = [
    { axis: 0, limit: -length / 2, greater: true },
    { axis: 0, limit: length / 2, greater: false },
    { axis: 1, limit: -halfWidth, greater: true },
    { axis: 1, limit: halfWidth, greater: false }
  ];
  const clip = (polygon, plane) => {
    const output = [];
    for (let i = 0; i < polygon.length; i++) {
      const a = polygon[i], b = polygon[(i + 1) % polygon.length];
      const av = local(a, plane.axis), bv = local(b, plane.axis);
      const ai = plane.greater ? av >= plane.limit : av <= plane.limit;
      const bi = plane.greater ? bv >= plane.limit : bv <= plane.limit;
      if (ai) output.push(a);
      if (ai !== bi) {
        const t = (plane.limit - av) / (bv - av);
        output.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]);
      }
    }
    return output;
  };
  const draw = (polygon, material, region) => {
    for (let i = 1; i + 1 < polygon.length; i++) {
      const a = polygon[0], b = polygon[i], c = polygon[i + 1];
      builder.quad(a, b, c, c, material, [uv2(a), uv2(b), uv2(c), uv2(c)], [0, 0, 1], region);
    }
  };
  const bottom = (p, lift = 0) => {
    const along = local(p, 0) * 0.94, across = local(p, 1) * 0.72;
    return [
      centre[0] + direction[0] * along + normal[0] * across,
      centre[1] + direction[1] * along + normal[1] * across,
      p[2] - depth + lift
    ];
  };
  const glowPlanes = [
    { axis: 0, limit: -length * 0.35, greater: true },
    { axis: 0, limit: length * 0.35, greater: false },
    { axis: 1, limit: -halfWidth * 0.55, greater: true },
    { axis: 1, limit: halfWidth * 0.75, greater: false }
  ];
  let jointWritten = false;
  return {
    triangle(a, b, c) {
      let inside2 = [a, b, c];
      for (const plane of planes) {
        draw(clip(inside2, { ...plane, greater: !plane.greater }), 0, 4);
        inside2 = clip(inside2, plane);
        if (inside2.length < 3) return;
      }
      const floor = inside2.map((p) => bottom(p));
      draw(floor, 2, 3);
      for (let i = 0; i < inside2.length; i++) {
        const next = (i + 1) % inside2.length, p = inside2[i], q = inside2[next];
        if (!planes.some((plane) => Math.abs(local(p, plane.axis) - plane.limit) < EPSILON && Math.abs(local(q, plane.axis) - plane.limit) < EPSILON)) continue;
        builder.quad(p, q, floor[next], floor[i], 2, [uv2(p), uv2(q), uv2(floor[next]), uv2(floor[i])], [0, 0, 1], 3);
      }
      if (builder.spec.blocking !== 1) return;
      let glow = inside2;
      for (const plane of glowPlanes) glow = clip(glow, plane);
      if (glow.length < 3) return;
      const lit = glow.map((p) => bottom(p, 0.04));
      draw(lit, 3, 3);
      if (!jointWritten) {
        builder.joint([
          lit.reduce((sum, p) => sum + p[0], 0) / lit.length,
          lit.reduce((sum, p) => sum + p[1], 0) / lit.length,
          lit.reduce((sum, p) => sum + p[2], 0) / lit.length
        ]);
        jointWritten = true;
      }
    }
  };
}

// src/generation/world-study/native-volume-expansion.ts
var NATIVE_VOLUME_SHAPE_PROFILES = ["rib-vault", "pleated-sheet", "cellular-shell", "lobed-cushion", "monolith-buttress", "terrace-shelf", "pleated-tear"];
var uv3 = (p) => [p[0], p[1]];
var clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
function noise(seed, salt) {
  let value = Math.imul(seed ^ salt, 73244475);
  value = Math.imul(value ^ value >>> 16, 73244475);
  return ((value ^ value >>> 16) >>> 0) / 4294967296;
}
function fracture(b, a, c, d, size) {
  const sample = (u, v) => [
    a[0] + (c[0] - a[0]) * u + (d[0] - a[0]) * v,
    a[1] + (c[1] - a[1]) * u + (d[1] - a[1]) * v,
    a[2] + (c[2] - a[2]) * u + (d[2] - a[2]) * v + 0.08
  ];
  const length = Math.hypot(c[0] - a[0], c[1] - a[1]);
  const perpendicular = Math.abs((c[0] - a[0]) * (d[1] - a[1]) - (c[1] - a[1]) * (d[0] - a[0])) / Math.max(1e-3, length);
  const du = size ? Math.min(0.44, size[0] / Math.max(1e-3, length)) : 0.44;
  const dv = size ? Math.min(0.22, size[1] / Math.max(1e-3, perpendicular)) : 0.22;
  const p = sample(0.16, 0.12), q = sample(size ? 0.16 + du : 0.6, 0.12), r = sample(size ? 0.16 + du * 0.82 : 0.52, size ? 0.12 + dv : 0.34), s = sample(0.16, size ? 0.12 + dv : 0.34);
  b.quad(p, q, r, s, 3, [uv3(p), uv3(q), uv3(r), uv3(s)], [0, 0, 1], 3);
  b.joint(sample(size ? 0.16 + du * 0.43 : 0.35, size ? 0.12 + dv * 0.5 : 0.23));
}
function ribbon(b, centres, radii, form, marked = false, sideScales) {
  const rows = [];
  const section2 = form === "ridge" ? [[-1, 0], [-0.91, 0.14], [-0.63, 0.62], [-0.12, 1], [0.28, 0.9], [0.75, 0.41], [0.94, 0.14], [1, 0]] : [[-1, 0], [-0.95, 0.2], [-0.76, 0.77], [-0.37, 0.98], [0.29, 1], [0.74, 0.84], [0.94, 0.2], [1, 0]];
  for (let i = 0; i < centres.length; i++) {
    const p = centres[i], before = centres[Math.max(0, i - 1)], after = centres[Math.min(centres.length - 1, i + 1)];
    const dx = after[0] - before[0], dy = after[1] - before[1], length = Math.hypot(dx, dy) || 1;
    const radius = radii[i], foot = b.spec.blocking === 1 ? Math.min(8, p[2] * 0.32) : 0;
    rows.push(section2.map(([across, rise], at) => {
      const breadth = radius * across * (sideScales?.[i]?.[across < 0 ? 0 : 1] ?? 1);
      return [
        p[0] - dy / length * breadth,
        p[1] + dx / length * breadth,
        at === 0 || at === section2.length - 1 ? 0 : Math.max(foot, p[2] * rise)
      ];
    }));
  }
  let distance2 = 0;
  for (let i = 0; i < rows.length - 1; i++) {
    const a = rows[i], c = rows[i + 1], nextDistance = distance2 + Math.hypot(centres[i + 1][0] - centres[i][0], centres[i + 1][1] - centres[i][1]);
    for (let j = 0; j < a.length - 1; j++) {
      const cut = j === 0 || j === a.length - 2, slot = cut ? 1 : j >= 4 ? 2 : 0;
      b.quad(
        a[j],
        c[j],
        c[j + 1],
        a[j + 1],
        slot,
        [[distance2, j * radii[i] / 3], [nextDistance, j * radii[i + 1] / 3], [nextDistance, (j + 1) * radii[i + 1] / 3], [distance2, (j + 1) * radii[i] / 3]],
        [0, 0, 1],
        cut ? 3 : form === "pad" ? 5 : 4
      );
      if (marked && i === Math.floor((rows.length - 1) * 0.53) && j === 3) fracture(b, a[j], c[j], c[j + 1]);
    }
    distance2 = nextDistance;
  }
  for (const index of [0, rows.length - 1]) {
    const row = rows[index], centre = centres[index], neighbour = centres[index === 0 ? 1 : index - 1];
    const dx = centre[0] - neighbour[0], dy = centre[1] - neighbour[1], length = Math.hypot(dx, dy) || 1;
    const run = Math.min(7, b.spec.thickness * 0.6);
    for (let j = 0; j < row.length - 1; j++) {
      const a = row[j], c = row[j + 1], af = [a[0] + dx / length * run, a[1] + dy / length * run, 0], cf = [c[0] + dx / length * run, c[1] + dy / length * run, 0];
      b.quad(a, af, cf, c, 1, [uv3(a), uv3(af), uv3(cf), uv3(c)], [0, 0, 1], 3);
    }
  }
}
function ribVault(b) {
  const s = b.spec, count = s.branches, spine = [], radii = [];
  for (let i = 0; i <= 28; i++) {
    const t = i / 28, arch = Math.sin(Math.PI * t);
    spine.push([(t - 0.5) * s.length, -s.width * (0.33 + 0.035 * Math.sin(t * 5)), s.height * (0.53 + arch * 0.47)]);
    radii.push(s.width * (0.058 + 0.018 * arch));
  }
  ribbon(b, spine, radii, "ridge", true);
  for (let rib = 0; rib < count; rib++) {
    const at = (rib + 0.52) / count, length = s.width * (0.46 + noise(s.seed, 1900 + rib) * 0.28), centres = [], widths = [];
    for (let i = 0; i <= 20; i++) {
      const t = i / 20, bend = Math.sin(t * Math.PI * 0.86);
      centres.push([
        (at - 0.5) * s.length + bend * s.length * (0.036 + s.fold * 0.035),
        -s.width * 0.33 + t * length,
        s.height * (0.6 - t * 0.36 + bend * 0.12) * (1 - rib % 3 * 0.055)
      ]);
      widths.push(Math.min(s.length / count * 0.18, s.width * 0.057) * (1 - t * 0.38));
    }
    ribbon(b, centres, widths, "ridge");
  }
}
function pleatedSheet(b, openedTear = false) {
  const s = b.spec, gap = Math.min(s.length * 0.38, Math.max(48, s.width * (0.28 + s.opening * 0.14) + 20));
  const centreGap = (0.04 + (noise(s.seed, 1981) - 0.5) * 0.1) * s.length;
  const folds = [
    [-0.35, 0.08],
    [0, 0.68],
    [0.16, 0.13],
    [0.43, 0.94],
    [0.56, 0.17],
    [0.9, 0.58],
    [1.14, 0.06],
    [1.31, 0.85],
    [1.6, 0.14],
    [1.87, 0.7],
    [2.2, 0.12]
  ];
  const creaseAt = (at) => {
    for (let i = 1; i < folds.length; i++) if (at <= folds[i][0]) {
      const a = folds[i - 1], c = folds[i], t = clamp((at - a[0]) / (c[0] - a[0]), 0, 1);
      return a[1] + (c[1] - a[1]) * t;
    }
    return folds[folds.length - 1][1];
  };
  const tear = (at, centre, radius) => Math.max(0, 1 - Math.abs(at - centre) / radius);
  const pieces = [[-s.length * 0.5, centreGap - gap * 0.5], [centreGap + gap * 0.5, s.length * 0.5]];
  for (const [piece, [start, end]] of pieces.entries()) {
    const along = 36, across = 16, rows = [];
    for (let i = 0; i <= along; i++) {
      const t = i / along, baseX = start + (end - start) * t, u = baseX / s.length + 0.5, row = [];
      const north = s.width * (-0.43 + 0.045 * Math.sin(u * 5.1) + 0.13 * tear(t, piece ? 0.28 : 0.7, 0.16));
      const south = s.width * (0.38 + 0.065 * Math.sin(u * 4.6 + 0.8) - 0.17 * tear(t, piece ? 0.78 : 0.23, 0.13));
      for (let j = 0; j <= across; j++) {
        const v = j / across;
        const x = baseX + s.length * (0.012 + 0.06 * tear(v, piece ? 0.7 : 0.24, 0.2)) * (1 - t) ** 5 - s.length * (0.018 + 0.075 * tear(v, piece ? 0.34 : 0.76, 0.18)) * t ** 5;
        const phase2 = u * (0.6 + s.branches * 0.16) + (v - 0.5) * (0.2 + s.fold * 0.1);
        const crease = creaseAt(phase2), amplitude = 0.79 + 0.12 * Math.sin(u * 4.7 + 0.9) + v * 0.09;
        const foot = s.blocking === 1 ? Math.min(8, s.height * 0.22) : 0;
        row.push([
          x,
          north + (south - north) * v,
          foot + s.height * (0.065 + crease * amplitude) * (0.79 + 0.21 * Math.sin(Math.PI * v))
        ]);
      }
      rows.push(row);
    }
    let ridge = 4;
    if (openedTear && piece === 1) {
      for (let i = 5; i < along - 4; i++)
        if (rows[i][6][2] > rows[ridge][6][2]) ridge = i;
    }
    const openedSurface = openedTear && piece === 1 ? createPleatedTear(
      b,
      rows[ridge][6],
      [rows[ridge][7][0] - rows[ridge][5][0], rows[ridge][7][1] - rows[ridge][5][1]]
    ) : void 0;
    for (let i = 0; i < along; i++) for (let j = 0; j < across; j++) {
      const a = rows[i][j], c = rows[i + 1][j], d = rows[i + 1][j + 1], e = rows[i][j + 1];
      if (openedSurface) {
        openedSurface.triangle(a, c, d);
        openedSurface.triangle(a, d, e);
      } else b.quad(a, c, d, e, 0, [uv3(a), uv3(c), uv3(d), uv3(e)], [0, 0, 1], 4);
      if (!openedTear && start < 0 && i === 15 && j === 7) fracture(b, a, c, d);
    }
    const outline = [
      ...rows.map((row) => row[0]),
      ...rows[along].slice(1),
      ...rows.slice(0, along).reverse().map((row) => row[across]),
      ...rows[0].slice(1, across).reverse()
    ];
    const feet = outline.map((p, i) => {
      const prev = outline[(i + outline.length - 1) % outline.length], next = outline[(i + 1) % outline.length];
      const dx = next[0] - prev[0], dy = next[1] - prev[1], length = Math.hypot(dx, dy) || 1, width = s.blocking === 1 ? Math.min(6, s.thickness * 0.55) : 1.5;
      return [p[0] + dy / length * width, p[1] - dx / length * width, 0];
    });
    for (let i = 0; i < outline.length; i++) {
      const next = (i + 1) % outline.length, a = outline[i], c = outline[next];
      const exposedInnerTear = piece === 0 && i > along + 3 && i < along + across - 3;
      b.quad(a, feet[i], feet[next], c, exposedInnerTear ? 2 : 1, [uv3(a), uv3(feet[i]), uv3(feet[next]), uv3(c)], [0, 0, 1], 3);
    }
  }
}
function lobedCushion(b) {
  const s = b.spec, count = clamp(s.branches - 1, 2, 3);
  for (let lobe = 0; lobe < count; lobe++) {
    const side = (lobe + 0.5) / count - 0.5, extent = (lobe === 0 ? 0.94 : 0.7) + noise(s.seed, 2100 + lobe) * 0.05;
    const points = [], radii = [], sideScales = [];
    for (let i = 0; i <= 36; i++) {
      const t = i / 36, shoulder = Math.pow(Math.sin(Math.PI * t), 0.5), taper = 0.04 + 0.96 * shoulder;
      const widthPeak = Math.exp(-Math.pow((t - (0.32 + lobe * 0.18)) / 0.22, 2));
      const curl = Math.exp(-Math.pow((t - (lobe === 0 ? 0.81 : 0.67)) / (0.1 + s.fold * 0.04), 2));
      points.push([
        (t - 0.5) * s.length * extent + lobe * s.length * 0.105,
        side * s.width + (t - 0.5) * s.width * (0.12 + s.distortion * 0.14),
        s.height * (0.1 + shoulder * 0.15 + curl * (lobe === 0 ? 0.5 + s.fold * 0.25 : 0.19))
      ]);
      radii.push(s.width / count * 0.33 * taper * (1 - s.opening * 0.14));
      const outer = 1.15 + widthPeak * (lobe === 0 ? 0.8 : 0.4);
      const notch = 1 - 0.17 * Math.exp(-Math.pow((t - 0.61) / 0.095, 2));
      sideScales.push(lobe === 0 ? [outer * notch, 0.9] : lobe === count - 1 ? [0.9, outer] : [0.86, 0.88]);
    }
    ribbon(b, points, radii, "pad", lobe === 0, sideScales);
  }
}
function planarMass(b, outline, topHeight, baseZ = 0, marked = false) {
  const cx = outline.reduce((sum, p) => sum + p[0], 0) / outline.length, cy = outline.reduce((sum, p) => sum + p[1], 0) / outline.length;
  const foot = outline.map(([x, y]) => [x, y, baseZ]);
  const low = outline.map(([x, y]) => [
    cx + (x - cx) * 0.965,
    cy + (y - cy) * 0.965,
    baseZ + Math.min(b.spec.blocking === 1 ? 9 : 1, (topHeight(x, y) - baseZ) * 0.32)
  ]);
  const crown = outline.map(([x, y]) => {
    const px = cx + (x - cx) * 0.85, py = cy + (y - cy) * 0.85;
    return [px, py, topHeight(px, py)];
  });
  const centre = [cx, cy, topHeight(cx, cy)];
  let distance2 = 0;
  for (let i = 0; i < outline.length; i++) {
    const next = (i + 1) % outline.length, a = foot[i], c = foot[next], edge = Math.hypot(c[0] - a[0], c[1] - a[1]);
    b.quad(a, c, low[next], low[i], 1, [[distance2, baseZ], [distance2 + edge, baseZ], [distance2 + edge, low[next][2]], [distance2, low[i][2]]], [0, 0, 1], 3);
    b.quad(
      low[i],
      low[next],
      crown[next],
      crown[i],
      i % 3 === 0 ? 2 : 1,
      [[distance2, low[i][2]], [distance2 + edge, low[next][2]], [distance2 + edge, crown[next][2]], [distance2, crown[i][2]]],
      [0, 0, 1],
      1
    );
    b.quad(centre, crown[i], crown[next], centre, 0, [uv3(centre), uv3(crown[i]), uv3(crown[next]), uv3(centre)], [0, 0, 1], 0);
    if (marked && i === 1) fracture(b, centre, crown[i], crown[next], [18, 1.4]);
    distance2 += edge;
  }
}
function monolithButtress(b) {
  const s = b.spec, l = s.length, w = s.width, gap = Math.max(30, l * (0.12 + s.opening * 0.14));
  const offset = (noise(s.seed, 2201) - 0.5) * l * 0.08;
  const sideMouth = Math.min(w * 0.2, Math.max(32, w * (0.08 + s.opening * 0.08)) - w * 0.025);
  planarMass(
    b,
    [[-l * 0.46, -w * 0.42], [l * 0.34, -w * 0.49], [l * 0.46, -w * 0.27], [l * 0.38, -w * 0.025], [-l * 0.4, -w * 0.025]],
    (x, y) => s.height * (0.8 + x / l * s.fold * 0.2 - y / w * 0.24),
    0,
    true
  );
  planarMass(b, [
    [-l * 0.4, -w * 0.12],
    [-gap * 0.5 + offset, -w * 0.12],
    [-gap * 0.5 + offset, w * 0.31],
    [-l * 0.25, w * 0.48],
    [-l * 0.46, w * 0.34]
  ], (x, y) => s.height * (0.65 - y / w * 0.4 - x / l * 0.14));
  planarMass(b, [
    [gap * 0.5 + offset, sideMouth],
    [l * 0.39, sideMouth],
    [l * 0.46, w * 0.26],
    [l * 0.31, w * 0.43],
    [gap * 0.5 + offset, w * 0.29]
  ], (_x, y) => s.height * (0.67 - y / w * (0.2 + s.fold * 0.22)));
}
function terraceShelf(b) {
  const s = b.spec, tiers = clamp(s.branches, 2, 4), l = s.length, w = s.width;
  const scaled = (outline) => outline.map(([x, y]) => [x * l, y * w]);
  const lowerHeight = (x, y) => s.height * (0.4 + x / l * 0.17 + y / w * (0.06 + s.fold * 0.04));
  planarMass(b, scaled([[-0.49, -0.32], [-0.34, -0.5], [0.41, -0.43], [0.49, -0.18], [0.39, 0.035], [-0.38, 0.035]]), lowerHeight);
  planarMass(b, scaled([[-0.43, -0.09], [0.085, -0.09], [0.045, 0.22], [-0.1, 0.44], [-0.48, 0.32]]), lowerHeight);
  planarMass(b, scaled([[0.245, -0.09], [0.41, -0.1], [0.5, 0.13], [0.35, 0.39], [0.285, 0.25]]), lowerHeight);
  const upper = [[-0.37, -0.26], [-0.27, -0.43], [-0.02, -0.39], [0.18, -0.17], [0.04, -0.055], [-0.28, -0.09]];
  for (let tier = 1; tier < tiers; tier++) {
    const along = 0.56 ** (tier - 1), across = 0.68 ** (tier - 1);
    const outline = scaled(upper.map(([x, y]) => [-0.12 + (x + 0.12) * along, -0.23 + (y + 0.23) * across]));
    const height = (x, y) => s.height * (0.42 + 0.53 * tier / (tiers - 1) + (x / l + 0.15) * 0.1 - (y / w + 0.25) * (0.08 + s.fold * 0.05));
    planarMass(b, outline, height, 0, tier === tiers - 1);
  }
}
function buildExpandedNativeVolume(builder) {
  switch (builder.spec.shapeProfile) {
    case "rib-vault":
      ribVault(builder);
      return;
    case "pleated-sheet":
      pleatedSheet(builder);
      return;
    case "pleated-tear":
      pleatedSheet(builder, true);
      return;
    case "cellular-shell":
      buildCellularShell(builder);
      return;
    case "lobed-cushion":
      lobedCushion(builder);
      return;
    case "monolith-buttress":
      monolithButtress(builder);
      return;
    case "terrace-shelf":
      terraceShelf(builder);
      return;
    default:
      throw new Error("Unknown expanded native shape profile");
  }
}

// src/generation/world-study/native-volume-organization.ts
var uv4 = (p) => [p[0], p[1]];
var mix = (a, c, t) => [a[0] + (c[0] - a[0]) * t, a[1] + (c[1] - a[1]) * t, a[2] + (c[2] - a[2]) * t];
function curved(points, at) {
  const i = Math.min(points.length - 2, Math.floor(at)), t = at - i;
  const a = points[i], c = points[i + 1], before = points[Math.max(0, i - 1)], after = points[Math.min(points.length - 1, i + 2)];
  const tangent = (u, v) => u * v <= 0 ? 0 : 2 / (1 / u + 1 / v);
  return [0, 1, 2].map((axis) => {
    const d = c[axis] - a[axis], start = i === 0 ? d : tangent(a[axis] - before[axis], d);
    const end = i === points.length - 2 ? d : tangent(d, after[axis] - c[axis]);
    return (2 * t ** 3 - 3 * t * t + 1) * a[axis] + (t ** 3 - 2 * t * t + t) * start + (-2 * t ** 3 + 3 * t * t) * c[axis] + (t ** 3 - t * t) * end;
  });
}
function pressureFracture(b, a, c, d) {
  if (b.spec.blocking !== 1) return;
  const sample = (u, v) => [
    a[0] + (c[0] - a[0]) * u + (d[0] - a[0]) * v,
    a[1] + (c[1] - a[1]) * u + (d[1] - a[1]) * v,
    a[2] + (c[2] - a[2]) * u + (d[2] - a[2]) * v + 0.04
  ];
  const p = sample(0.16, 0.16), q = sample(0.45, 0.16), r = sample(0.39, 0.28), t = sample(0.16, 0.28);
  b.quad(p, q, r, t, 3, [uv4(p), uv4(q), uv4(r), uv4(t)], [0, 0, 1], 3);
  b.joint(sample(0.28, 0.21));
}
function buildCompressedWedge(b) {
  const s = b.spec;
  const along = [-0.5, -0.34, -0.03, 0.19, 0.32, 0.43];
  const breadth = [0.57, 0.94, 1, 0.89, 0.75, 0.63];
  const rise = [0.51, 0.9, 1, 0.77, 0.52, 0.3];
  const across = [-1, -0.73, -0.36, 0.02, 0.41, 0.76, 1];
  const crown = [0.23, 0.68, 0.94, 1, 0.88, 0.62, 0.19];
  const tear = [-0.04, 0.01, -0.045, 0.075, -5e-3, -0.075, -0.11];
  const rows = [], feet = [];
  for (let i = 0; i < along.length; i++) {
    const u = i / (along.length - 1), centre = s.width * (-0.06 + 0.08 * u + 0.025 * Math.sin(u * Math.PI));
    const radius = s.width * 0.48 * breadth[i];
    const top = s.height * rise[i], foot = s.blocking === 1 ? Math.min(4, s.height * 0.12) : 0;
    const row = across.map((v, j) => {
      const shift = s.length * (tear[j] * u ** 5 + v * (0.025 - u * 0.04));
      const z = foot + (top - foot) * crown[j];
      return [s.length * along[i] + shift, centre + radius * v, z];
    });
    rows.push(row);
    const spread = Math.min(6, s.width * 0.04);
    feet.push(row.map((p, j) => [
      p[0] + (i === 0 ? -spread : i === along.length - 1 ? spread : 0),
      p[1] + (j === 0 ? -spread : j === across.length - 1 ? spread : 0),
      0
    ]));
  }
  const sample = (u, v) => curved(rows.map((row) => curved(row, v)), u);
  for (let i = 0; i < (rows.length - 1) * 2; i++) for (let j = 0; j < (across.length - 1) * 2; j++) {
    const a = sample(i / 2, j / 2), c = sample((i + 1) / 2, j / 2), d = sample((i + 1) / 2, (j + 1) / 2), e = sample(i / 2, (j + 1) / 2);
    const cut = i >= (rows.length - 2) * 2 && (j === 2 || j === 3 || j === 8 || j === 9);
    b.quad(a, c, d, e, cut ? 1 : 0, [uv4(a), uv4(c), uv4(d), uv4(e)], [0, 0, 1], cut ? 3 : 1);
    if (i === 3 && j === 4) pressureFracture(b, a, c, d);
  }
  for (const side of [0, across.length - 1]) for (let i = 0; i < (rows.length - 1) * 2; i++) {
    const a = sample(i / 2, side), c = sample((i + 1) / 2, side), af = curved(feet.map((row) => row[side]), i / 2), cf = curved(feet.map((row) => row[side]), (i + 1) / 2);
    b.quad(af, cf, c, a, 0, [uv4(af), uv4(cf), uv4(c), uv4(a)], [0, side ? 1 : -1, 0], 1);
  }
  for (const i of [0, rows.length - 1]) for (let j = 0; j < (across.length - 1) * 2; j++) {
    const a = sample(i, j / 2), c = sample(i, (j + 1) / 2), af = curved(feet[i], j / 2), cf = curved(feet[i], (j + 1) / 2);
    const cut = i !== 0, sectionUV = (p) => [p[1], p[2]];
    b.quad(
      af,
      cf,
      c,
      a,
      cut ? 1 : 0,
      [sectionUV(af), sectionUV(cf), sectionUV(c), sectionUV(a)],
      [cut ? 1 : -1, 0, 0],
      cut ? 3 : 1
    );
  }
}
function buildPorousBreak(b) {
  const s = b.spec;
  const along = [-0.49, -0.34, -0.19, -0.025, 0.19, 0.35, 0.48];
  const widths = [0.43, 0.82, 1, 0.91, 0.94, 0.66, 0.29];
  const heights = [0.43, 0.76, 1, 0.93, 0.74, 0.62, 0.27];
  const split = [0.77, 0.55, 0.19, 0.13, 0.28, 0.52, 0.81];
  const rows = along.map((x, i) => {
    const radius = s.width * 0.48 * widths[i], centre = s.width * (0.045 * Math.sin(i * 0.7) - 0.035);
    const z = s.height * heights[i], t = split[i];
    const foot = [x * s.length, centre - radius, 0];
    const shoulder = [x * s.length + s.length * 0.012, centre - radius * 0.77, z * 0.59];
    const crown = [x * s.length, centre - radius * 0.17, z];
    const lip = [x * s.length + s.length * 0.022 * Math.sin(i * 1.3), centre + radius * t, z * (1 - 0.25 * t - 0.65 * t * t)];
    const toe = [x * s.length + Math.min(5, s.length * 0.02), centre + radius, 0];
    return { foot, shoulder, crown, lip, toe };
  });
  const sizes = [5, 12, 7, 14, 6, 4], offsets = [0.56, 0.35, 0.65, 0.47, 0.37, 0.48], depths = [0.44, 0.61, 0.38, 0.5, 0.63, 0.43];
  const rowAt = (u) => ["foot", "shoulder", "crown", "lip", "toe"].map((key) => curved(rows.map((row) => row[key]), u));
  for (let i = 0; i < rows.length - 1; i++) {
    const a = rows[i], c = rows[i + 1];
    for (let along2 = 0; along2 < 2; along2++) for (let across = 0; across < 6; across++) {
      const start = rowAt(i + along2 / 2), end = rowAt(i + (along2 + 1) / 2);
      const p = curved(start, across / 2), q = curved(end, across / 2), r = curved(end, (across + 1) / 2), t = curved(start, (across + 1) / 2);
      b.quad(p, q, r, t, 0, [uv4(p), uv4(q), uv4(r), uv4(t)], [0, 0, 1], 0);
      if (i === 2 && along2 === 1 && across === 4) pressureFracture(b, p, q, r);
    }
    const sample = (u, v) => {
      const row = rowAt(i + u);
      return mix(row[3], row[4], v);
    };
    const centreU = offsets[i], centreV = depths[i], centre = sample(centreU, centreV);
    const width = c.lip[0] - a.lip[0], depth = (a.toe[1] - a.lip[1] + (c.toe[1] - c.lip[1])) / 2;
    const radius = Math.min(sizes[i] / 2, width * 0.23, depth * 0.23);
    const outer = [[0, 0], [0.5, 0], [1, 0], [1, 0.5], [1, 1], [0.5, 1], [0, 1], [0, 0.5]];
    const ring = outer.map(([u, v]) => sample(u, v)), mouth = [], bottom = [];
    const recess = Math.min(5, centre[2] * 0.32, radius * 0.74);
    for (let j = 0; j < 8; j++) {
      const angle = -Math.PI * 0.75 + j * Math.PI / 4;
      const dx = Math.cos(angle) * radius, dy = Math.sin(angle) * radius * (0.68 + i % 2 * 0.12);
      mouth.push(sample(centreU + dx / width, centreV + dy / depth));
      const p = sample(centreU + dx * 0.63 / width, centreV + dy * 0.63 / depth);
      bottom.push([p[0], p[1], p[2] - recess]);
    }
    const centreBottom = [centre[0], centre[1], centre[2] - recess];
    for (let j = 0; j < 8; j++) {
      const k = (j + 1) % 8, p = mouth[j], q = mouth[k], af = bottom[j], cf = bottom[k];
      b.quad(ring[j], ring[k], q, p, 1, [uv4(ring[j]), uv4(ring[k]), uv4(q), uv4(p)], [0, 0, 1], 3);
      b.quad(p, q, cf, af, 2, [uv4(p), uv4(q), uv4(cf), uv4(af)], [0, 0, 1], 2);
      b.quad(
        af,
        cf,
        centreBottom,
        centreBottom,
        2,
        [uv4(af), uv4(cf), uv4(centreBottom), uv4(centreBottom)],
        [0, 0, 1],
        0
      );
    }
  }
  for (const i of [0, rows.length - 1]) {
    const row = rowAt(i), face = [0, 0.5, 1, 1.5, 2, 2.5, 3, 4].map((at) => curved(row, at));
    for (let j = 1; j < face.length - 1; j++) {
      const a = face[0], c = face[j], d = face[j + 1];
      b.quad(a, c, d, d, 0, [uv4(a), uv4(c), uv4(d), uv4(d)], [i ? 1 : -1, 0, 0], 0);
    }
  }
}
function smoothOrganizedSurface(mesh) {
  const groups = /* @__PURE__ */ new Map();
  for (let face = 0; face < mesh.triangleCount; face++) {
    if (mesh.materials[face] !== 0) continue;
    for (let corner = 0; corner < 3; corner++) {
      const vertex = mesh.indices[face * 3 + corner], at = vertex * 3;
      const previous = mesh.indices[face * 3 + (corner + 1) % 3] * 3;
      const next = mesh.indices[face * 3 + (corner + 2) % 3] * 3;
      const ax = mesh.positions[previous] - mesh.positions[at], ay = mesh.positions[previous + 1] - mesh.positions[at + 1], az = mesh.positions[previous + 2] - mesh.positions[at + 2];
      const bx = mesh.positions[next] - mesh.positions[at], by = mesh.positions[next + 1] - mesh.positions[at + 1], bz = mesh.positions[next + 2] - mesh.positions[at + 2];
      const dot = (ax * bx + ay * by + az * bz) / (Math.hypot(ax, ay, az) * Math.hypot(bx, by, bz));
      const weight = Math.acos(Math.max(-1, Math.min(1, dot)));
      const key = `${mesh.positions[at]},${mesh.positions[at + 1]},${mesh.positions[at + 2]}:${mesh.regions[face]}`;
      const entries = groups.get(key) ?? [];
      entries.push({ vertex, weight });
      groups.set(key, entries);
    }
  }
  const normals = new Float32Array(mesh.normals), creaseCosine = Math.cos(55 * Math.PI / 180);
  for (const entries of groups.values()) for (const { vertex } of entries) {
    const at = vertex * 3, nx = mesh.normals[at], ny = mesh.normals[at + 1], nz = mesh.normals[at + 2];
    let x = 0, y = 0, z = 0;
    for (const { vertex: other, weight } of entries) {
      const q = other * 3, ox = mesh.normals[q], oy = mesh.normals[q + 1], oz = mesh.normals[q + 2];
      if (nx * ox + ny * oy + nz * oz < creaseCosine) continue;
      x += ox * weight;
      y += oy * weight;
      z += oz * weight;
    }
    const length = Math.hypot(x, y, z);
    if (length > 0) {
      normals[at] = x / length;
      normals[at + 1] = y / length;
      normals[at + 2] = z / length;
    }
  }
  return { ...mesh, normals };
}

// src/generation/world-study/native-volume-settled-sheet.ts
function buildSettledSheet(b) {
  const outline = [
    [-0.5, -0.23],
    [-0.29, -0.48],
    [0.13, -0.37],
    [0.4, -0.26],
    [0.51, -0.03],
    [0.34, 0.29],
    [0.23, 0.13],
    [0.04, -0.02],
    [0.13, 0.23],
    [-0.1, 0.49],
    [-0.37, 0.34],
    [-0.28, 0.13],
    [-0.46, 0.02]
  ];
  const parts = [[0, 1, 2, 7, 11, 12], [11, 7, 8, 9, 10], [2, 3, 4, 5, 6, 7]];
  buildSettledMaterial(b, outline, parts, "sheet");
}
function buildSettledFan(b) {
  const outline = [
    [-0.5, -0.3],
    [-0.32, -0.49],
    [0.24, -0.4],
    [0.43, -0.18],
    [0.51, 0.17],
    [0.29, 0.39],
    [0.16, 0.21],
    [0.09, -0.04],
    [-0.02, 0.36],
    [-0.3, 0.5],
    [-0.46, 0.17],
    [-0.3, -0.1]
  ];
  const parts = [[0, 1, 2, 3, 7, 11], [11, 7, 8, 9, 10], [7, 3, 4, 5, 6]];
  buildSettledMaterial(b, outline, parts, "fan");
}
function buildSettledMaterial(b, outline, parts, profile) {
  const s = b.spec;
  if (s.blocking !== 0 || s.height > 6) throw new Error("Settled material requires shallow, nonblocking material");
  const boundary = outline.map(([x, y]) => [x * s.length, y * s.width]);
  const smooth = (n) => {
    const t = Math.max(0, Math.min(1, n));
    return t * t * (3 - 2 * t);
  };
  const height = ([x, y]) => {
    let distance2 = Infinity;
    for (let i = 0; i < boundary.length; i++) {
      const a = boundary[i], c = boundary[(i + 1) % boundary.length];
      const dx = c[0] - a[0], dy = c[1] - a[1];
      const t = Math.max(0, Math.min(1, ((x - a[0]) * dx + (y - a[1]) * dy) / (dx * dx + dy * dy)));
      distance2 = Math.min(distance2, Math.hypot(x - a[0] - dx * t, y - a[1] - dy * t));
    }
    const retreat = 5 + 3 * Math.sin(x * 0.043 + y * 0.025) + 2 * Math.sin(y * 0.071 - x * 0.019);
    const buried = smooth((distance2 - retreat) / 24);
    const fold = profile === "sheet" ? 0.45 + 0.55 * smooth((y / s.width + 0.34 + 0.14 * x / s.length) / 0.7) : 0.78 + x / s.length * (0.08 + s.fold * 0.08) - y / s.width * 0.13 - 0.27 * smooth((x / s.length - 0.09) / 0.25) * smooth((y / s.width + 0.04) / 0.3);
    return s.height * buried * fold;
  };
  const clip = (polygon, axis, at, greater) => {
    const result = [];
    for (let i = 0; i < polygon.length; i++) {
      const a = polygon[i], c = polygon[(i + 1) % polygon.length];
      const ai = greater ? a[axis] >= at : a[axis] <= at;
      const ci = greater ? c[axis] >= at : c[axis] <= at;
      if (ai) result.push(a);
      if (ai !== ci) {
        const t = (at - a[axis]) / (c[axis] - a[axis]);
        result.push([a[0] + (c[0] - a[0]) * t, a[1] + (c[1] - a[1]) * t]);
      }
    }
    return result;
  };
  const minX = Math.min(...boundary.map((p) => p[0])), maxX = Math.max(...boundary.map((p) => p[0]));
  const minY = Math.min(...boundary.map((p) => p[1])), maxY = Math.max(...boundary.map((p) => p[1]));
  const xs = Array.from({ length: 13 }, (_, i) => minX + (maxX - minX) * i / 12);
  const ys = Array.from({ length: 11 }, (_, i) => minY + (maxY - minY) * i / 10);
  for (const part of parts) for (let x = 0; x < 12; x++) for (let y = 0; y < 10; y++) {
    const polygon = clip(clip(clip(
      clip(part.map((i) => boundary[i]), 0, xs[x], true),
      0,
      xs[x + 1],
      false
    ), 1, ys[y], true), 1, ys[y + 1], false);
    if (polygon.length < 3) continue;
    const points = polygon.map((p) => [p[0], p[1], height(p)]);
    for (let i = 1; i < points.length - 1; i++) {
      b.quad(
        points[0],
        points[i],
        points[i + 1],
        points[i + 1],
        0,
        [polygon[0], polygon[i], polygon[i + 1], polygon[i + 1]],
        [0, 0, 1],
        4
      );
    }
  }
}

// src/generation/world-study/native-volume-settled-projection.ts
var cross = (a, b) => a[0] * b[1] - a[1] * b[0];
var subtract = (a, b) => [a[0] - b[0], a[1] - b[1]];
var xy = (p) => [p[0], p[1]];
function buildSettledProjection(b, construct, refine) {
  if (b.spec.blocking !== 0 || b.spec.height > 6) throw new Error("Settled projection requires shallow nonblocking material");
  const source = [];
  const add = (a, c, d) => {
    if (Math.abs(cross(subtract(xy(c), xy(a)), subtract(xy(d), xy(a)))) > 1e-8) source.push([a, c, d]);
  };
  construct({
    spec: b.spec,
    quad(a, c, d, e) {
      add(a, c, d);
      add(a, d, e);
    },
    joint() {
      throw new Error("Shallow source must not emit a pollution joint");
    }
  });
  const weights = (p, t) => {
    const a = xy(t[0]), ab = subtract(xy(t[1]), a), ac = subtract(xy(t[2]), a), ap = subtract(p, a);
    const area = cross(ab, ac), v = cross(ap, ac) / area, w = cross(ab, ap) / area, u = 1 - v - w;
    return u >= -1e-8 && v >= -1e-8 && w >= -1e-8 ? [u, v, w] : null;
  };
  const contains = (p) => source.some((t) => weights(p, t) !== null);
  const key = (p) => `${p[0].toFixed(7)},${p[1].toFixed(7)}`;
  const edges = /* @__PURE__ */ new Map();
  for (const t of source) for (let i = 0; i < 3; i++) {
    const a = xy(t[i]), c = xy(t[(i + 1) % 3]), ak = key(a), ck = key(c), id = ak < ck ? `${ak}/${ck}` : `${ck}/${ak}`;
    const edge = edges.get(id);
    if (edge) edge.uses++;
    else edges.set(id, { a, b: c, uses: 1 });
  }
  const candidates = [...edges.values()].filter((e) => e.uses === 1), boundary = [];
  const epsilon = Math.max(b.spec.length, b.spec.width) * 1e-6;
  for (const edge of candidates) {
    const ab = subtract(edge.b, edge.a), length = Math.hypot(...ab), cuts = [0, 1];
    for (const other of candidates) {
      if (other === edge) continue;
      const cd = subtract(other.b, other.a), ac = subtract(other.a, edge.a), denominator = cross(ab, cd);
      if (Math.abs(denominator) > 1e-9) {
        const t = cross(ac, cd) / denominator, u = cross(ac, ab) / denominator;
        if (t > 0 && t < 1 && u >= 0 && u <= 1) cuts.push(t);
      } else if (Math.abs(cross(ac, ab)) < 1e-7) {
        for (const p of [other.a, other.b]) {
          const ap = subtract(p, edge.a), t = (ap[0] * ab[0] + ap[1] * ab[1]) / (length * length);
          if (t > 0 && t < 1) cuts.push(t);
        }
      }
    }
    cuts.sort((a, c) => a - c);
    const at = (t) => [edge.a[0] + ab[0] * t, edge.a[1] + ab[1] * t];
    for (let i = 0; i < cuts.length - 1; i++) {
      if (cuts[i + 1] - cuts[i] < 1e-8) continue;
      const p = at((cuts[i] + cuts[i + 1]) / 2), nx = -ab[1] / length * epsilon, ny = ab[0] / length * epsilon;
      if (contains([p[0] + nx, p[1] + ny]) !== contains([p[0] - nx, p[1] - ny]))
        boundary.push({ a: at(cuts[i]), b: at(cuts[i + 1]), uses: 1 });
    }
  }
  if (!boundary.length) throw new Error("Settled material has no exterior boundary");
  const cache = /* @__PURE__ */ new Map();
  const surface = (p) => {
    const id = key(p), known = cache.get(id);
    if (known) return known;
    let distance2 = Infinity, height = 0;
    for (const edge of boundary) {
      const ab = subtract(edge.b, edge.a), ap = subtract(p, edge.a);
      const t2 = Math.max(0, Math.min(1, (ap[0] * ab[0] + ap[1] * ab[1]) / (ab[0] * ab[0] + ab[1] * ab[1])));
      distance2 = Math.min(distance2, Math.hypot(ap[0] - ab[0] * t2, ap[1] - ab[1] * t2));
    }
    for (const triangle of source) {
      const w = weights(p, triangle);
      if (w) height = Math.max(height, w[0] * triangle[0][2] + w[1] * triangle[1][2] + w[2] * triangle[2][2]);
    }
    const span = Math.min(34, Math.max(16, b.spec.width * 0.18)) * (1 + 0.22 * p[0] / b.spec.length - 0.12 * p[1] / b.spec.width);
    const t = Math.max(0, Math.min(1, distance2 / span)), settled = t * t * (3 - 2 * t);
    const point = [p[0], p[1], height * settled];
    cache.set(id, point);
    return point;
  };
  const emit = (a, c, d) => {
    b.quad(surface(a), surface(c), surface(d), surface(d), 0, [a, c, d, d], [0, 0, 1], 0);
  };
  const midpoint = (a, c) => [(a[0] + c[0]) / 2, (a[1] + c[1]) / 2];
  for (const triangle of source) {
    const [a, c, d] = triangle.map(xy);
    if (refine) {
      const ac = midpoint(a, c), cd = midpoint(c, d), da = midpoint(d, a);
      emit(a, ac, da);
      emit(ac, c, cd);
      emit(da, cd, d);
      emit(ac, cd, da);
    } else emit(a, c, d);
  }
}

// src/generation/world-study/native-volume-ground.ts
var NATIVE_VOLUME_V4_PROFILES = ["fracture-fan", "fallen-bundle", "clamp-bank", "torn-sheet", "compressed-wedge", "porous-break", "settled-sheet", "settled-fan", "settled-bundle", "settled-clamp"];
var uv5 = (p) => [p[0], p[1]];
function fracturedFace(b, a, c, d) {
  if (b.spec.blocking !== 1) return;
  const length = Math.hypot(c[0] - a[0], c[1] - a[1]);
  const perpendicular = Math.abs((c[0] - a[0]) * (d[1] - a[1]) - (c[1] - a[1]) * (d[0] - a[0])) / Math.max(1e-3, length);
  const du = Math.min(0.34, 24 / Math.max(1, length)), dv = Math.min(0.23, 6 / Math.max(1, perpendicular));
  const sample = (u, v) => [
    a[0] + (c[0] - a[0]) * u + (d[0] - a[0]) * v,
    a[1] + (c[1] - a[1]) * u + (d[1] - a[1]) * v,
    a[2] + (c[2] - a[2]) * u + (d[2] - a[2]) * v + 0.06
  ];
  const p = sample(0.17, 0.14), q = sample(0.17 + du, 0.14), r = sample(0.17 + du * 0.78, 0.14 + dv), t = sample(0.17, 0.14 + dv);
  b.quad(p, q, r, t, 3, [uv5(p), uv5(q), uv5(r), uv5(t)], [0, 0, 1], 3);
  b.joint(sample(0.17 + du * 0.43, 0.14 + dv * 0.43));
}
function insetOutline(b, outline) {
  const cx = outline.reduce((sum, p) => sum + p[0], 0) / outline.length, cy = outline.reduce((sum, p) => sum + p[1], 0) / outline.length;
  return outline.map(([x, y]) => {
    const factor = b.spec.blocking === 1 ? Math.min(0.25, 6.5 / Math.max(1, Math.hypot(x - cx, y - cy))) : 0;
    return [x + (cx - x) * factor, y + (cy - y) * factor];
  });
}
function surfaceHeight(b, height) {
  const foot = b.spec.blocking === 1 ? Math.min(6, b.spec.height * 0.3) : 0;
  return foot + height * (1 - foot / b.spec.height);
}
function section(b, outline, height, scar = false, closed = true) {
  const crown = closed ? insetOutline(b, outline) : outline;
  const top = crown.map(([x, y]) => [x, y, surfaceHeight(b, height(x, y))]);
  const cx = crown.reduce((sum, p) => sum + p[0], 0) / crown.length;
  const cy = crown.reduce((sum, p) => sum + p[1], 0) / crown.length;
  const centre = [cx, cy, surfaceHeight(b, height(cx, cy))];
  for (let i = 0; i < top.length; i++) {
    const a = top[i], c = top[(i + 1) % top.length];
    b.quad(a, c, centre, centre, 0, [uv5(a), uv5(c), uv5(centre), uv5(centre)], [0, 0, 1]);
    if (closed) {
      const footA = outline[i], footC = outline[(i + 1) % outline.length], af = [...footA, 0], cf = [...footC, 0];
      b.quad(
        af,
        cf,
        c,
        a,
        1,
        [[a[0], 0], [c[0], 0], [c[0], c[2]], [a[0], a[2]]],
        [a[0] + c[0] - 2 * cx, a[1] + c[1] - 2 * cy, 0],
        3
      );
    }
    if (scar && i === 1) fracturedFace(b, a, c, centre);
  }
}
function strip(b, rows, innerFrom = Infinity) {
  for (let i = 0; i < rows.length - 1; i++) {
    const a = rows[i], c = rows[i + 1];
    for (let j = 0; j < a.length - 1; j++) {
      const edge = j === 0 || j === a.length - 2;
      b.quad(
        a[j],
        c[j],
        c[j + 1],
        a[j + 1],
        edge ? 1 : j >= innerFrom ? 2 : 0,
        [uv5(a[j]), uv5(c[j]), uv5(c[j + 1]), uv5(a[j + 1])],
        [0, 0, 1],
        edge ? 3 : 0
      );
      if (i === 1 && j === 3) fracturedFace(b, a[j], c[j], c[j + 1]);
    }
  }
  for (const index of [0, rows.length - 1]) {
    const row = rows[index], direction = index === 0 ? -1 : 1;
    for (let j = 0; j < row.length - 1; j++) {
      const a = row[j], c = row[j + 1], af = [a[0], a[1], 0], cf = [c[0], c[1], 0];
      b.quad(af, a, c, cf, 1, [uv5(af), uv5(a), uv5(c), uv5(cf)], [direction, 0, 0], 3);
    }
  }
}
function fractureFan(b) {
  const s = b.spec, l = s.length, w = s.width;
  const outline = [
    [-0.5, -0.3],
    [-0.32, -0.49],
    [0.24, -0.4],
    [0.43, -0.18],
    [0.51, 0.17],
    [0.29, 0.39],
    [0.16, 0.21],
    [0.09, -0.04],
    [-0.02, 0.36],
    [-0.3, 0.5],
    [-0.46, 0.17],
    [-0.3, -0.1]
  ];
  const feet = outline.map(([x, y]) => [x * l, y * w]);
  const depths = [0.16, 0.1, 0.18, 0.48, 0.94, 0.3, 0.78, 0.42, 0.7, 1, 0.26, 0.12];
  const breadth = Math.min(s.blocking === 1 ? 11 : 6, Math.min(l, w) * 0.065);
  const inward = (a, c) => {
    const dx = c[0] - a[0], dy = c[1] - a[1], size = Math.hypot(dx, dy);
    return [-dy / size, dx / size];
  };
  const crown = feet.map((p, i) => {
    const before = inward(feet[(i + feet.length - 1) % feet.length], p), after = inward(p, feet[(i + 1) % feet.length]);
    const dx = before[0] + after[0], dy = before[1] + after[1], size = Math.hypot(dx, dy);
    return [p[0] + dx / size * breadth * depths[i], p[1] + dy / size * breadth * depths[i]];
  });
  const rims = feet.map((a, i) => {
    const next = (i + 1) % feet.length, c = feet[next], p = crown[i], q = crown[next], normal = inward(a, c);
    const samples = i === 4 ? [0, 0.24, 0.61, 0.76, 1] : i === 8 ? [0, 0.32, 0.79, 1] : [0, 1];
    return samples.map((t) => {
      const chip = i === 4 ? t === 0.61 ? 0.83 : t === 0.76 ? 0.12 : 0 : i === 8 && t === 0.32 ? 0.38 : 0;
      return {
        foot: [a[0] + (c[0] - a[0]) * t, a[1] + (c[1] - a[1]) * t],
        top: [
          p[0] + (q[0] - p[0]) * t + normal[0] * breadth * chip,
          p[1] + (q[1] - p[1]) * t + normal[1] * breadth * chip
        ]
      };
    });
  });
  const parts = [[0, 1, 2, 3, 7, 11], [11, 7, 8, 9, 10], [7, 3, 4, 5, 6]];
  const alongShoulder = ([x, y]) => ((y / w + 0.04) * 0.34 + (x / l - 0.09) * 0.14) / Math.hypot(0.34, 0.14);
  const bands = [-1, 0.055, 0.14, 1], drops = [0, 0, 0.27, 0.45];
  const height = (p, part) => {
    let drop = 0;
    if (part === 2) {
      const v = alongShoulder(p), band = Math.max(0, Math.min(2, bands.findIndex((at) => at > v) - 1));
      const t = (v - bands[band]) / (bands[band + 1] - bands[band]);
      drop = drops[band] + (drops[band + 1] - drops[band]) * t;
    }
    return surfaceHeight(b, s.height * (0.78 + p[0] / l * (0.08 + s.fold * 0.08) - p[1] / w * 0.13 - drop));
  };
  const clip = (polygon, boundary, greater) => {
    const result = [];
    for (let j = 0; j < polygon.length; j++) {
      const a = polygon[j], c = polygon[(j + 1) % polygon.length], av = alongShoulder(a), cv = alongShoulder(c);
      const ai = greater ? av >= boundary : av <= boundary, ci = greater ? cv >= boundary : cv <= boundary;
      if (ai) result.push(a);
      if (ai !== ci) {
        const t = (boundary - av) / (cv - av);
        result.push([a[0] + (c[0] - a[0]) * t, a[1] + (c[1] - a[1]) * t]);
      }
    }
    return result;
  };
  for (const [part, indices] of parts.entries()) {
    const polygon = [];
    for (let i = 0; i < indices.length; i++) {
      const at = indices[i], next = indices[(i + 1) % indices.length];
      if ((at + 1) % feet.length === next) polygon.push(...rims[at].slice(0, -1).map((p) => p.top));
      else polygon.push(crown[at]);
    }
    for (let band = 0; band < (part === 2 ? 3 : 1); band++) {
      const face = part === 2 ? clip(clip(polygon, bands[band], true), bands[band + 1], false) : polygon;
      if (face.length < 3) continue;
      const centre = [face.reduce((sum, p) => sum + p[0], 0) / face.length, face.reduce((sum, p) => sum + p[1], 0) / face.length];
      const mid = [...centre, height(centre, part)];
      for (let i = 0; i < face.length; i++) {
        const p = face[i], q = face[(i + 1) % face.length], a = [...p, height(p, part)], c = [...q, height(q, part)];
        b.quad(a, c, mid, mid, 0, [uv5(a), uv5(c), uv5(mid), uv5(mid)], [0, 0, 1]);
        if (part === 0 && i === 1) fracturedFace(b, a, c, mid);
      }
    }
  }
  for (let edge = 0; edge < feet.length; edge++) {
    const row = rims[edge], part = edge >= 3 && edge <= 6 ? 2 : 0;
    for (let j = 0; j < row.length - 1; j++) {
      const p = row[j], q = row[j + 1], av = alongShoulder(p.top), cv = alongShoulder(q.top);
      const cuts = part === 2 ? [0, ...bands.map((v) => (v - av) / (cv - av)).filter((t) => t > 0 && t < 1), 1].sort((a, c) => a - c) : [0, 1];
      for (let k = 0; k < cuts.length - 1; k++) {
        const lerp2 = (a2, c2, t) => [a2[0] + (c2[0] - a2[0]) * t, a2[1] + (c2[1] - a2[1]) * t];
        const a = lerp2(p.top, q.top, cuts[k]), c = lerp2(p.top, q.top, cuts[k + 1]);
        const af = [...lerp2(p.foot, q.foot, cuts[k]), 0], cf = [...lerp2(p.foot, q.foot, cuts[k + 1]), 0];
        const at = [...a, height(a, part)], ct = [...c, height(c, part)];
        const material = edge === 4 || edge === 5 || edge === 8 || edge === 7 && j === 0 ? 1 : 0;
        b.quad(af, cf, ct, at, material, [uv5(af), uv5(cf), uv5(ct), uv5(at)], [0, 0, 1], material === 1 ? 3 : 0);
      }
    }
  }
}
function fallenBundle(b) {
  const s = b.spec, rows = [];
  const bend = ((Math.imul(s.seed, 1103515245) >>> 0) / 4294967296 - 0.5) * s.distortion * 0.06;
  const widths = [1, 1.16, 1.02, 0.77, 0.64, 0.38];
  const xs = [-0.5, -0.34, -0.1, 0.15, 0.34, 0.5];
  for (let i = 0; i < xs.length; i++) {
    const t = i / (xs.length - 1), x = xs[i] * s.length;
    const centre = s.width * (Math.sin(t * 2.2) * (0.12 + s.fold * 0.06 + bend) - 0.06);
    const radius = s.width * 0.4 * widths[i];
    const peak = s.height * (0.93 - t * 0.48 + Math.sin(t * Math.PI) * 0.1);
    const foot = s.blocking === 1 ? Math.min(7, peak * 0.3) : 0;
    const profile = [[-1, 0], [-0.93, foot / peak], [-0.63, 0.69], [-0.16, 1], [0.32, 0.85], [0.77, 0.41], [0.96, foot / peak], [1, 0]];
    rows.push(profile.map(([across, rise], at) => [
      x + s.length * 0.022 * across * (i === 0 ? 1 : i === xs.length - 1 ? -1 : 0),
      centre + radius * across * (across > 0 ? 0.84 + 0.1 * t : 1),
      at === 0 || at === profile.length - 1 ? 0 : Math.max(foot, peak * rise)
    ]));
  }
  strip(b, rows);
  const count = Math.min(4, s.branches);
  for (let i = 0; i < count; i++) {
    const y = s.width * (0.02 + (i / (count - 1) - 0.5) * 0.22), x = s.length * (0.38 + i % 2 * 0.022);
    section(
      b,
      [
        [x, y - s.width * 0.065],
        [s.length * (0.56 + 0.035 * i), y - s.width * 0.026],
        [s.length * (0.53 + 0.032 * i), y + s.width * 0.019],
        [x, y + s.width * 0.039]
      ],
      (px) => s.height * (0.26 - (px / s.length - 0.38) * 0.63)
    );
  }
}
function clampBank(b) {
  const s = b.spec, rows = [], textureRows = [];
  const along = [-0.5, -0.36, -0.13, 0.12, 0.34, 0.49];
  const breadths = [0.62, 1, 1.14, 0.91, 0.72, 0.35];
  const stations = along.map((t, i) => ({
    x: t * s.length,
    bend: s.width * (0.1 * Math.sin(i * 0.65) - 0.03),
    width: s.width * breadths[i],
    peak: s.height * (0.7 + 0.3 * Math.sin((i + 0.6) / (along.length + 0.2) * Math.PI))
  }));
  const across = [-0.5, -0.46, -0.34, -0.13 - s.fold * 0.045, 0.05, 0.2 + s.opening * 0.035, 0.4, 0.47, 0.5];
  const samples = across.flatMap((a, i) => i === across.length - 1 ? [a] : [a, a + (across[i + 1] - a) / 3, a + (across[i + 1] - a) * 2 / 3]);
  const smoothHeight = (v, values) => {
    const slopes = across.slice(0, -1).map((a, i) => (values[i + 1] - values[i]) / (across[i + 1] - a));
    const tangents = values.map((_value, i) => i === 0 ? slopes[0] : i === values.length - 1 ? slopes[i - 1] : slopes[i - 1] * slopes[i] <= 0 ? 0 : 2 / (1 / slopes[i - 1] + 1 / slopes[i]));
    const index = Math.min(across.length - 2, Math.max(0, across.findIndex((a) => a > v) - 1));
    const span = across[index + 1] - across[index], t = (v - across[index]) / span;
    return (2 * t ** 3 - 3 * t * t + 1) * values[index] + (t ** 3 - 2 * t * t + t) * span * tangents[index] + (-2 * t ** 3 + 3 * t * t) * values[index + 1] + (t ** 3 - t * t) * span * tangents[index + 1];
  };
  const subdivisions = 2;
  for (let at = 0; at <= (stations.length - 1) * subdivisions; at++) {
    const segment = Math.min(stations.length - 2, Math.floor(at / subdivisions)), t = at / subdivisions - segment;
    const a = stations[segment], c = stations[segment + 1], u = at / ((stations.length - 1) * subdivisions);
    const lerp2 = (p, q) => p + (q - p) * t;
    const x = lerp2(a.x, c.x), width = lerp2(a.width, c.width), bend = lerp2(a.bend, c.bend);
    const peak = lerp2(a.peak, c.peak), foot = s.blocking === 1 ? Math.min(8, peak * 0.32) : 0;
    const pressure = Math.sin(Math.PI * u) ** 2, shoulder = 0.5 + 0.5 * Math.cos(u * Math.PI * 1.7 + 0.4);
    const profile = [
      0,
      foot / peak,
      0.54 + shoulder * 0.08,
      1,
      0.84 + pressure * 0.09,
      0.31 + shoulder * 0.16,
      0.13 + pressure * 0.09,
      foot / peak,
      0
    ];
    const row = samples.map((v, j) => {
      const isFoot = j === 0 || j === samples.length - 1;
      const end = Math.min(9, s.length * 0.038) * ((1 - u) ** 12 - u ** 12);
      const tear = 0.42 + 0.58 * Math.max(0, 1 - Math.abs((v - 0.1) / 0.35));
      return [
        x + s.length * 0.028 * v + (isFoot ? 0 : end * tear),
        bend + width * v,
        isFoot ? 0 : Math.max(foot * 0.6, peak * smoothHeight(v, profile))
      ];
    });
    let arc = 0;
    const texels = row.map((point, j) => {
      if (j) {
        const previous = row[j - 1];
        arc += Math.hypot(point[1] - previous[1], point[2] - previous[2]);
      }
      return [x, arc];
    });
    rows.push(row);
    textureRows.push(texels);
  }
  for (let i = 0; i < rows.length - 1; i++) for (let j = 0; j < samples.length - 1; j++) {
    const a = rows[i][j], c = rows[i + 1][j], d = rows[i + 1][j + 1], e = rows[i][j + 1];
    const edge = j === 0 || j === samples.length - 2, inner = samples[j] >= 0.05;
    const slot = edge ? 1 : inner ? 2 : 0;
    b.quad(a, c, d, e, slot, [
      textureRows[i][j],
      textureRows[i + 1][j],
      textureRows[i + 1][j + 1],
      textureRows[i][j + 1]
    ], [0, 0, 1], edge ? 3 : inner ? 1 : 0);
    if (i === Math.floor((rows.length - 1) * 0.34) && j === 10) fracturedFace(b, a, c, d);
  }
  for (const index of [0, rows.length - 1]) {
    const row = rows[index], station = stations[index === 0 ? 0 : stations.length - 1];
    for (let j = 0; j < row.length - 1; j++) {
      const a = row[j], c = row[j + 1], af = [station.x + s.length * 0.028 * samples[j], a[1], 0], cf = [station.x + s.length * 0.028 * samples[j + 1], c[1], 0];
      b.quad(af, cf, c, a, 1, [[0, a[1]], [0, c[1]], [c[2], c[1]], [a[2], a[1]]], [0, 0, 1], 3);
    }
  }
}
function tornSheet(b) {
  const s = b.spec;
  const outline = [
    [-0.5, -0.23],
    [-0.29, -0.48],
    [0.13, -0.37],
    [0.4, -0.26],
    [0.51, -0.03],
    [0.34, 0.29],
    [0.23, 0.13],
    [0.04, -0.02],
    [0.13, 0.23],
    [-0.1, 0.49],
    [-0.37, 0.34],
    [-0.28, 0.13],
    [-0.46, 0.02]
  ];
  const feet = outline.map(([x, y]) => [x * s.length, y * s.width]);
  const depths = [0.18, 0.1, 0.16, 0.3, 0.52, 0.94, 0.62, 0.28, 0.72, 1, 0.47, 0.23, 0.14];
  const breadth = Math.min(s.blocking === 1 ? 4 : 1.2, Math.min(s.length, s.width) * 0.035);
  const inward = (a, c) => {
    const dx = c[0] - a[0], dy = c[1] - a[1], size = Math.hypot(dx, dy);
    return [-dy / size, dx / size];
  };
  const crown = feet.map((p, i) => {
    const a = inward(feet[(i + feet.length - 1) % feet.length], p), c = inward(p, feet[(i + 1) % feet.length]);
    const dx = a[0] + c[0], dy = a[1] + c[1], size = Math.hypot(dx, dy);
    return [p[0] + dx / size * breadth * depths[i], p[1] + dy / size * breadth * depths[i]];
  });
  const parts = [[0, 1, 2, 7, 11, 12], [11, 7, 8, 9, 10], [2, 3, 4, 5, 6, 7]];
  const clamp3 = (value) => Math.max(0, Math.min(1, value));
  const smooth = (value) => {
    const t = clamp3(value);
    return t * t * (3 - 2 * t);
  };
  const phase2 = ([x, y]) => y / s.width + (0.18 + s.fold * 0.1) * x / s.length;
  const height = (point) => {
    const v = phase2(point), x = point[0] / s.length;
    const lift = v < -0.25 ? 0.035 : v < 0.17 ? 0.035 + 0.965 * smooth((v + 0.25) / 0.42) : 1 - 0.71 * smooth((v - 0.17) / 0.25);
    const amplitude = 0.56 + 0.44 * smooth((0.38 - x) / 0.86);
    const foot = s.blocking === 1 ? Math.min(3.5, s.height * 0.16) : 0;
    return foot + (s.height - foot) * (0.025 + amplitude * lift);
  };
  const clip = (polygon, axis, boundary, greater) => {
    const result = [];
    for (let j = 0; j < polygon.length; j++) {
      const a = polygon[j], c = polygon[(j + 1) % polygon.length], av = a[axis], cv = c[axis];
      const ai = greater ? av >= boundary : av <= boundary, ci = greater ? cv >= boundary : cv <= boundary;
      if (ai) result.push(a);
      if (ai !== ci) {
        const t = (boundary - av) / (cv - av);
        result.push([a[0] + (c[0] - a[0]) * t, a[1] + (c[1] - a[1]) * t]);
      }
    }
    return result;
  };
  const xs = [-0.52, -0.36, -0.18, 0.1, 0.27, 0.4, 0.53].map((x) => x * s.length);
  const ys = [-0.52, -0.35, -0.25, -0.16, -0.05, 0.035, 0.1, 0.16, 0.22, 0.28, 0.35, 0.43, 0.55].map((y) => y * s.width);
  for (const [part, indices] of parts.entries()) for (let x = 0; x < xs.length - 1; x++) for (let y = 0; y < ys.length - 1; y++) {
    const polygon = clip(clip(clip(clip(indices.map((i) => crown[i]), 0, xs[x], true), 0, xs[x + 1], false), 1, ys[y], true), 1, ys[y + 1], false);
    if (polygon.length < 3) continue;
    const points = polygon.map((p) => [...p, height(p)]);
    const centre = [polygon.reduce((sum, p) => sum + p[0], 0) / polygon.length, polygon.reduce((sum, p) => sum + p[1], 0) / polygon.length];
    const material = phase2(centre) > 0.17 ? 2 : 0;
    for (let i = 1; i < points.length - 1; i++) {
      const a = points[0], c = points[i], d = points[i + 1];
      b.quad(a, c, d, d, material, [uv5(a), uv5(c), uv5(d), uv5(d)], [0, 0, 1], 4);
      if (part === 0 && x === 2 && y === 3 && i === 1) fracturedFace(b, a, c, d);
    }
  }
  for (let edge = 0; edge < feet.length; edge++) {
    const next = (edge + 1) % feet.length, a = crown[edge], c = crown[next], af = feet[edge], cf = feet[next];
    const cuts = [0, ...xs.map((v) => (v - a[0]) / (c[0] - a[0])), ...ys.map((v) => (v - a[1]) / (c[1] - a[1])), 1].filter((t) => t >= 0 && t <= 1).sort((x, y) => x - y);
    const at = (u, v, t) => [u[0] + (v[0] - u[0]) * t, u[1] + (v[1] - u[1]) * t];
    for (let i = 0; i < cuts.length - 1; i++) {
      if (cuts[i + 1] - cuts[i] < 1e-9) continue;
      const p = at(a, c, cuts[i]), q = at(a, c, cuts[i + 1]);
      const pFoot = [...at(af, cf, cuts[i]), 0], qFoot = [...at(af, cf, cuts[i + 1]), 0];
      const pTop = [...p, height(p)], qTop = [...q, height(q)];
      const material = edge === 5 || edge === 6 || edge === 8 || edge === 9 ? 1 : 0;
      b.quad(pFoot, qFoot, qTop, pTop, material, [uv5(pFoot), uv5(qFoot), uv5(qTop), uv5(pTop)], [0, 0, 1], material === 1 ? 3 : 4);
    }
  }
}
function buildGroundNativeVolume(builder) {
  switch (builder.spec.shapeProfile) {
    case "fracture-fan":
      fractureFan(builder);
      return;
    case "fallen-bundle":
      fallenBundle(builder);
      return;
    case "clamp-bank":
      clampBank(builder);
      return;
    case "torn-sheet":
      tornSheet(builder);
      return;
    case "compressed-wedge":
      buildCompressedWedge(builder);
      return;
    case "porous-break":
      buildPorousBreak(builder);
      return;
    case "settled-sheet":
      buildSettledSheet(builder);
      return;
    case "settled-fan":
      buildSettledFan(builder);
      return;
    case "settled-bundle":
      buildSettledProjection(builder, fallenBundle, true);
      return;
    case "settled-clamp":
      buildSettledProjection(builder, clampBank, false);
      return;
    default:
      throw new Error("Unknown construction 4 native shape profile");
  }
}

// src/generation/world-study/native-volume-ground-edge.ts
function distance(p, a, b) {
  const x = b.x - a.x, y = b.y - a.y, length = x * x + y * y;
  const t = Math.max(0, Math.min(1, ((p.x - a.x) * x + (p.y - a.y) * y) / length));
  return Math.hypot(p.x - a.x - x * t, p.y - a.y - y * t);
}
function appendNativeGroundEdges(b, context) {
  const width = b.spec.groundEdgeWidth;
  if (width === void 0) return;
  if (!context || !context.polygons.length || typeof context.matterAt !== "function" || !Number.isInteger(context.width / 8) || !Number.isInteger(context.height / 8) || context.width <= 0 || context.height <= 0 || context.width * context.height > 4194304)
    throw new Error("Ground edge requires the complete bounded authoritative terrain context");
  const triangleBudget = context.width <= 1280 && context.height <= 1024 ? 2048 : 20480;
  const cosine = Math.cos(b.spec.rotation), sine = Math.sin(b.spec.rotation);
  const local = (x, y, z) => {
    const dx = x - b.spec.x, dy = y - b.spec.y;
    return [dx * cosine + dy * sine, -dx * sine + dy * cosine, z];
  };
  const nearest = (x, y) => {
    let result = Infinity;
    for (const polygon of context.polygons) for (let i = 0; i < polygon.length; i++) result = Math.min(result, distance({ x, y }, polygon[i], polygon[(i + 1) % polygon.length]));
    return result;
  };
  const heightAt = (x, y) => {
    const t = Math.min(1, nearest(x, y) / width);
    return b.spec.height * (t < 0.3 ? t / 0.3 : (1 - t) / 0.7);
  };
  const normalRunsAcrossX = (x, y) => {
    let nearestSquared = Infinity, acrossX = true;
    for (const polygon of context.polygons) for (let i = 0; i < polygon.length; i++) {
      const a = polygon[i], c = polygon[(i + 1) % polygon.length], dx = c.x - a.x, dy = c.y - a.y;
      const t = Math.max(0, Math.min(1, ((x - a.x) * dx + (y - a.y) * dy) / (dx * dx + dy * dy)));
      const nx = x - a.x - dx * t, ny = y - a.y - dy * t, squared = nx * nx + ny * ny;
      if (squared < nearestSquared) {
        nearestSquared = squared;
        acrossX = squared < 1e-12 ? Math.abs(dy) >= Math.abs(dx) : Math.abs(nx) >= Math.abs(ny);
      }
    }
    return acrossX;
  };
  let previousPeak = 0;
  const cells = /* @__PURE__ */ new Map();
  const horizontalMidpoints = /* @__PURE__ */ new Set(), verticalMidpoints = /* @__PURE__ */ new Set();
  const stride = context.width / 8 + 1;
  for (const polygon of context.polygons) {
    const minX = Math.max(0, Math.floor((Math.min(...polygon.map((p) => p.x)) - width) / 8));
    const maxX = Math.min(context.width / 8 - 1, Math.floor((Math.max(...polygon.map((p) => p.x)) + width) / 8));
    const minY = Math.max(0, Math.floor((Math.min(...polygon.map((p) => p.y)) - width) / 8));
    const maxY = Math.min(context.height / 8 - 1, Math.floor((Math.max(...polygon.map((p) => p.y)) + width) / 8));
    for (let row = minY; row <= maxY; row++) for (let col = minX; col <= maxX; col++) {
      const key = row * (context.width / 8) + col, x = col * 8, y = row * 8;
      if (cells.has(key) || !context.matterAt(x + 4, y + 4) || nearest(x + 4, y + 4) > width + 6) continue;
      previousPeak = Math.max(
        previousPeak,
        heightAt(x, y),
        heightAt(x + 8, y),
        heightAt(x + 8, y + 8),
        heightAt(x, y + 8),
        heightAt(x + 4, y + 4)
      );
      const acrossX = normalRunsAcrossX(x + 4, y + 4);
      const samples = [
        [x, y],
        [x + 8, y],
        [x + 8, y + 8],
        [x, y + 8],
        [x + 4, y],
        [x + 4, y + 8],
        [x, y + 4],
        [x + 8, y + 4]
      ];
      if (samples.every((p) => heightAt(p[0], p[1]) === 0)) continue;
      cells.set(key, { col, row, acrossX });
      if (acrossX) {
        horizontalMidpoints.add(row * stride + col);
        horizontalMidpoints.add((row + 1) * stride + col);
      } else {
        verticalMidpoints.add(row * stride + col);
        verticalMidpoints.add(row * stride + col + 1);
      }
    }
  }
  let triangles = 0, nextPeak = 0;
  const faces = [];
  const face = (polygon) => {
    triangles += polygon.length - 2;
    if (triangles > triangleBudget) throw new Error(`Authored ground cut exceeds the ${triangleBudget}-triangle edge budget`);
    faces.push(polygon);
    for (const p of polygon) nextPeak = Math.max(nextPeak, heightAt(p[0], p[1]));
  };
  for (const { col, row, acrossX } of cells.values()) {
    const x = col * 8, y = row * 8;
    const a = [x, y], c = [x + 8, y], d = [x + 8, y + 8], e = [x, y + 8];
    const top = [x + 4, y], right = [x + 8, y + 4], bottom = [x + 4, y + 8], left = [x, y + 4];
    if (acrossX) {
      face([top, bottom, e, ...verticalMidpoints.has(row * stride + col) ? [left] : [], a]);
      face([top, c, ...verticalMidpoints.has(row * stride + col + 1) ? [right] : [], d, bottom]);
    } else {
      face([left, a, ...horizontalMidpoints.has(row * stride + col) ? [top] : [], c, right]);
      face([left, right, d, ...horizontalMidpoints.has((row + 1) * stride + col) ? [bottom] : [], e]);
    }
  }
  if (triangles === 0 || nextPeak === 0) throw new Error("Authored ground edge produced no present material");
  const heightScale = previousPeak > 0 ? previousPeak / nextPeak : 1;
  for (const polygon of faces) {
    const points = polygon.map((p) => local(p[0], p[1], heightAt(p[0], p[1]) * heightScale));
    for (let i = 1; i < polygon.length - 1; i++) b.quad(
      points[0],
      points[i],
      points[i + 1],
      points[i + 1],
      1,
      [polygon[0], polygon[i], polygon[i + 1], polygon[i + 1]],
      [0, 0, 1],
      3
    );
  }
}

// src/generation/world-study/native-volume-geometry.ts
var NATIVE_VOLUME_REGIONS = { intact: 0, compressed: 1, peeled: 2, fractured: 3, tension: 4, glazed: 5 };
var TAU2 = Math.PI * 2;
var clamp2 = (v, low, high) => Math.max(low, Math.min(high, v));
function phase(seed, salt) {
  let a = Math.imul((seed | 0) ^ salt, 73244475);
  a = Math.imul(a ^ a >>> 16, 73244475);
  return ((a ^ a >>> 16) >>> 0) / 4294967296;
}
function validateNativeVolumeSpec(spec) {
  const numbers = ["id", "seed", "x", "y", "rotation", "length", "width", "height", "thickness", "fold", "branches", "opening", "distortion"];
  const keys = /* @__PURE__ */ new Set([...numbers, "family", "blocking", "constructionVersion", "shapeProfile", "groundEdgeWidth"]);
  if (Object.keys(spec).some((key) => !keys.has(key)) || numbers.some((key) => !Number.isFinite(spec[key])))
    throw new Error("Native volume must contain exactly the known required numeric fields");
  for (const [key, value] of Object.entries(spec)) {
    if (key !== "family" && key !== "shapeProfile" && !((key === "blocking" || key === "constructionVersion") && value === void 0) && (typeof value !== "number" || !Number.isFinite(value))) {
      throw new Error(`Native volume ${key} must be finite`);
    }
  }
  if (!["folded-slab", "fibre-knot", "broken-shell", "granular-ridge", "membrane-rim", "gel-flow"].includes(spec.family)) throw new Error("Unknown native volume family");
  if (!Number.isInteger(spec.id) || spec.id < 1 || spec.id > 2147483647) throw new Error("Volume id must be a positive Int32");
  if (!Number.isInteger(spec.seed)) throw new Error("Volume seed must be an integer");
  if (spec.constructionVersion !== void 0 && ![1, 2, 3, 4].includes(spec.constructionVersion)) throw new Error("Native volume constructionVersion must be 1, 2, 3 or 4");
  const profiles = spec.constructionVersion === 4 ? NATIVE_VOLUME_V4_PROFILES : spec.constructionVersion === 3 ? NATIVE_VOLUME_SHAPE_PROFILES : [];
  if (profiles.length ? !profiles.includes(spec.shapeProfile) : spec.shapeProfile !== void 0)
    throw new Error("Native volume shapeProfile must belong to its explicit construction version");
  if (spec.blocking !== void 0 && spec.blocking !== 0 && spec.blocking !== 1) throw new Error("Native volume blocking must be 0 or 1");
  if (spec.shapeProfile?.startsWith("settled-") && (spec.blocking !== 0 || spec.height > 6))
    throw new Error("Settled material requires explicit nonblocking material with height at most 6");
  if (spec.groundEdgeWidth !== void 0 && (spec.constructionVersion !== 4 || spec.blocking !== 0 || spec.height > 6 || spec.groundEdgeWidth < 8 || spec.groundEdgeWidth > 24)) throw new Error("Native ground edge requires v4 low relief and width 8\u201324px");
  if (spec.length < 16 || spec.width < 12 || spec.height < 2 || spec.thickness < 1 || spec.length > 2048 || spec.width > 2048 || spec.height > 512 || spec.thickness > Math.min(spec.length, spec.width) * 0.45) throw new Error("Native volume dimensions outside bounded construction range");
  for (const key of ["fold", "opening", "distortion"]) {
    if (spec[key] < 0 || spec[key] > 1) throw new Error(`Native volume ${key} must be in [0, 1]`);
  }
  if (!Number.isInteger(spec.branches) || spec.branches < 2 || spec.branches > 8) throw new Error("Native volume branches must be an integer in [2, 8]");
}
var MeshBuilder = class {
  constructor(spec) {
    this.spec = spec;
    this.cosine = Math.cos(spec.rotation);
    this.sine = Math.sin(spec.rotation);
  }
  groundEdgeStart;
  points = [];
  normalData = [];
  texels = [];
  triangles = [];
  slots = [];
  regions = [];
  joints = [];
  bounds = { minX: Infinity, minY: Infinity, maxX: -Infinity, maxY: -Infinity, maxZ: 0 };
  cosine;
  sine;
  vertex(p, uv6, n) {
    const x = this.spec.x + p[0] * this.cosine - p[1] * this.sine;
    const y = this.spec.y + p[0] * this.sine + p[1] * this.cosine;
    const z = Math.max(0, p[2]);
    this.bounds.minX = Math.min(this.bounds.minX, x);
    this.bounds.maxX = Math.max(this.bounds.maxX, x);
    this.bounds.minY = Math.min(this.bounds.minY, y);
    this.bounds.maxY = Math.max(this.bounds.maxY, y);
    this.bounds.maxZ = Math.max(this.bounds.maxZ, z);
    const index = this.points.length / 3;
    this.points.push(x, y, z);
    this.normalData.push(n[0] * this.cosine - n[1] * this.sine, n[0] * this.sine + n[1] * this.cosine, n[2]);
    this.texels.push(uv6[0], uv6[1]);
    return index;
  }
  quad(a, b, c, d, material, uvs, wanted, region = 0) {
    const triangle = (p, q, r, up, uq, ur) => {
      const ux = q[0] - p[0], uy = q[1] - p[1], uz = q[2] - p[2], vx = r[0] - p[0], vy = r[1] - p[1], vz = r[2] - p[2];
      let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
      const size = Math.hypot(nx, ny, nz);
      if (size < 1e-6) return;
      nx /= size;
      ny /= size;
      nz /= size;
      if (wanted && nx * wanted[0] + ny * wanted[1] + nz * wanted[2] < 0) {
        nx = -nx;
        ny = -ny;
        nz = -nz;
      }
      const normal = [nx, ny, nz];
      this.triangles.push(this.vertex(p, up, normal), this.vertex(q, uq, normal), this.vertex(r, ur, normal));
      this.slots.push(material);
      this.regions.push(region);
    };
    triangle(a, b, c, uvs[0], uvs[1], uvs[2]);
    triangle(a, c, d, uvs[0], uvs[2], uvs[3]);
  }
  joint(p) {
    this.joints.push({
      index: this.joints.length,
      x: this.spec.x + p[0] * this.cosine - p[1] * this.sine,
      y: this.spec.y + p[0] * this.sine + p[1] * this.cosine,
      z: p[2]
    });
  }
  beginGroundEdges() {
    this.groundEdgeStart = Object.freeze({ vertex: this.points.length / 3, triangle: this.slots.length });
  }
  finish() {
    const heightScale = this.spec.height / Math.max(1, this.bounds.maxZ);
    for (let i = 0; i < this.points.length; i += 3) {
      this.points[i + 2] = this.points[i + 2] * heightScale;
      const nx = this.normalData[i], ny = this.normalData[i + 1], nz = this.normalData[i + 2] / heightScale;
      const length = Math.hypot(nx, ny, nz) || 1;
      this.normalData[i] = nx / length;
      this.normalData[i + 1] = ny / length;
      this.normalData[i + 2] = nz / length;
    }
    for (const joint of this.joints) joint.z *= heightScale;
    this.bounds.maxZ = this.spec.height;
    return {
      spec: Object.freeze({ ...this.spec }),
      positions: new Float32Array(this.points),
      normals: new Float32Array(this.normalData),
      uv: new Float32Array(this.texels),
      indices: new Uint32Array(this.triangles),
      materials: new Uint8Array(this.slots),
      regions: new Uint8Array(this.regions),
      vertexCount: this.points.length / 3,
      triangleCount: this.slots.length,
      ...this.groundEdgeStart ? { groundEdgeStart: this.groundEdgeStart } : {},
      bounds: Object.freeze(this.bounds),
      joints: this.joints
    };
  }
};
function foldedSlab(b) {
  const s = b.spec, l = s.length, w = s.width, h = s.height;
  const shift = (phase(s.seed, 101) - 0.5) * 0.05;
  const thrust = (s.fold - 0.5) * 0.075;
  const px = (x) => (x + shift) * l;
  const py = (y) => y * w;
  const near = (ratio) => Math.min(h * ratio, 19 + s.thickness * 0.22);
  const a = [
    [-l * 0.51, py(-0.14), 0],
    [-l * 0.37, py(-0.37), h * 0.33],
    [px(-0.15), py(-0.43), h * 0.6424],
    [px(0.025), py(-0.2), h * 0.486],
    [px(-0.014), py(0.058 + thrust), near(0.31056 - thrust * 0.68)],
    [px(-0.19), py(0.235), near(0.1902)],
    [-l * 0.42, py(0.135), h * 0.025]
  ];
  const c = [
    [px(0.035), py(-0.3), h * 0.7028],
    [px(0.22), py(-0.49), h * 0.9836],
    [l * 0.49, py(-0.27), h * 0.16],
    [l * 0.46, py(-5e-3), h * 0.025],
    [px(0.24), py(0.095), near(0.1662)],
    [px(0.085), py(-0.025), near(0.3218)]
  ];
  const outlet = [
    [px(-0.26), py(0.3), near(0.11)],
    [px(-0.075), py(0.135 + thrust), near(0.21)],
    [px(0.09), py(0.13 + thrust), near(0.19)],
    [px(0.265), py(0.35), near(0.08)],
    [px(0.095), py(0.535), 0],
    [px(-0.15), py(0.49), h * 0.018]
  ];
  const plane = (outline, peak, dx, dy) => {
    const depth = outline.map((p) => p[0] * dx + p[1] * dy), min = Math.min(...depth), span = Math.max(...depth) - min;
    for (let i = 0; i < outline.length; i++) outline[i] = [outline[i][0], outline[i][1], (depth[i] - min) / span * peak];
    const x = outline.reduce((n, p) => n + p[0], 0) / outline.length, y = outline.reduce((n, p) => n + p[1], 0) / outline.length;
    return [x, y, (x * dx + y * dy - min) / span * peak];
  };
  const aCentre = plane(a, h * 0.73, 0.16, -1);
  const cCentre = plane(c, h, -0.35, -1);
  const outletCentre = plane(outlet, near(0.25), 0.13, -1);
  bedMass(b, a, aCentre, 0, [3, 4], Math.min(24, Math.max(9, w * 0.12)));
  bedMass(b, c, cCentre, 1, [4, 5], Math.min(21, Math.max(8, w * 0.105)));
  bedMass(b, outlet, outletCentre, 2, [0, 1], Math.min(17, Math.max(7, w * 0.085)));
}
function bedMass(b, top, centre, salt, faultEdges, cutWidth) {
  const n = top.length, s = b.spec;
  const lerp2 = (a, c, t) => [a[0] + (c[0] - a[0]) * t, a[1] + (c[1] - a[1]) * t, a[2] + (c[2] - a[2]) * t];
  const footHeight = s.blocking === 1 ? Math.min(s.height * 0.42, 8.5 + salt * 0.9 + phase(s.seed, 810 + salt) * 1.2) : 0;
  const lift = (p) => footHeight > 0 ? [p[0], p[1], footHeight + p[2] * (1 - footHeight / s.height)] : p;
  const surfaceCentre = lift(centre);
  const rim = [];
  let distance2 = 0;
  const mouthPeak = 0.43 + phase(s.seed, 700 + salt) * 0.16;
  for (let i = 0; i < n; i++) {
    const p = top[i], q = top[(i + 1) % n], rank = faultEdges.indexOf(i), fault = rank >= 0;
    const subdivisions = fault ? 5 : 1;
    const edgeLength = Math.hypot(q[0] - p[0], q[1] - p[1]);
    for (let j = 0; j < subdivisions; j++) {
      const t = j / subdivisions, at = lerp2(p, q, t), along = (rank + t) / faultEdges.length;
      const lobe = fault ? clamp2(along < mouthPeak ? along / mouthPeak : (1 - along) / (1 - mouthPeak), 0, 1) : 0;
      const mouth = lobe * lobe * (3 - 2 * lobe);
      const radius = Math.hypot(at[0] - centre[0], at[1] - centre[1]) || 1;
      const nx = (at[0] - centre[0]) / radius, ny = (at[1] - centre[1]) / radius;
      const inset = cutWidth * mouth * (salt === 2 ? 0.52 : 0.78);
      let lip = lerp2(at, centre, Math.min(0.26, inset / radius));
      const burial = clamp2(at[2] / Math.max(3, s.height * 0.16), 0, 1);
      const spread = cutWidth * burial * (fault ? 0.13 + mouth * 1.8 : 0.26);
      const foot = [at[0] + nx * spread, at[1] + ny * spread, 0];
      if (footHeight > 0) {
        const sectionWidth = 6.5 + phase(s.seed, 830 + salt) * 1.5 + (at[0] / s.length + 0.5) * 1.1 + mouth * 0.8;
        const run = Math.hypot(lip[0] - foot[0], lip[1] - foot[1]);
        const lowEnd = 1 - clamp2(at[2] / (footHeight * 2), 0, 1);
        const toCentre = Math.hypot(lip[0] - centre[0], lip[1] - centre[1]) || 1;
        lip = lerp2(lip, centre, clamp2((sectionWidth - run) * lowEnd / toCentre, 0, 0.34));
      }
      const shoulder = lift(lerp2(lip, centre, Math.min(0.34, (5 + cutWidth * 0.7) * mouth / radius)));
      lip = lift(lip);
      rim.push({ top: lip, foot, shoulder, mouth, distance: distance2 + edgeLength * t, fault });
    }
    distance2 += edgeLength;
  }
  let contactPlaced = false;
  for (let i = 0; i < rim.length; i++) {
    const next = (i + 1) % rim.length, a = rim[i], c = rim[next];
    const region = salt === 2 ? NATIVE_VOLUME_REGIONS.compressed : NATIVE_VOLUME_REGIONS.intact;
    const topUv = (p) => [p[0], p[1]];
    b.quad(
      surfaceCentre,
      a.shoulder,
      c.shoulder,
      surfaceCentre,
      0,
      [topUv(surfaceCentre), topUv(a.shoulder), topUv(c.shoulder), topUv(surfaceCentre)],
      [0, 0, 1],
      region
    );
    b.quad(
      a.shoulder,
      a.top,
      c.top,
      c.shoulder,
      0,
      [topUv(a.shoulder), topUv(a.top), topUv(c.top), topUv(c.shoulder)],
      [0, 0, 1],
      NATIVE_VOLUME_REGIONS.peeled
    );
    const endDistance = next === 0 ? distance2 : c.distance;
    const sideUv = (p, d) => [d, p[2]];
    const open = a.fault && Math.max(a.mouth, c.mouth) > 0.08;
    b.quad(
      a.top,
      a.foot,
      c.foot,
      c.top,
      open ? 1 : 0,
      [sideUv(a.top, a.distance), sideUv(a.foot, a.distance), sideUv(c.foot, endDistance), sideUv(c.top, endDistance)],
      [0, 0, 1],
      open ? NATIVE_VOLUME_REGIONS.fractured : region
    );
    b.quad(
      [centre[0], centre[1], 0],
      c.foot,
      a.foot,
      [centre[0], centre[1], 0],
      2,
      [topUv(centre), topUv(c.foot), topUv(a.foot), topUv(centre)],
      [0, 0, -1],
      NATIVE_VOLUME_REGIONS.intact
    );
    if (salt === 0 && !contactPlaced && a.fault && a.mouth > 0.5 && c.mouth > a.mouth) {
      const point = (t, v) => [
        a.top[0] + t * (c.foot[0] - a.top[0]) + v * (a.foot[0] - a.top[0]),
        a.top[1] + t * (c.foot[1] - a.top[1]) + v * (a.foot[1] - a.top[1]),
        a.top[2] + t * (c.foot[2] - a.top[2]) + v * (a.foot[2] - a.top[2]) + 0.055
      ];
      const p0 = point(0.08, 0.08), p1 = point(0.46, 0.08), p2 = point(0.46, 0.42), p3 = point(0.08, 0.42);
      b.quad(p0, p3, p2, p1, 3, [[0, 0], [0, 6], [12, 6], [12, 0]], [0, 0, 1], NATIVE_VOLUME_REGIONS.compressed);
      b.joint([(p0[0] + p1[0] + p2[0] + p3[0]) * 0.25, (p0[1] + p1[1] + p2[1] + p3[1]) * 0.25, (p0[2] + p1[2] + p2[2] + p3[2]) * 0.25]);
      contactPlaced = true;
    }
  }
}
function fibreKnot(b) {
  const s = b.spec, l = s.length, w = s.width, h = s.height;
  const knotX = l * (-0.08 + (phase(s.seed, 211) - 0.5) * 0.045), knotY = w * (0.05 + 0.12 * s.distortion + (phase(s.seed, 213) - 0.5) * 0.035);
  const main = [
    [-l * 0.51, -w * 0.16, s.thickness * 0.6],
    [-l * 0.3, -w * 0.08, h * 0.27],
    [knotX, knotY, h * 0.57],
    [l * 0.18, w * 0.02, h * 0.38],
    [l * 0.5, w * 0.19, s.thickness * 0.63]
  ];
  sweptBundle(b, main, w * 0.145, 0);
  const cross2 = [
    [-l * 0.24, w * 0.48, s.thickness * 0.44],
    [-l * 0.18, w * 0.28, h * 0.29],
    [knotX + w * 0.07, knotY, h * 0.82],
    [l * 0.04, -w * 0.15, h * 0.45],
    [l * 0.15, -w * 0.46, s.thickness * 0.51]
  ];
  sweptBundle(b, cross2, w * 0.08, 1);
  if (s.branches >= 3) {
    const subordinate = [
      [l * 0.41, -w * 0.38, s.thickness * 0.36],
      [l * 0.2, -w * 0.16, h * 0.25],
      [knotX + w * 0.06, knotY - w * 0.045, h * 0.69],
      [-l * 0.13, w * 0.26, h * 0.35]
    ];
    sweptBundle(b, subordinate, w * 0.047, 2);
  }
  b.joint([knotX + w * 0.04, knotY, h * 0.84]);
}
function sweptBundle(b, spine, radius, salt) {
  const s = b.spec, cross2 = 18, steps = (spine.length - 1) * 8;
  const rings = [];
  for (let i = 0; i <= steps; i++) {
    const whole = i / steps * (spine.length - 1), segment = Math.min(spine.length - 2, Math.floor(whole));
    const t = i === steps ? 1 : whole - segment;
    const a = spine[segment], c = spine[segment + 1];
    const before = spine[Math.max(0, segment - 1)], after = spine[Math.min(spine.length - 1, segment + 2)];
    const curve = (channel, q) => 0.5 * (2 * a[channel] + (-before[channel] + c[channel]) * q + (2 * before[channel] - 5 * a[channel] + 4 * c[channel] - after[channel]) * q * q + (-before[channel] + 3 * a[channel] - 3 * c[channel] + after[channel]) * q * q * q);
    const tangent = (channel) => 0.5 * (-before[channel] + c[channel] + 2 * (2 * before[channel] - 5 * a[channel] + 4 * c[channel] - after[channel]) * t + 3 * (-before[channel] + 3 * a[channel] - 3 * c[channel] + after[channel]) * t * t);
    const dx = tangent(0), dy = tangent(1), len = Math.hypot(dx, dy) || 1;
    const vx = -dy / len, vy = dx / len, along = i / steps;
    const clampWidth = 1 - Math.exp(-Math.pow((along - 0.5) / 0.16, 2)) * (salt === 0 ? 0.3 : 0.12);
    const rootTaper = 0.28 + Math.pow(Math.sin(along * Math.PI), 0.7) * 0.75;
    const r = radius * rootTaper * clampWidth;
    const cx = curve(0, t), cy = curve(1, t), cz = Math.max(r * (s.constructionVersion === 2 ? 0.78 : 0.62), curve(2, t));
    const ring = [];
    for (let j = 0; j < cross2; j++) {
      const angle = j / cross2 * TAU2;
      const root = Math.pow(Math.abs(along - 0.5) * 2, 5);
      const flute = 1 + Math.cos(angle * 5 + salt + along * 3) * (0.045 + 0.07 * root);
      ring.push([
        cx + vx * Math.cos(angle) * r * flute,
        cy + vy * Math.cos(angle) * r * flute,
        cz + Math.sin(angle) * r * (0.57 + 0.19 * Math.sin(along * Math.PI))
      ]);
    }
    rings.push(ring);
  }
  for (let i = 0; i < steps; i++) for (let j = 0; j < cross2; j++) {
    const a = rings[i], c = rings[i + 1], k = (j + 1) % cross2;
    const slot = salt > 0 && i > steps * 0.45 && i < steps * 0.54 && j > 2 && j < 5 ? 3 : 0;
    b.quad(
      a[j],
      c[j],
      c[k],
      a[k],
      slot,
      [
        [i * s.length / steps, j * radius * TAU2 / cross2],
        [(i + 1) * s.length / steps, j * radius * TAU2 / cross2],
        [(i + 1) * s.length / steps, (j + 1) * radius * TAU2 / cross2],
        [i * s.length / steps, (j + 1) * radius * TAU2 / cross2]
      ]
    );
    if (s.constructionVersion === 2 && salt === 1 && i === Math.floor(steps * 0.5) && j === 3) {
      b.joint([
        (a[j][0] + c[j][0] + c[k][0]) / 3,
        (a[j][1] + c[j][1] + c[k][1]) / 3,
        (a[j][2] + c[j][2] + c[k][2]) / 3 + 0.055
      ]);
    }
  }
  for (const end of [0, steps]) {
    const r = rings[end];
    const middle = [
      r.reduce((sum, p) => sum + p[0], 0) / cross2,
      r.reduce((sum, p) => sum + p[1], 0) / cross2,
      r.reduce((sum, p) => sum + p[2], 0) / cross2
    ];
    for (let j = 0; j < cross2; j++) {
      const k = (j + 1) % cross2;
      b.quad(middle, r[j], r[k], middle, end === 0 ? 1 : 2, [[0, 0], [j, radius], [j + 1, radius], [0, 0]]);
    }
  }
}
function brokenShell(b) {
  const s = b.spec;
  const gap = 0.82 + s.opening * 1.35;
  shellPetal(b, -s.length * 0.06, -s.width * 0.045, s.length * 0.49, s.width * 0.47, gap * 0.5, TAU2 - gap, 1, 0);
  shellPetal(
    b,
    s.length * 0.22,
    s.width * 0.16,
    s.length * 0.25,
    s.width * 0.31,
    Math.PI * 1.1,
    Math.PI * (1.08 + s.fold * 0.13),
    0.68,
    1
  );
  b.joint([s.length * 0.22, s.width * 0.02, s.height * 0.34]);
}
function shellPetal(b, ox, oy, rx, ry, begin, sweep, heightScale, salt) {
  const s = b.spec, around = 54, radial = 16, seedPhase = phase(s.seed, 53 + salt) * TAU2;
  const rings = [];
  for (let i = 0; i <= around; i++) {
    const angle = begin + i / around * sweep, ca = Math.cos(angle), sa = Math.sin(angle);
    const jointCompression = Math.exp(-Math.pow((i / around - 0.78) / 0.2, 2));
    const lip = 1 + 0.12 * s.distortion * Math.sin(angle * 2 + seedPhase) - jointCompression * 0.1 + 0.045 * Math.sin(angle * 9 + salt);
    const rimZ = s.height * heightScale * (0.6 + 0.26 * Math.sin(angle - 0.5) + 0.12 * Math.cos(angle * 2 + seedPhase));
    const thickness = clamp2(s.thickness / Math.min(rx, ry), 0.1, 0.42);
    const rimInner = 0.69 - thickness * 0.43;
    const profile = [
      [1, 0],
      [0.96, rimZ * 0.22],
      [0.84 * lip, rimZ * 0.68],
      [0.73 * lip, rimZ],
      [rimInner, rimZ * 0.94],
      [rimInner - 0.09, rimZ * 0.6],
      [0.31, rimZ * 0.14],
      [0.15, s.thickness * 0.17],
      [0, s.thickness * 0.13]
    ];
    const ring = [];
    for (let j = 0; j <= radial; j++) {
      const f = j / radial * (profile.length - 1), a = Math.floor(f), t = f - a;
      const p = profile[a], q = profile[Math.min(a + 1, profile.length - 1)];
      const r = p[0] + (q[0] - p[0]) * t, z = p[1] + (q[1] - p[1]) * t;
      const inner = 1 - r;
      const flare = Math.exp(-Math.pow((angle - (begin + 0.32)) / 0.35, 2)) * s.fold;
      ring.push([
        ox + ca * rx * r + inner * rx * (0.24 + s.distortion * 0.17) + flare * rx * 0.1 * r,
        oy + sa * ry * r - inner * ry * (0.13 + s.distortion * 0.08),
        z * (1 - flare * 0.34) * (1 + 0.07 * Math.sin(angle * 7 + seedPhase) * r)
      ]);
    }
    rings.push(ring);
  }
  for (let i = 0; i < around; i++) for (let j = 0; j < radial; j++) {
    const a = rings[i], c = rings[i + 1];
    const slot = j < 6 ? 0 : j < 8 ? 1 : j < 13 ? 2 : 0;
    b.quad(
      a[j],
      c[j],
      c[j + 1],
      a[j + 1],
      salt === 1 && i < 4 && j >= 7 && j < 12 ? 3 : slot,
      [
        [i / around * sweep * (rx + ry) * 0.5, j / radial * s.width],
        [(i + 1) / around * sweep * (rx + ry) * 0.5, j / radial * s.width],
        [(i + 1) / around * sweep * (rx + ry) * 0.5, (j + 1) / radial * s.width],
        [i / around * sweep * (rx + ry) * 0.5, (j + 1) / radial * s.width]
      ],
      [0, 0, 1]
    );
  }
  for (const end of [0, around]) {
    const ring = rings[end];
    for (let j = 0; j < radial; j++) {
      const a = ring[j], c = ring[j + 1];
      const sign = end === 0 ? -1 : 1, angle = begin + end / around * sweep;
      const dx = -Math.sin(angle) * s.thickness * 0.72 * sign, dy = Math.cos(angle) * s.thickness * 0.72 * sign;
      b.quad(
        a,
        c,
        [c[0] + dx, c[1] + dy, 0],
        [a[0] + dx, a[1] + dy, 0],
        1,
        [[j * s.width / radial, a[2]], [(j + 1) * s.width / radial, c[2]], [(j + 1) * s.width / radial, 0], [j * s.width / radial, 0]],
        [0, 0, 1]
      );
    }
  }
}
function granularRidge(b) {
  const s = b.spec, along = 30, across = 14, rows = [];
  const authored = s.constructionVersion === 2;
  const clusters = Array.from({ length: s.branches + 3 }, (_, i) => ({
    x: (i + 0.25 + phase(s.seed, 910 + i) * 0.5) / (s.branches + 3),
    y: 0.24 + phase(s.seed, 950 + i) * 0.5,
    span: 0.09 + phase(s.seed, 980 + i) * 0.08,
    rise: 0.1 + phase(s.seed, 1010 + i) * 0.2
  }));
  for (let i = 0; i <= along; i++) {
    const u = i / along, taper = 0.25 + 0.75 * Math.pow(Math.sin(Math.PI * u), authored ? 0.25 + s.opening * 0.9 : 0.48), row = [];
    const spine = Math.sin(u * (authored ? 2.2 + s.fold * 3 : 4.5) + phase(s.seed, 897) * 2) * s.width * (authored ? 0.025 + s.distortion * 0.13 : 0.11);
    for (let j = 0; j <= across; j++) {
      const v = j / across, edge = Math.min(u * along, (1 - u) * along, v * across, (1 - v) * across);
      const foot = Math.min(1, edge), peak = (authored ? 0.28 + s.fold * 0.3 : 0.43) + 0.08 * Math.sin(u * 5.4);
      const side = v < peak ? v / peak : (1 - v) / (1 - peak);
      let rise = Math.pow(Math.max(0, side), authored ? 0.48 + s.fold * 1.2 : 0.86) * (0.51 + 0.16 * Math.sin(u * 4 + 1));
      for (const c of clusters) {
        const distance2 = Math.abs(u - c.x) / c.span + Math.abs(v - c.y) / 0.26;
        rise += Math.max(0, 1 - distance2) * c.rise * (authored ? 0.45 + s.distortion * 2 : 1);
      }
      const z = (s.blocking === 1 ? Math.min(8, s.height * 0.26) * foot : 0) + s.height * rise * foot * Math.pow(Math.sin(Math.PI * u), 0.34);
      row.push([(u - 0.5) * s.length, (v - 0.5) * s.width * taper + spine, z]);
    }
    rows.push(row);
  }
  for (let i = 0; i < along; i++) for (let j = 0; j < across; j++) {
    const cut = j === 0 || j === across - 1 || i === 0 || i === along - 1;
    const a = rows[i][j], c = rows[i + 1][j], d = rows[i + 1][j + 1], e = rows[i][j + 1];
    b.quad(
      a,
      c,
      d,
      e,
      cut ? 1 : j > 8 ? 2 : 0,
      [
        [i * s.length / along, j * s.width / across],
        [(i + 1) * s.length / along, j * s.width / across],
        [(i + 1) * s.length / along, (j + 1) * s.width / across],
        [i * s.length / along, (j + 1) * s.width / across]
      ],
      [0, 0, 1],
      cut ? NATIVE_VOLUME_REGIONS.fractured : j < 6 ? NATIVE_VOLUME_REGIONS.compressed : NATIVE_VOLUME_REGIONS.intact
    );
  }
  surfaceFracture(b, rows, [[10.1, 5.9], [11.8, 6.1], [12.5, 5.6], [14.2, 5.8], [15.1, 6.4], [17.4, 6.2]], 0.085);
}
function membraneRim(b) {
  const s = b.spec, around = 46, radial = 12, rows = [];
  const begin = 0.2 + s.opening * 0.3, sweep = TAU2 - (1.35 + s.opening * 1.15), offset = phase(s.seed, 1131) * 1.4;
  for (let i = 0; i <= around; i++) {
    const angle = begin + i / around * sweep, ca = Math.cos(angle), sa = Math.sin(angle);
    const uneven = 1 + 0.13 * Math.sin(angle * 3 + offset) + 0.06 * Math.cos(angle * 5 - 0.3);
    const crown = s.height * (0.64 + 0.24 * Math.sin(angle + 0.8) + 0.09 * Math.cos(angle * 2 + offset));
    const profile = [
      [1, 0],
      [0.955, s.blocking === 1 ? Math.min(crown * 0.35, 9) : crown * 0.05],
      [0.875, crown * 0.82],
      [0.78, crown],
      [0.69, crown * 0.62],
      [0.54, crown * 0.15],
      [0, crown * 0.075]
    ];
    const row = [];
    for (let j = 0; j <= radial; j++) {
      const q = j / radial * (profile.length - 1), n = Math.floor(q), f = q - n;
      const p = profile[n], next = profile[Math.min(n + 1, profile.length - 1)];
      const r = p[0] + (next[0] - p[0]) * f, z = p[1] + (next[1] - p[1]) * f;
      const tension = j > 8 ? Math.sin(angle * 11 + r * 5) * s.thickness * 0.12 * r : 0;
      row.push([ca * s.length * 0.5 * r * uneven + (1 - r) * s.length * 0.1, sa * s.width * 0.49 * r * uneven - (1 - r) * s.width * 0.17, z + tension]);
    }
    rows.push(row);
  }
  for (let i = 0; i < around; i++) for (let j = 0; j < radial; j++) {
    const a = rows[i], c = rows[i + 1];
    const slot = j < 2 ? 1 : j < 8 ? 0 : 2;
    b.quad(
      a[j],
      c[j],
      c[j + 1],
      a[j + 1],
      slot,
      [
        [i * s.length / around, j * s.width / radial],
        [(i + 1) * s.length / around, j * s.width / radial],
        [(i + 1) * s.length / around, (j + 1) * s.width / radial],
        [i * s.length / around, (j + 1) * s.width / radial]
      ],
      [0, 0, 1],
      j > 7 ? NATIVE_VOLUME_REGIONS.tension : NATIVE_VOLUME_REGIONS.intact
    );
  }
  surfaceFracture(b, rows, [[12.2, 2.8], [13.5, 3.3], [13.2, 4.4], [14.1, 5], [13.7, 6.3], [14.6, 7.6], [14.4, 8.7]], 0.095);
  for (const i of [0, around]) for (let j = 0; j < radial; j++) {
    const a = rows[i][j], c = rows[i][j + 1], angle = begin + i / around * sweep, sign = i === 0 ? -1 : 1;
    const dx = -Math.sin(angle) * s.thickness * 0.3 * sign, dy = Math.cos(angle) * s.thickness * 0.3 * sign;
    b.quad(
      a,
      c,
      [c[0] + dx, c[1] + dy, 0],
      [a[0] + dx, a[1] + dy, 0],
      1,
      [[j * s.width / radial, a[2]], [(j + 1) * s.width / radial, c[2]], [(j + 1) * s.width / radial, 0], [j * s.width / radial, 0]],
      [0, 0, 1],
      NATIVE_VOLUME_REGIONS.fractured
    );
  }
}
function gelFlow(b) {
  const s = b.spec, along = 32, across = 20, rows = [];
  const profile = [[0, 0], [0.08, 0.11], [0.33, 0.19], [0.58, 0.38], [0.78, 0.78], [0.88, 1], [0.95, 0.52], [1, 0]];
  for (let i = 0; i <= along; i++) {
    const u = i / along, side = Math.pow(Math.sin(Math.PI * u), 0.35), lobes = 0.12 * Math.sin(u * 13 + phase(s.seed, 1207) * 2) + 0.055 * Math.sin(u * 27 + 0.5);
    const row = [];
    for (let j = 0; j <= across; j++) {
      const v = j / across;
      let p = 0;
      while (p + 1 < profile.length && profile[p + 1][0] < v) p++;
      const a = profile[p], c = profile[Math.min(p + 1, profile.length - 1)], f = (v - a[0]) / Math.max(1e-3, c[0] - a[0]);
      const ridge = a[1] + (c[1] - a[1]) * f, edge = Math.min(u * along, (1 - u) * along, v * across, (1 - v) * across);
      const foot = s.blocking === 1 ? Math.min(s.height * 0.22, 7) * Math.min(1, edge) : 0;
      row.push([
        (u - 0.5) * s.length + (v - 0.5) * s.length * 0.08,
        (v - 0.5) * s.width * (0.3 + side * 0.7) + Math.pow(v, 3) * lobes * s.width,
        foot + ridge * s.height * side * (0.75 + 0.19 * Math.sin(u * 8 + 0.2))
      ]);
    }
    rows.push(row);
  }
  for (let i = 0; i < along; i++) for (let j = 0; j < across; j++) {
    const front = j >= 18, thin = j <= 6;
    const a = rows[i][j], c = rows[i + 1][j], d = rows[i + 1][j + 1], e = rows[i][j + 1];
    b.quad(
      a,
      c,
      d,
      e,
      front ? 1 : thin ? 2 : 0,
      [
        [i * s.length / along, j * s.width / across],
        [(i + 1) * s.length / along, j * s.width / across],
        [(i + 1) * s.length / along, (j + 1) * s.width / across],
        [i * s.length / along, (j + 1) * s.width / across]
      ],
      [0, 0, 1],
      thin ? NATIVE_VOLUME_REGIONS.peeled : front ? NATIVE_VOLUME_REGIONS.compressed : NATIVE_VOLUME_REGIONS.glazed
    );
  }
  surfaceFracture(b, rows, [[10.2, 17.4], [11.5, 17.1], [12.1, 17.7], [13.8, 17.8], [14.4, 18.3], [16.5, 18.1]], 0.09);
}
function shearedBeds(b) {
  const s = b.spec, l = s.length, w = s.width, h = s.height;
  const gap = Math.min(w * 0.4, Math.max(30, w * (0.12 + s.opening * 0.15)));
  const shear = l * (0.025 + s.distortion * 0.1), skew = (phase(s.seed, 1301) - 0.5) * w * 0.05;
  const upper = [
    [-l * 0.5, -w * 0.27, 0],
    [-l * 0.36, -w * 0.5, 0],
    [l * 0.36 - shear, -w * 0.44, 0],
    [l * 0.5 - shear, -gap * 0.56 + skew, 0],
    [l * 0.12 - shear, -gap * 0.5 + skew, 0],
    [-l * 0.42, -gap * 0.6, 0]
  ];
  const lower = [
    [-l * 0.43 + shear, gap * 0.62, 0],
    [-l * 0.04 + shear, gap * 0.5 + skew, 0],
    [l * 0.48, gap * 0.6, 0],
    [l * 0.44, w * 0.43, 0],
    [l * 0.16, w * 0.5, 0],
    [-l * 0.5 + shear, w * 0.36, 0]
  ];
  const incline = (outline, peak, dx, dy) => {
    let min = Infinity, max = -Infinity;
    for (const p of outline) {
      const q = p[0] * dx + p[1] * dy;
      min = Math.min(min, q);
      max = Math.max(max, q);
    }
    let x = 0, y = 0;
    for (let i = 0; i < outline.length; i++) {
      const p = outline[i];
      x += p[0];
      y += p[1];
      outline[i] = [p[0], p[1], (p[0] * dx + p[1] * dy - min) / (max - min) * peak];
    }
    x /= outline.length;
    y /= outline.length;
    return [x, y, (x * dx + y * dy - min) / (max - min) * peak];
  };
  bedMass(b, upper, incline(upper, h, 0.12, -1), 0, [3, 4], Math.min(6, w * 0.024));
  bedMass(b, lower, incline(lower, h * (0.32 + s.fold * 0.5), -0.1, 1), 1, [0, 1], Math.min(5, w * 0.022));
  if (s.branches >= 5) {
    const toe = [[-l * 0.42, w * 0.39, 0], [-l * 0.14, w * 0.42, 0], [-l * 0.05, w * 0.57, 0], [-l * 0.36, w * 0.59, 0]];
    bedMass(b, toe, incline(toe, h * 0.17, 0.2, -1), 2, [0, 1], Math.min(8, w * 0.03));
  }
}
function tensileBranches(b) {
  const s = b.spec, l = s.length, w = s.width, h = s.height;
  const pull = s.fold, joinX = l * (-0.18 + 0.18 * s.opening), joinY = w * (phase(s.seed, 1321) - 0.5) * 0.1;
  const radius = Math.max(s.thickness * 0.65, w * (0.068 + 0.028 * (1 - pull)));
  const main = [
    [-l * 0.52, -w * 0.08, s.thickness * 0.65],
    [-l * 0.28, -w * 0.04, h * 0.43],
    [joinX, joinY, h * 0.72],
    [l * 0.25, w * (0.03 + 0.1 * s.distortion), h * 0.48],
    [l * 0.52, w * 0.14, s.thickness * 0.72]
  ];
  sweptBundle(b, main, radius, 0);
  for (let arm = 1; arm < s.branches; arm++) {
    const side = arm % 2 === 1 ? -1 : 1, rank = Math.floor((arm - 1) / 2), spread = 0.27 + rank * 0.12;
    const attachX = joinX + l * (rank * 0.07 - 0.025), attachY = joinY + w * rank * 0.018;
    const endX = l * (0.46 - rank * 0.11) * (arm % 3 === 0 ? -1 : 1);
    const endY = side * w * Math.min(0.5, spread + s.opening * 0.18);
    const branch = [
      [attachX - l * 0.1, attachY, h * 0.55],
      [attachX, attachY, h * (0.74 - rank * 0.06)],
      [attachX + (endX - attachX) * 0.55, endY * (0.37 + 0.3 * (1 - pull)), h * (0.4 - rank * 0.03)],
      [endX, endY, s.thickness * (0.46 + 0.06 * rank)]
    ];
    sweptBundle(b, branch, radius * (0.7 - rank * 0.085), arm);
  }
}
function openShellWall(b) {
  const s = b.spec, around = 56, radial = 8, rows = [];
  const gap = 0.76 + s.opening * 2.4, begin = gap * 0.5, sweep = TAU2 - gap;
  const inner = 0.43 + s.opening * 0.19, phaseOffset = phase(s.seed, 1351) * TAU2;
  for (let i = 0; i <= around; i++) {
    const u = i / around, angle = begin + u * sweep, ca = Math.cos(angle), sa = Math.sin(angle);
    const uneven = 1 + s.distortion * (0.075 * Math.sin(angle * 2 + phaseOffset) + 0.035 * Math.sin(angle * 5));
    const crown = s.height * (0.66 + 0.23 * Math.sin(angle + 0.7) + 0.09 * Math.cos(angle * 2 + phaseOffset));
    const foot = s.blocking === 1 ? Math.min(9, s.height * 0.3) : s.height * 0.05;
    const lip = 0.82 - s.fold * 0.07;
    const profile = [
      [1, 0],
      [0.97, foot],
      [0.91, crown * 0.58],
      [lip, crown],
      [lip - 0.045, crown * 0.97],
      [inner + 0.075, crown * 0.72],
      [inner + 0.025, foot],
      [inner, 0],
      [inner, 0]
    ];
    rows.push(profile.map(([r, z]) => [
      ca * s.length * 0.5 * r * uneven + (1 - r) * s.length * s.distortion * 0.07,
      sa * s.width * 0.5 * r * uneven,
      z
    ]));
  }
  for (let i = 0; i < around; i++) for (let j = 0; j < radial; j++) {
    const a = rows[i], c = rows[i + 1], joint = i === Math.floor(around * 0.69) && j === 4;
    const slot = joint ? 3 : j < 3 ? 0 : j < 5 ? 1 : 2;
    b.quad(a[j], c[j], c[j + 1], a[j + 1], slot, [
      [i * s.length / around, j * s.width / radial],
      [(i + 1) * s.length / around, j * s.width / radial],
      [(i + 1) * s.length / around, (j + 1) * s.width / radial],
      [i * s.length / around, (j + 1) * s.width / radial]
    ], [0, 0, 1], j < 3 ? NATIVE_VOLUME_REGIONS.intact : j < 5 ? NATIVE_VOLUME_REGIONS.fractured : NATIVE_VOLUME_REGIONS.glazed);
    if (joint) b.joint([(a[j][0] + c[j + 1][0]) * 0.5, (a[j][1] + c[j + 1][1]) * 0.5, (a[j][2] + c[j + 1][2]) * 0.5]);
  }
  for (const end of [0, around]) {
    const row = rows[end], angle = begin + end / around * sweep, sign = end === 0 ? -1 : 1;
    for (let j = 0; j < radial - 1; j++) {
      const a = row[j], c = row[j + 1], dx = -Math.sin(angle) * s.thickness * 0.4 * sign, dy = Math.cos(angle) * s.thickness * 0.4 * sign;
      b.quad(
        a,
        c,
        [c[0] + dx, c[1] + dy, 0],
        [a[0] + dx, a[1] + dy, 0],
        1,
        [[j * s.width / radial, a[2]], [(j + 1) * s.width / radial, c[2]], [(j + 1) * s.width / radial, 0], [j * s.width / radial, 0]],
        [0, 0, 1],
        NATIVE_VOLUME_REGIONS.fractured
      );
    }
  }
}
function tornMembrane(b) {
  const s = b.spec, along = 36, across = 12, rows = [];
  const tearAt = 0.36 + phase(s.seed, 1381) * 0.17, tearDepth = 0.3 + s.opening * 0.58;
  for (let i = 0; i <= along; i++) {
    const u = i / along, edgeTaper = 0.63 + 0.37 * Math.sin(Math.PI * u), row = [];
    const tear = tearDepth * Math.pow(Math.max(0, 1 - Math.abs(u - tearAt) / (0.11 + s.distortion * 0.045)), 0.72);
    const second = s.branches >= 5 ? tearDepth * 0.68 * Math.pow(Math.max(0, 1 - Math.abs(u - 0.79) / 0.08), 0.8) : 0;
    const front = 1 - Math.max(tear, second);
    for (let j = 0; j <= across; j++) {
      const v = j / across, local = v * front;
      const taut = Math.pow(Math.sin(Math.PI * u), 0.45), curl = Math.exp(-Math.pow((local - (0.16 + s.fold * 0.09)) / 0.18, 2));
      const fold = Math.pow(Math.max(0, Math.sin(u * Math.PI * (s.branches - 1) + local * 2)), 3) * s.distortion * 0.15;
      const foot = s.blocking === 1 ? Math.min(8, s.height * 0.3) : 0;
      const z = foot + s.height * taut * (curl * (0.5 + s.fold * 0.3) + 0.075 + fold) * (0.55 + 0.45 * Math.sin(Math.PI * v));
      row.push([(u - 0.5) * s.length, (local - 0.5) * s.width * edgeTaper, z]);
    }
    rows.push(row);
  }
  for (let i = 0; i < along; i++) for (let j = 0; j < across; j++) {
    const a = rows[i], c = rows[i + 1], slot = j < 3 ? 0 : j > 9 ? 1 : 2;
    b.quad(a[j], c[j], c[j + 1], a[j + 1], slot, [
      [i * s.length / along, j * s.width / across],
      [(i + 1) * s.length / along, j * s.width / across],
      [(i + 1) * s.length / along, (j + 1) * s.width / across],
      [i * s.length / along, (j + 1) * s.width / across]
    ], [0, 0, 1], j < 3 ? NATIVE_VOLUME_REGIONS.compressed : NATIVE_VOLUME_REGIONS.tension);
  }
  const outline = [];
  for (let i = 0; i <= along; i++) outline.push(rows[i][0]);
  for (let j = 1; j <= across; j++) outline.push(rows[along][j]);
  for (let i = along - 1; i >= 0; i--) outline.push(rows[i][across]);
  for (let j = across - 1; j > 0; j--) outline.push(rows[0][j]);
  for (let i = 0; i < outline.length; i++) {
    const a = outline[i], c = outline[(i + 1) % outline.length], dx = c[0] - a[0], dy = c[1] - a[1], length = Math.hypot(dx, dy) || 1;
    const width = s.blocking === 1 ? Math.min(6, s.thickness * 0.55) : 1.5, ox = dy / length * width, oy = -dx / length * width;
    b.quad(a, [a[0] + ox, a[1] + oy, 0], [c[0] + ox, c[1] + oy, 0], c, 1, [[0, a[2]], [0, 0], [length, 0], [length, c[2]]], [0, 0, 1], NATIVE_VOLUME_REGIONS.fractured);
  }
  surfaceFracture(b, rows, [[8.2, 3.4], [9.7, 4], [10.3, 4.5], [11.8, 4.8], [12.3, 5.4]], 0.085);
}
function pooledGel(b) {
  const s = b.spec, along = 38, across = 22, rows = [];
  const lobeCount = Math.max(2, s.branches - 1), offset = phase(s.seed, 1411) * 1.7;
  for (let i = 0; i <= along; i++) {
    const u = i / along, side = Math.pow(Math.sin(Math.PI * u), 0.28), row = [];
    const lobes = Math.pow(0.5 + 0.5 * Math.sin(u * Math.PI * 2 * lobeCount + offset), 2);
    const irregular = 0.045 * Math.sin(u * 19 + offset);
    for (let j = 0; j <= across; j++) {
      const v = j / across, edge = Math.min(u * along, (1 - u) * along, v * across, (1 - v) * across);
      const frontAt = 0.74 + s.opening * 0.13, front = Math.exp(-Math.pow((v - frontAt) / (0.09 + s.fold * 0.09), 2));
      const pool = 0.065 + Math.sin(Math.PI * v) * (0.09 + s.opening * 0.04);
      const ridge = front * (0.42 + s.fold * 0.39) * (0.6 + 0.4 * lobes);
      const foot = s.blocking === 1 ? Math.min(8, s.height * 0.28) * Math.min(1, edge) : 0;
      row.push([
        (u - 0.5) * s.length + (v - 0.5) * s.length * s.distortion * 0.1,
        (v - 0.5) * s.width * (0.5 + side * 0.5) + Math.pow(v, 4) * s.width * (lobes * (0.09 + s.distortion * 0.12) + irregular),
        foot + (pool + ridge) * s.height * side * Math.min(1, edge)
      ]);
    }
    rows.push(row);
  }
  for (let i = 0; i < along; i++) for (let j = 0; j < across; j++) {
    const a = rows[i], c = rows[i + 1], front = j >= across - 2, thin = j < across * 0.48;
    b.quad(
      a[j],
      c[j],
      c[j + 1],
      a[j + 1],
      front ? 1 : thin ? 2 : 0,
      [
        [i * s.length / along, j * s.width / across],
        [(i + 1) * s.length / along, j * s.width / across],
        [(i + 1) * s.length / along, (j + 1) * s.width / across],
        [i * s.length / along, (j + 1) * s.width / across]
      ],
      [0, 0, 1],
      front ? NATIVE_VOLUME_REGIONS.compressed : thin ? NATIVE_VOLUME_REGIONS.peeled : NATIVE_VOLUME_REGIONS.glazed
    );
  }
  surfaceFracture(b, rows, [[12.1, 17.4], [13.2, 17.8], [14.1, 17.7], [15.2, 18.1], [16.4, 18]], 0.09);
}
function surfaceFracture(b, rows, path, halfWidth) {
  const sample = (u, v) => {
    const i = clamp2(Math.floor(u), 0, rows.length - 2), j = clamp2(Math.floor(v), 0, rows[0].length - 2), a = u - i, t = v - j;
    const p = rows[i][j], q = rows[i + 1][j], r = rows[i + 1][j + 1], s = rows[i][j + 1];
    const weights = t <= a ? [1 - a, a - t, t, 0] : [1 - t, 0, a, t - a];
    return [
      p[0] * weights[0] + q[0] * weights[1] + r[0] * weights[2] + s[0] * weights[3],
      p[1] * weights[0] + q[1] * weights[1] + r[1] * weights[2] + s[1] * weights[3],
      p[2] * weights[0] + q[2] * weights[1] + r[2] * weights[2] + s[2] * weights[3] + 0.12
    ];
  };
  for (let i = 1; i < path.length; i++) {
    const a = path[i - 1], c = path[i], dx = c[0] - a[0], dy = c[1] - a[1], length = Math.hypot(dx, dy), px = -dy / length * halfWidth, py = dx / length * halfWidth;
    const uv6 = [[a[0] + px, a[1] + py], [c[0] + px, c[1] + py], [c[0] - px, c[1] - py], [a[0] - px, a[1] - py]];
    b.quad(sample(...uv6[0]), sample(...uv6[1]), sample(...uv6[2]), sample(...uv6[3]), 3, uv6, [0, 0, 1], NATIVE_VOLUME_REGIONS.fractured);
  }
  const centre = path[Math.floor(path.length / 2)];
  b.joint(sample(...centre));
}
function buildNativeVolume(spec, ground) {
  validateNativeVolumeSpec(spec);
  if (spec.groundEdgeWidth !== void 0 && !ground) throw new Error("Native ground edge is missing its authoritative terrain context");
  const builder = new MeshBuilder(spec);
  if (spec.constructionVersion === 4) buildGroundNativeVolume(builder);
  else if (spec.constructionVersion === 3) buildExpandedNativeVolume(builder);
  else if (spec.constructionVersion === 2) {
    if (spec.family === "folded-slab") shearedBeds(builder);
    else if (spec.family === "fibre-knot") tensileBranches(builder);
    else if (spec.family === "broken-shell") openShellWall(builder);
    else if (spec.family === "membrane-rim") tornMembrane(builder);
    else if (spec.family === "gel-flow") pooledGel(builder);
    else granularRidge(builder);
  } else if (spec.family === "folded-slab") foldedSlab(builder);
  else if (spec.family === "fibre-knot") fibreKnot(builder);
  else if (spec.family === "broken-shell") brokenShell(builder);
  else if (spec.family === "granular-ridge") granularRidge(builder);
  else if (spec.family === "membrane-rim") membraneRim(builder);
  else gelFlow(builder);
  if (spec.groundEdgeWidth !== void 0) {
    builder.beginGroundEdges();
    appendNativeGroundEdges(builder, ground);
  }
  const mesh = builder.finish();
  if (spec.constructionVersion === 4 && (spec.shapeProfile === "compressed-wedge" || spec.shapeProfile === "porous-break"))
    return smoothOrganizedSurface(mesh);
  return mesh;
}

// src/config/constants.ts
var GAME_CONSTANTS = {
  /** Tile size in pixels */
  TILE_SIZE: 32,
  /** Camera. Zoom 1.5 on a 960x640 canvas gives a ~640x427 logical viewport = ~20x13 tiles (DEC-009). */
  CAMERA: {
    ZOOM: 1.5
  },
  /** Player movement (docs/specs/system-movement-vision.md, section M) */
  PLAYER: {
    SPEED: 80,
    // px/s base speed = 2.5 tiles/s (tuned down for deliberate stealth feel)
    MAX_HEALTH: 100,
    INVENTORY_SLOTS: 4,
    MOVE_ACCEL_TIME: 0.08,
    // s from standstill to full speed
    MOVE_DECEL_TIME: 0.1,
    // s from full speed to standstill
    FACING_TURN_RATE: 1080,
    // deg/s the vision cone swings toward the input direction
    FACING_QUANT_HYSTERESIS: 5,
    // deg of dead zone around the 45 degree facing4 boundaries
    BODY_SIZE: 20,
    // px collider edge; < TILE_SIZE so 1-tile gaps stay passable
    BODY_OFFSET: { x: 6, y: 6 },
    // centres the collider inside the 32x32 sprite
    SPEED_MOD_MIN: 0.5
    // floor on the multiplied speed modifier stack
  },
  /**
   * Presentation-only gait (art-direction §3.3). Does not change facingAngle,
   * facing4 snap timing, speeds, or colliders.
   */
  ACTOR_MOTION: {
    FRAME_COUNT: 4,
    TURN_MS: 180,
    LAG_PX: 3,
    LAG_ALPHA: 0.38,
    MOVE_SPEED_FLOOR: 6,
    // px/s; below this the idle cycle plays
    PLAYER_IDLE_FPS: 4,
    PLAYER_WALK_FPS: 8,
    INFILTRATOR_IDLE_FPS: 4,
    INFILTRATOR_WALK_FPS: 4,
    // puppet hitch supplies the step; keep the sheet slow
    REWRITER_IDLE_FPS: 4,
    REWRITER_WALK_FPS: 6
  },
  /** Chaos system (docs/specs/system-chaos-scavenge-extract.md) */
  CHAOS: {
    START_VALUE: 0,
    MAX_VALUE: 100,
    // HUD gauge max (value CAN exceed this)
    HARD_CAP: 150,
    BASE_RATE: 0.5,
    // points per second (DEC-024: calibrated for 80 px/s travel)
    THRESHOLD_1: 50,
    THRESHOLD_2: 75,
    THRESHOLD_3: 100,
    COMBAT_BONUS: 5,
    DETECTION_BONUS: 3,
    DETECTION_BONUS_COOLDOWN: 1e4,
    // ms per-enemy cooldown on detection chaos
    CHASE_RATE_MULT: 2,
    EMIT_STEP: 1,
    // minimum delta before emitting CHAOS_CHANGED
    MODULATOR_STEP: 1
    // minimum delta before calling onModulate callback
  },
  /** Loot / kindling nodes (docs/specs/system-chaos-scavenge-extract.md) */
  LOOT: {
    /** 迭代 10 起退役，见 spec 规则 14。名义参数，代码无引用；由 SEARCH_RADIUS 取代。 */
    PICKUP_RADIUS: 16,
    NODE_COUNT: 8,
    VALUE_SAFE: 1,
    VALUE_CONTESTED: 2,
    VALUE_DEEP: 4,
    SEARCH_CHANNEL_MS: 1200,
    SEARCH_RADIUS: 48,
    SEARCH_NOISE_RADIUS: 96,
    SEARCH_NOISE_LEVEL: "suspicious"
  },
  /** Extraction point (docs/specs/system-chaos-scavenge-extract.md) */
  EXTRACTION: {
    TRIGGER_RADIUS: 48,
    KEY: "E",
    SETTLE_DELAY_MS: 600,
    RESTART_KEY: "R"
  },
  /**
   * Visibility / FOV (docs/specs/system-movement-vision.md, section V).
   * Models a forward cone unioned with an ambient ring, with three fixed-width edge
   * bands. The older single-radius + edge-softness model was replaced rather than
   * extended, so the two parameter sets never coexist.
   */
  VISIBILITY: {
    RADIUS_FORWARD: 224,
    // px straight ahead (7 tiles); must exceed every profile sightRange (I1)
    RADIUS_AMBIENT: 80,
    // px all around (2.5 tiles) = the lamp the player carries
    CONE_HALF_ANGLE: 50,
    // deg half-angle of the full-range sector
    CONE_FALLOFF_ANGLE: 30,
    // deg of transition from forward range down to ambient
    MIN_SOLID_RADIUS: 48,
    // px that stay fully lit no matter what
    EDGE_BAND_WIDTH: 32,
    // px per gradient band (1 tile, art-direction 4.3)
    BAND_ALPHAS: [1, 0.6, 0.2],
    // visibility of core / middle / outer band
    ERASE_ALPHAS: [1, 0.5, 0.2],
    // per-layer erase strength producing those alphas
    RAY_COUNT: 60,
    // architecture ceiling
    RAY_SPLIT_FORWARD: 40,
    // rays inside the cone sector
    RAY_SPLIT_AMBIENT: 20,
    // rays across the remaining angles
    RAY_COUNT_DEGRADED: 40,
    // first degradation step
    RAY_SPLIT_FORWARD_DEGRADED: 28,
    RAY_SPLIT_AMBIENT_DEGRADED: 12,
    MIN_RADIUS_SCALE: 0.4,
    // hard floor for the chaos radius modulator
    CACHE_POS_EPSILON: 0.5,
    // px of movement tolerated before the cache is dropped
    CACHE_ANGLE_EPSILON: 0.5,
    // deg of rotation tolerated before the cache is dropped
    BUDGET_MS: 2,
    // per-frame raycasting budget
    DEGRADE_SAMPLE_FRAMES: 30,
    // consecutive frames over budget before degrading
    /** Void outside the field of view */
    VOID_COLOR: 526860,
    VOID_NOISE_ALPHA: 0.04,
    VOID_NOISE_TILE: 64,
    // px noise texture size
    VOID_NOISE_SCROLL: 2,
    // px/s drift
    /** Warm lamp the player carries - the only warm light inside a rift */
    PLAYER_LAMP_COLOR: 9067562,
    PLAYER_LAMP_ALPHA: 0.12,
    /**
     * Flashlight beam: an additive warm pool pushed forward along facing and clipped to
     * the vision cone by the darkness mask. This is what makes the forward cone read as
     * "lit by a flashlight" rather than merely "revealed" (A-G3 / DEC-018 beam gain).
     */
    FLASHLIGHT_COLOR: 11047018,
    // pale warm; a saturated brown would wash the cold floor out
    FLASHLIGHT_ALPHA: 0.16,
    // low enough that fragment L1 (clinic/metro/soil) still reads under the cone
    FLASHLIGHT_FORWARD_FRAC: 0.34,
    // push the pool centre this fraction of forward range ahead
    FLASHLIGHT_RADIUS_FRAC: 0.85,
    // pool radius as a fraction of forward range
    /** Glow bleeding through the darkness (Slice 1: extraction point only) */
    GLOW_LEAK_ALPHA: 0.25,
    GLOW_LEAK_RADIUS: 48,
    /** Chaos corruption of the vision edge */
    CORRUPTION_COLOR: 1748374,
    CORRUPTION_MAX_MIX: 0.6,
    // alpha of the teal band at corruption 1.0
    CORRUPTION_MAX_DEPTH: 0.35,
    // fraction of the range teal can eat at corruption 1.0
    CORRUPTION_JITTER_PX: 4,
    CORRUPTION_JITTER_HZ: 6,
    /**
     * Overflow (chaos > 100) full-screen teal wash. Persistent base stays well below the
     * old 0.08 epilepsy cap; the jump is a discrete ~2 s pulse (not a strobe), so its
     * peak can read as a "skip" without a rapid flash train.
     */
    FLICKER_BASE_ALPHA: 0.05,
    FLICKER_JUMP_ALPHA: 0.16,
    FLICKER_JUMP_PERIOD_MS: 2200,
    FLICKER_JUMP_WIDTH_MS: 140,
    /** Extra teal bite / edge jitter scale at screenFlicker = 1.0 */
    OVERFLOW_CORRUPTION_DEPTH_BOOST: 0.4,
    OVERFLOW_JITTER_BOOST: 1,
    /** Purification point overrides (omni mode) */
    PURIFY_RADIUS: 400,
    PURIFY_RAY_COUNT: 90
  },
  /**
   * Enemy AI (docs/specs/system-enemy-ai.md, "数值结构"). Every AI number lives here;
   * none are inlined in the systems.
   *
   * Six of these values are load-bearing relations rather than free parameters - the
   * balance invariants I1-I6 that make stealth playable at all. `config/invariants.ts`
   * asserts them at boot so tuning cannot silently break one.
   *
   * The old `SIGHT_ANGLE: 90 // cone half-angle` key was removed rather than kept: its
   * meaning split into a core cone and a peripheral band, and three overlapping angle
   * parameters would have been three ways to be wrong.
   */
  AI: {
    // --- movement and body (shared; per-role speeds live in data/enemies.csv) ---
    TURN_RATE: 360,
    // deg/s; a third of the player's, which is what makes flanking work (I6)
    BODY_SIZE: 20,
    // px collider edge; < TILE_SIZE so 1-tile gaps stay passable
    BODY_OFFSET: { x: 6, y: 6 },
    // centres the collider inside the 32x32 infiltrator sprite
    SEPARATION_RADIUS: 24,
    // px; soft repulsion instead of enemy-vs-enemy physics
    SEPARATION_WEIGHT: 0.35,
    // how strongly separation bends the movement direction
    STANDOFF_DISTANCE: 30,
    // px; where a chaser stops. Must stay under COMBAT.ATTACK_RANGE
    STANDOFF_BAND: 4,
    // px of tolerance around it (26..34)
    STANDOFF_ADJUST_SPEED: 60,
    // px/s used to back off when the player crowds it
    // --- perception (shared; cone / hearing radii / weights live in data/enemies.csv) ---
    DETECT_FILL_TIME: 0.45,
    // s of clear sight to go from 0 to certain; then × visionWeight
    HEAR_FILL_TIME: 2,
    // s of hearing fill baseline; then × hearingWeight × moveMult
    HEARING_STILL_CAP: 0.2,
    // still-hearing cannot push detection past this (below 0.35)
    HEAR_ALERT_THRESHOLD: 0.7,
    // rewriter T0-4b: hearing can push to ALERT, never CHASE
    DETECT_DIST_FACTOR_NEAR: 1.6,
    // detection rate multiplier at point blank
    DETECT_DIST_FACTOR_FAR: 0.5,
    // ...and at the edge of sight range
    DETECT_ZONE_FACTOR_PERIPH: 0.45,
    // peripheral vision fills far slower than the core cone
    SUSPICION_THRESHOLD: 0.35,
    // detection at which it stops and turns - the player's warning
    REACQUIRE_THRESHOLD: 0.5,
    // lower bar to re-lock while already searching
    DETECT_DECAY_RATE: 0.67,
    // per s; ~1.5 s to clear after breaking sight
    DETECT_DECAY_ALERT_SCALE: 0.5,
    // decays half as fast while searching: it is holding a grudge
    HEARING_JITTER: 32,
    // px of positional fuzz, so hearing is not a wall-hack locator
    PERCEPTION_TICK_MS: 100,
    // 10 Hz perception; one raycast per enemy per tick
    PERCEPTION_TICK_MS_FAR: 200,
    // 5 Hz beyond ACTIVE_RANGE (rule N8)
    // --- timers (section "计时器") ---
    LOS_GRACE_MS: 400,
    // how long a chase survives with no line of sight
    LOST_PLAYER_DURATION: 5e3,
    // ms of ALERT searching
    ALERT_DURATION: 3e3,
    // ms a SUSPICIOUS enemy stays wary with no new stimulus
    CHASE_ABANDON_RANGE: 320,
    // px past which an unseen chase is given up
    WAYPOINT_PAUSE_MS: 1200,
    // dwell at a patrol waypoint - the player's window to slip past
    SCAN_HOLD_MS: 600,
    // dwell on each scan heading
    SEARCH_HOLD_MS: 800,
    // dwell at each ALERT search point
    EXTRAPOLATE_SEC: 0.6,
    // how far ahead of the last sighting to guess - punishes running straight
    SEARCH_SPREAD: 96,
    // px radius of the random third search point
    ALERT_EMIT_COOLDOWN_MS: 1e3,
    // suppression window for repeated same-level ENEMY_ALERT
    SUSPICIOUS_TURN_HOLD_MS: 200,
    // minimum standstill when turning to look (rule B2, ">= 0.2 s")
    SCAN_SWEEP_ANGLE: 45,
    // deg to each side when scanning in place
    SCAN_SWEEP_PERIOD_MS: 1500,
    // full left-right-left sweep period
    FACING_ARRIVE_EPSILON: 6,
    // deg within which a turn counts as completed
    // --- pathfinding and performance (section "寻路与性能") ---
    MAX_PATHS_PER_FRAME: 1,
    // architecture hard rule
    REPATH_INTERVAL_MS: 500,
    REPATH_INTERVAL_MS_FAR: 1e3,
    // for requests past SIMPLE_PATH_RANGE (rule N5)
    REPATH_MOVE_THRESHOLD: 48,
    // px of target movement that earns an early chase repath
    SIMPLE_PATH_RANGE: 384,
    // px past which a request drops to the lowest priority
    ASTAR_MAX_NODES: 3e3,
    // expansion ceiling; real cap is the 5ms budget, not node count. Worst cross-map search measured 1050 nodes / 0.31ms, so 3000 stays well under 5ms and leaves RETURN headroom (DEC-022)
    PATH_FAIL_LIMIT: 3,
    // consecutive failures before giving up on the goal
    ACTIVE_RANGE: 640,
    // px; beyond this the FSM runs at 5 Hz and never asks for a path
    ARRIVE_EPSILON: 8,
    // px within which a path point counts as reached
    MAX_ACTIVE_ENEMIES: 8,
    // Slice 1 uses 4; more than this means the map data is wrong
    MAX_PATH_POINTS: 64,
    // capacity of a per-enemy dynamic path buffer
    DT_CLAMP_MS: 100,
    // stops a backgrounded tab from teleporting enemies on return
    /**
     * Stuck watchdog. Rule N4 skips A* whenever the target is in line of sight, but a
     * clear sight line does not prove a 20 px body fits through the diagonal seam it
     * crosses. Instead of pre-emptively restricting N4 to 3 tiles, we detect the
     * symptom (wanting to move but not moving) and fall back to a real path.
     */
    STUCK_REPATH_MS: 400,
    STUCK_PATH_PREFERENCE_MS: 2e3,
    // how long a stuck enemy keeps preferring A* over straight lines
    STUCK_PROGRESS_FRACTION: 0.25,
    // actual/desired speed below which we count as stuck
    // --- placeholder presentation (section "占位期表现", art-direction 12) ---
    BODY_COLOR: 13386820,
    // "low tier enemy"; encodes tier, never state
    INDICATOR_COLOR: 2811592,
    // contamination teal; state lives here
    SUSPICIOUS_BREATH_HZ_MIN: 1.5,
    // breathing rate at the suspicion threshold...
    SUSPICIOUS_BREATH_HZ_MAX: 3,
    // ...and at full certainty (rule R3)
    ALERT_BLINK_HZ: 3,
    // blinking = searching
    AFTERIMAGE_INTERVAL_MS: 100,
    AFTERIMAGE_LIFETIME_MS: 300,
    AFTERIMAGE_ALPHA: 0.3,
    AFTERIMAGE_SLOTS: 4,
    // ring buffer per enemy; lifetime/interval + 1
    /** Rule R5's fallback visualisation. The cone drawing itself is not implemented yet. */
    DEBUG_SHOW_VISION_CONE: false
  },
  /** Map generation */
  MAP: {
    WIDTH: 80,
    // tiles (larger to accommodate multiple fragments)
    HEIGHT: 80,
    // tiles
    /** Voronoi partitioning */
    FRAGMENT_COUNT_MIN: 4,
    FRAGMENT_COUNT_MAX: 6,
    FRAGMENT_MIN_AREA: 150,
    // minimum tiles per fragment
    /** Cellular automata */
    CA_ITERATIONS: 5,
    // smoothing passes
    CA_WALL_THRESHOLD: 4,
    // cells with >= N wall neighbors become wall
    CA_INITIAL_FILL: 0.45,
    // initial random fill ratio (lower = more open)
    /** Fracture connections between fragments */
    FRACTURE_WIDTH: 2,
    // tiles (narrow passage width)
    FRACTURE_MAX_PER_EDGE: 2
    // max connections between two adjacent fragments
  },
  /**
   * Slice 6 C1 land outline. Rectangular tile buffer; walkable land must not fill it.
   * 80×80 MAP.* numbers stay architecture placeholders — do not use them for this generator.
   */
  GENERATION: {
    BUFFER_COLS: 64,
    BUFFER_ROWS: 42,
    MAX_OUTLINE_ATTEMPTS: 28,
    LAND_FILL_MIN: 0.24,
    LAND_FILL_MAX: 0.48,
    BORDER_RING: 2,
    /** Fraction of the outer ring that may be land. Higher = island hugging the rectangle. */
    BORDER_OCCUPANCY_MAX: 0.12,
    /** Land / axis-aligned bbox. Circles sit near 0.78; filled rectangles sit near 1. */
    BBOX_FILL_MAX: 0.8,
    /**
     * Share of land cells that touch void. Large blobs naturally sit lower;
     * this only rejects near-solid blocks (a 1-cell frame around a filled rect).
     */
    ROUGHNESS_MIN: 0.08,
    /** bbox must leave at least this many leftover cells on width+height combined. */
    MIN_BBOX_SLACK: 8,
    MAX_EDGES_TOUCHING: 3,
    MAX_RUIN_ATTEMPTS: 40,
    MIN_FEATURE_SEPARATION: 7,
    WALL_RATIO_MIN: 0.018,
    WALL_RATIO_MAX: 0.22,
    /** Largest leftover open rectangle (tiles). Bigger than this reads as an empty plaza. */
    YARD_AREA_MAX: 64
  },
  /** Purification point (docs/specs/system-purification-impact.md) */
  PURIFICATION: {
    /** Spatial layout */
    MAP_COLS: 14,
    // tiles
    MAP_ROWS: 12,
    // tiles
    INTERACTION_RADIUS: 32,
    // pixels for module/rift-entrance interaction
    /** Module state */
    MODULE_INITIAL_HP: 70,
    /** Tier-0 repair cap / effect denominator baseline (DEC-064). */
    MODULE_BASE_MAX_HP: 100,
    /** Alias of MODULE_BASE_MAX_HP so older call sites still compile. */
    MODULE_MAX_HP: 100,
    /** Each thicken tier adds this many maxHp to every module. */
    MODULE_MAX_HP_PER_TIER: 15,
    /** Highest purchasable thicken tier (maxHp = 100 + 15*3 = 145). */
    MODULE_MAX_HP_TIERS: 3,
    // Thickening purchase costs are authored alongside all other growth steps
    // in data/growth-route.csv, not a separate system-constant price ladder.
    /** All three module effects use this HP reference; thickening does not raise it. */
    MODULE_EFFECT_HP_REF: 100,
    /** Starting chaos when purifier hp = 0 (full integrity → 0). */
    CHAOS_HARD_START: 50,
    REPAIR_PER_KINDLING: 4,
    // 1 kindling = this many hp (tuned for scarcity)
    /** Impact system (intensity now driven by TideSystem, see TIDE constants) */
    BASE_IMPACT_DAMAGE: 30,
    THREAT_FOCUS_RATIO: 0.65,
    // primary target gets this fraction of total damage
    FORECAST_ACCURACY: 0.8,
    // particle prediction accuracy
    /** combust defense mechanic (DEC-030): fixed threshold, not derived from
     * BASE_IMPACT_DAMAGE, so tide-driven damage swings don't shift the trigger point.
     * Value chosen to equal ~2x BASE_IMPACT_DAMAGE(30) per the CSV's "约等于2次满额冲击". */
    COMBUST_BURN_THRESHOLD: 60,
    /** Module effects */
    MAX_CORE_REDUCTION: 0.3,
    // chaosRate reduction at full hp
    MAX_STORAGE_BONUS: 0.5,
    // kindling value bonus at full hp
    /** resonate (Slice 5 gap-fill, DEC-039): "装备期间CORE和STORAGE模块效果上限各提升10%".
     * A flat bump to both caps above while at least one resonate sits in a defense slot -
     * not a multiplier, so it reads the same way the CSV states it ("+10%" alongside two
     * numbers already expressed as flat percentages). "不叠加" is enforced by storing this
     * as a single on/off flag (`GameState.isResonateBonusActive()`), not a per-item count. */
    RESONATE_MODULE_CAP_BONUS: 0.1,
    /** siphon (Slice 5 gap-fill): "装备期间所有薪柴修复模块的效率翻倍(1薪柴=8hp)" - same
     * "装备期间" derivation pattern as RESONATE_MODULE_CAP_BONUS above (owned by
     * `ContaminantSystem.syncRepairEfficiencyMult()` + `GameState`, not a per-impact
     * defense-engine effect), since the CSV names it a standing equip-state bonus rather
     * than a one-impact trigger. 4 (REPAIR_PER_KINDLING) * 2.0 = 8, matching the CSV. */
    SIPHON_REPAIR_EFFICIENCY_MULT: 2,
    /** Boundary atmosphere */
    ATMOSPHERE: {
      PARTICLE_COUNT: 50,
      // active boundary particles
      PARTICLE_ALPHA_MIN: 0.06,
      PARTICLE_ALPHA_MAX: 0.25,
      PARTICLE_SPEED: 8,
      // px/s slow inward drift
      APPARITION_INTERVAL_MIN: 8e3,
      // ms
      APPARITION_INTERVAL_MAX: 15e3,
      APPARITION_DURATION: 3e3,
      // ms (0.5s fade in + 2s hold + 0.5s fade out)
      APPARITION_MAX_SIMULTANEOUS: 3
    },
    /** Dynamic boundary shape (polar pressure blob) */
    BOUNDARY: {
      SHRINK_AT_MAX_INTENSITY: 0.72,
      // tideScale at intensity 3.0 (boundary loses up to 28%)
      PRESSURE_PRIMARY_AMP: 0.2,
      // max inward push fraction (primary Gaussian lobe)
      PRESSURE_SECONDARY_AMP: 0.1,
      // secondary lobe amplitude
      PRESSURE_LOBE_SIGMA: 0.7,
      // radians; width of each Gaussian lobe
      PRESSURE_CREST_BONUS: 0.4,
      // +40% amplitude during crest phase
      PRESSURE_EBB_FACTOR: 0.6,
      // amplitude multiplier during ebb phase
      SAFE_MARGIN_TILES: 1,
      // minimum distance from any interaction point to boundary
      GRADIENT_INNER_START: 0.8,
      // fraction of R where darkening begins
      GRADIENT_MEMBRANE_START: 0.95,
      // fraction where "membrane" teal band begins
      GRADIENT_OUTER_END: 1.15,
      // fraction where full void begins
      /**
       * B4 (Slice 5): the old BREATH_BASE_ALPHA/AMP/FREQ/CREST_FREQ_MULT/EBB_AMP_MULT
       * keys described a single global sinusoidal pulse from a "whole-boundary breathing"
       * design that DEC-028 (Slice 4.5) replaced with localized pressure impacts
       * (`src/systems/boundary-breath.ts`). Those 5 keys had zero consumers and were
       * removed; this nested object holds boundary-breath.ts's real tuning knobs
       * (previously inlined as top-of-file `const`s there) instead. Values unchanged.
       */
      BREATH: {
        SAMPLE_COUNT: 72,
        // angular resolution of the membrane/impact draw
        MAX_IMPACTS: 5,
        // max simultaneous localized impacts
        ARC_HALF_MIN: 0.4,
        // rad; narrowest impact arc half-width
        ARC_HALF_MAX: 0.8,
        // rad; widest impact arc half-width
        SPAWN_DIST_MIN: 14,
        // px; closest impact spawn distance outside the membrane
        SPAWN_DIST_MAX: 30,
        // px; farthest impact spawn distance
        IMPACT_DURATION_MIN: 1800,
        // ms; shortest single-impact lifetime
        IMPACT_DURATION_MAX: 3500,
        // ms; longest single-impact lifetime
        SPAWN_INTERVAL_MIN: 400,
        // ms; shortest gap between new impacts
        SPAWN_INTERVAL_MAX: 1200,
        // ms; longest gap between new impacts (x0.6 during crest)
        WAVE_COLOR: 936511,
        // dark desaturated teal, the inbound wave arcs
        MEMBRANE_COLOR: 1735274,
        // the boundary membrane line itself
        DEFORM_MAX_PX: 8
        // px; max inward push of the membrane at impact center
      }
    },
    /** Scene transition timing */
    IMPACT_RESULT_DISPLAY_MS: 2e3,
    SCENE_TRANSITION_DELAY_MS: 600
  },
  /**
   * Combat (docs/specs/system-combat.md, "数值结构"). Every combat number lives here.
   *
   * The system is a price list, not a fight: the point is that the player can work out
   * what swinging costs before swinging. Three of these relations carry that promise and
   * are asserted at boot by `config/invariants.ts` (K1/K2/K3/K5) - notably
   * `ENEMY_MAX_HEALTH` being an exact multiple of `PLAYER_DAMAGE`, which is what makes
   * "three hits" a fact rather than an average.
   *
   * When combat turns out too cheap in playtesting, the spec's tuning order is
   * `CHAOS.COMBAT_BONUS` and `NOISE_HIT_RADIUS` first, `ENEMY_MAX_HEALTH` second, and
   * `PLAYER_DAMAGE` never (weakening it makes combat expensive *and* unpleasant).
   */
  COMBAT: {
    // --- player attack (section "玩家攻击") ---
    PLAYER_DAMAGE: 25,
    ATTACK_COOLDOWN: 500,
    // ms, counted from the input instant, parallel to the phases
    ATTACK_RANGE: 40,
    // px centre-to-centre; must exceed ENEMY_ATTACK_RANGE (K2)
    ATTACK_HALF_ANGLE: 60,
    // deg -> a 120 deg forward sector
    ATTACK_WINDUP_MS: 100,
    // the player's side of the commitment
    ATTACK_ACTIVE_MS: 50,
    // ~3 frames; exists to tolerate frame jitter, not to widen the hit
    ATTACK_RECOVERY_MS: 70,
    ATTACK_SLOW_MS: 220,
    // derived: windup + active + recovery (asserted, not free)
    ATTACK_SELF_SLOW: 0.35,
    // move speed while swinging - the "cost" that lands on feel
    ATTACK_MIN_ANGLE_BYPASS: 16,
    // px within which the angle test is meaningless and skipped
    /** Key name in `Phaser.Input.Keyboard.KeyCodes`. Read by RiftScene, which owns input. */
    ATTACK_KEY: "SPACE",
    // --- infiltrator (section "敌人（渗透体）") ---
    ENEMY_MAX_HEALTH: 75,
    // = 3 x PLAYER_DAMAGE exactly (K1, DEC-012)
    ENEMY_DAMAGE_BASE: 15,
    ENEMY_ATTACK_RANGE: 38,
    // px; between AI.STANDOFF_DISTANCE and ATTACK_RANGE (K2)
    ENEMY_ATTACK_HALF_ANGLE: 60,
    // deg; symmetric with the player's
    ENEMY_ATTACK_WINDUP_MS: 350,
    // the player's dodge window - the whole of "controllable" (K3)
    ENEMY_ATTACK_COOLDOWN_MS: 1200,
    ENEMY_FIRST_ATTACK_DELAY_MS: 300,
    // "caught up with you" and "hit you" stay two events
    ENEMY_ATTACK_TOKENS: 2,
    // enemies allowed in windup at once; caps unavoidable damage
    ENEMY_HIT_FLASH_MS: 80,
    ENEMY_DEATH_FX_MS: 180,
    // presentation only; the enemy is gone from logic at 0 ms
    // --- player health and hits (section "玩家生命值与受击") ---
    PLAYER_IFRAME_MS: 400,
    // stops two enemies resolving on one frame for 30 damage
    PLAYER_HIT_FLASH_MS: 100,
    // --- noise: the exposure half of the price (section "噪声") ---
    NOISE_SWING_RADIUS: 96,
    // px (3 tiles), 'suspicious' - a whiff is heard, not billed
    NOISE_HIT_RADIUS: 160,
    // px (5 tiles), 'alert' - the main reason a fight is loud
    NOISE_KILL_RADIUS: 192,
    // px (6 tiles), 'alert'
    /**
     * Placeholder presentation (spec V2). White is on loan here: it currently means
     * "player / extraction point" in art-direction 12, and using thin white lines and
     * flashes for combat actions is still awaiting art sign-off (spec escalate 1 and 2).
     * Treat these as stand-ins, not as the visual language.
     */
    FX_COLOR: 16777215,
    ATTACK_FAN_FX_MS: 60,
    // how long the swing outline stays up (spec V2)
    PLAYER_FLASH_PAD: 6,
    // px the hit flash overshoots the body; see report on white-on-white
    FX_POOL_SIZE: 12
    // preallocated flash/death sprites: 8 enemies + headroom
  },
  /**
   * Contamination lexicon (DEC-076). Morph tables stay in CSV.
   * These are system constants: core HP, chaos prices, draw retry, encounter timing.
   */
  CONTAMINATION: {
    CORE_MAX_HEALTH: 50,
    ADJACENT_STRIKE_DAMAGE: 15,
    ADJACENT_STRIKE_WINDUP_MS: 350,
    PAINT_STEP_CHAOS_REST: 2,
    PAINT_STEP_CHAOS_INFLATED: 4,
    VOLUME_CHAOS_PER_SEC: 1,
    VOLUME_SIGHT_MULT: 0.7,
    DRAW_RETRY_LIMIT: 12,
    ENCOUNTER_COOLDOWN_MS: 6e4,
    ENCOUNTER_GAP_MS: 2500,
    ENCOUNTER_HOLD_MS: 2500,
    VOLUME_DEPTH: 40,
    COLONY_NUCLEUS_COUNT_MIN: 2,
    COLONY_NUCLEUS_COUNT_MAX: 3,
    COLONY_NUCLEUS_MIN_TILE_GAP: 3
  },
  /** Audio */
  AUDIO: {
    MAX_SIMULTANEOUS_SFX: 8,
    DEFAULT_SFX_VOLUME: 0.7,
    DEFAULT_BGM_VOLUME: 0.4,
    DEFAULT_AMBIENT_VOLUME: 0.5
  },
  /** Tide system (docs/specs/system-growth-tide.md, section T) */
  TIDE: {
    TIDES: [
      { floor: 1, peak: 1.6, riseCycles: 3, crestCycles: 1, ebbCycles: 2, ebbTarget: 1.2 },
      { floor: 1.2, peak: 2, riseCycles: 4, crestCycles: 1, ebbCycles: 2, ebbTarget: 1.5 },
      { floor: 1.5, peak: 2.4, riseCycles: 4, crestCycles: 2, ebbCycles: 2, ebbTarget: 1.8 },
      { floor: 1.8, peak: 2.8, riseCycles: 4, crestCycles: 2, ebbCycles: 3, ebbTarget: 2 },
      { floor: 2, peak: 3, riseCycles: 5, crestCycles: Infinity, ebbCycles: 0, ebbTarget: 2 }
    ],
    CREST_CHARGE_COST: 3,
    // impact charge cost during Crest phase
    NORMAL_CHARGE_COST: 1,
    // impact charge cost during Rise/Ebb phases
    TRANSFORM_THRESHOLD: 3
    // charges needed to transform defense -> tool
  },
  // Growth / permanent upgrades (docs/specs/system-growth-tide.md, section G):
  // Definitions come from data/upgrades.csv; all step costs come from
  // data/growth-route.csv (including thickening). Both generate upgrade-data.ts
  // under the CSV source rule — no constants block here
  // by design; growth-system.ts reads UPGRADE_DATA directly.
  /** Contaminant system (docs/specs/system-growth-tide.md, section CN) */
  CONTAMINANT: {
    NODES_PER_MAP: 3,
    // contaminant pickup nodes per rift map
    RARITY_WEIGHTS: { common: 60, fine: 30, rare: 10 },
    DEFENSE_SLOTS: 1,
    // base slot; each growth_defense_slot level adds +1
    SORTIE_SLOTS: 3,
    // base slots (2 active + 1 passive); growth_sortie_slot adds +1 active
    MAX_DEFENSE_SLOTS: 4,
    // DEFENSE_SLOTS + max growth_defense_slot bonus (maxLevel 3)
    MAX_SORTIE_SLOTS: 4,
    // SORTIE_SLOTS + max growth_sortie_slot bonus (maxLevel 1)
    USES: { common: 5, fine: 3, rare: 2 },
    // uses remaining after transformation
    /** echo defense mechanic: "单件因此最多+2" — per-tool cap on echo bonus grants. */
    ECHO_MAX_TOOL_USE_BONUS: 2,
    /**
     * Hotkeys for the active sortie slots, in slot order. The passive slot (always the
     * last unlocked slot, see `contaminantSystem.getSortiePassiveSlotIndex()`) never gets
     * an entry here - it has no hotkey by design. G was picked for the 3rd slot
     * (growth_sortie_slot, Slice 5 T5) because it sits directly beside F on the keyboard,
     * the same "one key past the movement cluster" reach as Q/F already use, and every
     * other neighbour (E/R/T) is already taken by extraction/restart/nothing-reserved-but-
     * awkward. Single source of truth for both the RiftScene binding and any UI that needs
     * to render the real key label.
     */
    SORTIE_ACTIVE_KEYS: ["Q", "F", "G"]
  },
  /** Purification stability (docs/specs/system-growth-tide.md, section S) */
  STABILITY: {
    MAX: 100,
    GAIN_EXTRACT: 1,
    // successful extraction (calibrated: ~35 cycles to cap)
    GAIN_GROWTH: 1,
    // purchased an upgrade
    GAIN_CREST_SURVIVED: 3,
    // survived a full Crest with no module at zero
    GAIN_TIDE_ADVANCE: 5,
    // tide advanced to next number
    LOSS_MODULE_ZERO: -1
    // a module reached 0 hp
  },
  /**
   * Fine/Rare active+passive tool numbers not already carried by
   * `src/generated/contaminant-data.ts` (radius/duration/uses read straight from the CSV
   * at the point of use instead of being re-hardcoded here - see `docs/design-notes/
   * slice3-sortie-tools.md`). Everything below is either a multiplier/amount the CSV
   * description states in prose (`data/contaminants.csv`, `description_tool` column) or,
   * where flagged, a placeholder-tier number the CSV leaves unspecified (Slice 5 T1).
   */
  TOOLS: {
    /** compress: "半径2格内敌人移速-60%" */
    COMPRESS_SPEED_MULT: 0.4,
    /** resonate: "弹回3格并眩晕2秒" */
    RESONATE_KNOCKBACK_PX: 96,
    RESONATE_STUN_MS: 2e3,
    /** overwrite: "感知范围缩小50%" */
    OVERWRITE_PERCEPTION_MULT: 0.5,
    /** combust: "感知范围-50%"(烈焰遮蔽视线) */
    COMBUST_PERCEPTION_MULT: 0.5,
    /** combust: "每秒受到持续伤害" - CSV gives no amount; placeholder tuned so an enemy
     * that stays the full 8s duration dies (75 hp / 15 = 5 ticks), matching the tool's
     * rare-tier power level. Flagged for design confirmation (see delivery report). */
    COMBUST_DAMAGE_PER_TICK: 15,
    COMBUST_TICK_MS: 1e3,
    /** mirror: "被敌人接触后碎裂消失" - CSV gives no contact radius; placeholder tuned to
     * roughly one enemy body width. Flagged for design confirmation. */
    MIRROR_CONTACT_RADIUS: 20,
    /** abyss: "使用后5秒内混乱增速+50%" - a second timing value the CSV's single
     * `tool_duration_ms` column cannot carry (that field holds the 10s reveal instead). */
    ABYSS_CHAOS_BOOST_MULT: 1.5,
    ABYSS_CHAOS_BOOST_MS: 5e3,
    /** siphon: "吸取2点薪柴且...混乱值增速减半" */
    SIPHON_KINDLING_GAIN: 2,
    SIPHON_CHAOS_REDUCTION_MULT: 0.5
  },
  /** Persistent save (docs/specs/system-growth-tide.md, section P) */
  SAVE: {
    KEY: "coh-save-v1",
    VERSION: 2
  }
};

// src/generation/world-study/native-volume-erosion.ts
var FRAGMENT_TERRAIN_BUDGET = Object.freeze({ minPolygons: 0, maxPolygons: 128, maxPoints: 2048, maxTotalPoints: 8192 });

// src/generation/world-study/native-terrain.ts
var HALF_BODY = GAME_CONSTANTS.PLAYER.BODY_SIZE / 2;

// src/generation/world-study/native-spatial-geometry.ts
function nativePrimitive(points, objectId) {
  const xs = points.filter((_, index) => index % 2 === 0), ys = points.filter((_, index) => index % 2 === 1);
  return { points, objectId, minX: Math.min(...xs), minY: Math.min(...ys), maxX: Math.max(...xs), maxY: Math.max(...ys) };
}
function nativePrimitiveTree(items) {
  const bounds = { minX: Infinity, minY: Infinity, maxX: -Infinity, maxY: -Infinity };
  for (const item of items) {
    bounds.minX = Math.min(bounds.minX, item.minX);
    bounds.minY = Math.min(bounds.minY, item.minY);
    bounds.maxX = Math.max(bounds.maxX, item.maxX);
    bounds.maxY = Math.max(bounds.maxY, item.maxY);
  }
  if (items.length <= 8) return { ...bounds, items };
  const horizontal = bounds.maxX - bounds.minX >= bounds.maxY - bounds.minY;
  const sorted = [...items].sort((a, b) => horizontal ? a.minX + a.maxX - b.minX - b.maxX : a.minY + a.maxY - b.minY - b.maxY);
  const middle = Math.floor(sorted.length / 2);
  return { ...bounds, left: nativePrimitiveTree(sorted.slice(0, middle)), right: nativePrimitiveTree(sorted.slice(middle)) };
}
function segmentDistanceSq(x, y, ax, ay, bx, by) {
  const dx = bx - ax, dy = by - ay, size = dx * dx + dy * dy;
  const t = size === 0 ? 0 : Math.max(0, Math.min(1, ((x - ax) * dx + (y - ay) * dy) / size));
  return (x - ax - t * dx) ** 2 + (y - ay - t * dy) ** 2;
}
function distanceSq(x, y, p) {
  const a = p.points;
  if (a.length === 4) return segmentDistanceSq(x, y, a[0], a[1], a[2], a[3]);
  const e0 = (a[2] - a[0]) * (y - a[1]) - (a[3] - a[1]) * (x - a[0]);
  const e1 = (a[4] - a[2]) * (y - a[3]) - (a[5] - a[3]) * (x - a[2]);
  const e2 = (a[0] - a[4]) * (y - a[5]) - (a[1] - a[5]) * (x - a[4]);
  if (e0 >= 0 && e1 >= 0 && e2 >= 0 || e0 <= 0 && e1 <= 0 && e2 <= 0) return 0;
  return Math.min(segmentDistanceSq(x, y, a[0], a[1], a[2], a[3]), segmentDistanceSq(x, y, a[2], a[3], a[4], a[5]), segmentDistanceSq(x, y, a[4], a[5], a[0], a[1]));
}
function boundsDistanceSq(x, y, p) {
  return Math.max(p.minX - x, 0, x - p.maxX) ** 2 + Math.max(p.minY - y, 0, y - p.maxY) ** 2;
}
function nativePrimitiveDistance(root, x, y) {
  return Math.sqrt(visitPrimitiveDistance(root, x, y, Infinity));
}
function visitPrimitiveDistance(node, x, y, best) {
  if (boundsDistanceSq(x, y, node) >= best) return best;
  if (node.items) {
    for (const item of node.items) best = Math.min(best, distanceSq(x, y, item));
    return best;
  }
  const left = node.left, right = node.right;
  if (boundsDistanceSq(x, y, left) <= boundsDistanceSq(x, y, right)) {
    best = visitPrimitiveDistance(left, x, y, best);
    return visitPrimitiveDistance(right, x, y, best);
  }
  best = visitPrimitiveDistance(right, x, y, best);
  return visitPrimitiveDistance(left, x, y, best);
}

// src/generation/world-study/fragment-shape/types.ts
var FRAGMENT_SHAPE_LIMITS = Object.freeze({
  maxRectangles: 128,
  maxGridCells: 65536,
  maxFrameDimension: 16384,
  maxSourceVertices: 2048,
  maxOutputVertices: 8192
});

// src/generation/world-study/native-spatial-bay-layout.ts
var inside = (rects, x, y) => rects.some((r) => x >= r[0] && y >= r[1] && x <= r[0] + r[2] && y <= r[1] + r[3]);
function createNativeSpatialPlanningGround(land, cuts) {
  const all = [...land, ...cuts], xs = [...new Set(all.flatMap((r) => [r[0], r[0] + r[2]]))].sort((a, b) => a - b), ys = [...new Set(all.flatMap((r) => [r[1], r[1] + r[3]]))].sort((a, b) => a - b), segments = [];
  const contains = (p) => inside(land, p.x, p.y) && !inside(cuts, p.x, p.y);
  const present = (x, y) => x >= 0 && y >= 0 && x < xs.length - 1 && y < ys.length - 1 && contains({ x: (xs[x] + xs[x + 1]) / 2, y: (ys[y] + ys[y + 1]) / 2 });
  for (let y = 0; y < ys.length - 1; y++) for (let x = 0; x < xs.length - 1; x++) if (present(x, y)) {
    const l = xs[x], r = xs[x + 1], t = ys[y], b = ys[y + 1];
    if (!present(x - 1, y)) segments.push(nativePrimitive([l, t, l, b], -1));
    if (!present(x + 1, y)) segments.push(nativePrimitive([r, t, r, b], -1));
    if (!present(x, y - 1)) segments.push(nativePrimitive([l, t, r, t], -1));
    if (!present(x, y + 1)) segments.push(nativePrimitive([l, b, r, b], -1));
  }
  const tree = nativePrimitiveTree(segments);
  const supportsFootprint = (primitives, offset) => primitives.every((triangle) => {
    const p = triangle.points;
    if (p.length !== 6) throw new Error("Planning support expects projected triangles");
    for (let i = 0; i < 6; i += 2) if (!contains({ x: p[i] + offset.x, y: p[i + 1] + offset.y })) return false;
    const orientation = Math.sign((p[2] - p[0]) * (p[5] - p[1]) - (p[3] - p[1]) * (p[4] - p[0]));
    if (!orientation) return true;
    for (const edge of segments) {
      if (edge.maxX <= triangle.minX + offset.x || edge.minX >= triangle.maxX + offset.x || edge.maxY <= triangle.minY + offset.y || edge.minY >= triangle.maxY + offset.y) continue;
      const ax = edge.points[0] - offset.x, ay = edge.points[1] - offset.y, bx = edge.points[2] - offset.x, by = edge.points[3] - offset.y;
      let lo = 0, hi = 1;
      for (let i = 0; i < 6 && lo < hi; i += 2) {
        const j = (i + 2) % 6, dx = p[j] - p[i], dy = p[j + 1] - p[i + 1], start = orientation * (dx * (ay - p[i + 1]) - dy * (ax - p[i])), slope = orientation * (dx * (by - ay) - dy * (bx - ax));
        if (Math.abs(slope) < 1e-9) {
          if (start <= 1e-7) {
            lo = 1;
            hi = 0;
          }
        } else if (slope > 0) lo = Math.max(lo, (1e-7 - start) / slope);
        else hi = Math.min(hi, (1e-7 - start) / slope);
      }
      if (lo < hi) return false;
    }
    return true;
  });
  return { contains, margin: (p) => contains(p) ? nativePrimitiveDistance(tree, p.x, p.y) : -1, supportsFootprint };
}

// src/generation/world-study/native-spatial-joint-refinement.ts
function worldPrimitives(primitives, site) {
  return primitives.map((p) => nativePrimitive(p.points.map((value, index) => value + (index % 2 ? site.y : site.x)), p.objectId));
}
function overlaps(a, b) {
  for (const p of [a, b]) for (let i = 0; i < p.points.length; i += 2) {
    const next = (i + 2) % p.points.length, nx = p.points[i + 1] - p.points[next + 1], ny = p.points[next] - p.points[i];
    let amin = Infinity, amax = -Infinity, bmin = Infinity, bmax = -Infinity;
    for (let j = 0; j < a.points.length; j += 2) {
      const value = a.points[j] * nx + a.points[j + 1] * ny;
      amin = Math.min(amin, value);
      amax = Math.max(amax, value);
    }
    for (let j = 0; j < b.points.length; j += 2) {
      const value = b.points[j] * nx + b.points[j + 1] * ny;
      bmin = Math.min(bmin, value);
      bmax = Math.max(bmax, value);
    }
    if (amax < bmin || bmax < amin) return false;
  }
  return true;
}
function tooClose(a, b, radius) {
  for (const p of a) for (const q of b) {
    if (Math.hypot(Math.max(p.minX - q.maxX, q.minX - p.maxX, 0), Math.max(p.minY - q.maxY, q.minY - p.maxY, 0)) >= radius) continue;
    if (overlaps(p, q)) return true;
    const pt = { ...p, items: [p] }, qt = { ...q, items: [q] };
    for (let i = 0; i < p.points.length; i += 2) if (nativePrimitiveDistance(qt, p.points[i], p.points[i + 1]) < radius) return true;
    for (let i = 0; i < q.points.length; i += 2) if (nativePrimitiveDistance(pt, q.points[i], q.points[i + 1]) < radius) return true;
  }
  return false;
}
function supported(object, site, ground) {
  if (!Number.isFinite(site.x) || !Number.isFinite(site.y) || site.x % 8 !== 0 || site.y % 8 !== 0 || ground.margin(site) < 24) return false;
  for (const p of object.support) for (let i = 0; i < p.points.length; i += 2) if (ground.margin({ x: p.points[i] + site.x, y: p.points[i + 1] + site.y }) < 24) return false;
  return ground.supportsFootprint(object.support, site);
}
function conflict(a, as, b, bs, gap) {
  const ap = worldPrimitives(a.blocking, as), bp = worldPrimitives(b.blocking, bs);
  if (tooClose(ap, bp, gap)) return true;
  if (a.kind === "hole" && tooClose(ap, worldPrimitives(b.support, bs), 24)) return true;
  if (b.kind === "hole" && tooClose(bp, worldPrimitives(a.support, as), 24)) return true;
  return false;
}
function nativeSpatialPlacementRejections(objects, entries, ground, gapPx) {
  if (entries.length < 1 || entries.length > 2 || new Set(entries.map((e) => e.index)).size !== entries.length) return ["invalid-object-pair"];
  const sites = new Map(entries.map((e) => [e.index, e.site]));
  const reasons = [];
  for (const entry of entries) {
    const object = objects[entry.index];
    if (!object) {
      reasons.push("unknown-object");
      continue;
    }
    if (!supported(object, entry.site, ground)) reasons.push(`${object.id}:ground-support`);
    for (let j = 0; j < objects.length; j++) {
      if (j === entry.index) continue;
      const other = objects[j];
      if (conflict(object, entry.site, other, sites.get(j) ?? other.site, gapPx)) reasons.push(`${object.id}:${other.id}:${sites.has(j) ? "moved" : "fixed"}-conflict`);
    }
  }
  return reasons;
}

// src/utils/grid-raycast.ts
function createRayHit() {
  return { x: 0, y: 0, dist: 0, hit: false };
}
var losScratch = createRayHit();

// src/generation/world-study/native-spatial-routes.ts
function classifyNativeRouteHoleShare(holes, total, policy) {
  const { minRouteHoleShare: min, maxRouteHoleShare: max, holeToSolidRatio: ratio } = policy;
  if (!Number.isSafeInteger(holes) || !Number.isSafeInteger(total) || total <= 0 || holes < 0 || holes > total || !Number.isFinite(min) || !Number.isFinite(max) || min < 0 || min > max || max > 1 || !Number.isSafeInteger(ratio) || ratio <= 0 || !Number.isSafeInteger(ratio + 1) || !Number.isSafeInteger(ratio * total))
    throw new Error("Invalid native route hole-share count or frozen cycle");
  const share = holes / total, continuousAccepted = share >= min && share <= max, ideal = ratio * total / (ratio + 1);
  const phaseAccepted = holes >= Math.floor(ideal) && holes <= Math.ceil(ideal);
  return { accepted: continuousAccepted || phaseAccepted, continuousAccepted, phaseAccepted, basis: continuousAccepted ? "continuous-band" : phaseAccepted ? "periodic-phase" : "outside" };
}

// src/generation/world-study/native-spatial-route-layout.ts
var LIMIT = 48;
var snap = (value) => Math.round(value / 8) * 8;
function routeDistance(point, path) {
  let minimum = Infinity;
  for (let i = 0; i < path.length; i++) {
    const a = path[i], b = path[i + 1] ?? a, dx = b.x - a.x, dy = b.y - a.y, n = dx * dx + dy * dy, t = n ? Math.max(0, Math.min(1, ((point.x - a.x) * dx + (point.y - a.y) * dy) / n)) : 0;
    minimum = Math.min(minimum, Math.hypot(point.x - a.x - t * dx, point.y - a.y - t * dy));
  }
  return minimum;
}
function excessKind(witness, policy) {
  if (witness.kind === "window") return "solid";
  if (witness.kind !== "hole-share" || !witness.events.length) return;
  const n = witness.events.length, h = witness.events.filter((e) => e.kind === "hole").length;
  let nearest = -1, distance2 = Infinity;
  for (let k = 0; k <= n; k++) if (classifyNativeRouteHoleShare(k, n, policy).accepted && Math.abs(k - h) < distance2) {
    nearest = k;
    distance2 = Math.abs(k - h);
  }
  return nearest < 0 || nearest === h ? void 0 : h > nearest ? "hole" : "solid";
}
function shareDeficit(holes, count, policy) {
  let distance2 = Infinity;
  for (let k = 0; k <= count; k++) if (classifyNativeRouteHoleShare(k, count, policy).accepted) distance2 = Math.min(distance2, Math.abs(k - holes));
  return Number.isFinite(distance2) ? distance2 / Math.max(1, count) : 0;
}
function footprintSize(object) {
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const p of object.support) {
    minX = Math.min(minX, p.minX);
    minY = Math.min(minY, p.minY);
    maxX = Math.max(maxX, p.maxX);
    maxY = Math.max(maxY, p.maxY);
  }
  return [maxX - minX, maxY - minY];
}
function selectNativeSpatialRoutePlacement(context) {
  const { objects, ground, policy, feedback, checkpoint } = context, ordinal = feedback.refinementOrdinal;
  if (!Number.isSafeInteger(ordinal) || ordinal < 0) throw new Error("Invalid native route refinement ordinal");
  const budget = feedback.remainingTupleBudget;
  if (!Number.isSafeInteger(budget) || budget < 0 || budget > LIMIT) throw new Error("Invalid native route remaining tuple budget");
  if (feedback.gate.accepted || !feedback.comparable) throw new Error("Native route refinement requires a comparable rejected actual probe");
  const byId = new Map(objects.map((o, index) => [o.id, index]));
  if (byId.size !== objects.length) throw new Error("Native route objects require unique identities");
  const resolve = (ids, kind) => {
    const matches = [...new Set(ids.flatMap((id) => byId.has(id) ? [byId.get(id)] : []))];
    return matches.length === 1 && objects[matches[0]].kind === kind ? matches[0] : void 0;
  };
  const unavailable = [], raw = [];
  const trials = [], seen = new Set(feedback.seenTupleKeys ?? []);
  if (seen.size > LIMIT) throw new Error("Native route tuple history exceeds its bounded epoch");
  let nextOrdinal = ordinal, selected, selectedIndex = null, candidateCount = 0;
  const trace = () => ({ ordinal, nextOrdinal, consumedTuples: trials.length, seenTupleKeys: [...seen], candidateCount, legalCount: selected ? 1 : 0, exhausted: !selected, entries: selected?.entries ?? [], selectedIndex, trials, unavailable });
  try {
    const sorted = [...feedback.witnesses].sort((a, b) => a.routeId.localeCompare(b.routeId) || a.kind.localeCompare(b.kind));
    const orderedEvents = (events) => [...events].sort((a, b) => a.at - b.at || a.structureId.localeCompare(b.structureId));
    const eventObjects = (events, kind) => {
      const seen2 = /* @__PURE__ */ new Set();
      return orderedEvents(events).flatMap((event) => {
        if (event.kind !== kind) return [];
        const index = resolve(event.objectIds, kind);
        if (index === void 0 || seen2.has(index)) return [];
        seen2.add(index);
        return [{ index, event }];
      });
    };
    const propose = (w, at, cause, variant, sourceStructureIds, entries) => {
      raw.push({ routeId: w.routeId, witnessKind: w.kind, at, cause, variant, sourceStructureIds, objectIds: entries.map((e) => objects[e.index].id), entries });
    };
    for (const witness of sorted) {
      checkpoint();
      if (witness.kind === "hole-share" || witness.kind === "window") {
        const surplus = excessKind(witness, policy);
        if (!surplus) {
          unavailable.push({ routeId: witness.routeId, reason: "no-excess-type" });
          continue;
        }
        const missing = surplus === "hole" ? "solid" : "hole", primaries = eventObjects(witness.kind === "window" ? witness.windowEvents ?? [] : witness.events, surplus);
        if (!primaries.length) {
          unavailable.push({ routeId: witness.routeId, reason: "no-unique-excess-object" });
          continue;
        }
        const reverse = sorted.filter((w) => w.kind === "hole-share" && excessKind(w, policy) === missing).flatMap((w) => eventObjects(w.events, missing).map((entry) => ({ ...entry, witness: w })));
        const partners = objects.map((o, index) => ({ index, id: o.id, kind: o.kind })).filter((o) => o.kind === missing);
        for (const primary of primaries) for (const partner of partners) {
          const a = objects[primary.index], b = objects[partner.index], as = footprintSize(a), bs = footprintSize(b), reverseSources = reverse.filter((r) => r.index === partner.index);
          let correctionValue = 0;
          const scored = /* @__PURE__ */ new Set();
          for (const w of sorted) {
            if (w.kind === "narrow") continue;
            const events = w.kind === "window" ? w.windowEvents ?? [] : w.events, key = `${w.routeId}|${w.kind}|${events.map((e) => e.structureId).join(",")}`;
            if (scored.has(key) || !events.length) continue;
            scored.add(key);
            const h = events.filter((e) => e.kind === "hole").length;
            let delta = 0;
            for (const e of events) {
              const index = resolve(e.objectIds, e.kind);
              if (index === primary.index) delta += b.kind === "hole" ? 1 : -1;
              else if (index === partner.index) delta += a.kind === "hole" ? 1 : -1;
            }
            correctionValue += w.kind === "window" ? (Math.max(0, policy.minWindowHoles - h) - Math.max(0, policy.minWindowHoles - h - delta)) / policy.minWindowHoles : shareDeficit(h, events.length, policy) - shareDeficit(h + delta, events.length, policy);
          }
          const sources2 = (reverseSources.length ? reverseSources : [void 0]).map((r) => ({ routeId: witness.routeId, kind: witness.kind, primaryObjectId: a.id, primaryStructureId: primary.event.structureId, at: primary.event.at, partnerObjectId: b.id, ...r ? { reverseRouteId: r.witness.routeId, partnerStructureId: r.event.structureId } : {} }));
          raw.push({
            routeId: witness.routeId,
            witnessKind: witness.kind,
            at: primary.event.at,
            cause: "type-swap",
            variant: 0,
            sourceStructureIds: [primary.event.structureId],
            objectIds: [a.id, b.id],
            entries: [{ index: primary.index, site: { ...b.site } }, { index: partner.index, site: { ...a.site } }],
            swapRank: { correctionValue, reverseEvidenceCount: new Set(reverseSources.map((r) => r.witness.routeId)).size, footprintMismatch: Math.abs(as[0] - bs[0]) / Math.max(1, as[0], bs[0]) + Math.abs(as[1] - bs[1]) / Math.max(1, as[1], bs[1]), distance: Math.hypot(a.site.x - b.site.x, a.site.y - b.site.y) + routeDistance(b.site, witness.points), sources: sources2 }
          });
        }
        continue;
      }
      const section2 = [...witness.crossSections ?? []].filter((s) => s.closed && Number.isFinite(s.widthLowerPx) && s.widthLowerPx >= 0).sort((a, b) => a.widthLowerPx - b.widthLowerPx || a.at - b.at)[0];
      if (!section2) {
        unavailable.push({ routeId: witness.routeId, reason: "no-owned-closed-section" });
        continue;
      }
      const [left, right] = section2.hits, dx = right.point.x - left.point.x, dy = right.point.y - left.point.y, length = Math.hypot(dx, dy);
      if (length <= 1e-7) {
        unavailable.push({ routeId: witness.routeId, reason: "degenerate-section-normal" });
        continue;
      }
      const indices = section2.hits.map((hit) => hit.owner.kind === "exterior" ? void 0 : resolve(hit.owner.objectIds, hit.owner.kind)), amount = Math.ceil(Math.max(8, policy.narrowWidthPx - section2.widthLowerPx) / 8) * 8;
      if (section2.hits.some((hit, i) => hit.owner.kind !== "exterior" && indices[i] === void 0) || indices[0] !== void 0 && indices[0] === indices[1]) {
        unavailable.push({ routeId: witness.routeId, reason: "ambiguous-section-object" });
        continue;
      }
      const move = (index, sign, distance2) => ({ index, site: { x: snap(objects[index].site.x + sign * distance2 * dx / length), y: snap(objects[index].site.y + sign * distance2 * dy / length) } }), sources = section2.hits.flatMap((h) => h.owner.structureId ? [h.owner.structureId] : []);
      if (section2.hits.some((hit) => hit.owner.kind === "exterior")) {
        const side = indices[0] !== void 0 ? 0 : 1, index = indices[side];
        if (index === void 0 || objects[index].kind !== "hole") {
          unavailable.push({ routeId: witness.routeId, reason: "exterior-without-owned-hole" });
          continue;
        }
        for (let tier = 0; tier < 2; tier++) propose(witness, section2.at, "narrow-single", tier, sources, [move(index, side === 0 ? -1 : 1, amount + tier * 8)]);
      } else {
        const a = indices[0], b = indices[1];
        for (let tier = 0; tier < 2; tier++) {
          const distance2 = amount + tier * 8;
          propose(witness, section2.at, "narrow-single", tier * 3, sources, [move(a, -1, distance2)]);
          propose(witness, section2.at, "narrow-single", tier * 3 + 1, sources, [move(b, 1, distance2)]);
          propose(witness, section2.at, "narrow-pair", tier * 3 + 2, sources, [move(a, -1, distance2 / 2), move(b, 1, distance2 / 2)]);
        }
      }
    }
    raw.sort((a, b) => a.routeId.localeCompare(b.routeId) || a.at - b.at || a.objectIds.join("|").localeCompare(b.objectIds.join("|")) || a.variant - b.variant || a.cause.localeCompare(b.cause));
    const keyOf = (entries) => [...entries].sort((a, b) => a.index - b.index).map((e) => `${e.index}@${e.site.x},${e.site.y}`).join("|");
    const unique = /* @__PURE__ */ new Map();
    for (const candidate of raw) {
      const key = keyOf(candidate.entries), existing = unique.get(key);
      if (!existing) {
        unique.set(key, candidate);
        continue;
      }
      if (existing.swapRank && candidate.swapRank) {
        const sources = [...existing.swapRank.sources, ...candidate.swapRank.sources], sourceKeys = /* @__PURE__ */ new Set();
        unique.set(key, { ...existing, swapRank: { ...existing.swapRank, reverseEvidenceCount: Math.max(existing.swapRank.reverseEvidenceCount, candidate.swapRank.reverseEvidenceCount), distance: Math.min(existing.swapRank.distance, candidate.swapRank.distance), sources: sources.filter((source) => {
          const identity = JSON.stringify(source);
          if (sourceKeys.has(identity)) return false;
          sourceKeys.add(identity);
          return true;
        }) } });
      }
    }
    const stable = (a, b) => a.routeId.localeCompare(b.routeId) || a.at - b.at || a.objectIds.join("|").localeCompare(b.objectIds.join("|")) || a.variant - b.variant || a.cause.localeCompare(b.cause);
    const swaps = [...unique.values()].filter((c) => c.swapRank), narrow = [...unique.values()].filter((c) => !c.swapRank), uses = /* @__PURE__ */ new Map(), orderedSwaps = [];
    while (swaps.length && orderedSwaps.length < LIMIT) {
      checkpoint();
      const use = (c) => c.entries.map((e) => uses.get(e.index) ?? 0);
      swaps.sort((a, b) => Math.max(...use(a)) - Math.max(...use(b)) || use(a).reduce((s, n) => s + n, 0) - use(b).reduce((s, n) => s + n, 0) || b.swapRank.correctionValue - a.swapRank.correctionValue || b.swapRank.reverseEvidenceCount - a.swapRank.reverseEvidenceCount || a.swapRank.footprintMismatch - b.swapRank.footprintMismatch || a.swapRank.distance - b.swapRank.distance || stable(a, b));
      const chosen = swaps.shift();
      orderedSwaps.push(chosen);
      for (const e of chosen.entries) uses.set(e.index, (uses.get(e.index) ?? 0) + 1);
    }
    const domain = [];
    for (let i = 0; domain.length < LIMIT && (i < orderedSwaps.length || i < narrow.length); i++) {
      if (i < orderedSwaps.length) domain.push(orderedSwaps[i]);
      if (domain.length < LIMIT && i < narrow.length) domain.push(narrow[i]);
    }
    candidateCount = domain.length;
    const consider = (candidate) => {
      checkpoint();
      if (trials.length >= budget) return;
      const key = keyOf(candidate.entries);
      if (seen.has(key)) return;
      seen.add(key);
      const stationary = candidate.entries.every((e) => e.site.x === objects[e.index].site.x && e.site.y === objects[e.index].site.y);
      const index = trials.length;
      trials.push({ ...candidate, reasons: ["evaluation-incomplete"] });
      const reasons = stationary ? ["unchanged-complete-state"] : nativeSpatialPlacementRejections(objects, candidate.entries, ground, policy.wideRadiusPx * 1.5), trial = { ...candidate, reasons };
      trials[index] = trial;
      return trial;
    };
    for (let index = ordinal; index < domain.length && trials.length < budget; index++) {
      nextOrdinal = index + 1;
      const candidate = domain[index], trial = consider(candidate);
      if (!trial) continue;
      if (!trial.reasons.length) {
        selected = trial;
        selectedIndex = index;
        break;
      }
      if (trial.entries.length !== 1) continue;
      const first = trial.entries[0], primary = objects[first.index], blockers = objects.flatMap((o, i) => i !== first.index && trial.reasons.includes(`${primary.id}:${o.id}:fixed-conflict`) ? [i] : []);
      if (blockers.length !== 1 || trial.reasons.some((reason) => reason !== `${primary.id}:${objects[blockers[0]].id}:fixed-conflict`)) continue;
      const partner = blockers[0], other = objects[partner], delta = { x: first.site.x - primary.site.x, y: first.site.y - primary.site.y };
      const released = consider({ ...candidate, cause: "blocker-release", objectIds: [primary.id, other.id], entries: [first, { index: partner, site: { x: other.site.x + delta.x, y: other.site.y + delta.y } }] });
      if (released && !released.reasons.length) {
        selected = released;
        selectedIndex = index;
        break;
      }
    }
    return trace();
  } catch (error) {
    throw Object.assign(error instanceof Error ? error : new Error(String(error)), { routeRefinement: trace() });
  }
}

// src/generation/world-study/native-spatial-layout.ts
function meshPrimitives(instances, native, seed, includeRelief = false) {
  const result = [];
  for (const instance of instances) {
    if (instance.role !== "solid" && !includeRelief) continue;
    const { role: _role, groundEdgeWidth: _edge, ...source } = instance;
    const mesh = buildNativeVolume({ ...source, family: instance.family ?? native.family, blocking: instance.role === "solid" ? 1 : 0, seed: seed ^ Math.imul(instance.id, 104729) });
    for (let t = 0; t < mesh.triangleCount; t++) {
      const points = [];
      for (let c = 0; c < 3; c++) {
        const at = mesh.indices[t * 3 + c] * 3;
        points.push(mesh.positions[at], mesh.positions[at + 1]);
      }
      if (Math.abs((points[2] - points[0]) * (points[5] - points[1]) - (points[3] - points[1]) * (points[4] - points[0])) > 1e-7) result.push(nativePrimitive(points, instance.id));
    }
  }
  return result;
}
function rectPrimitives(rects, id) {
  return rects.flatMap(([x, y, w, h]) => [nativePrimitive([x, y, x + w, y, x + w, y + h], id), nativePrimitive([x, y, x + w, y + h, x, y + h], id)]);
}
function planningObject(source, native, seed) {
  const blocking = source.kind === "hole" ? rectPrimitives(source.rects, -1) : meshPrimitives(source.instances, native, seed);
  return { source, support: source.kind === "hole" ? blocking : meshPrimitives(source.instances, native, seed, true), blocking, g1Blocking: blocking };
}
export {
  createNativeSpatialPlanningGround,
  planningObject,
  selectNativeSpatialRoutePlacement
};
