/** Independent fixed-fixture QA. No full generation, no production mutations. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {buildNativeSpatialGeometry} from '../../../../src/generation/world-study/native-spatial-geometry.ts';
import {evaluateNativeSpatialFinalSupport} from '../../../../src/generation/world-study/native-spatial-final-support.ts';
import {identifyNativeSpatialStructures,evaluateNativeSpatialGeometry} from '../../../../src/generation/world-study/native-spatial-measure.ts';
import {NativeSpatialGeometryArchive,nativeSpatialGeometryFingerprint} from '../../../../src/generation/world-study/native-spatial-generation.ts';
import {NATIVE_SPATIAL_POLICY as policy} from '../../../../src/generated/r100-native-spatial.ts';
const output=process.argv[2];assert(output&&!fs.existsSync(output),'Supply a NEW report path');
const oldPath='docs/qa/artifacts/native-spatial-2026-10-14/static-final-support-counterexample.json',scriptPath='docs/qa/artifacts/native-spatial-2026-10-14/static-final-support-counterexample.mjs';
const sourceFiles=['src/generation/world-study/native-spatial-final-support.ts','src/generation/world-study/native-spatial-measure.ts','src/generation/world-study/native-spatial-generation.ts','src/generation/world-study/native-spatial-geometry.ts',oldPath,scriptPath];
const hashes=()=>Object.fromEntries(sourceFiles.map(f=>[f,createHash('sha256').update(fs.readFileSync(f)).digest('hex')])),sourceHashes=hashes(),old=JSON.parse(fs.readFileSync(oldPath,'utf8')),cases=[];
function test(id,fn){try{const result=fn();cases.push({id,passed:true,...result});}catch(error){cases.push({id,passed:false,error:String(error.stack??error)});}}
const geometry=buildNativeSpatialGeometry(old.definition,old.seed),assemblies=[{assemblyId:'counterexample-source',instanceIds:[13],maxSpanPx:512}],layout={candidate:0,assemblies,holes:[]};
test('unchanged-real-counterexample-is-rejected-by-integrated-ground-gate',()=>{
 const before=JSON.stringify(old.definition),groups=identifyNativeSpatialStructures(geometry,assemblies,policy),support=evaluateNativeSpatialFinalSupport(geometry),gate=evaluateNativeSpatialGeometry(geometry,groups,policy,{targetWalkAreaPx2:geometry.supportedCount*64});
 assert(!support.accepted);assert(!gate.accepted);assert(gate.reasons.includes('final-source-footprint-unsupported'));assert.equal(support.metrics.unsupportedSources[0].instanceId,13);assert.equal(support.metrics.unsupportedSources[0].role,'solid');assert.equal(JSON.stringify(old.definition),before);
 return{support,integratedReasons:gate.reasons};
});
test('same-source-on-intact-land-is-not-falsely-rejected',()=>{
 const terrainOutline=[{x:32,y:32},{x:992,y:32},{x:992,y:736},{x:32,y:736}],g=buildNativeSpatialGeometry({...old.definition,terrainOutline},old.seed),gate=evaluateNativeSpatialFinalSupport(g);
 assert(gate.accepted);assert.equal(gate.metrics.finalSourceSupportViolationCount,0);return{gate};
});
test('actual-relief-source-is-covered-by-same-final-support-gate',()=>{
 const g=buildNativeSpatialGeometry({...old.definition,instances:old.definition.instances.map(i=>({...i,role:'relief'}))},old.seed),gate=evaluateNativeSpatialFinalSupport(g);
 assert(!gate.accepted);assert.equal(gate.metrics.unsupportedSources[0].role,'relief');return{gate};
});
let fingerprintA,fingerprintB;
test('actual-geometry-fingerprint-does-not-use-candidate-number-or-gate-values',()=>{
 fingerprintA=nativeSpatialGeometryFingerprint(geometry,layout);
 const clone=nativeSpatialGeometryFingerprint(geometry,{...layout,candidate:99});assert.equal(clone.canonical,fingerprintA.canonical);assert.equal(clone.hash,fingerprintA.hash);
 const moved=buildNativeSpatialGeometry({...old.definition,instances:old.definition.instances.map(i=>({...i,x:i.x+8}))},old.seed);fingerprintB=nativeSpatialGeometryFingerprint(moved,layout);assert.notEqual(fingerprintA.canonical,fingerprintB.canonical);
 return{sameGeometryHash:fingerprintA.hash,movedSourceHash:fingerprintB.hash};
});
const baseMetrics={holes:10,solids:5,targetCount:15,minCount:12,maxCount:18,rejectedObjects:[],reachableBodySeats:1000,supportedBodySeats:1000,walkAreaPx2:64000,targetWalkAreaPx2:64000,maxEmptyUpperPx:180,maxDeepSpanPx:440,wideRatio:.55,largestWideRatio:.9,holeProfileViolationCount:0,finalSourceSupportViolationCount:0};
const gate=(changes={})=>({accepted:false,reasons:['fixture-real-state-transition-only'],metrics:{...baseMetrics,...changes}});
const plan=(candidate)=>({...layout,candidate,requestedCounts:{holes:10,solids:5}});
test('persistent-exhaustion-moves-to-other-base-and-cannot-be-revived-by-new-id',()=>{
 const archive=new NativeSpatialGeometryArchive(policy),a=plan(1),b=plan(2),ga=gate(),gb=gate({maxEmptyUpperPx:172,wideRatio:.52});archive.offer(a,ga,fingerprintA);archive.offer(b,gb,fingerprintB);
 const first=archive.nextBase;assert.strictEqual(first.layout,b);assert.strictEqual(first.gate,gb);assert.equal(first.fingerprint.canonical,fingerprintB.canonical);
 for(let i=0;i<4;i++)archive.recordRefinement(first,{layout:plan(20+i),gate:gb,fingerprint:fingerprintB});
 assert.strictEqual(archive.best.layout,b);const second=archive.nextBase;assert.strictEqual(second.layout,a);assert.strictEqual(second.gate,ga);
 for(let i=0;i<4;i++)archive.recordRefinement(second);
 assert.equal(archive.nextBase,undefined);archive.offer(plan(100),gb,fingerprintB);assert.equal(archive.nextBase,undefined);assert.equal(archive.firstCandidate(fingerprintB),2);
 assert(archive.baseHistory.every(s=>s.exhausted&&s.refinements===4&&s.stagnantRefinements===4));
 const beforeClear=archive.baseHistory;archive.clear();assert.equal(archive.nextBase,undefined);assert.deepEqual(archive.baseHistory,beforeClear);assert.equal(archive.firstCandidate(fingerprintB),undefined);
 return{history:beforeClear};
});
test('new-measured-improvement-resets-only-its-actual-parent',()=>{
 const archive=new NativeSpatialGeometryArchive(policy),ga=gate(),gb=gate({maxEmptyUpperPx:168});archive.offer(plan(1),ga,fingerprintA);const base=archive.nextBase;archive.recordRefinement(base);assert.equal(archive.baseHistory[0].stagnantRefinements,1);
 const b=plan(2);archive.offer(b,gb,fingerprintB);archive.recordRefinement(base,{layout:b,gate:gb,fingerprint:fingerprintB});assert.equal(archive.baseHistory[0].stagnantRefinements,0);assert.strictEqual(archive.nextBase.layout,b);assert.strictEqual(archive.nextBase.gate,gb);assert.equal(archive.nextBase.fingerprint.canonical,fingerprintB.canonical);
 return{history:archive.baseHistory,candidates:archive.candidateIds};
});
const sourceHashesAfter=hashes(),sourcesStable=JSON.stringify(sourceHashes)===JSON.stringify(sourceHashesAfter),report={status:cases.every(c=>c.passed)&&sourcesStable?'passed':'failed',createdAt:new Date().toISOString(),sourceHashes,sourceHashesAfter,sourcesStable,cases,scope:'Independent closure of final support P2 using original frozen fixture unchanged; three archive/fingerprint state contracts. No whole-map admission, no B gate qualification, no browser/Worker or capacity/FPS test.'};fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({status:report.status,sourcesStable,cases:cases.map(({id,passed})=>({id,passed}))}));if(report.status!=='passed')process.exitCode=1;
