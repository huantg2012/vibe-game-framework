/** One fixed, real-constructor geometry counterexample; no full world search. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {NATIVE_SPATIAL_POLICY as policy,NATIVE_SPATIAL_SUBORDINATE_PROFILES as profiles} from '../../../../src/generated/r100-native-spatial.ts';
import {buildNativeVolume} from '../../../../src/generation/world-study/native-volume-geometry.ts';
import {compileR100FragmentShape} from '../../../../src/generation/world-study/r100-fragment-shape.ts';
import {buildNativeSpatialGeometry} from '../../../../src/generation/world-study/native-spatial-geometry.ts';
import {identifyNativeSpatialStructures,evaluateNativeSpatialGeometry} from '../../../../src/generation/world-study/native-spatial-measure.ts';
const output=process.argv[2];assert(output&&!fs.existsSync(output),'Supply a NEW report path');
const sourceFiles=['src/generation/world-study/native-spatial-layout.ts','src/generation/world-study/native-spatial-measure.ts','src/generation/world-study/native-spatial-generation.ts','src/generation/world-study/native-terrain.ts','src/generation/world-study/r100-master-world.ts','src/generation/world-study/r100-production-map.ts'];
const hashes=()=>Object.fromEntries(sourceFiles.map(file=>[file,createHash('sha256').update(fs.readFileSync(file)).digest('hex')])),sourceHashes=hashes();
const recipe=JSON.parse(fs.readFileSync('docs/qa/artifacts/native-generation-2026-10-14/recovery/gel-rafts-medium-20261012.recipe.json','utf8'));
const seed=20261012,p=profiles.find(p=>p.id==='native-gel-peeled-front');assert(p);
const fragmentShape={algorithmVersion:'rectilinear-fragment-v1',layoutId:'static-final-support',sourceHash:policy.sourceHash,seedMode:'run-seed',seedSalt:0,edgeSeed:seed,layout:{worldScale:2,authoringFrame:[512,384],landRects:[[16,16,480,352]],voidRects:[]}};
const compiled=compileR100FragmentShape(fragmentShape,seed),source={id:13,role:'solid',family:p.family,constructionVersion:4,shapeProfile:p.shapeProfile,x:0,y:0,rotation:0,length:p.minLengthPx,width:p.minWidthPx,height:p.minHeightPx,thickness:p.thicknessPx,fold:p.fold,branches:p.branches,opening:p.opening,distortion:p.distortion};
const {role,...volume}=source,local=buildNativeVolume({...volume,blocking:1,seed:seed^Math.imul(source.id,104729)}),xs=[],ys=[];
for(let i=0;i<local.positions.length;i+=3){xs.push(local.positions[i]);ys.push(local.positions[i+1]);}
const instance={...source,x:56-Math.min(...xs),y:56-Math.min(...ys)};
const definition={...recipe.nativeDefinition,cols:32,rows:24,instances:[instance],erosion:compiled.erosion,terrainOutline:compiled.terrainOutline,fragmentShapeVersion:'rectilinear-fragment-v1',spawn_x:512,spawn_y:384,exit_x:900,exit_y:600,search_x:500,search_y:500,enemy_x:600,enemy_y:600};
const geometry=buildNativeSpatialGeometry(definition,seed),mesh=geometry.terrain.meshes[0],unsupported=[];let rawMinimumVertexMargin=Infinity;
for(let at=0;at<mesh.positions.length;at+=3){const x=mesh.positions[at],y=mesh.positions[at+1];rawMinimumVertexMargin=Math.min(rawMinimumVertexMargin,x-32,992-x,y-32,736-y);if(!geometry.terrain.matterAt(x,y))unsupported.push({x,y});}
const groups=identifyNativeSpatialStructures(geometry,[{assemblyId:'counterexample-source',instanceIds:[13],maxSpanPx:512}],policy);
const gate=evaluateNativeSpatialGeometry(geometry,groups,policy,{targetWalkAreaPx2:geometry.supportedCount*64});
assert(rawMinimumVertexMargin>=24);assert(unsupported.length>0);assert.equal(groups.rejected.length,0);assert.equal(groups.structures.filter(s=>s.kind==='solid').length,1);
const sourceHashesAfter=hashes(),sourcesStable=JSON.stringify(sourceHashes)===JSON.stringify(sourceHashesAfter);assert(sourcesStable);
const report={status:'confirmed-counterexample',createdAt:new Date().toISOString(),sourceHashes,sourceHashesAfter,sourcesStable,seed,fragmentShape,definition,rawMinimumVertexMargin,unsupportedVertexCount:unsupported.length,witness:unsupported[0],effectiveStructures:groups.structures.map(({boundary,cells,distance,...s})=>s),rejectedObjects:groups.rejected,otherGateRejections:gate.reasons,scope:'The actual fragment compiler, native volume constructor, terrain compiler and structure qualification accept unsupported solid footprint. This intentionally small fixture fails unrelated count/ratio/empty-region gates; it is NOT a full production false-admission or frequency claim.'};
fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({status:report.status,rawMinimumVertexMargin,unsupportedVertexCount:unsupported.length,effectiveSolidCount:groups.structures.filter(s=>s.kind==='solid').length,sourcesStable}));
